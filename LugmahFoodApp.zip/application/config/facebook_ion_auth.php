<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| Settings.
| -------------------------------------------------------------------------
*/
$config['app_id'] 		= '1594182457564164'; 		// Your app id
$config['app_secret'] 	= '0c7e49e8005e3c0ec0654f7caf2bfb99'; 		// Your app secret key
$config['scope'] 		= 'email'; 	// custom permissions check - http://developers.facebook.com/docs/reference/login/#permissions
$config['redirect_uri'] = 'http://www.lugmah.com/beta/main/fblogin'; 		// url to redirect back from facebook. If set to '', site_url('') will be used