<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['application_name'] = 'lugmah';
$config['googleplus']['client_id'] = '386824156868-dh49e897q12fmv4h71tngdrvjcc5bn7a.apps.googleusercontent.com';
$config['googleplus']['client_secret'] = 'a0fCL84QEwd9PRyHhWcbVwuT';
$config['googleplus']['redirect_uri'] = 'http://www.lugmah.com/beta/auth/loginplus';
$config['googleplus']['api_key'] = 'AIzaSyD1wM4dOnGtC8xaRHI_oNP673Cmeqfgbkk';
$config['googleplus']['scopes']           = array();


