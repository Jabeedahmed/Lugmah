<?php
if (!empty($restaurants)) {
    foreach ($restaurants as $rest_data) {
        ?>
<tr>
            <td class="col-sm-4 col-md-4">
                <div class="media">
                    <a class=" pull-left" href="<?= base_url() ?>restaurant/<?= $rest_data->slug; ?>"
                       style="margin-right: 10px;"> <img class="media-object"
                                                         src="<?= $rest_data->logo_url; ?>"
                                                         style="width: 80px; height: 80px;"> </a>

                    <div class="media-body">
                        <h4><a href="<?= base_url() ?>restaurant/<?= $rest_data->slug; ?>"
                               style="color:#FFC001;"><?= $rest_data->name; ?></a></h4>

                        <p class="media-heading">
                            <?= $rest_data->type; ?></p>

                        <div class="stars">
                            <?php
                            for ($i = 1; $i < 6; $i++) {
                                if ($i <= $rest_data->rating) {
                                    ?>
                                    <span class="glyphicon glyphicon-star"
                                          style="color:#FFC001;"></span>
                                <?php } else { ?>
                                    <span class="glyphicon glyphicon-star-empty"></span>
                                    <?php
                                }
                            }
                            ?>
                        </div>
                                            <span class="text-success est"><?= $rest_data->rating_count; ?>
                                                ratings</span>
                    </div>
                </div>
            </td>
            <td class="col-lg-2 " style="text-align: center;">
                                    <span class="text-success min">Min Delivery: <?= (float)$rest_data->min_order; ?>
                                        KD</span>

                <div class="col-lg-12 center">
                    <?php
                    if (isset($rest_data->payment_methods)) {
                        foreach ($rest_data->payment_methods as $methods) {
                            ?>

                            <img class="  " src="<?= $methods->image_url ?>"
                                 alt="<?= $methods->name ?>" style="width: 26px; height: 20px;">
                        <?php }
                    }
                    ?>
                </div>
            </td>
            <td class="col-sm-2 col-md-2 text-center ">
                <div class="col-lg-12"><strong><?= $rest_data->delivery_time; ?> Mins</strong>
                </div>
                <br>
                <span class="est">Delievery Time</span></td>
            <td class="col-sm-2 col-md-2 text-center ">
                <div class="col-lg-12"><a class="btn btn-simple margin-bottom"
                                          href="<?= base_url() ?>restaurant/<?= $rest_data->slug; ?>">Go
                        to Menu</a></div>
                <br>

                <div class="main_favorite" id="main-<?= $rest_data->id; ?>">
                    <?php if ($rest_data->bookmark_status == 'NO') { ?>

                        <a style="text-decoration: none;color: grey;"
                           class="glyphicon glyphicon-heart add_fvrt "
                           id="<?= $rest_data->id; ?>"><span
                                class="fav pushme2"> Add To Favorite</span> </a>

                    <?php } else { ?>
                        <a style="text-decoration: none;color: #FFC000;"
                           class="glyphicon glyphicon-heart add_fvrt "
                           id="<?= $rest_data->id; ?>"><span
                                class="fav pushme2"> Remove Favorite</span></a>

                    <?php } ?>
                </div>
                <span id="message-<?= $rest_data->id; ?>" style="display: none;font-weight: 600;">&#10004;</span>
            </td>
            <td class="col-sm-3 col-md-3" style="text-align:right;">
                <?php if ($rest_data->discount != 0) { ?>
                    <div class="discountlabel" style="margin-bottom:30px;">
                        <img class="media-object off" src="<?= base_url() ?>img/export.png">

                        <h3 class="discount"><?= $rest_data->discount + 0; ?>%</h3>
                    </div>
                <?php } else {
                } ?>
                <?php if ($rest_data->discount_type == 'flat'){ ?>
                    <span class="text-success est" style="margin-top:500px;">Flat <?= $rest_data->discount + 0; ?>% off</span><br>
                <?php }elseif ($rest_data->discount_type == 'voucher'){?>
                    <span class="text-success est">Use code: </span><strong><?= $rest_data->promotion_code; ?></strong>
                <?php } ?>
            </td>
        </tr>
        <?php
    }
} ?>