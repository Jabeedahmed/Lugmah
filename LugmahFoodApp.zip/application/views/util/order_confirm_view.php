<div class="checkout_main_outer">
    <?php
    if (!empty($restaurant)) {
        foreach ($restaurant as $rest_data) {
            ?>
            <div class="checkout-main" style="margin-top: 20px">
                <img class="checkout-img" src="<?= $rest_data->logo_url ?>"/>

                <p class="checkout-title raleway-font">
                    <a href="<?= base_url() ?>restaurant/<?= $rest_data->slug; ?>"><span
                            class="color-yellow font16 bold"><?= $rest_data->restaurant_name ?></span></a><br/>
                    <span class="color-grey font13">Open from 11:00 - 23:00</span>
                </p>
                <span class="font13 pull-right" style="margin-right: 20px;">Avg Delivery: <?= $rest_data->delivery_time ?> min</span>


            </div>
            <div class="checkout-item">
                <table class="checkout-table checkout_items">

                    <?php if(isset($rest_data->c_items)){ foreach ($rest_data->c_items as $items) { ?>

                        <tr class='check-out-items' style="border: none;">
                            <td width="50%">
                                                            <span
                                                                class="color-black oswald-font bold" style="margin-left: 10px;"><?php echo $items->item_name; ?>
                                                                <?php if(isset($items->attr_name)&& !empty($items->attr_name)){
                                                                    echo '('.$items->attr_name.')';
                                                                } ?></span>
                            </td>
                            <td width="25%" class=" txt-right">
                                <label class="checkout-label">Qty. <?= $items->item_quantity ?></label>
                            </td>
                            <td class="txt-right" width="25%">
                                                            <span class="color-yellow bold font16 pr20">
                                                                KD <?= number_format(($items->item_price+$items->attr_price)*$items->item_quantity,3); ?>
                                                            </span>
                            </td>

                        </tr>

                    <?php }} ?>

                    <tr style="line-height: 0.429 !important; margin-top: 25px;">
                        <?php if($rest_data->discount>0){?>
                        <td></td>

                        <td class="txt-right">
                                                        <span class="color-grey bold font14">
                                                            Discount
                                                        </span>
                        </td>
                        <td class="txt-right">
                                                        <span class="color-black bold font14 pr20 sub-total">
                                                            <?= (float)$rest_data->discount; ?> %
                                                        </span>
                        </td>
                        <?php }?>
                    </tr>
                    <tr style="background-color: #f2f2f2;border: none; line-height: 0.429 !important; margin-top: 25px;">
                        <td></td>

                        <td class="txt-right">
                                                        <span class="color-yellow bold font16">
                                                            RESTAURANT TOTAL
                                                        </span>
                        </td>
                        <td class="txt-right">
                                                        <span class="color-yellow bold font16 pr20 sub-total">
                                                            KD <?= number_format($rest_data->total_amount,3); ?>
                                                        </span>
                        </td>
                    </tr>
                </table>

            </div>
            <?php
        }
    }
    ?>
</div>