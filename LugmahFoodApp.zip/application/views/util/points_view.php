<div class="form-group">

    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
        <span class="help-block color-yellow  font16 bold">Redeem your credit</span>

        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 no-padding-left">
            <input name="points_used" type="text" <?php if (empty($user_points)) {
                echo "disabled";
            } else {
            } ?> placeholder="<?php if (!empty($user_points)) {
                echo $user_points;
            } else {
                echo '0';
            } ?> pts Available" class="form-control input-md points_used_val">
            <?php $used_points = $this->session->userdata('used_points');
            if (isset($used_points) && !empty($used_points)) { ?>
                <div class="col-lg-8"><span class="help-block ">Points Used: <?= $used_points ?></span></div>
                <div class="col-lg-4"><a class="btn btn-group-xs" id="remove_points">Remove</a></div>
            <?php } ?>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
            <a class="btn btn-simple" id="apply_points">APPLY</a>

        </div>

    </div>
</div>