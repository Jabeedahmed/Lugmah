<div class="outer_div">
    <?php if (isset($latest_order)) {
        $g_total = 0;
        foreach ($latest_order as $order) {
            $g_total = $g_total+ $order->total_amount;
            ?>
            <div class="order_detail_div">
                <label
                    class="checkout-label pull-right">Status: <?= $order->order_status; ?></label>

                <div class="checkout-main roborto mt40" style="border: none">
                    <img class="checkout-img" src="<?= $order->rest_logo; ?>"/>

                    <p class="checkout-title">
                        <a style="cursor: pointer;"><span
                                class="color-yellow font16 bold"><?= $order->rest_name; ?></span></a><br/>


                    <p style="padding-top: 25px;padding-left: 30px;">
                        <span class="">
                            <?php
                            for ($i = 1; $i < 6; $i++) {
                                if ($i < $order->rating) {
                                    ?>
                                    <a onclick="return false"
                                       class="glyphicon glyphicon-star color-yellow font12 nodec"></a>
                                <?php } else { ?>
                                    <a onclick="return false"
                                       class="glyphicon glyphicon-star color-grey font12 nodec"></a>
                                    <?php
                                }
                            }
                            ?>
                            <br/>

                        </span>
                        <span class="color-light-grey font12">
                            <?= $order->rating_count; ?> total Ratings
                        </span>
                    </p>
                </div>
                <div class="checkout-item mt20">
                    <table class="checkout-table">
                        <?php
                        if (!empty($order->items)) {
                            foreach ($order->items as $item_row) {
                                ?>
                                <tr>
                                    <td>
                                        <span
                                            class="color-black oswald-font bold"><?= $item_row->item_name; ?><?php if (isset($item_row->attr_name) && !empty($item_row->attr_name)) {
                                                echo ' (' . $item_row->attr_name . ')';
                                            } ?></span>
                                    </td>
                                    <td>
                                        <label
                                            class="checkout-label"><?= $item_row->item_quantity; ?></label>
                                    </td>
                                    <td class="txt-right">
                                        <span class="color-yellow bold font16 pr20">
                                            KD <?= number_format((float)($item_row->item_quantity * ($item_row->item_price + $item_row->attr_price)), 3,'.',''); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                    </table>
                    <div class="col-lg-12 roborto font16 no-padding-left"
                         style="padding: 0 16px 0 0;">
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 no-padding-right no-padding-right history-into">

                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 history-into">

                        </div>
                        <div
                            class="col-lg-4 col-md-4 col-sm-12 col-xs-12 pt10 no-padding-right">
                            <table style="width: 100%">
                                <tr>
                                    <td class="color-light-grey"><p>Subtotal</p></td>
                                    <td class="color-yellow bold txt-right">
                                        KD <?= $order->subtotal; ?></td>
                                </tr>
                                <?php if (!empty($order->discount) && $order->discount > 0) { ?>
                                    <tr>
                                        <td class="color-light-grey"><p>Discount</p></td>
                                        <td class="color-yellow bold txt-right">
                                            KD <?= $order->discount; ?></td>
                                    </tr>
                                <?php } ?>
                                <tr>
                                    <td class="color-light-grey">
                                        Delivery Charges
                                    </td>
                                    <td class="color-yellow bold txt-right">
                                        KD <?= $order->delivery_charges; ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <table style="width:100%;">
                        <tr class="subtotal-head">
                            <td class="txt-right">
                                                                    <span class="color-yellow bold font16">
                                                                        Restaurant Total
                                                                    </span>
                            </td>
                            <td class="txt-right"
                                style="width:192px;padding: 15px 0;">
                                                                    <span class="color-yellow bold font16 pr15">
                                                                        KD <?= $order->total_amount; ?>
                                                                    </span>
                            </td>
                        </tr>
                    </table>

                </div>
            </div>
        <?php } ?>
        <div class="col-lg-12 roborto font16 no-padding-left mt20">
            <div
                class="col-lg-4 col-md-4 col-sm-12 col-xs-12 no-padding-right no-padding-right pt20 pb20 history-into">
                <p class="color-light-grey">
                    Lugmah Order No: <?= $latest_order[0]->order_id; ?><br/><br/>
                    Payment Method: <?= $latest_order[0]->payment_method;?>
                </p>
            </div>
            <div
                class="col-lg-4 col-md-4 col-sm-12 col-xs-12 pt20 pb20 history-into">
                <p class="color-light-grey">

                    Delivery Address:<br/>
                    <?= $latest_order[0]->delivery_address; ?>
                </p>
            </div>
            <div
                class="col-lg-4 col-md-4 col-sm-12 col-xs-12 pt20 pb20 no-padding-right">
                <p class="color-light-grey font22 txt-center">
                    Grand Total
                </p>

                <p class="color-yellow font30 txt-center">
                    KD <?= $g_total; ?>
                </p>
            </div>
        </div>

        <div class="pull-right mt30 raleway-font txt-right" style="display: inline;">
            <a class="btn3-grey round20 ml15 reorder_class" href="#" onclick="return false" id="<?= $order->order_id; ?>">RE ORDER </a>
        </div>
        <div class="clearfix"></div>
    <?php } else {
        echo 'No order found';
    }
    ?>
</div>