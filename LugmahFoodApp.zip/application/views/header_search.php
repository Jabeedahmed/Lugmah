
<style>
    .divider {
        background-color: white !important;
        height: 0px !important;
        margin: 0px 0 !important;
        overflow: hidden;
    }
    .dropdown-header{
        font-size: 17px !important;
    }
</style>

<div class="" id="home" style=" margin-bottom: 100px;">
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container menus">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand img-responsive" style="height: auto;padding-bottom: 13px" href="<?= base_url() ?>"><img src="<?= base_url() ?>img/lugmahlogo.png" style="height: 60px;"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse " id="bs-example-navbar-collapse-1" style="margin-top: 20px;">
                <ul class="nav navbar-nav navbar-right torq-menu">
                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <li><a href="<?= base_url() ?>main/my_account">My Account</a></li>
                    <?php } ?>
                    <li><a href="<?= base_url() ?>main/track_order">Track Order</a></li>
                    <li><a href="" class="customer_support" data-toggle="modal">Customer Support</a></li>
                    <?php if (sizeof($this->cart->contents()) == '0') { ?>
                        <li><a id="itemsss"  class="no-item cart_button_proceed" style="cursor: pointer;">
                                <div class="cart"><img class="cart_img" src="<?= base_url() ?>img/cart 5.png"><span
                                        class="cartnum"><?php echo sizeof($this->cart->contents()); ?></span></div>
                            </a></li>
                    <?php } else { ?>
                        <li><a class="cart_button_proceed" style="cursor: pointer;">
                                <div class="cart"><img class="cart_img" src="<?= base_url() ?>img/cart 5.png"><span
                                        class="cartnum"><?php echo sizeof($this->cart->contents()); ?></span></div>
                            </a></li>
                    <?php } ?>
                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <li><form action="<?= base_url() ?>main/logout" method="get"><button class=" btn btn-warning" >Logout</button></form></li>
                    <?php } else { ?>
                        <li><button class="btn btn-danger dan" data-toggle="modal" data-target="#myModal">Login</button></li>
                        <li> <form action="<?= base_url() ?>main/register" method="get"><button class=" btn btn-warning" >Register</button></form>
                    <?php } ?>
                </ul>
            </div><!-- /.navbar-collapse -->
            <div class="clearfix"></div>
           
        </div><!-- /.container-fluid -->
 <div class="col-md-11 col-lg-offset-1  search_fixed" >

     <form class="form-horizontal" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-lg-12">
                    <div class="col-md-3 center" style="padding-top: 15px;margin-left: 10px;">
<!--                        <label class="toggler toggler--is-active" id="filt-css">Restaurant</label>-->
<!--                        <div class="toggle">-->
<!--                            <input type="checkbox" id="switcher" name="catering" value="1"  class="check" style="display:block;">-->
<!--                            <b class="b switch"></b>-->
<!--                        </div>-->
<!--                        <label class="toggler" id="filt-javascript">Catering</label>-->
                    </div>
                    <div class="col-md-3" style="padding-right: 1px;padding-left: 1px;">
                        <div class="form-group">
                            <select name="cuisine[]" multiple title="Choose Your Cuisine" data-show-icon="true" id="cuisine_types" class="form-control selectpicker select_color cuisine_selected_val_area2"
                                    data-live-search="true">
                                <?php foreach ($cuisine_types as $cuisinesz) { ?>
                                    <?php print_r($cuisinesz)?>
                                    <option value="<?= $cuisinesz->id; ?>" <?php if($selected_cuisine == $cuisinesz->id ){echo "selected";}?>><?= $cuisinesz->name; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <?php if(empty($selected_area)){
                        $city_id = 0;
                    }else{
                        $city_id = $selected_area->city_id;
                    } ?>
                    <div class="col-md-3" style="padding-right: 1px;padding-left: 1px;">
                        <div class="form-group">
                            <select name="area"  id="city_area" data-show-icon="true" class="form-control selectpicker country_dropdown"  data-live-search="true">
                                <option value="" data-icon="glyphicon glyphicon-map-marker marker">Choose Your Area</option>
                                <?php if(!empty($capitals)){
                                    foreach($capitals as $capital){
                                        ?>
                                        <optgroup label="<?php echo ucwords($capital->capital_name);?>">
                                            <?php if(!empty($cities)){
                                                foreach($cities as $row){
                                                    if($row->capital_id == $capital->id ){
                                                        ?>
                                                        <option value="<?php echo $row->city_id; ?>"<?php if(isset($selected_area->city_id)){
                                                        if($selected_area->city_id == $row->city_id ){echo "selected";}
                                                        } ?>><?php echo $row->city_name; ?></option>
                                                    <?php }}} ?>
                                        </optgroup>
                                    <?php }} ?>
                            </select>
                        </div>
                        <span id="error1" style="color:yellow; margin-left: 30px;font-size: 16px;" ></span>
                    </div>
                    <div class="col-md-2" style="padding-left: 1px;">
                        <div class="form-group">
                            <input  class="btn btn-success search_area do_search" type="button"  role="button" value="Search" name="search_area">
                        </div>
                    </div>
                        </div>
                </div>
         </form>
            </div>
    </nav>

</div>
<!--head-top-->
<!--default-js-->
<script src="<?= base_url() ?>js/jquery-2.1.4.min.js"></script>

<?php if (!$this->ion_auth->logged_in()) {?>
    <!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <form name="" id="login" method="POST" action="<?= base_url('auth/login'); ?>" enctype="multipart/form-data" class="form-horizontal">
            <!-- Modal content-->
            <div class="col-lg-8 col-lg-offset-2">
                <div class="well">
                    <div class="con" >
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title" style="color:white;">Login</h4>
                        </div>
                        <div class="modal-body" style="     padding: 0px; ">
                            <div class="col-lg-12" style="margin-top:20px;">
                                <div class="form-group ">
                                    <input type="text" name="email" placeholder="Email" class="form-control">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group ">
                                    <input type="password" name="password" placeholder="Password" class="form-control">
                                </div>
                            </div>
                            <div class="">

                                <div class="col-lg-12 checkbox">
                                    <input id="remember" type="checkbox" value="1" name="remember"
                                           style="margin-right:5px">
                                    <label class="label-radio oswald-font bold font22" for="remember">Remember
                                        Password</label>
                                    <div class=" pull-right">
                                        <a href="<?= base_url('main/forget_password'); ?>">Forgot Password?</a>
                                    </div>
                                </div>

                                <div class="col-lg-12 " style="margin-bottom: 5px;">
                                    <p class="pull-right">
                                        <a class="btn btn-primary social-login-btn social-facebook" href="<?= base_url('auth/loginfacebook'); ?>"><i class="fa fa-facebook"></i></a>
                                        <!--                                                            <a class="btn btn-primary social-login-btn social-twitter" href="/auth/twitter"><i class="fa fa-twitter"></i></a>-->
                                        <a class="btn btn-primary social-login-btn social-google" href="<?php echo $login_url;?>"><i class="fa fa-google-plus"></i></a>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-simple lognow btn-block" type="submit">
                                Login Now
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php } ?>

<div class="modal fade" id="customer_support" tabindex="-2" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog">
        <div class="col-lg-8 col-lg-offset-2" style="margin-top: 150px;">
            <div class="con" >
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style="color:white; text-align: center;">Customer Support</h4>
                </div>
                <div class="modal-body" style=" text-align: center; ">
                        <div class="col-lg-12 center">
                            <span>+956 000 456 1234<br></span>
                        </div>
                        <div class="clearfix"></div>


                </div>
                <div class="modal-footer">
                    <button class="btn btn-simple lognow btn-block"
                            type="submit"  data-dismiss="modal">
                        Ok
                    </button>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
    $(window).scroll(function () {
        if ($(document).scrollTop() > 20) {
            $('.menus').hide('slow');
            

        } else {
           $('.menus').show('slow');

        }
    });
</script>

<script>
    $(".search_area").click(function () {
        if ($("#city_area").val() === "") {
            $('#error1').empty();
            document.getElementById("error1").innerHTML = "Please Choose Your Area";
            $('#error1').show();
            $('#error1').fadeOut(2000);
           return false;
        }else{
            var city_pick_id =  $("#city_area").val();

        }
    });
</script>