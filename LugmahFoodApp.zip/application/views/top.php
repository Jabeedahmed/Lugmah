<head>
    <link rel="shortcut icon" href="<?= base_url();?>/img/favicon.ico">
    <title>Lugmah</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="Food,Pizza, Restaurants"/>
    <?php if (isset($file_name)) {
        if ($file_name == 'thankyou') {
            ?>
            <!-- sample fb meta -->
            <meta property="og:title" content="Eating And Enjoying"/>
            <meta property="og:type" content="website"/>
            <?php
            if(!empty($restaurant)){
                foreach ($restaurant as $item) { ?>
                    <meta property="og:image" content="<?=$item->cover_image_url?>"/>
                <?php }}?>
            <meta property="og:url" content="http://www.lugmah.com/beta/main/thankyou?order_id=<?=$order_id?>"/>
            <meta property="og:description" content="<?= $og_description?>"/>

            <!-- sample twitter meta -->
            <meta name="twitter:card" content="summary_large_image">
            <meta name="twitter:site" content="@therealkni">
            <meta name="twitter:creator" content="@dbox">
            <meta name="twitter:title" content="Ridiculously Responsive Social Sharing Buttons">
            <meta name="twitter:description"
                  content="Ridiculously Responsive Social Sharing Buttons by @dbox and @joshuatuscan: http://dotsnpixelz.com/demo/lugma_new92/ | http://www.dotsnpixelz.com/demo/lugma_new92/admin_panel/uploads/restaurantimages/r4f2v.jpg">
            <meta name="twitter:image" content="http://www.lugmah.com/beta/admin_panel/uploads/restaurantimages/r4f2v.jpg">
        <?php }
    } ?>

    <link href='//fonts.googleapis.com/css?family=Viga' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?= base_url() ?>css/formValidation.css"/>
    <link href="<?= base_url() ?>css/owl.carousel.css" rel="stylesheet">
    <link href="<?= base_url() ?>css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="<?= base_url() ?>css/style.css" rel="stylesheet" type="text/css"/>
    <link href="<?= base_url() ?>css/bootstrap-select.min.css" rel="stylesheet" type="text/css"/>
    <link href="<?= base_url() ?>css/custom.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="<?= base_url() ?>css/toastr.css"/>
</head>