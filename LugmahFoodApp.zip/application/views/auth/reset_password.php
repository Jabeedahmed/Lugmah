<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="shortcut icon" href="<?= base_url();?>/img/favicon.ico">
    <title>Lugmah</title>
    <link href='//fonts.googleapis.com/css?family=Viga' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?= base_url() ?>css/formValidation.css"/>
    <link href="<?= base_url() ?>css/owl.carousel.css" rel="stylesheet">
    <link href="<?= base_url() ?>css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="<?= base_url() ?>css/style.css" rel="stylesheet" type="text/css"/>
    <link href="<?= base_url() ?>css/bootstrap-select.min.css" rel="stylesheet" type="text/css"/>
    <link href="<?= base_url() ?>css/custom.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="<?= base_url() ?>css/toastr.css"/>
</head>
<?php
if (!empty($header_banner->banner_url)) {
    $header_file = $header_banner->banner_url;
    ?>

    <style>
        .navbar-default {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(<?=$header_file; ?>) center !important;
            background-size: cover;
            border-bottom: 3px solid #FFC001;
            min-height: 80px;
        }
    </style>
<?php } else { ?>
    <style>
        .navbar-default {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(<?=base_url() ?>images/b2.jpg);
            background-size: cover;
            border-bottom: 3px solid #FFC001;
            min-height: 80px;
        }
    </style>
<?php } ?>
<body>


<div class="whole_div"
     style="width:100%;height:100%;display: none;position: fixed;z-index: 99999; background:url(<?= base_url() ?>img/loading.gif) no-repeat center center;"></div>
<style>
    .navbar-default .navbar-nav > li > a {
        color: white !important;
        font-size: 17px !important;
    }
    .dropdown-submenu {
        position: relative;
    }

    .dropdown-submenu>.dropdown-menu {
        top: 0;
        left: 100%;
        margin-top: -6px;
        margin-left: -1px;
        -webkit-border-radius: 0 6px 6px 6px;
        -moz-border-radius: 0 6px 6px;
        border-radius: 0 6px 6px 6px;
    }

    .dropdown-submenu:hover>.dropdown-menu {
        display: block;
    }

    .dropdown-submenu>a:after {
        display: block;
        content: " ";
        float: right;
        width: 0;
        height: 0;
        border-color: transparent;
        border-style: solid;
        border-width: 5px 0 5px 5px;
        border-left-color: #ccc;
        margin-top: 5px;
        margin-right: -10px;
    }

    .dropdown-submenu:hover>a:after {
        border-left-color: #fff;
    }

    .dropdown-submenu.pull-left {
        float: none;
    }

    .dropdown-submenu.pull-left>.dropdown-menu {
        left: -100%;
        margin-left: 10px;
        -webkit-border-radius: 6px 0 6px 6px;
        -moz-border-radius: 6px 0 6px 6px;
        border-radius: 6px 0 6px 6px;
    }
    }</style>

<div class="" id="home" style=" margin-bottom: 100px;">
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand img-responsive" style="height: auto;padding-bottom: 13px" href="<?= base_url() ?>"><img src="<?= base_url() ?>img/lugmahlogo.png" style="height: 60px;"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="margin-top: 20px;">
                <ul class="nav navbar-nav navbar-right torq-menu">
                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <li><a href="<?= base_url() ?>main/my_account">My Account</a></li>
                    <?php } ?>

                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <ul class="nav navbar-nav">
                            <li>
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Track Order<span class="caret "></span></a>
                                <ul class="dropdown-menu multi-level">
                                    <li><a href="<?= base_url() ?>main/track_order"><strong> Track Order</strong> </a></li>
                                    <li class="dropdown-submenu">
                                        <a href="#" tabindex="-1"><strong>Active Splits</strong></a>
                                        <ul class="dropdown-menu" style="width:250px; margin-top: 1px;">
                                            <?php
                                            if(!empty($split_payments)){
                                                foreach($split_payments as $split_row){ ?>
                                                    <li ><a href="<?=base_url() ?>main/split_payment_status?split_transaction_id=<?= urlencode($split_row->split_trans_id); ?>"><strong><?=ucfirst($split_row->name).'  '.$split_row->start_time; ?></strong></a></li>
                                                <?php } }else{ ?>
                                                <li><a><strong>No Active Split Availeble</strong></a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    <?php }else{ ?>
                        <li><a href="<?= base_url() ?>main/track_order">Track Order</a></li>
                    <?php } ?>
                    <li><a href="" class="customer_support" data-toggle="modal">Customer Support</a></li>
                    <?php if(sizeof($this->cart->contents()) == '0') { ?>
                        <li><a id="itemsss"  class="no-item cart_button_proceed" style="cursor: pointer;">
                                <div class="cart "><img class="cart_img" src="<?= base_url() ?>img/cart 5.png"><span
                                        class="cartnum"><?php echo sizeof($this->cart->contents()); ?></span></div>
                            </a></li>
                    <?php } else { ?>
                        <li><a id="itemed" class="yesh cart_button_proceed" style="cursor: pointer;" >
                                <div class="cart"><img class="cart_img" src="<?= base_url() ?>img/cart 5.png"><span
                                        class="cartnum"><?php echo sizeof($this->cart->contents()); ?></span></div>
                            </a></li>
                    <?php } ?>



                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <li><form action="<?= base_url() ?>main/logout" method="get"><button class=" btn btn-warning" >Logout</button></form></li>
                    <?php } else { ?>
                    <li><button class="btn btn-danger dan" data-toggle="modal" data-target="#myModal">Login</button></li>
                    <li> <form action="<?= base_url() ?>main/register" method="get"><button class=" btn btn-warning" >Register</button></form>
                        <?php } ?>
                </ul>
            </div><!-- /.navbar-collapse -->
            <div class="clearfix"></div>
        </div><!-- /.container-fluid -->

    </nav>

</div>
<!--head-top-->
<!--default-js-->
<script src="<?= base_url() ?>js/jquery-2.1.4.min.js"></script>

<!-- Modal -->
<?php if (!$this->ion_auth->logged_in()) {?>
    <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <form name="" id="login" method="POST" action="<?= base_url('auth/login'); ?>" enctype="multipart/form-data" class="form-horizontal">
                <!-- Modal content-->
                <div class="col-lg-8 col-lg-offset-2">
                    <div class="well">
                        <div class="con" >
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title" style="color:white;">Login</h4>
                            </div>
                            <div class="modal-body" style="     padding: 0px; ">
                                <div class="col-lg-12" style="margin-top:20px;">
                                    <div class="form-group ">
                                        <input type="text" name="email" placeholder="Email" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group ">
                                        <input type="password" name="password" placeholder="Password" class="form-control">
                                    </div>
                                </div>
                                <div class="">

                                    <div class="col-lg-12 checkbox">
                                        <input id="remember" type="checkbox" value="1" name="remember"
                                               style="margin-right:5px">
                                        <label class="label-radio oswald-font bold font22" for="remember">Remember
                                            Password</label>
                                        <div class=" pull-right">
                                            <a href="<?= base_url('main/forget_password'); ?>">Forgot Password?</a>
                                        </div>
                                    </div>

                                    <div class="col-lg-12 " style="margin-bottom: 5px;">
                                        <p class="pull-right">
                                            <a class="btn btn-primary social-login-btn social-facebook" href="<?= base_url('auth/loginfacebook'); ?>"><i class="fa fa-facebook"></i></a>
                                            <!--                                                            <a class="btn btn-primary social-login-btn social-twitter" href="/auth/twitter"><i class="fa fa-twitter"></i></a>-->
                                            <a class="btn btn-primary social-login-btn social-google" href="<?php echo $login_url;?>"><i class="fa fa-google-plus"></i></a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-simple lognow btn-block" type="submit">
                                    Login Now
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php }?>

<div class="modal fade" id="customer_support" tabindex="-2" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog">
        <div class="col-lg-8 col-lg-offset-2" style="margin-top: 150px;">
            <div class="con" >
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style="color:white;  text-align: center;">Customer Support</h4>
                </div>
                <div class="modal-body" style=" text-align: center; ">
                    <div class="col-lg-12 center">
                        <span>+956 000 456 1234<br></span>
                    </div>
                    <div class="clearfix"></div>


                </div>
                <div class="modal-footer">
                    <button class="btn btn-simple lognow btn-block"
                            type="submit"  data-dismiss="modal">
                        Ok
                    </button>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div id="pg-content" class="row">

                    <h1><?php echo lang('reset_password_heading'); ?></h1>

                    <div id="infoMessage"><?php echo $message; ?></div>

                    <?php echo form_open('auth/reset_password/' . $code); ?>

                    <p>
                        <label for="new_password"><?php echo sprintf(lang('reset_password_new_password_label'), $min_password_length); ?></label> <br/>
                        <?php echo form_input($new_password); ?>
                    </p>

                    <p>
                        <?php echo lang('reset_password_new_password_confirm_label', 'new_password_confirm'); ?> <br/>
                        <?php echo form_input($new_password_confirm); ?>
                    </p>

                    <?php echo form_input($user_id); ?>
                    <?php echo form_hidden($csrf); ?>

                    <p><?php echo form_submit('submit', lang('reset_password_submit_btn')); ?></p>

                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="footer">
    <div class="container">
        <div class="div1 col-md-12">
            <div class="col-md-5 head">
                <h3>Payment Method</h3>
                <ul class="customer">
                    <?php if (!empty($payment_method_db)) {
                        foreach ($payment_method_db as $payment_method) {
                            ?>
                            <a style="cursor: pointer;"> <img style="height: 40px;width: 70px;float: left;" class="img-responsive"
                                                              src="<?= $payment_method->image_url; ?>"></a>
                        <?php }
                    } ?>

                </ul>
            </div>
            <div class="col-md-4 head">
                <h3>Contact Us</h3>
                <ul class="contents">
                    <p style="color:white" href="products.html">Plot No 447-44B General</p>

                    <p style="color:white;" href="typography.html">Stand Ravi Link Road Kuwait</p>
                </ul>
            </div>
            <div class="col-md-3 mail_soc">
                <div class="form_data">
                    <h3>Get In Touch With Us</h3>
                </div>
                <ul class="social-network social-circle">
                    <li><a href="<?= $settings->fb_link ?>" target="_blank" title="Facebook"><img class="img-responsive"
                                                                                                  src="<?= base_url() ?>img/facebook-256.png"></a></li>
                    <li><a href="<?= $settings->twitter_link ?>" target="_blank" title="Twitter"><img class=" img-responsive"
                                                                                                      src="<?= base_url() ?>img/twitter-256.png"></a></li>
                    <li><a href="<?= $settings->insta_link ?>" target="_blank" title="Instagram"><img class=" img-responsive "
                                                                                                      src="<?= base_url() ?>img/instagram-256.png"></a></li>
                    <li><a href="<?= $settings->youtube_link ?>" target="_blank" title="Youtube"><img class=" img-responsive "
                                                                                                      src="<?= base_url() ?>img/youtube-256.png"></a></li>
                </ul>

            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <a href="#home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover"
                                                                             style="opacity: 1;"> </span></a>
</div>
<div class="div2">
    <ul class="social-network">
        <li><a href="<?= base_url() ?>main/about_us">About Us</a></li>
        <li><a href="<?= base_url() ?>main/feedback">Contact Us</a></li>
        <li><a href="<?= base_url() ?>main/faq">FAQ</a></li>
        <li><a href="<?= base_url() ?>main/privacy_policy">Privacy</a></li>
    </ul>
    <p>Terms of Use Read our Privacy Policy @2015</p>
</div>
</body>
</html>
<script type="text/javascript" src="<?= base_url() ?>js/formValidation.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/framework/bootstrap.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/validation.js"></script>
<!--bootstrap-js-->
<script src="<?= base_url() ?>js/bootstrap.min.js"></script>
<!--script-->
<script type="text/javascript" src="<?= base_url() ?>js/move-top.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/easing.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/toastr.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/instafeed.min.js"></script>


<?php if ($this->session->flashdata('success') != ""): ?>

    <script type="text/javascript">
        $(document).ready(function () {
            toastr.success('<?php echo $this->session->flashdata("success"); ?>');
        });
    </script>
<?php endif; ?>
<?php if ($this->session->flashdata('error') != ""): ?>
    <script type="text/javascript">
        $(document).ready(function () {
            toastr.error('<?php echo $this->session->flashdata("error"); ?>');
        });
    </script>
<?php endif; ?>

<script type="text/javascript">
    $(document).ready(function () {
        $().UItoTop({easingType: 'easeOutQuart'});

    });

</script>
<script>
    $(document).ready(function () {
        $(".no-item").click(function () {
            $('#no-item').modal('show');
        });
        $(".promotions").click(function () {
            $('#promotions').modal('show');
        });

        $(".editpass").click(function () {
            $('#editpass').modal('show');
        });
        $(".editemail").click(function () {
            $('#editemail').modal('show');
        });

        $(".thankyou").click(function () {
            $('#thankyou').modal('show');
        });
        $(".customer_support").click(function () {
            $('#customer_support').modal('show');
        });

    });
</script>
<script>
    setTimeout(function () {
        $('.alert').fadeOut('fast');
    }, 5000);
    $(".close").click(function () {
        $(".alert").hide();
    });
</script>
<script src="<?php echo base_url() ?>js/owl.carousel.js"></script>
<script>

    $(document).ready(function () {
        $("#owl-demo2").owlCarousel({
            items: 1,
            lazyLoad: true,
            autoPlay: true,
            navigation: true,
            pagination: false,
            navigationText: [
                "<i class='glyphicon glyphicon-chevron-left'></i>",
                "<i class='glyphicon glyphicon-chevron-right'></i>"
            ],
        });
        $("#owl-demo1").owlCarousel({
            items: 3,
            lazyLoad: true,
            autoPlay: true,
            navigation: true,
            pagination: false,
            navigationText: [
                "<i class='glyphicon glyphicon-chevron-left'></i>",
                "<i class='glyphicon glyphicon-chevron-right'></i>"
            ],
        });
    });
</script>
<script>

    $(document).ready(function () {
        $("#owl-demo").owlCarousel({
            items: 4,
            lazyLoad: true,
            autoPlay: true,
            navigation: true,
            pagination: false,
            navigationText: [
                "<i class='glyphicon glyphicon-chevron-left'></i>",
                "<i class='glyphicon glyphicon-chevron-right'></i>"
            ],
        });
    });
</script>

<script>
    $( document ).ready(function() {
        $(document).ajaxStart(function() {
            $(".whole_div").show();
        });

        $(document).ajaxStop(function() {
            $(".whole_div").hide();
        });
    });
</script>