<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" />
    <title>Lugmah Order Confirmation</title>
    <style type="text/css">
        .ReadMsgBody { width: 100%; background-color: #ffffff; }
        .ExternalClass { width: 100%; background-color: #ffffff; }
        .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div { line-height: 100%; }
        html { width: 100%; }
        body { -webkit-text-size-adjust: none; -ms-text-size-adjust: none; margin: 0; padding: 0; }
        table { border-spacing: 0; border-collapse: collapse; table-layout: fixed; margin: 0 auto; }
        table table table { table-layout: auto; }
        img { display: block !important; }
        table td { border-collapse: collapse; }
        .yshortcuts a { border-bottom: none !important; }
        a { color: #ffc001; text-decoration: none; }
        .textbutton a { font-family: 'open sans', arial, sans-serif !important; color: #ffffff !important; }
        .text-link a { color: #3b3b3b !important; }
        @media only screen and (max-width: 640px) {
            body { width: auto !important; }
            table[class="table600"] { width: 450px !important; }
            table[class="table-inner"] { width: 90% !important; }
            table[class="table3-3"] { width: 100% !important; text-align: center !important; }
        }
        @media only screen and (max-width: 479px) {
            body { width: auto !important; }
            table[class="table600"] { width: 290px !important; }
            table[class="table-inner"] { width: 82% !important; }
            table[class="table3-3"] { width: 100% !important; text-align: center !important; }
        }
    </style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#494c50">
    <tr>
        <td align="center" background="http://lugmah.com/beta/images/b2.jpg" style="background-size:cover; background-position:top;">
            <table class="table600" width="600" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                    <td height="60"></td>
                </tr>
                <tr>
                    <td align="center">
                        <table style="border-top:3px solid #ffc001; border-radius:4px;box-shadow: 0px 3px 0px #bdc3c7;" bgcolor="#FFFFFF" width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                                <td align="center">
                                    <table width="550" align="center" class="table-inner" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td height="15"></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <table class="table3-3" width="196" border="0" align="left" cellpadding="0" cellspacing="0">
                                                    <tr>
                                                        <td align="center" style="line-height:0px;">
                                                            <img style="display:block; line-height:0px; font-size:0px; border:0px;" src="http://lugmah.com/beta/img/logo-black.png" width="196" height="64" alt="logo" />
                                                        </td>
                                                    </tr>
                                                </table>
                                                <table width="1" height="15" border="0" cellpadding="0" cellspacing="0" align="left">
                                                    <tr>
                                                        <td height="15" style="font-size: 0;line-height: 0;border-collapse: collapse;">
                                                            <p style="padding-left: 24px;">&nbsp;</p>
                                                        </td>
                                                    </tr>
                                                </table>
                                                <table align="right" class="table3-3" width="160" border="0" cellspacing="0" cellpadding="0">
                                                    <tr>
                                                        <td align="center" style="font-family: 'Open Sans', Arial, sans-serif; font-size:13px; color:#7f8c8d; line-height:30px;">
                                                            <span style="font-weight: bold; color:#ffc001;">Lugmah Order Number</span>
                                                            <?=$order_id?>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="15"></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="25"></td>
                </tr>
                <tr>
                    <td align="center">
                        <table align="center" bgcolor="#FFFFFF" style="box-shadow: 0px 3px 0px #bdc3c7; border-radius:4px;" width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td align="center">
                                    <table align="center" class="table-inner" width="500" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td height="50"></td>
                                        </tr>
                                        <tr>
                                            <td align="center" style="font-family: 'Open Sans', Arial, sans-serif; font-size:30px; color:#3b3b3b; font-weight: bold; ">Your Order has been placed</td>
                                        </tr>
                                        <tr>
                                            <td align="center">
                                                <table width="25" border="0" cellspacing="0" cellpadding="0">
                                                    <tr>
                                                        <td height="20" style="border-bottom:2px solid #91c444;"></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="20"></td>
                                        </tr>
                                        <tr>
                                            <td align="center" style="font-family: 'Open Sans', Arial, sans-serif; font-size:13px; color:#7f8c8d; line-height:30px;">
                                                Thank you for ordering with Lugmah.<br>Your order has been placed and will be delivered to you as soon possible.<br>
                                                You can check your order details by clicking on the link bellow.
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td height="40"></td>
                            </tr>
                            <tr>
                                <td align="center" bgcolor="#ecf0f1">
                                    <table align="center" class="table-inner" width="550" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td height="30"></td>
                                        </tr>
                                        <tr>
                                            <td align="center">
                                                <table class="textbutton" align="center" bgcolor="#ffc001" border="0" cellspacing="0" cellpadding="0" style=" border-radius:30px; box-shadow: 0px 2px 0px #dedfdf;">
                                                    <tr>
                                                        <td height="55" align="center" style="font-family: 'Open Sans', Arial, sans-serif; font-size:16px; color:#7f8c8d; line-height:30px; font-weight: bold;padding-left: 25px;padding-right: 25px;">
                                                            <a href="http://www.lugmah.com/beta/main/thankyou?order_id=<?=$order_id?>">View your Order</a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="30"></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="25"></td>
                </tr>
                <tr>
                    <td>
                        <table bgcolor="#ecf0f1" style="box-shadow: 0px 3px 0px #bdc3c7; border-radius:4px;" class="table3-3" align="left" width="183" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td class="text-link" height="50" align="center" style="font-family: 'Open Sans', Arial, sans-serif; font-size:14px; color:#3b3b3b; line-height:30px;padding-left: 20px;padding-right: 20px;">
                                    <a href="http://www.lugmah.com/beta/main/faq">Need Help?</a>
                                </td>
                            </tr>
                        </table>
                        <table width="1" height="25" border="0" cellpadding="0" cellspacing="0" align="left">
                            <tr>
                                <td height="25" style="font-size: 0;line-height: 0;border-collapse: collapse;">
                                    <p style="padding-left: 24px;">&nbsp;</p>
                                </td>
                            </tr>
                        </table>
                        <table bgcolor="#ecf0f1" style="box-shadow: 0px 3px 0px #bdc3c7; border-radius:4px;" class="table3-3" align="left" width="183" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td class="text-link" height="50" align="center" style="font-family: 'Open Sans', Arial, sans-serif; font-size:14px; color:#3b3b3b; line-height:30px;padding-left: 20px;padding-right: 20px;">
                                    <a href="http://www.lugmah.com/beta/main/feedback">Contact us</a>
                                </td>
                            </tr>
                        </table>
                        <table width="1" height="25" border="0" cellpadding="0" cellspacing="0" align="left">
                            <tr>
                                <td height="25" style="font-size: 0;line-height: 0;border-collapse: collapse;">
                                    <p style="padding-left: 24px;">&nbsp;</p>
                                </td>
                            </tr>
                        </table>
                        <table bgcolor="#ecf0f1" style="box-shadow: 0px 3px 0px #bdc3c7; border-radius:4px;" class="table3-3" align="right" width="183" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td class="text-link" height="50" align="center" style="font-family: 'Open Sans', Arial, sans-serif; font-size:14px; color:#3b3b3b; line-height:30px;padding-left: 20px;padding-right: 20px;">
                                    <a href="http://www.lugmah.com/beta/main/about_us">About us</a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="20"></td>
                </tr>
                <tr>
                    <td>
                        <table align="left" class="table3-3" width="390" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td style="font-family: 'Open Sans', Arial, sans-serif; font-size:12px; color:#ffffff; line-height:30px;">
                                    © 2017
                                    <a href="http://www.lugmah.com/beta">Lugmah</a>
                                    . All Rights Reserved.
                                </td>
                            </tr>
                        </table>
                        <table width="1" height="25" border="0" cellpadding="0" cellspacing="0" align="left">
                            <tr>
                                <td height="25" style="font-size: 0;line-height: 0;border-collapse: collapse;">
                                    <p style="padding-left: 24px;">&nbsp;</p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="60"></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>
</html>