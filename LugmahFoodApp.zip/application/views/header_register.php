<div class="" id="home" style=" margin-bottom: 100px;">
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand img-responsive" style="height: auto;padding-bottom: 13px" href="<?= base_url() ?>"><img src="<?= base_url() ?>img/lugmahlogo.png" style="height: 60px;"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="margin-top: 20px;">
                <ul class="nav navbar-nav navbar-right torq-menu">
                    <li><a href="<?= base_url() ?>main/track_order">Track Order</a></li>
                    <li><a href="" class="customer_support" data-toggle="modal">Customer Support</a></li>
                    <li><button class=" btn btn-danger dan" data-toggle="modal" data-target="#myModal">Login</button></li>


                </ul>
            </div><!-- /.navbar-collapse -->
            <div class="clearfix"></div>
        </div><!-- /.container-fluid -->

    </nav>

</div>
<!--head-top-->
<!--default-js-->
<script src="<?= base_url() ?>js/jquery-2.1.4.min.js"></script>


<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <form name="" id="login" method="POST" action="<?= base_url('auth/login'); ?>" enctype="multipart/form-data" class="form-horizontal">
            <!-- Modal content-->
            <div class="col-lg-8 col-lg-offset-2">
                <div class="well">
                    <div class="con" >
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title" style="color:white;">Login</h4>
                        </div>
                        <div class="modal-body" style="     padding: 0px; ">
                            <div class="col-lg-12" style="margin-top:20px;">
                                <div class="form-group ">
                                    <input type="text" name="email" placeholder="Email" class="form-control">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group ">
                                    <input type="password" name="password" placeholder="Password" class="form-control">
                                </div>
                            </div>
                            <div class="">

                                <div class="col-lg-12 checkbox">
                                    <input id="remember" type="checkbox" value="1" name="remember"
                                           style="margin-right:5px">
                                    <label class="label-radio oswald-font bold font22" for="remember">Remember
                                        Password</label>
                                    <div class=" pull-right">
                                        <a href="<?= base_url('main/forget_password'); ?>">Forgot Password?</a>
                                    </div>
                                </div>

                                <div class="col-lg-12 " style="margin-bottom: 5px;">
                                    <p class="pull-right">
                                        <a class="btn btn-primary social-login-btn social-facebook" href="<?= base_url('auth/loginfacebook'); ?>"><i class="fa fa-facebook"></i></a>
                                        <!--                                                            <a class="btn btn-primary social-login-btn social-twitter" href="/auth/twitter"><i class="fa fa-twitter"></i></a>-->
                                        <a class="btn btn-primary social-login-btn social-google" href="<?php echo $login_url;?>"><i class="fa fa-google-plus"></i></a>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-simple lognow btn-block" type="submit">
                                Login Now
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="customer_support" tabindex="-2" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog">
        <div class="col-lg-8 col-lg-offset-2" style="margin-top: 150px;">
            <div class="con" >
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style="color:white;  text-align: center;">Customer Support</h4>
                </div>
                <div class="modal-body" style=" text-align: center; ">
                        <div class="col-lg-12 center">
                            <span>+956 000 456 1234<br></span>
                        </div>
                        <div class="clearfix"></div>


                </div>
                <div class="modal-footer">
                    <button class="btn btn-simple lognow btn-block"
                            type="submit"  data-dismiss="modal">
                        Ok
                    </button>
                </div>
            </div>
        </div>

    </div>
</div>

