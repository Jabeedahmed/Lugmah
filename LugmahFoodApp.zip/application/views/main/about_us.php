<link rel="stylesheet" href="<?= base_url() ?>css/app.css">
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div id="pg-content" class="row">
                    <div class="col-lg-12">
                        <div class="image">
                            <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                            <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png"
                                                                     style="width: 50px; height: 50px;"> </a>

                                <div class="media-body">
                                    <h4><b>About US</b></h4>

                                    <p style="font-style: italic;">Know More About us</p>
                                </div>
                            </div>
                        </div>
                        <div id="description" class="small-12 columns">
                            <p>
                                <span>Since 2016,</span>
                                we have been committed to providing an easy, fast way to connect customers with their favorite restaurants. It takes just few clicks from your computer to place an
                                order through <span>Lugmah.com</span> from your preferred restaurants.
                            </p>
                        </div><!-- Description End -->
                        <div class="clearfix"></div>

                        <div id="about-us-list" style="margin-top: 25px;" class="small-12 columns">
                            <ul class="small-12 columns">
                                <?php if ($about_us) {
                                    foreach ($about_us as $row) { ?>

                                        <div class="section-heading">
                                            <li><a href="javascript:void(0)"><?= $row->main_title; ?></a></li>
                                        </div>
                                        <div id="feature-list">
                                            <ul>
                                                <?php if (!empty($row->about_desc)) {
                                                    foreach ($row->about_desc as $item) {
                                                        ?>
                                                        <li>
                                                            <?php echo $item->description; ?>
                                                        </li>
                                                        <?php
                                                    }
                                                } ?>

                                            </ul>
                                        </div>

                                    <?php }
                                } ?>
                            </ul>
                        </div>


                    </div>
                    <hr/>
                </div>
            </div>
            <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top: 50px;">
                <hr>
                <div id="owl-demo1" class="owl-carousel text-center">
                    <?php
                    if (isset($banners)) {
                        foreach ($banners as $ban) {
                            ?>
                            <div class="item">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <a href="<?=$ban->link_type == 1? base_url() . 'restaurant/' . $ban->link_url . '?promo=1':$ban->link_url;?>" <?=$ban->link_type != 1? 'target="_blank"':''?>>
                                            <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;" alt="" class="responsive">
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>