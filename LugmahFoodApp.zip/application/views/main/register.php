<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="col-lg-12">
                    <div class="image" style="margin-bottom: 40px;">
                        <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                        <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                            <a class=" pull-left"> <img src="<?= base_url() ?>img/registerlogo.png" style="width: 50px; height: 50px;"> </a>

                            <div class="media-body" style="padding-top: 7px;">
                                <h4><b>Register Now</b></h4>

                                <p style="font-size:12px;font-style: italic;">Register With Us</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 col-sm-12">
                    <div class="well">
                        <div class="container" style="">
                            <form name="" id="register_user" method="POST" enctype="multipart/form-data" class="form-horizontal">
                                <div class="col-lg-8 registerdiv">
                                    <header class="heading1">
                                        <h4 class="color_register minute">Personal Information</h4>
                                    </header>
                                    <div class="col-lg-12">
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="first_name" placeholder="First Name*" class="form-control">
                                            </div>

                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="last_name" placeholder="Last Name*" class="form-control">
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="email" placeholder="Email*" class="form-control">
                                            </div>

                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="mobile_number" placeholder="Mobile*" class="form-control">
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="password" name="password" placeholder="Password*" class="form-control">
                                            </div>

                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="password" name="confirm_pass" placeholder="Confirm Password*" class="form-control">
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <label class="">Gender</label>

                                                <div class="radio">
                                                    <input id="male_gend" type="radio" name="gender" value="male" checked>
                                                    <label class="label-radio oswald-font bold font22" for="male_gend">Male</label>
                                                    <input id="female_gend" type="radio" name="gender" value="female">
                                                    <label class="label-radio oswald-font bold font22" for="female_gend">Female</label>


                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="col-lg-7">
                                            <div class="form-group">
                                                <label class="">Birthday</label>

                                                <div class="">
                                                    <div class="col-lg-4" style="padding: 0px">
                                                        <select name="month" style="font-size: 12px; " class="form-control u_b_date">
                                                            <option value="">Month</option>
                                                            <option value="01">January</option>
                                                            <option value="02">February</option>
                                                            <option value="03">March</option>
                                                            <option value="04">April</option>
                                                            <option value="05">May</option>
                                                            <option value="06">June</option>
                                                            <option value="07">July</option>
                                                            <option value="08">August</option>
                                                            <option value="09">September</option>
                                                            <option value="10">October</option>
                                                            <option value="11">November</option>
                                                            <option value="12">December</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <select name="day" style="font-size: 11px;" class="form-control" id="d_day">
                                                            <option value="">Day</option>
                                                            <option value="01">1</option>
                                                            <option value="02">2</option>
                                                            <option value="03">3</option>
                                                            <option value="04">4</option>
                                                            <option value="05">5</option>
                                                            <option value="06">6</option>
                                                            <option value="07">7</option>
                                                            <option value="08">8</option>
                                                            <option value="09">9</option>
                                                            <option value="10">10</option>
                                                            <option value="11">11</option>
                                                            <option value="12">12</option>
                                                            <option value="13">13</option>
                                                            <option value="14">14</option>
                                                            <option value="15">15</option>
                                                            <option value="16">16</option>
                                                            <option value="17">17</option>
                                                            <option value="18">18</option>
                                                            <option value="19">19</option>
                                                            <option value="20">20</option>
                                                            <option value="21">21</option>
                                                            <option value="22">22</option>
                                                            <option value="23">23</option>
                                                            <option value="24">24</option>
                                                            <option value="25">25</option>
                                                            <option value="26">26</option>
                                                            <option value="27">27</option>
                                                            <option value="28">28</option>
                                                            <option value="29">29</option>
                                                            <option value="30">30</option>
                                                            <option value="31">31</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <select name="year" style="font-size: 11px;" class="form-control u_b_date">
                                                            <option value="">Year</option>
                                                            <?php for ($i = $settings->start_year; $i <= $settings->end_year; $i++) { ?>
                                                                <option value="<?= $i ?>"><?= $i ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <header class="heading2">
                                        <h4 class="color_register">Address Information</h4>
                                    </header>
                                    <div class="col-lg-12" style="margin-bottom:10px;">
                                        <div class="form-group">
                                            <div class="col-lg-12">
                                                <div class="radio">
                                                    <input id="house" type="radio" name="address_type_id" value="1" checked>
                                                    <label class="label-radio oswald-font bold font22" for="house">House</label>
                                                    <input id="building" type="radio" name="address_type_id" value="2">
                                                    <label class="label-radio oswald-font bold font22" for="building">Building</label>
                                                    <input id="office" type="radio" name="address_type_id" value="3">
                                                    <label class="label-radio oswald-font bold font22" for="office">Office</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <select name="city_id" class="form-control">
                                                    <option value="" disabled selected> Select Your Area</option>
                                                    <?php if (!empty($capitals)) {
                                                        foreach ($capitals as $capital) {
                                                            ?>
                                                            <optgroup label="<?php echo ucwords($capital->capital_name); ?>">
                                                                <?php if (!empty($cities)) {
                                                                    foreach ($cities as $row) {
                                                                        if ($row->capital_id == $capital->id) {
                                                                            ?>
                                                                            <option value="<?php echo $row->city_id; ?>"><?php echo $row->city_name; ?></option>
                                                                        <?php }
                                                                    }
                                                                } ?>
                                                            </optgroup>
                                                        <?php }
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="address_name" placeholder="Address Title*" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="block" placeholder="Block*" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="judda" placeholder="Road" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="street" placeholder="Street*" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="office_name" id="number" placeholder="House Number*" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div id="house_div" style="display:none;">
                                            <div class="col-lg-6">
                                                <div class="form-group ">
                                                    <input type="text" name="floor" id="floor" placeholder="Floor*" class="form-control" disabled>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group ">
                                                    <input type="text" name="appartment" id="apartment_office" placeholder="Apartment/Office*" class="form-control" disabled>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="col-lg-12">
                                            <div class="form-group ">
                                                    <textarea type="text" name="extra_direction" class="form-control"
                                                              placeholder="Extra Direction(add more details for the restaurants driver to find you faster)"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class=" col-lg-12">
                                            <div class="form-group checkbox">
                                                <input id="promo_setting" type="checkbox" name="promo_setting" value="promo_setting">
                                                <label class="label-radio oswald-font bold font22" for="promo_setting">Get latest Promos and offers by Newsletters</label>
                                            </div>
                                            <div class=" form-group checkbox">
                                                <input id="sms_setting" type="checkbox" name="sms_setting" value="sms_setting">
                                                <label class="label-radio oswald-font bold font22" for="sms_setting">Keep me posted via Email</label>
                                            </div>
                                            <div class="form-group checkbox">
                                                <input id="terms" type="checkbox" name="terms" value="terms">
                                                <label class="label-radio oswald-font bold font22" for="terms">I have read and understood the privacy policy and agree to the terms of use</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group" style="padding-bottom:20px;">
                                                <input type="submit" name="register" class="btn btn-contact" value="Register">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <div class="col-lg-3 ">
                                <div class="row register">
                                    <h4 class="color_register minute center">Why Register With Us</h4>
                                    <li><a class="pull-left"> <img src="<?= base_url() ?>img/save.png" style="width: 40px; height: 40px;"> </a>Save your detail for faster easier ordering</li>
                                    <hr>
                                    <li><a class="pull-left"> <img src="<?= base_url() ?>img/oneclick.png" style="width: 40px; height: 40px;"> </a>One-click re-ordering of previous meals from
                                        your order history
                                    </li>
                                    <hr>
                                    <li><a class="pull-left"> <img src="<?= base_url() ?>img/track.png" style="width: 40px; height: 40px;"> </a>Track your order service. Track your order
                                        service
                                    </li>
                                    <hr>
                                    <li><a class="pull-left"> <img src="<?= base_url() ?>img/share.png" style="width: 40px; height: 40px;"> </a>Share your review and ratings on your order
                                        experience
                                    </li>
                                    <hr>
                                    <li><a class="pull-left"> <img src="<?= base_url() ?>img/recieve.png" style="width: 40px; height: 40px;"> </a>Receive exclusive restaurants offers and
                                        promotions
                                    </li>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<script>

    $(document).ready(function () {
        $("#house").attr('checked', 'checked');
        $("#house").click(function () {
            $("#house_div").hide();
            $("#house_div").find('input').prop('disabled', true);
            $('#register_user').data('formValidation').resetForm();
            $('#register_user').data('formValidation').validate();

            $("#number").attr("placeholder", "House Number");
        });
        $("#building").click(function () {
            $("#number").attr("placeholder", "Building Number");
            $("#house_div").find('input').prop('disabled', false);
            $("#house_div").show();
        });
        $("#office").click(function () {
            $("#number").attr("placeholder", "Office Number");
            $("#house_div").find('input').prop('disabled', false);
            $("#house_div").show();
        });

        $(".u_b_date").on('change', function () {
            var month = $("[name='month']").val();
            var month_31 = ['01', '03', '05', '07', '08', '10', '12'];
            var month_30 = ['04', '06', '09', '11'];
            var da_day = $("#d_day");
            if (jQuery.inArray(month, month_31) !== -1) {
                if (da_day.find('option').length != 32) {
                    if (da_day.find('option').length == 31) {
                        da_day.append(new Option("31", "31"));
                    } else if (da_day.find('option').length == 29) {
                        da_day.append(new Option("29", "29"));
                        da_day.append(new Option("30", "30"));
                        da_day.append(new Option("31", "31"));
                    } else if (da_day.find('option').length == 30) {
                        da_day.append(new Option("30", "30"));
                        da_day.append(new Option("31", "31"));
                    }

                }
            } else if (jQuery.inArray(month, month_30) !== -1) {
                if (da_day.find('option').length != 31) {
                    if (da_day.find('option').length == 32) {
                        da_day.find("[value='31']").remove();
                    } else if (da_day.find('option').length == 30) {
                        da_day.append(new Option("30", "30"));
                    } else if (da_day.find('option').length == 29) {
                        da_day.append(new Option("29", "29"));
                        da_day.append(new Option("30", "30"));
                    }
                }
            } else {
                year = $("[name='year']").val();
                if (year != undefined && year % 4 == 0) {

                    if (da_day.find('option').length == 32) {
                        da_day.find("[value='31']").remove();
                        da_day.find("[value='30']").remove();
                    } else if (da_day.find('option').length == 31) {
                        da_day.find("[value='30']").remove();
                    } else if (da_day.find('option').length == 29) {
                        da_day.append(new Option("29", "29"));

                    }

                } else {
                    if (da_day.find('option').length == 32) {
                        da_day.find("[value='31']").remove();
                        da_day.find("[value='30']").remove();
                        da_day.find("[value='29']").remove();
                    } else if (da_day.find('option').length == 31) {
                        da_day.find("[value='30']").remove();
                        da_day.find("[value='29']").remove();
                    } else if (da_day.find('option').length == 30) {
                        da_day.find("[value='29']").remove();

                    }

                }

            }

        });
    });

</script>