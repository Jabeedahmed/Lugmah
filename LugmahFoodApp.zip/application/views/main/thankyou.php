<link rel="stylesheet" href="<?= base_url() ?>shareit/rrssb.css"/>
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-2"></div>
            <div class="col-lg-8">
                <div id="pg-content" class="row">
                    <div class="col-lg-12">
                        <div class="image">
                            <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                            <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px; text-align: center">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/checkout_done.png"
                                                                     style="width: 50px; height: 50px;"> </a>

                                <div class="media-body">
                                    <h4><b>Thank you for Ordering with us</b></h4>

                                    <p style="font-style: italic;">Your Order will be delivered soon.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12  thank">
                        <h2 class="shares margin-bottoms"><b>Your Order Summery</b></h2>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="col-lg-2">
                                    Full Name
                                </div>
                                <div class="col-lg-6 color-grey">
                                    <?= $user_detail->name ?>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="col-lg-2">
                                    Email
                                </div>
                                <div class="col-lg-6  color-grey">
                                    <?= $user_detail->email ?>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="col-lg-2">
                                    Contact No
                                </div>
                                <div class="col-lg-6 color-grey">
                                    <?= $user_detail->phone ?>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="col-lg-2">
                                    Address
                                </div>
                                <div class="col-lg-6 color-grey">
                                    <?= wordwrap($user_detail->address, 50, '<br>') ?>
                                </div>
                            </div>
                        </div>

                        <div class="checkout_rest_items" style="margin-top: 30px">
                            <?= $order_confirm_view; ?>
                        </div>
                        <table class="checkout-table mt40">
                            <?php if (!empty($points_earned) && $points_earned > 0) { ?>
                                <tr style="border: none;">
                                    <td colspan="" class="txt-right col-lg-9">
                                    <span class="color-yellow bold font16">
                                        Points Earned
                                    </span>
                                    </td>
                                    <td class="txt-right" style="    width: 170px;">
                                    <span class="color-yellow bold font16 pr20 sub-total">
                                         <?= number_format($points_earned, 3) ?>
                                    </span>
                                    </td>
                                </tr>
                            <?php } ?>
                            <tr style="background-color: #f2f2f2;border: none;">
                                <td colspan="" class="txt-right col-lg-9">
                                    <span class="color-yellow bold font16">
                                        GRAND TOTAL
                                    </span>
                                </td>
                                <td class="txt-right" style="width: 170px;">
                                    <span class="color-yellow bold font16 pr20 sub-total">
                                         KD <?php
                                        if (!empty($total_cost)) {
                                            echo number_format($total_cost, 3);
                                        } else {
                                            echo '0.00';
                                        }
                                        ?>
                                    </span>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-lg-12 center" style="margin-top: 50px;margin-bottom: 25px;">
                        <h3 class="shares"><b>Share With Your Friends</b></h3>
                    </div>
                    <div style="margin-left: 388px" id="shareRoundIcons"></div>

                    <ul class="rrssb-buttons">

                        <li class="rrssb-facebook">
                            <!--  Replace with your URL. For best results, make sure you page has the proper FB Open Graph tags in header:
                                  https://developers.facebook.com/docs/opengraph/howtos/maximizing-distribution-media-content/ -->
                            <a href="https://www.facebook.com/sharer/sharer.php?u=http://www.dotsnpixelz.com/demo/lugma_new92/main/thankyou?order_id=<?= $order_id ?>"
                               class="popup">
          <span class="rrssb-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 29 29">
                <path
                    d="M26.4 0H2.6C1.714 0 0 1.715 0 2.6v23.8c0 .884 1.715 2.6 2.6 2.6h12.393V17.988h-3.996v-3.98h3.997v-3.062c0-3.746 2.835-5.97 6.177-5.97 1.6 0 2.444.173 2.845.226v3.792H21.18c-1.817 0-2.156.9-2.156 2.168v2.847h5.045l-.66 3.978h-4.386V29H26.4c.884 0 2.6-1.716 2.6-2.6V2.6c0-.885-1.716-2.6-2.6-2.6z"/>
            </svg>
          </span>
                                <span class="rrssb-text">facebook</span>
                            </a>
                        </li>
                        <li class="rrssb-instagram">
                            <!-- Replace href with your URL  -->
                            <a href="http://dotsnpixelz.com/demo/lugma_new92/">
          <span class="rrssb-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28">
                <path
                    d="M4.066.636h19.867c1.887 0 3.43 1.543 3.43 3.43v19.868c0 1.888-1.543 3.43-3.43 3.43H4.066c-1.887 0-3.43-1.542-3.43-3.43V4.066c0-1.887 1.544-3.43 3.43-3.43zm16.04 2.97c-.66 0-1.203.54-1.203 1.202v2.88c0 .662.542 1.203 1.204 1.203h3.02c.663 0 1.204-.54 1.204-1.202v-2.88c0-.662-.54-1.203-1.202-1.203h-3.02zm4.238 8.333H21.99c.224.726.344 1.495.344 2.292 0 4.446-3.72 8.05-8.308 8.05s-8.31-3.604-8.31-8.05c0-.797.122-1.566.344-2.293H3.606v11.29c0 .584.48 1.06 1.062 1.06H23.28c.585 0 1.062-.477 1.062-1.06V11.94h.002zm-10.32-3.2c-2.963 0-5.367 2.33-5.367 5.202 0 2.873 2.404 5.202 5.368 5.202 2.965 0 5.368-2.33 5.368-5.202s-2.403-5.2-5.368-5.2z"/>
            </svg>
          </span>
                                <span class="rrssb-text">instagram</span>
                            </a>
                        </li>
                        <li class="rrssb-twitter">
                            <!-- Replace href with your Meta and URL information  -->
                            <a href="https://twitter.com/intent/tweet?text=Ridiculously%20Responsive%20Social%20Sharing%20Buttons%20by%20%40dbox%20and%20%40joshuatuscan%3A%20http%3A%2F%2Fkurtnoble.com%2Flabs%2Frrssb%20%7C%20http%3A%2F%2Fkurtnoble.com%2Flabs%2Frrssb%2Fmedia%2Frrssb-preview.png"
                               class="popup">
          <span class="rrssb-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28">
                <path
                    d="M24.253 8.756C24.69 17.08 18.297 24.182 9.97 24.62a15.093 15.093 0 0 1-8.86-2.32c2.702.18 5.375-.648 7.507-2.32a5.417 5.417 0 0 1-4.49-3.64c.802.13 1.62.077 2.4-.154a5.416 5.416 0 0 1-4.412-5.11 5.43 5.43 0 0 0 2.168.387A5.416 5.416 0 0 1 2.89 4.498a15.09 15.09 0 0 0 10.913 5.573 5.185 5.185 0 0 1 3.434-6.48 5.18 5.18 0 0 1 5.546 1.682 9.076 9.076 0 0 0 3.33-1.317 5.038 5.038 0 0 1-2.4 2.942 9.068 9.068 0 0 0 3.02-.85 5.05 5.05 0 0 1-2.48 2.71z"/>
            </svg>
          </span>
                                <span class="rrssb-text">twitter</span>
                            </a>
                        </li>
                        <li class="rrssb-googleplus">
                            <!-- Replace href with your meta and URL information.  -->
                            <a href="https://plus.google.com/share?url=Check%20out%20how%20ridiculously%20responsive%20these%20social%20buttons%20are%20http://dotsnpixelz.com/demo/lugma_new92/"
                               class="popup">
          <span class="rrssb-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path
                    d="M21 8.29h-1.95v2.6h-2.6v1.82h2.6v2.6H21v-2.6h2.6v-1.885H21V8.29zM7.614 10.306v2.925h3.9c-.26 1.69-1.755 2.925-3.9 2.925-2.34 0-4.29-2.016-4.29-4.354s1.885-4.353 4.29-4.353c1.104 0 2.014.326 2.794 1.105l2.08-2.08c-1.3-1.17-2.924-1.883-4.874-1.883C3.65 4.586.4 7.835.4 11.8s3.25 7.212 7.214 7.212c4.224 0 6.953-2.988 6.953-7.082 0-.52-.065-1.104-.13-1.624H7.614z"/>
            </svg>            </span>
                                <span class="rrssb-text">google+</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top:50px;">
                <hr>
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner" role="listbox">
                        <div class="item active">
                            <div class="featured-partners">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-01.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-02.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-03.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="featured-partners">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-01.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-02.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-03.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Left and right controls -->
                    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    window.jQuery || document.write('<script src="<?=base_url() ?>shareit/vendor/jquery.1.10.2.min.js"><\/script>')
</script>

<script src="<?= base_url() ?>shareit/rrssb.min.js"></script>