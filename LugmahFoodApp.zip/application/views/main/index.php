<div class="content">
    <div class="container">
        <div class="features-section">
            <div class="col-lg-12">
                <div class="col-lg-12">
                    <div class="col-lg-8 col-lg-offset-2"><h3>Promotions</h3></div>
                    <div class="col-lg-2" style="margin-top: 10px;text-align: center;"><p style="font-size:13px;"><b><a
                                    style="color: black;cursor: pointer;" class="promotions" data-toggle="modal">SEE ALL
                                    PROMOTIONS</a></b></p></div>

                </div>

                <div class="col-lg-12 " style="margin-bottom: 40px;">

                    <div id="owl-demo1" class="owl-carousel text-center">
                        <?php
                        if (isset($banners)) {
                            foreach ($banners as $ban) {
                                ?>
                                <div class="item">
                                    <div class="col-md-4 fet-part">
                                        <div class="feature-img-grid">
                                            <a href="<?=$ban->link_type == 1? base_url() . 'restaurant/' . $ban->link_url . '?promo=1':$ban->link_url;?>" <?=$ban->link_type != 1? 'target="_blank"':''?>>
                                                <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;" alt="" class="responsive">
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <?php
                            }
                        }
                        ?>
                    </div>

                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="featured-companies">
            <h3>See What others <b>are Eating</b></h3>
            <hr style="border: 1px solid; width: 200px;">
            <div id="instafeed" class="owl-carousel text-center"></div>

            <!--//sreen-gallery-cursual-->
            <div class="clearfix"></div>
        </div>
        <div class="our-team">
            <div class="col-lg-12">
                <div class="col-lg-8 col-lg-offset-2"><h3>Browse <b>by category</b></h3></div>
                <div class="col-lg-2" style="margin-top: 55px;text-align: center;"><p style="font-size:13px;"><b><a
                                style="color: black;" href="<?= base_url() ?>main/see_all_cuisines">SEE ALL
                                CUISINES</a></b></p></div>

            </div>

            <div class="item">

                <div class="col-lg-3">
                    <a href="<?= base_url() ?>main/search_result?cuisine=<?php echo $cuisine_banner[0]->id; ?>">
                        <div class="col-lg-12 no-padding">
                            <div class="cuadro_intro_hover " style="background-color:#cccccc;">
                                <p style="text-align:center;">
                                    <img class="lazyOwl img-responsive tem-g" style="height: 200px;object-fit: cover;"
                                         src="<?php echo $cuisine_banner[0]->image_url; ?>" alt="<?php echo $cuisine_banner[0]->name; ?>">
                                </p>

                                <div class="caption">
                                    <div class="blur"></div>
                                    <div class="caption-text">
                                        <h3><?php echo $cuisine_banner[0]->name; ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="<?= base_url() ?>main/search_result?cuisine=<?php echo $cuisine_banner[1]->id; ?>">
                        <div class="col-lg-12 no-padding" style="margin-top:15px;">
                            <div class="cuadro_intro_hover " style="background-color:#cccccc;">
                                <p style="text-align:center;">
                                    <img class="lazyOwl img-responsive tem-g" style="height: 200px;object-fit: cover;"
                                         src="<?php echo $cuisine_banner[1]->image_url; ?>" alt="<?php echo $cuisine_banner[1]->name; ?>">
                                </p>

                                <div class="caption">
                                    <div class="blur"></div>
                                    <div class="caption-text">
                                        <h3><?php echo $cuisine_banner[1]->name; ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>

                </div>
                </a>
                <a href="<?= base_url() ?>main/search_result?cuisine=<?php echo $cuisine_banner[2]->id; ?>">
                    <div class="col-lg-3">
                        <div class="cuadro_intro_hover " style="background-color:#cccccc;">
                            <p style="text-align:center;">
                                <img class="lazyOwl img-responsive tem-g" style="height: 415px;object-fit: cover;"
                                     src="<?php echo $cuisine_banner[2]->image_url; ?>" alt="<?php echo $cuisine_banner[2]->name; ?>">
                            </p>

                            <div class="caption">
                                <div class="blur"></div>
                                <div class="caption-text">
                                    <h3 style="margin-top:150px;"><?php echo $cuisine_banner[2]->name; ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
                <a href="<?= base_url() ?>main/search_result?cuisine=<?php echo $cuisine_banner[3]->id; ?>">
                    <div class="col-lg-6">
                        <div class="cuadro_intro_hover " style="background-color:#cccccc;">
                            <p style="text-align:center;">
                                <img class="lazyOwl img-responsive tem-g" style="height: 415px;object-fit: cover;"
                                     src="<?php echo $cuisine_banner[3]->image_url; ?>" alt="<?php echo $cuisine_banner[3]->name; ?>">
                            </p>

                            <div class="caption">
                                <div class="blur"></div>
                                <div class="caption-text">
                                    <h3 style="margin-top:150px;"><?php echo $cuisine_banner[3]->name; ?></h3>

                                </div>
                            </div>
                        </div>
                    </div>
                </a>


            </div>


            <!--//sreen-gallery-cursual-->
            <div class="clearfix"></div>
        </div>
        <div class="col-lg-12 lists" style="margin-top: 10px;">

            <ul>
                <?php $count = 1;
                foreach ($cuisine_types as $row) { ?>
                    <div class="col-lg-2 ">
                        <li class="vertical_line">
                            <a href="<?= base_url() ?>main/search_result?cuisine=<?php echo $row->id; ?>"><?php echo $row->name; ?></a>
                        </li>
                    </div>
                    <?php
                    if ($count % 6 == 0) {
                        echo '<div style="height:10px; clear: both;"></div>';
                    }
                    $count++;
                }
                ?>
            </ul>


        </div>


        <div class="clearfix"></div>
        <div class="col-lg-12" style="margin-top:60px;">
            <div class="col-lg-6"><img class=" img-responsive " src="<?= base_url() ?>img/mobiles.png"></div>
            <div class="col-lg-4 col-lg-offset-1" style="margin-top: 50px;"><img class=" img-responsive "
                                                                                 src="<?= base_url() ?>img/lugma.png">

                <div class="col-lg-6" style="margin-top:20px;"><a href="https://play.google.com/store" target="_blank">
                        <img class=" img-responsive " src="<?= base_url() ?>img/google-play-badge.png"></a>
                </div>
                <div class="col-lg-6" style="margin-top:20px;"><a href="http://www.apple.com/" target="_blank">
                        <img class=" img-responsive " src="<?= base_url() ?>img/app-store-badge.png"></a>
                </div>
            </div>
        </div>

    </div>
</div>
<script>
    $(document).ready(function ($) {
        function adjustStyle(width) {
            width = parseInt(width);
            if (width < 701) {
                $(".vertical_line").removeClass("vertical_line");
            } else {
                $(".vertical_line").addClass("vertical_line");
            }
        }

        $(function () {
            adjustStyle($(this).width());
            $(window).resize(function () {
                adjustStyle($(this).width());
            });
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        var feed = new Instafeed({
            get: 'user',
            userId: 'self',
            accessToken: '3051257884.e0ce6e7.afa39aed29a448a79445ba274b2e95d8',
            limit: '10',
            resolution: 'standard_resolution',
            template: '<div class="item"><a href="{{link}}"><img style="height:265px; width: 265px;padding:5px;" class="lazyOwl img-responsive tem-g" src="{{image}}" /></a></div>',
            after: function () {
                $("#instafeed").owlCarousel({
                    items: 4,
                    lazyLoad: true,
                    autoPlay: true,
                    navigation: true,
                    pagination: false,
                    navigationText: [
                        "<i class='glyphicon glyphicon-chevron-left'></i>",
                        "<i class='glyphicon glyphicon-chevron-right'></i>"
                    ],
                });
            }

        });
        feed.run();
    });
</script>

