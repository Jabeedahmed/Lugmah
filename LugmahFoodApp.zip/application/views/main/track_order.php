<style>
    .progress-bar {
        background-color: #fec00f !important;
    }

    .well {
        background-color: #F9F9F9;
    }

    .one, .two, .three {
        position: absolute;
        margin-top: -5px;
        z-index: 1;
        height: 30px;
        width: 30px;
        border-radius: 19px;

    }

    .progress {
        margin: 40px;
    }

    .one {
        left: 25%;
    }

    .two {
        left: 50%;
    }

    .three {
        left: 75%;
    }

    .primary-color {
        background-color: #FFC000;
    }

    .success-color {
        background-color: #5cb85c;
    }

    .danger-color {
        background-color: #d9534f;
    }

    .warning-color {
        background-color: #f0ad4e;
    }

    .info-color {
        background-color: #5bc0de;
    }

    .no-color {
        background-color: inherit;
    }

</style>
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div id="pg-content">
                    <div class="col-lg-12">
                        <div class="image">
                            <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                            <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png"
                                                                     style="width: 50px; height: 50px;"> </a>

                                <div class="media-body">
                                    <h4><b>Track Order</b></h4>

                                    <p style="font-style: italic;">Your Order will be delivered soon.</p>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-12" style="margin-top:40px;">

                        <?php if (!empty($message)) { ?>
                            <div class="panel" style="background-color: red;color: white;padding: 10px;">
                                <h6><?= $message ?></h6>
                            </div>
                        <?php } else { ?>

                            <div class="col-lg-8">
                                <div class="col-lg-3">
                                    <label class="sort">Track Order:</label></div>

                                <div class="form-group col-lg-5">
                                    <select name="country" class="form-control order_details selectpicker" data-live-search="true">
                                        <option value="">Select Order</option>
                                        <?php if (!empty($order_history)) {
                                            foreach ($order_history as $item) { ?>
                                                <option value="<?= $item->order_id ?>"><?= $item->rest_name ?>
                                                    &nbsp;<?= $item->datetime; ?></option>
                                            <?php }
                                        } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="well">
                                <div class="progress ">
                                    <div class="one primary-color"></div>
                                    <div class="two primary-color"></div>
                                    <div class="three primary-color"></div>

                                    <div class="order_outerdiv">

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12 col-lg-offset-1" style="margin-left: 120px;">
                                        <div class="col-lg-3 ">
                                            <img class="img-responsive" src="<?= base_url() ?>img/orderRecievedBy.png"
                                                 style="width: 250px; height: 150px;">
                                        </div>
                                        <div class="col-lg-3 ">
                                            <img class="img-responsive" src="<?= base_url() ?>img/orderReady.png"
                                                 style="margin-left: 35px;width: 200px; height: 150px;">
                                        </div>
                                        <div class="col-lg-3 ">
                                            <img class="img-responsive" src="<?= base_url() ?>img/orderOutOfdelivery.png"
                                                 style="margin-left: 60px;width: 200px; height: 150px;">
                                        </div>


                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top:50px;">
                <hr>
                <div id="owl-demo1" class="owl-carousel text-center">
                    <?php
                    if (isset($banners)) {
                        foreach ($banners as $ban) {
                            ?>
                            <div class="item">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <a href="<?=$ban->link_type == 1? base_url() . 'restaurant/' . $ban->link_url . '?promo=1':$ban->link_url;?>" <?=$ban->link_type != 1? 'target="_blank"':''?>>
                                            <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;" alt="" class="responsive">
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {

        $(document).on("change", '.order_details', function () {
            $('.order_outerdiv').css('width', '0%');
            var order_id = $(this).val();
            if (order_id !== '') {
                $url = '<?= base_url() ?>index.php/main/get_order_detail_by_id';
                $data = 'order_id=' + order_id;
                $.ajax({
                    url: $url,
                    type: "POST",
                    dataType: 'json',
                    data: $data,
                    success: function (data) {
                        if (data.order_status === 'pend') {
                            $(".order_outerdiv").addClass('progress-bar');
                            $(".order_outerdiv").css('width', '23%');
                        } else if (data.order_status === 'recv') {
                            $(".order_outerdiv").addClass('progress-bar');
                            $(".order_outerdiv").css('width', '23%');
                        } else if (data.order_status === 'ordy') {
                            $(".order_outerdiv").addClass('progress-bar');
                            $(".order_outerdiv").css('width', '53%');
                        } else if (data.order_status === 'ofdv') {
                            $(".order_outerdiv").addClass('progress-bar');
                            $(".order_outerdiv").css('width', '81%');
                        }else if (data.order_status === 'dilv') {
                            $(".order_outerdiv").addClass('progress-bar');
                            $(".order_outerdiv").css('width', '100%');
                        }
                    }
                });
            }
        });
    });
</script>

















