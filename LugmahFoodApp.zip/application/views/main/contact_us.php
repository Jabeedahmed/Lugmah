<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div id="pg-content" class="row">
                    <div class="col-lg-12">
                        <div class="image">
                            <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                            <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png"
                                                                     style="width: 50px; height: 50px;"> </a>

                                <div class="media-body">
                                    <h4><b>Contact Us</b></h4>

                                    <p style="font-style: italic;">Contact Us to know More</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12" style="margin-top:40px;">
                        <div class="clearfix"></div>
                        <div class="well">
                            <div class="container">
                                <div class="col-lg-6" style="padding-left:0px; margin-top: 10px;">
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" placeholder="Name" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" placeholder="Telephone" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" placeholder="Email" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" placeholder="Company" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group ">
                                            <textarea type="text" placeholder="Comments" cols="7"
                                                      class="form-control"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <input type="submit" class="btn btn-contact " value="Submit">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="col-lg-6 col-lg-offset-4">
                                        <p>You may contact us through our call center number <b>111 888 00</b> or our to
                                            get the quick response in case you need. </p><br>

                                        <p>Or For any other queries email us to <b style="word-wrap:break-word;">customercare@lugmah.com</b>
                                            or fill up the following from and we will get back to you. </p>

                                        <div class="col-lg-6" style="float:right;">
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top: 50px;">
                <hr>
                <div id="owl-demo1" class="owl-carousel text-center">
                    <?php
                    if (isset($banners)) {
                        foreach ($banners as $ban) {
                            ?>
                            <div class="item">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;"
                                             alt="" class="responsive">
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                    }
                    ?>
                </div>

            </div>
        </div>

    </div>
</div>















