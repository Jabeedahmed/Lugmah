<style>
    .glyphicon-chevron-right {
        top: 0px !important;
    }
</style>
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div id="pg-content" class="row">
                    <div class="col-lg-12">
                        <div class="image">
                            <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                            <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png" style="width: 50px; height: 50px;"> </a>

                                <div class="media-body">
                                    <h4><b>FAQ</b></h4>

                                    <p style="font-style: italic;">Frequently Asked Questions</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12" style="margin-top:40px;">
                        <div class="clearfix"></div>
                        <!-- Tab panes -->
                        <div class="tab-content faq-cat-content">
                            <div class="tab-pane active in fade" id="faq-cat-1">
                                <div class="panel-group" id="accordion-cat-1">
                                    <?php if (!empty($faqs)) {
                                        $i = 1;
                                        foreach ($faqs as $faq) {
                                            ?>

                                            <div class="panel panel-default panel-faq">
                                                <div class="panel-heading">
                                                    <a data-toggle="collapse" data-parent="#accordion-cat-1" href="#faq-cat-1-sub-<?= $i ?>">
                                                        <h4 class="panel-title">
                                                            <span style="display: inline-block"><i class="glyphicon glyphicon-chevron-right"></i></span>
                                                            <?php echo $faq->question; ?>
                                                        </h4>
                                                    </a>
                                                </div>
                                                <div id="faq-cat-1-sub-<?= $i ?>" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <?php echo $faq->answer; ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php $i++;
                                        }
                                    } ?>


                                </div>
                            </div>

                        </div>
                    </div>


                    <hr/>

                </div>
            </div>
            <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top: 50px;">
                <hr>
                <div id="owl-demo1" class="owl-carousel text-center">
                    <?php
                    if (isset($banners)) {
                        foreach ($banners as $ban) {
                            ?>
                            <div class="item">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <a href="<?=$ban->link_type == 1? base_url() . 'restaurant/' . $ban->link_url . '?promo=1':$ban->link_url;?>" <?=$ban->link_type != 1? 'target="_blank"':''?>>
                                            <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;" alt="" class="responsive">
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                    }
                    ?>
                </div>

            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        $('.collapse').on('show.bs.collapse', function () {
            var id = $(this).attr('id');
            $('a[href="#' + id + '"]').closest('.panel-heading').addClass('active-faq');
            $('a[href="#' + id + '"] .panel-title span').html('<i class="glyphicon glyphicon-chevron-down"></i>');
        });
        $('.collapse').on('hide.bs.collapse', function () {
            var id = $(this).attr('id');
            $('a[href="#' + id + '"]').closest('.panel-heading').removeClass('active-faq');
            $('a[href="#' + id + '"] .panel-title span').html('<i class="glyphicon glyphicon-chevron-right"></i>');
        });
    });
</script>















