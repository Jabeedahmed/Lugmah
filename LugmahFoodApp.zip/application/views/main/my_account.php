<style>
    .buttons {
        margin-bottom: -20px !important;
    }

    .media-heading {
        margin-top: 5px;
    }

    .selected {
        color: white;
        background: green
    }

    .tableform {
        border-radius: 5px;
    }

    .delivery {
        margin-bottom: 20px;
    }

    .favorite {
        margin-bottom: 20px;
    }

    .text-center a {
        background-color: #FFC000;
        border-color: #FFC000;
        margin-right: 20px;
        padding-right: 25px;
        padding-left: 25px;
        float: right;
    }

    a {
        color: #D6D6D6;
    }

    .media-body {
        padding-top: 40px;
    }

    .media-object {
        width: 100px !important;
        height: 100px !important;
    }

    .media-body hr {
        transform: rotate(90deg);
        width: 50px;
        margin-top: -20px;
        float: right;
        margin-bottom: 50px;
    }

    .btn-active {
        background-color: #FFC000;
        color: white;
    }
</style>
<div class="whole_div"
     style="width:100%;height:100%;display: none;position: fixed;z-index: 99999; background:url(<?= base_url() ?>img/loading.gif) no-repeat center center;"></div>
<div class="content">
    <div class="container">
        <div class="col-lg-12">
            <div class="col-lg-12">
                <?php if ($this->session->flashdata('message')) { ?>
                    <div class="alert alert-success">
                        <h6><?= strip_tags($this->session->flashdata('message')); ?><a class="close fa fa-times"
                                                                                       href="#"></a></h6>
                    </div>
                <?php } ?>
                <div class="image">
                    <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                    <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                        <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/registerlogo.png"
                                                             style="width: 50px; height: 50px;"> </a>

                        <div class="media-body" style="padding-top: 7px;">
                            <h4><b>My Account</b></h4>

                            <p style="font-size:12px;font-style: italic;">My Account Page</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="well" style="padding:0px; margin-top: 50px;">
                    <h4 class="color1">Hello <?= $user_info->first_name ?>&nbsp;<?= $user_info->last_name ?>
                        (<?= $user_info->email ?>)
                    </h4>

                    <div class="media" style="margin-left: 15px;margin-bottom: 20px;">
                        <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/Moneybag.png"
                                                             style="width: 30px; height: 30px;"> </a>

                        <div class="media-body" style="padding-top: 7px;">
                            <h4>Credit in bag: KD <?= $user_points; ?></h4>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-lg-12 col-sm-12">
                <div class="well">
                    <div class="btn-pref btn-group buttons" role="group" aria-label="...">
                        <div class="btn-group" role="group">
                            <a type="button" id="stars" class="btn tab-btn-grey account btn-active" href="#tab1"
                               data-toggle="tab">
                                <div>Account Information</div>
                            </a>
                        </div>
                        <div class="btn-group" role="group">
                            <a type="button" id="favorites" class="btn tab-btn-grey order" href="#tab2"
                               data-toggle="tab">
                                <div>Order History</div>
                            </a>
                        </div>
                        <div class="btn-group" role="group">
                            <a type="button" id="following" class="btn tab-btn-grey favorite favr" href="#tab3"
                               data-toggle="tab">
                                <div>My Favorites</div>
                            </a>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade in active" style="background-color:white;" id="tab1">
                            <div class="color account">
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <h4 style="margin-top:10px;">Account Summary</h4>
                                    </div>
                                    <div class="col-lg-6 row">
                                        <?php if ($change_pas_check == NULL) { ?>
                                            <a class="btn btn-default editpass" data-toggle="modal" style="float:right;">
                                                Change Password</a>
                                            <a class="btn btn-default editemail" data-toggle="modal"
                                               style="float:right;margin-right: 10px;">Change Email</a>
                                        <?php } ?>
                                        <a class="btn btn-default editprofile" data-toggle="modal"
                                           data-id="<?= $user_info->id ?>"
                                           data-firstname="<?= $user_info->first_name ?>"
                                           data-lastname="<?= $user_info->last_name ?>"
                                           data-mobileno="<?= $user_info->phone ?>"
                                           data-gender="<?= $user_info->gender ?>" data-dob="<?= $user_info->dob ?>"
                                           style="float:right;margin-right: 10px;">Edit Profile</a>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group col-lg-12">
                                            <label class="col-lg-4">First Name</label>

                                            <div class="col-lg-7">
                                                <p><?= $user_info->first_name ?></p>
                                            </div>
                                        </div>
                                        <div class="form-group col-lg-12">
                                            <label class="col-lg-4">Mobile Number</label>

                                            <div class="col-lg-7">
                                                <p><?= $user_info->phone ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group col-lg-12">
                                            <label class="col-lg-4">Last Name</label>

                                            <div class="col-lg-7">
                                                <p><?= $user_info->last_name ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <hr>
                                    <div class="col-lg-12">
                                        <div class="form-group col-lg-6">
                                            <label class="col-lg-12">Gender</label>

                                            <div class="col-lg-6">
                                                <div class="radio">
                                                    <input id="male" type="radio" name="gender"
                                                           value="male" <?php if ($user_info->gender == 'male') echo 'checked=checked'; ?> >
                                                    <label class="label-radio oswald-font bold font22"
                                                           for="male">Male</label>
                                                    <input id="female" type="radio" name="gender"
                                                           value="female" <?php if ($user_info->gender == 'female') echo 'checked=checked'; ?>>
                                                    <label class="label-radio oswald-font bold font22" for="female">Female</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group col-lg-12">
                                                <label class="col-lg-12">Birthday</label>

                                                <p class="col-lg-12"><?= $user_info->dob ?></p>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="color account">
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <h4 style="margin-top:10px;">Delivery Information</h4>
                                    </div>
                                    <div class="col-lg-6">
                                        <a class="btn btn-default addaddress" data-toggle="modal" style="float:right;">
                                            Add Address</a>

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="col-lg-12">
                                        <div class="col-lg-12">
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead>
                                                    <tr>
                                                        <th>Address Name</th>
                                                        <th>Address Information</th>
                                                        <th>Extra Information</th>
                                                        <th class="text-center"></th>
                                                    </tr>
                                                    </thead>
                                                    <?php
                                                    if (!empty($address_info)) {
                                                        foreach ($address_info as $address) {
                                                            ?>
                                                            <tr>
                                                                <td class="col-lg-2"><?= $address->address_title ?></td>
                                                                <td class="col-lg-3"><?php
                                                                    if (!empty($address->houseno_name)) {
                                                                        $address->houseno_name;
                                                                    } elseif (!empty($address->office_apt)) {
                                                                        $address->office_apt;
                                                                    } else {
                                                                        '';
                                                                    }
                                                                    ?>&nbsp;<?= $address->street ?>
                                                                    ,<?= $address->judda ?>,<?= $address->block ?></td>
                                                                <td class="col-lg-3"><?php echo $stringCut = substr($address->extra_direction, 0, 30); ?></td>
                                                                <td class="text-center"><a
                                                                        href="<?= base_url() ?>main/delete_user_address/<?= $address->id ?>"
                                                                        class="btn btn-simple ">Delete</a>
                                                                    <a class="btn btn-simple edit_useraddress"
                                                                       data-id="<?= $address->id ?>"
                                                                       data-type_id="<?= $address->type_id ?>"
                                                                       data-area_id="<?= $address->area_id ?>"
                                                                       data-address_title="<?= $address->address_title ?>"
                                                                       data-block="<?= $address->block ?>"
                                                                       data-judda="<?= $address->judda ?>"
                                                                       data-street="<?= $address->street ?>"
                                                                       data-houseno_name="<?= $address->houseno_name ?>"
                                                                       data-extra_direction="<?= $address->extra_direction ?>"
                                                                       data-floor="<?= $address->floor ?>"
                                                                       data-office_apt="<?= $address->office_apt ?>"
                                                                       data-type_name="<?= $address->type_name ?>"
                                                                       data-area_name="<?= $address->area_name ?>"
                                                                       data-toggle="modal"> Edit</a></td>
                                                            </tr>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- START::  Tab Order History-->
                        <div class="tab-pane fade in bg-white" id="tab2">
                            <div class="row">
                                <div class="col-lg-12 pt15">
                                    <div class="col-lg-12 ">
                                        <div id="order_details_view">
                                        <?= isset($latest_order_view) && !empty($latest_order_view) ? $latest_order_view : '' ?>
                                        </div>
                                        <div class="history-itembox mt40 border-top pb20 pt20">
                                            <?php
                                            if (!empty($order_history)) {
                                                $i = 0; ?>
                                                <table class="list-table table-responsive table">

                                                <?php foreach ($order_history as $user_order) {
                                                    ?>
                                                        <tr class="<?= $i == 0? 'selected' :''?> get_order_details" style="cursor: pointer">
                                                            <td style="width:50%;">
                                                                <p>
                                                                    <i style="top: 0px;" class="glyphicon glyphicon-chevron-right list-icon-red"></i>
                                                                    <span class="color-yellow"><a data-order_id="<?= $user_order['order_id']; ?>" class="color-yellow"><?= $user_order['restaurant']; ?></a></span>
                                                                </p>
                                                            </td>
                                                            <td>
                                                                <p class="color-black">
                                                                    Date: <?= $user_order['order_time']; ?></p>
                                                            </td>

                                                        </tr>
                                                    <?php $i++; } ?>
                                                </table>

                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- END::  Tab Order History-->
                        <div class="tab-pane fade in" style="background-color:white;" id="tab3">
                            <!-- -->
                            <div class="row">
                                <div class="btn-pref btn-group buttons" role="group">
                                    <div class="btn-group" role="group">
                                        <a type="button" class="btn tab-btn-grey favorite_item" href="#tab4"
                                           data-toggle="tab">
                                            <div>Favorite Item</div>
                                        </a>
                                    </div>
                                    <div class="btn-group" role="group">
                                        <a type="button" class="btn tab-btn-grey favorite_restaurant" href="#tab5"
                                           data-toggle="tab">
                                            <div>Favorite Restaurant</div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="col-lg-12">
                                        <div class="col-lg-12">
                                            <div class="table-responsive">
                                                <table class="table">

                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-content">
                                <div class="tab-pane fade in active item-active" style="background-color:white;" id="tab4">
                                    <div class="color favorite_item">
                                        <div class="col-lg-12">
                                            <div class="col-lg-6">
                                                <h4 style="margin-top:10px;">List of Favorit Items</h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="col-lg-12">
                                                <div class="col-lg-12">
                                                    <div class="table-responsive">
                                                        <table class="table">
                                                            <?php
                                                            if (!empty($fav_items)) {
                                                                foreach ($fav_items as $items_data) {
                                                                    ?>
                                                                    <tr>
                                                                        <td class="col-sm-4 col-md-4">
                                                                            <div class="media">
                                                                                <a class=" pull-left" href="<?= base_url() ?>restaurant/<?= $items_data->slug; ?>"
                                                                                   style="margin-right: 10px;"> <img
                                                                                        class="media-object"
                                                                                        src="<?= $items_data->image_url; ?>">
                                                                                </a>

                                                                                <div class="media-body">
                                                                                    <h4><a href="<?= base_url() ?>restaurant/<?= $items_data->slug; ?>"
                                                                                           class="color-yellow"><?= $items_data->name; ?></a>
                                                                                    </h4>
                                                                                    <h5 class="media-heading"
                                                                                        style="word-wrap: break-word;"><?php echo $stringCut = substr($items_data->description, 0, 50); ?>..</h5>
                                                                                    <hr>
                                                                                </div>
                                                                            </div>
                                                                        </td>

                                                                        <td class="col-sm-3 col-md-3">
                                                                            <div class="media-body">
                                                                                <h4>
                                                                                    <a href="<?= base_url() ?>restaurant/<?= $items_data->slug; ?>"
                                                                                       class="color-yellow"><?= $items_data->rest_name; ?></a>
                                                                                </h4>
                                                                                <h5 class="media-heading"><?= $items_data->rest_type; ?></h5>
                                                                                <hr>

                                                                            </div>
                                                                        </td>

                                                                        <td class="col-sm-3 col-md-3 ">
                                                                            <div class="media-body">
                                                                                <h4>Price</h4>
                                                                                <h5 class="media-heading">
                                                                                    KD <?= $items_data->price; ?></h5>
                                                                                <hr>
                                                                            </div>
                                                                        </td>
                                                                        <td class="col-sm-2 col-md-2 ">
                                                                            <div class="media-body">
                                                                                <a href="<?= base_url() ?>main/unbookmark_menu_item/<?= $items_data->id; ?>"
                                                                                   class="btn btn-active btn-block">Remove</a>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade in rest-active" style="background-color:white;" id="tab5">
                                    <div class="color favorite_restaurant">
                                        <div class="col-lg-12">
                                            <div class="col-lg-6">
                                                <h4 style="margin-top:10px;">List of Favorite Restaurants</h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="col-lg-12">
                                                <div class="col-lg-12">
                                                    <div class="table-responsive">
                                                        <table class="table">
                                                            <?php
                                                            if (!empty($fav_restaurant)) {
                                                                foreach ($fav_restaurant as $restaurant_data) {
                                                                    ?>
                                                                    <tr>
                                                                        <td class="col-sm-4 col-md-6">
                                                                            <div class="media">
                                                                                <a class=" pull-left" href="<?= base_url() ?>restaurant/<?= $restaurant_data->slug; ?>"
                                                                                   style="margin-right: 10px;"> <img
                                                                                        class="media-object"
                                                                                        src="<?= $restaurant_data->logo_url; ?>">
                                                                                </a>

                                                                                <div class="media-body">
                                                                                    <h4><a href="<?= base_url() ?>restaurant/<?= $restaurant_data->slug; ?>"
                                                                                           class="color-yellow"><?= $restaurant_data->rest_name; ?></a>
                                                                                    </h4>
                                                                                    <h5 class="media-heading"
                                                                                        style="word-wrap: break-word;"><?php echo $stringCut = substr($restaurant_data->description, 0, 50); ?>..</h5>
                                                                                    <hr>
                                                                                </div>
                                                                            </div>
                                                                        </td>

                                                                        <td class="col-sm-1 col-md-1">

                                                                        </td>

                                                                        <td class="col-sm-3 col-md-3 ">

                                                                        </td>
                                                                        <td class="col-sm-2 col-md-2 ">
                                                                            <div class="media-body">
                                                                                <a href="<?= base_url() ?>main/delete_fav_user_restaurant/<?= $restaurant_data->fav_id; ?>"
                                                                                   class="btn btn-active btn-block">Remove</a>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<?php include 'myaccount_modals.php'; ?>
<script>
    $(document).ready(function () {
        $("#editHomes").click(function () {
            $("#house_divs").hide();
            $('#edit_address').data('formValidation').resetForm();
            $("#house_divs").find('input').prop('disabled', true);
            $("#houseno_name").attr("placeholder", "House Number");
        });
        $("#editBuildings").click(function () {
            $("#houseno_name").attr("placeholder", "Building Number");
            $("#house_divs").find('input').prop('disabled', false);
            $("#house_divs").show();
        });
        $("#editOffices").click(function () {
            $("#houseno_name").attr("placeholder", "Office Number");
            $("#house_divs").find('input').prop('disabled', false);
            $("#house_divs").show();
        });
        $(".addaddress").click(function () {
            $('#add_address')[0].reset();
            $('#add_address').data('formValidation').resetForm();
            $('#addaddress').modal('show');
        });
        $(".edit_useraddress").click(function () {
            $('#edit_address')[0].reset();
            $('#edit_address').data('formValidation').resetForm();
            var area = $(this).data('area_id');
            $("#area").val(area);
            $("#address_title").val($(this).data('address_title'));
            $("#block").val($(this).data('block'));
            $("#judda").val($(this).data('judda'));
            $("#street").val($(this).data('street'));
            $("#houseno_name").val($(this).data('houseno_name'));
            $("#extra_direction").val($(this).data('extra_direction'));
            $("#floor").val($(this).data('floor'));
            $("#office_apt").val($(this).data('office_apt'));
            $("#type_name").val($(this).data('type_name'));
            $("#area_name").val($(this).data('area_name'));
            $("#id").val($(this).data('id'));
            var type = $(this).data('type_id');
            if (type == 1) {
                $("#editHomes").attr('checked', 'checked');
                $("#house_divs").hide();
                $("#house_divs").find('input').prop('disabled', true);
            } else if (type == 2) {
                $("#house_divs").find('input').prop('disabled', false);
                $("#house_divs").show();
                $("#editOffices").attr('checked', 'checked');
            } else if (type == 3) {
                $("#house_divs").find('input').prop('disabled', false);
                $("#house_divs").show();
                $("#editBuildings").attr('checked', 'checked');
            }

            $('#edit_useraddress').modal('show');
        });
        $("#Homes").click(function () {
            $("#house_div").hide();
            $('#add_address').data('formValidation').resetForm();
            $("#house_div").find('input').prop('disabled', true);
            $("#number").attr("placeholder", "House Number");
        });
        $("#Buildings").click(function () {

            $("#number").attr("placeholder", "Building Number");
            $("#house_div").find('input').prop('disabled', false);
            $("#house_div").show();
        });
        $("#Offices").click(function () {
            $("#number").attr("placeholder", "Office Number");
            $("#house_div").find('input').prop('disabled', false);
            $("#house_div").show();
        });

        $(".editprofile").click(function () {
            $("#userid").val($(this).data('id'));
            $("#firstname").val($(this).data('firstname'));
            $("#lastname").val($(this).data('lastname'));
            $("#mobileno").val($(this).data('mobileno'));
            $("#housephone").val($(this).data('housephone'));
            $("#workphone").val($(this).data('workphone'));
            $("#company").val($(this).data('company'));
            var gender = $(this).data('gender');
            if (gender == 'male') {
                $("#males").attr('checked', 'checked');
            } else {
                $("#females").attr('checked', 'checked');
            }
            var dateofbirth = $(this).data('dob');
            var dobdata = dateofbirth.split('-');
            var year_selected = dobdata[0];
            var month_selected = dobdata[1];
            var day_selected = dobdata[2];
            $("#year_sel").val(year_selected);
            $("#month_sel").val(month_selected);
            $("#day_sel").val(day_selected);
            $('#editprofile').modal('show');
        });
    });
</script>
<script type="text/javascript">
    $('.account').on('click', function () {
        $('.favorite').removeClass('btn-active');
        $('.account').addClass('btn-active');
        $('.order').removeClass('btn-active');
    });
    $('.order').on('click', function () {
        $('.favorite').removeClass('btn-active');
        $('.account').removeClass('btn-active');
        $('.order').addClass('btn-active');
    });
    $('.favorite').on('click', function () {
        $('.favorite').addClass('btn-active');
        $('.account').removeClass('btn-active');
        $('.order').removeClass('btn-active');
        $('.favorite_item').addClass('btn-active');
    });
    $('.favorite_item').on('click', function () {
        $('.favorite').addClass('btn-active');
        $('.favorite_item').addClass('btn-active');
        $('.account').removeClass('btn-active');
        $('.order').removeClass('btn-active');
        $('.favorite_restaurant').removeClass('btn-active');

    });
    $('.favorite_restaurant').on('click', function () {
        $('.favorite').addClass('btn-active');
        $('.favorite_restaurant').addClass('btn-active');
        $('.account').removeClass('btn-active');
        $('.order').removeClass('btn-active');
        $('.favorite_item').removeClass('btn-active');
    });
    $(document).ready(function () {
        $(document).on('click', '.favr', function (e) {
            $('.favorite_restaurant').removeClass('btn-active');

            $('.item-active').addClass('active');
            $('.item-active').addClass('in');
            $('.rest-active').removeClass('active');
        });
    });
    $(document).ready(function () {
        $(document).on('click', '.get_order_details', function (e) {
            $('.whole_div').show();
            $('#order_details_view').empty();
            $(this).siblings().removeClass('selected');
            $(this).addClass('selected');
            var order_id = encodeURIComponent($(this).find('a').data('order_id'));
            $url = '<?= base_url() ?>main/get_user_order_details';
            $data = 'order_id=' + order_id;
            $.ajax({
                url: $url,
                type: "POST",
                data: $data,
                success: function (data) {
                    if (data !== null) {
                        $('#order_details_view').append(data);
                    }else{
                        toastr.error('No order Found');
                    }
                }
            });
        });
    });

</script>













