<style>
    .edit_split_color {
        background-color: green;
        color: white;
    }
</style>
<div class="modal fade" id="split" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form name="" id="split_pay_guest" method="POST" action="<?= base_url() ?>main/guest_split_payment" enctype="multipart/form-data"
              class="form-horizontal">
            <!-- Modal content-->
            <input type="hidden" id="guest_name_val" name="name">
            <input type="hidden" id="guest_address_val" name="address">
            <input type="hidden" id="guest_contact_val" name="contact_no">
            <input type="hidden" id="guest_email_val" name="email">
            <input type="hidden" id="guest_other_info_val" name="other_info">

            <input type="hidden" id="payment_method_id_val" name="payment_method_id">
            <input type="hidden" id="split_points_used" name="points_used">
            <input type="hidden" id="delievery_pickup_val" name="delivery_pickup">
            <input type="hidden" id="pickup_address_id_val" name="pickup_address_id">
            <input type="hidden" id="order_time_val" name="order_time">

            <div class="col-lg-10 col-lg-offset-1">
                <div class="con">
                    <div class="modal-header" style="background-color: white;">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title center" style="color:#FFC000;">Split Your Payment</h4>
                    </div>
                    <div class="modal-header">
                        <h4 class="modal-title center" style="color:white;">Total Amount</h4>

                        <div class="center col-lg-offset-3 kd">
                            <input id="total_split_amount" name="total_amount" readonly type="text" class=" modal-title center" style="border: none;outline: none;"
                                   value="<?php if (!empty($total_cost)) {
                                       echo $total_cost . '&nbsp;KD';
                                   } ?>">

                        </div>
                    </div>
                    <div class="modal-body" style="padding: 0px; ">
                        <div class="col-lg-12 margin">
                            <div class="col-lg-12">
                                <div class="form-group">

                                </div>
                                <div id="split_details">
                                    <div class="payee_content">
                                        <label class="col-lg-6 color_model">
                                            <span class="circle col-lg-3">1</span>

                                            <div class="col-lg-9">
                                                <div class="form-group"><input id='admin_phone_no' class="form-control" style="border:none;width: 100px;" value="" name="phone_no[]" type="text" readonly
                                                                               required
                                                                               placeholder="Enter Phone"></div>
                                            </div>
                                        </label>

                                        <div class="col-lg-5">
                                            <div class="form-group">
                                                <input type="text" readonly required name="price[]" value="<?php if (!empty($total_cost)) {
                                                    echo $total_cost;
                                                } ?>" class="form-control round20 center round_color split_payee split_auto_payee">
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                        <hr class="no-marrgin">
                                    </div>
                                </div>

                                <div id="add_more_splits"></div>
                                <label class="col-lg-6"></label>

                                <div class="col-lg-6 " style="float:right;">
                                    <div class="form-group" style="float:right;">
                                        <button type="button" style="float:right;"
                                                class="btn btn-default add_more_splitter">Add more
                                        </button>
                                    </div>
                                </div>
                                <div class="clearfix"></div>

                            </div>
                        </div>
                    </div>
                    <div class="modal-footer ">
                        <input type="submit" id="submit_split" class="btn btn-simple btn-block no_border_radius pay" value="Pay">
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
    $(document).ready(function () {

        $(document).on('click', '.add_more_splitter', function (e) {
            var counter = $('#split_details').find('input[type=text].split_payee').size() + 1;
            if (counter < 6) {
                $('.payee_content').eq(0)
                    .clone().appendTo('#split_details')
                    .find('.clearfix')
                    .before('<span class="glyphicon glyphicon-minus del_splitter"></span>');
                $('.payee_content').last().find('input[type=text]').each(function () {
                    $(this).val('');
                    $(this).attr("readonly", false);
                });
                update_counter();
                update_split();
                if (counter == 5) {
                    $(".add_more_splitter").hide();
                }
            }
            $('#split_pay_guest').formValidation('addField', 'phone_no[]', {
                validators: {
                    notEmpty: {
                        message: 'Phone is required'
                    },
                    stringLength: {
                        max: 8,
                        min: 8,
                        message: 'Must be 8 digits'
                    }

                }
            });
            $('#split_pay_guest').formValidation('addField', 'price[]', {
                validators: {
                    notEmpty: {
                        message: 'Price is Required'
                    }
                }
            });

        });
        $(document).on('click', '.del_splitter', function (e) {
            $(this).parents().eq(0).remove();
            if (check_valid()) {
                $('.add_more_splitter').show();
            }
            update_counter();
            update_split();


        });
        $(document).on('change', '.split_payee', function (e) {

            $(this).removeClass('split_auto_payee');
            $(this).addClass('split_edit_payee');
            if (isNumeric($(this).val())) {
                if (parseFloat($(this).val()) >= parseFloat(total_cost_split)) {
                    toastr.error('Amount is greater than required');
                    $('#submit_split').hide();
                    $('.add_more_splitter').hide();
                }
                else if (!check_valid()) {
                    toastr.error('Added amount is greater than required');
                    $('#submit_split').hide();
                    $('.add_more_splitter').hide();
                }
                else {
                    update_split();
                }
            } else {
                toastr.error('Please Enter a Valid amount');
                $('#submit_split').hide();
                $('.add_more_splitter').hide();
            }
        });

        function update_split() {
            var edit_cost = 0;
            if (check_valid) {
                $('#split_details').find('input[type=text].split_edit_payee').each(function () {
                    if (isNumeric($(this).val())) {
                        edit_cost = parseFloat($(this).val()) + edit_cost;
                    }
                });

                var cost = (total_cost_split - edit_cost) / $('#split_details').find('input[type=text].split_auto_payee').size();


                $('#split_details').find('input[type=text].split_auto_payee').each(
                    function () {
                        $(this).val(cost.toFixed(3));
                    }
                );
                $('#submit_split').show();
                if ($('#split_details').find('input[type=text].split_payee').size() < 5) {
                    $('.add_more_splitter').show();
                }
            }
        }

        function check_valid() {
            var sp_cur_cost = 0;
            $('#split_details').find('input[type=text].split_edit_payee').each(function () {
                sp_cur_cost = parseFloat($(this).val()) + sp_cur_cost;
            });

            if (sp_cur_cost > total_cost_split) {
                return false;
            } else {
                return true;
            }
        }

        function update_counter() {
            var num = 1;
            $('#split_details').find('.circle').each(function () {
                $(this).empty().text(num);
                num++;
            });
        }

        function isNumeric(n) {
            return !isNaN(parseFloat(n)) && isFinite(n);
        }
    });
</script>