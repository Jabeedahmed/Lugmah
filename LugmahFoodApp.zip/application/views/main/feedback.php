<style>
    .help-block{
        color: red;
    }
</style>
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <form  method="post" action="#" name="r_add_feedback" id="r_add_feedback"  >
                    <div id="pg-content" class="row">
                    <div class="col-lg-12">
                        <div class="image" >
                            <img class="responsive" src="<?= base_url() ?>img/registerBack.png">
                            <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png" style="width: 50px; height: 50px;"> </a>
                                <div class="media-body">
                                    <h4><b>Give Feedback</b></h4>
                                    <p style="font-style: italic;">Help Others! Write Our review</p>
                                </div>
                            </div>
                        </div>
                    </div>
                        <?php  if (!($this->ion_auth->logged_in())) { ?>
                            <div class="col-lg-6" style="margin-top:40px;">
                                <div class="clearfix"></div>
                                <div class="well">
                                    <div class="media">
                                        <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png" style="width: 30px; height: 30px;"> </a>
                                        <div class="media-body">
                                            <h4 style="margin-bottom:10px;"><b>Name</b></h4>
                                            <input type="text" class="form-control" name="name" id="name" >
                                            <p style="font-style: italic; margin-top: 10px;"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <div class="col-lg-6" style="margin-top:40px;">
                            <div class="clearfix"></div>
                            <div class="well">
                                <div class="media">
                                    <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png" style="width: 30px; height: 30px;"> </a>
                                    <div class="media-body">
                                        <h4 style="margin-bottom:10px;"><b>Email</b></h4>
                                        <input type="email" class="form-control" name="email"  >
                                        <p style="font-style: italic; margin-top: 10px;"></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php } ?>

                    <div class="col-lg-9" style="margin-top:40px;">
                        <div class="clearfix"></div>
                        <div class="well">
                            <div class="media">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png" style="width: 30px; height: 30px;"> </a>
                                <div class="media-body">
                                    <h4 style="margin-bottom:10px;"><b>Review Title</b></h4>
                                    <input type="text" class="form-control" name="subject" id="subject" >
                                    <p style="font-style: italic; margin-top: 10px;">(Maximum 60 characters)</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="clearfix"></div>
                        <div class="well">
                            <div class="media">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png" style="width: 30px; height: 30px;"> </a>
                                <div class="media-body">
                                    <h4 style="margin-bottom:10px;"><b>Your Review:</b></h4>
                                    <textarea type="text" rows="8" class="form-control" name="detail"  ></textarea>
                                    <p style="font-style: italic; margin-top: 10px;">(Please make sure your review contains at least 50 characters.)</p>
                                </div>
                            </div>  
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <input type="submit" class="btn btn-contact " value="Submit" name="add_feedback">
                        </div>
                    <hr/>

                </div>
                </form>
            </div>
              <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top: 50px;">
                <hr>
                <div id="owl-demo1" class="owl-carousel text-center">
                    <?php
                    if (isset($banners)) {
                        foreach ($banners as $ban) {
                            ?>
                            <div class="item">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <a href="<?=$ban->link_type == 1? base_url() . 'restaurant/' . $ban->link_url . '?promo=1':$ban->link_url;?>" <?=$ban->link_type != 1? 'target="_blank"':''?>>
                                            <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;" alt="" class="responsive">
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                    }
                    ?>
                </div>

            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $("#name").keypress(function(event){
            var inputValue = event.charCode;
            if((inputValue > 47 && inputValue < 58) && (inputValue != 32)){
                event.preventDefault();
            }
        });
        $("#subject").keypress(function(event){
            var inputValue = event.charCode;
            if((inputValue > 47 && inputValue < 58) && (inputValue != 32)){
                event.preventDefault();
            }
        });
    });
</script>













