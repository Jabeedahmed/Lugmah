<style>
    hr {
        margin-top: 0px !important;
    }
</style>
<script>
    var total_cost_split = "<?php echo $total_cost; ?>";
</script>
<link href="<?= base_url() ?>css/custom.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url() ?>css/custom-select/select.css" rel="stylesheet" type="text/css"/>
<div class="content" style="padding: 2em 0;">

    <div class="container">
        <form class="form-horizontal" id="guest_checkout" name="checkoutdata" method="POST">
            <div class="col-lg-12">
                <div class="image" style="margin-bottom: 40px;">
                    <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                    <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                        <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/privacy-img.png"
                                                             style="width: 50px; height: 50px;"> </a>

                        <div class="media-body" style="padding-top: 7px;">
                            <h4 class="oswald-font bold">1. CHECKOUT</h4>

                            <p style="font-size:12px;font-style: italic;">Select Delivery address and payment type</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 mb60">
                    <div class="address-detailbox">
                        <span class="font24 mb10">Address Details</span>

                        <div class="form-horizontal raleway-font mt40">
                            <div class="form-group">
                                <label class="col-md-2 control-label txt-left font14">Name</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" id="guest_name" name="name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label txt-left font14">Address</label>

                                <div class="col-md-6">
                                    <textarea name="address" id="guest_address" class="form-control"></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label txt-left font14">Contact no</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" id="guest_contact" name="contact_no">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label txt-left font14">Email</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" id="guest_email" name="email">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label txt-left font14">Other info</label>

                                <div class="col-md-6">
                                    <textarea name="other_info" id="guest_other_info" class="form-control"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 no-padding mt20">
                        <div class="image" style="margin-bottom: 40px;">
                            <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                            <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/privacy-img.png"
                                                                     style="width: 50px; height: 50px;"> </a>

                                <div class="media-body" style="padding-top: 7px;">
                                    <h4 class="oswald-font bold">2. YOUR ORDER</h4>

                                    <p style="font-size:12px;font-style: italic;">Make sure everything is as you
                                        wish</p>
                                </div>
                            </div>
                        </div>
                        <div class="checkout_rest_items">
                            <?php if (isset($cart_view)) {
                                echo $cart_view;
                            } ?>
                        </div>
                        <div class="clear-fix"></div>

                    </div>

                    <div class="col-lg-12 no-padding mt20">
                        <div class="image" style="margin-bottom: 40px;">
                            <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                            <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/privacy-img.png"
                                                                     style="width: 50px; height: 50px;"> </a>

                                <div class="media-body" style="padding-top: 7px;">
                                    <h4 class="oswald-font bold">3. PAYMENT METHOD</h4>

                                    <p style="font-size:12px;font-style: italic;">Select Delivery address and payment
                                        type</p>
                                </div>
                            </div>
                        </div>
                        <div style="padding: 10px 0 30px">
                            <div class="radio">
                                <input id="credit_card" type="radio" name="payment_method_id" value="1" checked="">
                                <label class="label-radio oswald-font bold font22" for="credit_card">Knet / Credit Card</label>
                                <input id="cod" type="radio" name="payment_method_id" value="2">
                                <label class="label-radio oswald-font bold font22" for="cod">COD</label>
                                <input id="split_payment" type="radio" name="payment_method_id" value="4">
                                <label class="label-radio oswald-font bold font22" for="split_payment">SPLIT
                                    PAYMENT</label>
                            </div>
                        </div>

                        <table class="checkout-table mt40">
                            <tr style="background-color: #f2f2f2;border: none;">
                                <td colspan="3" class="txt-right">
                                    <span class="color-yellow bold font16">
                                        TOTAL
                                    </span>
                                </td>
                                <td class="txt-right" style="    width: 170px;">
                                    <span class="color-yellow bold font16 pr20 cart_total">
                                         KD <?php
                                        if (!empty($total_cost)) {
                                            echo number_format($total_cost,'3','.','');
                                        } else {
                                            echo '0.000';
                                        }
                                        ?>
                                    </span>
                                </td>
                            </tr>
                        </table>
                        <div class="pull-right mt20 raleway-font txt-right" style="display: inline;">
                            <p class="color-grey mb10"><i>Total will be round off</i></p>
                            <input type="button" class="btn4-yellow  checkout_btn without_split" name="checkout_trans"
                                   onclick="return check_action();" value="Checkout">
                            <button class="btn4-yellow split checkout_btn" style="display:none;" data-toggle="modal">
                                Checkout
                            </button>
                        </div>

                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="headingbox">
                        Order Information
                    </div>
                    <div class="order-infobox">
                        <div class="radio">
                            <input id="delivery" type="radio" name="delivery_pickup" checked value="0">
                            <label class="label-radio oswald-font bold font22" for="delivery">Delivery</label>

                            <p class="color-grey font12 pl25"><i>Your order will be delivered to your address</i></p>
                        </div>
                        <div class="radio">
                            <?php
                            if (!empty($restaurant)) {
                                if (sizeof($restaurant) > 1) { ?>
                                    <input id="pickup" type="radio" disabled name="delivery_pickup">
                                <?php } else { ?>
                                    <input id="pickup" type="radio" name="delivery_pickup" value="1">
                                <?php }
                            } ?>
                            <label class="label-radio oswald-font bold font22" for="pickup">Pickup</label>

                            <p class="color-grey font12 pl25"><i>You will be pick up the order yourself at
                                    restaurant </i><strong></strong></p>
                        </div>
                        <div class="time_div">
                            <hr/>
                            <div class="radio">
                                <input id="standard_time" type="radio" name="order_time" value="45" checked="">
                                <label class="label-radio oswald-font bold font22" for="standard_time">Standard
                                    Time</label>
                                <?php
                                if (!empty($restaurant)) {
                                    if (sizeof($restaurant) > 1) { ?>
                                        <p class="color-grey font12 pl25"><i>As Per Standard Delievery Time</i></p>
                                    <?php } else { ?>
                                        <p class="color-grey font12 pl25"><i>Estimated
                                                time: <?php if (!empty($restaurant)) {
                                                    echo $restaurant[0]->delivery_time;
                                                } ?> Min</i></p>
                                    <?php }
                                } ?>
                            </div>
                            <div class="radio">
                                <input id="some_time" type="radio" name="order_time" value="1">
                                <label class="label-radio oswald-font bold font22" for="some_time">After Some
                                    Time</label>
                            </div>
                        </div>
                        <div class="address" style="display:none;">
                            <hr/>
                            <p class="font12 txt-center mb10"> Please select Restaurant branch</p>

                            <div class="form-group p15">
                                <select name="pickup_address_id" class="form-control">
                                    <?php if (!empty($branches)) {
                                        ?>
                                        <?php foreach ($branches as $row) { ?>
                                            <option
                                                value="<?php echo $row['id']; ?>"><?php echo $row['branch_name']; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="time" style="display:none">
                            <hr/>
                            <p class="font12 txt-center mb10"> please select your desire time</p>

                            <div class="form-group p15">
                                <!--                                    <input type="text" class="form-control" name="" placeholder="Select a time" onfocus="(this.type='date')"/>-->
                                <select name="delivery_pickup_time" class="form-control">
                                    <option value="">Select a time</option>
                                    <option value="30">30 Minutes</option>
                                    <option value="60">1 Hour</option>
                                    <option value="120">2 Hour</option>
                                    <option value="180">3 Hour</option>
                                    <option value="240">4 Hour</option>
                                    <option value="300">5 Hour</option>
                                    <option value="360">6 Hour</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="container no-padding">
        <div class="row no-padding">
            <div class="col-lg-12 no-padding">
                <div id="myCarousel" class="carousel slide" data-ride="carousel">


                    <div class="carousel-inner" role="listbox">
                        <div class="item active">
                            <div class="featured-partners">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-01.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-02.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-03.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="featured-partners">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-01.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-02.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-03.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Left and right controls -->
                    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'guest_checkout_modals.php'; ?>
<script>
    $("#homes").attr('checked', 'checked');
    $("#homes").click(function () {
        $("#house_div").hide();
        $("#number").attr("placeholder", "House Number");
    });
    $("#buildings").click(function () {
        $("#number").attr("placeholder", "Building Number");
        $("#house_div").show();
    });
    $("#offices").click(function () {
        $("#number").attr("placeholder", "Office Number");
        $("#house_div").show();
    });
</script>
<script type="text/javascript">

    function DropDown(el) {
        this.dd = el;
        this.placeholder = this.dd.children('span');
        this.opts = this.dd.find('ul.dropdown > li');
        this.val = '';
        this.index = -1;
        this.initEvents();
    }
    DropDown.prototype = {
        initEvents: function () {
            var obj = this;
            obj.dd.on('click', function (event) {
                $(this).toggleClass('active');
                return false;
            });
            obj.opts.on('click', function () {
                var opt = $(this);
                obj.val = opt.text();
                obj.index = opt.index();
                obj.placeholder.text(obj.val);
            });
        },
        getValue: function () {
            return this.val;
        },
        getIndex: function () {
            return this.index;
        }
    }

    $(function () {

        var dd = new DropDown($('#dd'));
        $(document).click(function () {
            // all dropdowns
            $('.wrapper-dropdown-1').removeClass('active');
        });
    });</script>
<script>
    $("#house").attr('checked', 'checked');
    $("#delivery").click(function () {
        if (($('#some_time').prop('checked'))) {
            $('.time').show();
        }
        $(".time_div").show();
        $(".address").hide();
    });
    $("#pickup").click(function () {
        $(".time_div").hide();
        $(".time").hide();
        $(".address").show();
    });
    $("#some_time").click(function () {
        $(".time").show();
    });
    $("#standard_time").click(function () {
        $(".time").hide();
    });</script>
<script>

    var base_url = '<?= base_url() ?>';
    $("#credit_card").click(function () {
        $('.without_split').show();
        $('.without_split').removeClass('disabled');
        $('.without_split').attr('disabled', false);
        $('.split').hide();
    });
    $("#debit_card").click(function () {
        $('.without_split').show();
        $('.without_split').removeClass('disabled');
        $('.without_split').attr('disabled', false);
        $('.split').hide();
    });
    $("#cod").click(function () {
        $('.without_split').show();
        $('.without_split').removeClass('disabled');
        $('.without_split').attr('disabled', false);
        $('.split').hide();

    });
    $("#split_payment").click(function () {
        var guest_name = $("#guest_name").val();
        var guest_address = $("#guest_address").val();
        var guest_contact = $("#guest_contact").val();
        var guest_email = $("#guest_email").val();
        var guest_other_info = $("#guest_other_info").val();
        var payment_method_id_val = $('input[name=payment_method_id]:checked').val();
        var split_points_used = $(".points_used_val").val();
        var delievery_pickup_val = $('input[name=delivery_pickup]:checked').val();
        if (delievery_pickup_val == '0') {
            var order_time_val = $('input[name=order_time]:checked').val();
            if (order_time_val == '1') {
                var order_time_val = $('#delivery_pickup_time_val').val();
            }
        } else {
            var pickup_address_id_val = $('.pickup_address_id_val').val();
        }

        if (guest_name != "" && guest_address != "" && guest_contact != "" && guest_contact.length==8) {
            $('#guest_name_val').val(guest_name);
            $('#guest_address_val').val(guest_address);
            $('#guest_contact_val').val(guest_contact);
            $('#guest_email_val').val(guest_email);
            $('#guest_other_info_val').val(guest_other_info);
            $('#payment_method_id_val').val(payment_method_id_val);
            $('#split_points_used').val(split_points_used);
            $('#delievery_pickup_val').val(delievery_pickup_val);
            $('#pickup_address_id_val').val(pickup_address_id_val);
            $('#order_time_val').val(order_time_val);
            $('#admin_phone_no').val(guest_contact);
            $('.without_split').hide();
            $('.split').show();
        } else {
            $("#credit_card").trigger('click');
            toastr.error('Please fill guest details');
        }

    });
    $('.checkout_rest_items').on('click', ".btn-remove", function () {

        post_array =
        {
            "row_id": $(this).attr('value'),
            "qty": '0'
        }
        $.post(base_url + "main/update_cart", post_array,
            function (data) {
                var res = jQuery.parseJSON(data);
                if (res.status == 'OK') {
                    updateCheckoutCart(res.cart_view, res.total_cost, res.items_count);
                    if (typeof res.msg != 'undefined') {
                        toastr.warning(res.msg);
                    }
                } else {
                    toastr.error('No item in Cart');
                    window.location.href = '<?=base_url() ?>main/search_result';
                }
            });
    });


</script>
<script>
    function check_action() {
        var payment_method = $('input[name=payment_method_id]:checked').val();

        $('#guest_checkout').formValidation('validate');

        if (!$('#guest_checkout').data('formValidation').isValid()) {
            $("html, body").animate({ scrollTop: $('#guest_name').offset().top-200}, "slow");
            return false;
        } else {
            if (payment_method == 2) {
                document.checkoutdata.action = "<?php echo base_url() ?>main/guest_cod_checkout";
                document.checkoutdata.submit();
                return true;
            } else if(payment_method == 1){
                document.checkoutdata.action = "<?php echo base_url() ?>main/guest_payment_checkout";
                document.checkoutdata.submit();
                return true;
            }else {
                $('.split').show();
            }

        }


    }

</script>
<script>
    $(document).ready(function () {
        $(".split").click(function () {
            $('#split').modal('show');
        });

        $(document).on('click', '.voucher_btn', function (e) {

            var vou_code = $('#' + $(this).val()).val();
            if (vou_code != '' && vou_code.length == 6) {
                $url = '<?= base_url() ?>main/apply_voucher';
                $data = 'voucher_code=' + $(this).attr('data') + '|' + vou_code;
                $.ajax({
                    url: $url,
                    type: "POST",
                    dataType: 'json',
                    data: $data,
                    success: function (data) {
                        if (data.status == 'OK') {
                            updateCheckoutCart(data.cart_view, data.total_cost, data.items_count);
                            toastr.success('Voucher Applied');
                        }
                        else if (data.status == 'NO_VOUCHER') {
                            toastr.error('Voucher code not found');
                        }
                        else if (data.status == 'MIN_ORDER') {
                            toastr.error('Order is less than the minimum amount for this Voucher');
                        }
                        else {
                            toastr.error('Error while applying voucher');
                        }
                    }
                });
            } else {
                toastr.error('Please enter a valid Voucher Code');
            }

        });
    });

    function updateCheckoutCart(cart, total, items_count) {
        $('.checkout_rest_items').empty();
        $('.cart_total').empty();
        $('#total_split_amount').empty();
        $('#split_amount_is').empty();
        $('.cartnum').empty();

        $('.checkout_rest_items').append(cart);
        $(".cart_total").append('KD ' + total);

        $('#total_split_amount').val(total);
        $('#split_amount_is').val(total);
        $(".split_model_val").val(total);
        $(".cartnum").append(items_count);

    }

    $("[name='delivery_pickup']").on('change',function(){
        if($(this).val()==1){
            var amount = "KD "+ (parseFloat($('#restaurant_total').html().trim(' ').replace("KD",'')) - parseFloat($('#delivery_cost').html())).toFixed(3);
            $("#restaurant_total").html(amount);
            $('.cart_total').html(amount);
            $('#delivery_cost').closest('tr').hide();
        }else{
            var amount = 'KD '+ (parseFloat($('#restaurant_total').html().trim(' ').replace("KD",'')) + parseFloat($('#delivery_cost').html())).toFixed(3);
            $("#restaurant_total").html(amount );
            $('.cart_total').html(amount );
            $('#delivery_cost').closest('tr').show();
        }
    });

</script>
