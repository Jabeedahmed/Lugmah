<style>
    .red_col {
        background-color: red;
    }

    .green_col {
        background-color: green;
    }
</style>
<link rel="stylesheet" href="<?= base_url() ?>css/app.css">
<div class="">
    <div class="container">
        <div class="row">

            <div class="col-lg-8 col-lg-offset-2">
                <form name="" id="" method="POST" action="<?= base_url() ?>main/my_account"
                      enctype="multipart/form-data" class="form-horizontal">
                    <!-- Modal content-->
                    <div class="col-lg-10 col-lg-offset-1">
                        <div class="con">
                            <div class="modal-header" style="background-color: white;">
                                <h4 class="modal-title center" style="color:#FFC000;">Split Your Payment</h4>
                            </div>
                            <div class="modal-header">
                                <h1 class="modal-title center" style="color:white;">Payment Status</h1>

                            </div>
                            <div class="modal-body" style="padding: 0px; ">
                                <div class="col-lg-12 margin">
                                    <div class="col-lg-12">
                                        <div class="form-group ajax_div_data">
                                            <?php
                                            $i = 1;
                                            if($split_data['status'] == 'active') {
                                                foreach ($split_data['users_status'] as $row) { ?>
                                                    <label class="col-lg-8 color_model" style="margin-top: 8px;"><span
                                                            class="circle"><?= $i ?></span>
                                                        &nbsp;&nbsp;<?= $row['number']; ?></label>
                                                    <div class="col-lg-2">
                                                    <span style=""
                                                          class="<?php if ($row['status'] == 'active') { ?>circle2 glyphicon glyphicon-remove red_col<?php } elseif($row['status'] == 'completed') { ?>circle2 glyphicon glyphicon-ok green_col<?php }elseif($row['status'] == 'expired') { ?>circle2 glyphicon glyphicon-remove red_col<?php }else { ?>circle2 glyphicon glyphicon-remove red_col<?php } ?>"></span>
                                                    </div>
                                                    <div class="clearfix" style="margin-top: 50px;"></div>
                                                    <hr>
                                                    <?php $i++;
                                                }
                                            }elseif($split_data['status'] == 'admin_link'){
                                            foreach ($split_data['users_status'] as $row) { ?>
                                                <label class="col-lg-8 color_model" style="margin-top: 8px;"><span
                                                        class="circle"><?= $i ?></span>
                                                    &nbsp;&nbsp;<?= $row['number']; ?></label>
                                                <div class="col-lg-2">
                                                    <span style=""
                                                          class="<?php if ($row['status'] == 'active') { ?>circle2 glyphicon glyphicon-remove red_col<?php } elseif ($row['status'] == 'completed') { ?>circle2 glyphicon glyphicon-ok green_col<?php } elseif ($row['status'] == 'expired') { ?>circle2 glyphicon glyphicon-remove red_col<?php } else { ?>circle2 glyphicon glyphicon-remove red_col<?php } ?>"></span>
                                                </div>
                                                <?php if($row['status'] == 'admin_link'){?>
                                                <div class="col-lg-2"><a href="<?=base_url() ?>main/split_transaction_payment?split_transaction_id=<?=$row['split_trans_id']; ?>">Pay Admin</a> </div><?php } ?>
                                                <div class="clearfix" style="margin-top: 50px;"></div>
                                                <hr>
                                                <?php $i++;
                                            }
                                            }?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer ">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top: 50px;">
                <hr>
                <div id="owl-demo1" class="owl-carousel text-center">
                    <?php
                    if (isset($banners)) {
                        foreach ($banners as $ban) {
                            ?>
                            <div class="item">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <a href="<?=$ban->link_type == 1? base_url() . 'restaurant/' . $ban->link_url . '?promo=1':$ban->link_url;?>" <?=$ban->link_type != 1? 'target="_blank"':''?>>
                                            <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;" alt="" class="responsive">
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                    }
                    ?>
                </div>

            </div>
        </div>
    </div>
</div>

<script>
   var split_id = '<?=$split_id; ?>';
</script>
<script>
function get_latest_split_status(split_id) {
        $('.ajax_div_data').empty();
        $url = '<?= base_url() ?>main/split_payment_status_ajax?split_id=' + split_id;
        $.ajax({
            type: 'POST',
            url: $url,
            dataType: 'json',
            success: function (data) {
                console.log(data);
                if(data.status == 'active'){
                    var x = 1;
                    $.each(data.users_status, function (key, item) {
                        if(item.status == 'active'){
                            var active_class = 'circle2 glyphicon glyphicon-remove red_col';
                        }else if(item.status == 'completed'){
                            var active_class = 'circle2 glyphicon glyphicon-ok green_col';
                        }else{
                            var active_class = 'circle2 glyphicon glyphicon-remove red_col';
                        }
                        var split_statuses = '<label class="col-lg-8 color_model" style="margin-top: 8px;">' +
                            '<span class="circle">'+x+'</span> &nbsp;&nbsp;'+item.number+'</label>' +
                            '<div class="col-lg-2">' +
                            '<span style="" class="'+active_class+'"></span>' +
                            ' </div>' +
                            '<div class="clearfix" style="margin-top: 50px;"></div>' +
                            '<hr>';
                        $(".ajax_div_data").append(split_statuses);
                        x = x + 1;
                    });
                }else if(data.status == 'admin_link'){
                    var x = 1;
                    $.each(data.users_status, function (key, item) {
                        if(item.status == 'active'){
                            var active_class = 'circle2 glyphicon glyphicon-remove red_col';
                        }else if(item.status == 'completed'){
                            var active_class = 'circle2 glyphicon glyphicon-ok green_col';
                        }else{
                            var active_class = 'circle2 glyphicon glyphicon-remove red_col';
                        }
                        var payment_status = '<label class="col-lg-10 color_model" style="margin-top: 8px;">' +
                            '<span class="circle">' + x + '</span>&nbsp;&nbsp;' + item.username_no + '</label>' +
                            '<div class="col-lg-2">' +
                            '<span class="' + status_class + '"></span>' +
                            '</div>' +
                            '<div class="clearfix" style="margin-top: 50px;"></div>' +
                            '<hr>';
                        $(".ajax_div_data").append(payment_status);
                        x = x + 1;
                    });
                }
            },complete: function (data){
                setTimeout(function () {
                    get_latest_status(split_id);
                }, 30000);
            }
    })
    }
    $(function () {
        get_latest_status(split_id);
    });
    function get_latest_split_status(split_id) {
        $url = '<?= base_url() ?>main/guest_split_status?split_id=' + split_id;
        $.ajax({
            type: 'POST',
            url: $url,
            dataType: 'json',
            success: function (data) {
                if(data.sp_status == '2'){
                    window.location.href = '<?=base_url() ?>main/place_guest_split_order_expire?split_id='+split_id+'';
                }
            },complete: function (data){
                setTimeout(function () {
                    get_latest_split_status(split_id);
                }, 30000);
            }
        })
    }
    $(function () {
        get_latest_split_status(split_id);
    });

</script>