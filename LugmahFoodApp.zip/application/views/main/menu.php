<style>
    .des {
        margin-top: 100px;
    }

    .des2 {
        position: fixed !important;
    }

    .nav-active {
        color: #ffc001 !important;
    }
</style>
<div class="content" style="padding: 2em 0;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="coverbox">
                    <img class="cover-img img-responsive" style="width: 1110px;height: 350px;"
                         src="<?= $restaurant_detail->cover_image_url; ?>"/>

                </div>
                <div class="col-lg-3 col-md-3 col-sm-3">
                    <img class="cover-thumbnail img-responsive clearfix" style="width: 236px;height: 236px;"
                         src="<?= $restaurant_detail->logo_url; ?>"/>
                </div>
                <div class="col-lg-5 col-md-5 col-sm-5" id="desc">
                    <div class="cover-title">
                        <div class="">
                            <p class="color-yellow  bold ">

                            <div class="col-lg-12 no-padding">
                                <span class="font24" style="letter-spacing: 2px"><?= $restaurant_detail->name; ?></span>
                            </div>
                            <div class="col-lg-12 no-padding">
                                <span class="star-group font24">
                                    <?php
                                    for ($i = 1; $i < 6; $i++) {
                                        if ($i <= $restaurant_detail->rating) {
                                            ?>
                                            <span class="glyphicon glyphicon-star" style="color:#FFC001;"></span>
                                        <?php } else { ?>
                                            <span class="glyphicon glyphicon-star-empty color-grey"></span>
                                            <?php
                                        }
                                    }
                                    ?>
                                </span>
                            </div>
                            <span class="color-grey"><?= $restaurant_detail->location; ?></span>

                            </p>
                            <?php
                            if (!empty($payment_methods)) {
                                foreach ($payment_methods as $methods) { ?>
                                    <img src="<?= $methods->image_url ?>" style="height:20px;width: 26px;">
                                <?php }
                            } ?>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 no-padding-right pull-right align-right">
                    <div class="cover-title cover-category">
                        <div class="itembox pull-right" style="text-align: right">
                            <p class="color-black font24 bold no-padding-right">
                                Restaurant Category
                            </p>
                            <span class="color-grey font16 no-padding-right"
                                  style="padding-bottom: 5px"><?= $restaurant_detail->type; ?></span><br/>

                            <div class="main_favorite">
                                <a href="" class="color-black font18 nodec">
                                    <?php if ($restaurant_detail->bookmark_status == 'NO') { ?>
                                        <i class="glyphicon glyphicon-heart color-grey"></i><a class="add_fvrt"
                                                                                               style="cursor: pointer;"
                                                                                               id="<?= $restaurant_id; ?>"> Add To
                                            Favorite</a> <?php }
                                    if ($restaurant_detail->bookmark_status == 'YES') { ?>
                                        <i class="glyphicon glyphicon-heart color-yellow"></i><a style="cursor: pointer;"
                                                                                                 class="add_fvrt"
                                                                                                 id="<?= $restaurant_id; ?>"> Remove
                                            Favorite</a>

                                    <?php } ?>
                                </a>
                            </div>
                            <span id="message" style="display: none;font-weight: 600;">&#10004;</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row" style="margin: 40px 0 20px;">
            <div class="col-lg-12" style="border-bottom: 1px solid #e5e5e5;">
                <div class="col-lg-3">
                    <div class="headingbox oswald-font round-corner-2">
                        Min Order KD <?= $restaurant_detail->min_order; ?>
                    </div>
                </div>
                <div class="col-lg-9">
                    <p class="cover-desc">
                        <?php
                        $text = $restaurant_detail->descript;
                        $limit = '210';
                        echo $y = substr($text, 0, $limit) . '...';

                        ?>
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-9 col-md-9 col-sm-12">
                <!--  START :: Menu-->
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 no-padding">
                    <a id="menu_head1" class="head-btn current-head menu_head" href="#menu" data-toggle="tab">
                        Menu
                    </a>
                </div>
                <!--  START :: Menu-->
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 no-padding">
                    <a class="head-btn review" href="#reviews" data-toggle="tab"
                       style="border-left: 2px solid #e5e5e5;border-right: 2px solid #e5e5e5;">
                        Reviews
                    </a>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 no-padding">
                    <a class="head-btn info" href="#info" data-toggle="tab">
                        Info
                    </a>
                </div>
                <div class="tab-content cati" id="sidebar">
                    <div class="tab-pane fade bg-white in active" id="menu">
                        <div class="col-lg-12 no-padding-left">
                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 no-padding ">
                                <div class="cat css3transition" id="cat_id">
                                    <a id="menu_head2" class="head-btn current-head hidden head_menu">
                                        Menu
                                    </a>

                                    <div id="nav-anchor"></div>
                                    <div class="navi">
                                        <ul class="list ">
                                            <li class="list-head">Menu Categories</li>
                                            <div class="slim_scroll_area" style="max-height: 300px;">
                                                <?php
                                                $iterator = 0;
                                                if (isset($categories)) {
                                                    foreach ($categories as $value) {
                                                        if (!empty($sub_categories[$iterator])) {
                                                            ?>
                                                            <li>
                                                                <a href="#<?php echo $value->category_id; ?>"><?php echo $value->category_name; ?></a>
                                                            </li>
                                                        <?php }
                                                        $iterator++; ?>
                                                        <!--  END :: Category item list-->
                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </div>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 no-padding-right">

                                <div class="list-banner">
                                    <div class="bottom_slider row no-padding ">
                                        <div class="">
                                            <div class="col-lg-12 center" style="">
                                                <div id="owl-demo2" class="owl-carousel text-center">
                                                    <?php
                                                    if (isset($banner_list)) {
                                                        foreach ($banner_list as $ban) {
                                                            ?>
                                                            <div class="item">
                                                                <div class="col-md-2 fet-part">
                                                                    <div class="feature-img-grid">
                                                                        <img src="<?= $ban->banner_url ?>"
                                                                             style="width: 500px;height: 120px; object-fit: cover;"
                                                                             alt=""
                                                                             class="">
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <?php if ($restaurant_detail->discount_type == 'voucher') { ?>
                                    <div class="adbox">
                                        <div class="big-txt">
                                        <span class="font40 color-yellow roborto bold">
                                            <?= (float)$restaurant_detail->discount ?>%<br/>
                                            OFF
                                        </span>
                                        </div>
                                        <div class="right-txt">
                                            <span class="font18"><?= (float)$restaurant_detail->discount ?>% Off, Use Code : <?= $restaurant_detail->promotion_code ?></span><br/>
                                        <span class="font14">
                                            Get <?= (float)$restaurant_detail->discount ?>% off on min. order values  KD <?= $restaurant_detail->voucher_min_amount ?> & Above .
                                        </span><br/>
                                        <span class="font12 color-grey">
                                            *terms and conditions apply
                                        </span>
                                        </div>
                                    </div>

                                <?php } else if ($restaurant_detail->discount_type == 'flat') { ?>
                                    <div class="adbox">
                                        <div class="big-txt">
                                        <span class="font40 color-yellow roborto bold">
                                          <?= (float)$restaurant_detail->discount ?>%<br/>
                                            OFF
                                        </span>
                                        </div>
                                        <div class="right-txt">
                                            <span class="font18">Flat <?= (float)$restaurant_detail->discount ?>% off</span><br/>
                                        <span class="font14">
                                            Get Flat <?= (float)$restaurant_detail->discount ?>% off on all items.
                                        </span><br/>
                                        </div>
                                    </div>
                                <?php } ?>
                                <!--  START :: Category item list-->
                                <?php
                                $iterator = 0;
                                if (isset($categories)) {
                                    foreach ($categories as $value) { ?>
                                        <div id="<?php echo $value->category_id; ?>">
                                            <?php if (!empty($sub_categories[$iterator])) {
                                                ?>

                                                <div class="headingbox mt10 heading_cat">
                                                    <?php echo $value->category_name; ?>
                                                </div>
                                            <?php } ?>
                                            <?php for ($j = 0; $j < sizeof($sub_categories[$iterator]); $j++) { ?>
                                                <div class="innerbox">
                                                    <div class="col-lg-12 no-padding">

                                                        <input type="hidden"
                                                               id='name-<?= $sub_categories[$iterator][$j]->id; ?>'
                                                               value="<?= $sub_categories[$iterator][$j]->name; ?>">
                                                        <input type="hidden"
                                                               id='price-<?= $sub_categories[$iterator][$j]->id; ?>'
                                                               value="<?= number_format($sub_categories[$iterator][$j]->price, 3); ?>">
                                                        <input type="hidden"
                                                               id='qty-<?= $sub_categories[$iterator][$j]->id; ?>'
                                                               value="1">
                                                        <input type="hidden"
                                                               id='id-<?= $sub_categories[$iterator][$j]->id; ?>'
                                                               value="<?= $sub_categories[$iterator][$j]->id; ?>">
                                                        <input type="hidden"
                                                               id='restid-<?= $sub_categories[$iterator][$j]->id; ?>'
                                                               value="<?= $restaurant_id; ?>">

                                                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 no-padding imgbox">
                                                            <div class="thumb">
                                                                <img class="img-thumb"
                                                                     src="<?php echo $sub_categories[$iterator][$j]->image_url; ?>"/>
                                                            <span><img style="height:265px;width:265px;"
                                                                       src="<?php echo $sub_categories[$iterator][$j]->image_url; ?>"/></span>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-5 col-lg-5 col-sm-5 col-xs-5">
                                                            <div class="itembox ">
                                                                <a class="item-name font18 color-black item_detail"
                                                                   data-toggle="modal"><?php echo $sub_categories[$iterator][$j]->name; ?></a><br/>
                                                            <span
                                                                class="item-desc"><?php echo $sub_categories[$iterator][$j]->description; ?></span>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 no-padding-left">
                                                            <div id="itemdiv-<?= $sub_categories[$iterator][$j]->id; ?>"
                                                                 class="itembox">

                                                                <?php if ($sub_categories[$iterator][$j]->fav_status == 'NO') { ?>
                                                                    <i class="glyphicon glyphicon-heart favorit-icon color-yellow"></i>
                                                                    <a style="cursor: pointer;"
                                                                       class="favorit-text item_fvrt"
                                                                       id="<?= $sub_categories[$iterator][$j]->id; ?>-<?= $restaurant_id; ?>">Add
                                                                        To Favorite</a>
                                                                <?php } else { ?>
                                                                    <i class="glyphicon glyphicon-heart favorit-icon "
                                                                       style="color: grey;"></i> <a style="cursor: pointer;"
                                                                                                    class="favorit-text item_fvrt"
                                                                                                    id="<?= $sub_categories[$iterator][$j]->id; ?>-<?= $restaurant_id; ?>">Remove
                                                                        Favorite</a>
                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 no-padding">
                                                            <div class="itembox">
                                                            <span
                                                                class="item-title font18">KD <?= number_format($sub_categories[$iterator][$j]->price, 3); ?></span>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 no-padding">
                                                            <div class="itembox">
                                                                <a class="add_cart_modal" style="cursor: pointer;"
                                                                   value='<?= $sub_categories[$iterator][$j]->id; ?>'>
                                                                    <img src="<?= base_url() ?>img/icons/add_to_cart.png"/>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php }
                                            $iterator++; ?>
                                            <!--  END :: Category item list-->
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                            </div>
                            <!--  END :: Category item list-->
                        </div>
                    </div>
                    <div class="tab-pane fade bg-white in" id="reviews">
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 no-padding">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xm-3 big-star pull-left">
                                        <i class="glyphicon glyphicon-star"></i>
                                        <span class="font16"><?= $restaurant_detail->rating; ?></span>
                                    </div>
                                    <div class="col-lg-9 col-md-9 col-sm-9 col-xm-9 col-xm-9">
                                        <img class="review-stars" src="<?= base_url() ?>img/icons/review-stars.jpg"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                                <form id="reviews_validate"
                                      class="form-horizontal raleway-font"
                                      action="<?= base_url() ?>main/add_restaurant_review/<?php echo $slug; ?>"
                                      method="POST">
                                    <fieldset>
                                        <input type="hidden" name="restaurant_id" value="<?= $restaurant_id ?>">
                                        <!-- Form Name -->
                                        <p class="color-grey font16 mt10 bold mb10">All fields are mandatory</p>

                                        <!-- Text input-->
                                        <div class="form-group review-field" style="margin-bottom: 2px!important">
                                            <label class="col-md-3 control-label txt-left font16 color-grey"
                                                   for="review_title">Review Title</label>

                                            <div class="col-md-9">
                                                <input id="review_title" name="title" type="text" placeholder=""
                                                       class="form-control input-md">

                                            </div>
                                        </div>

                                        <!-- Textarea -->
                                        <div class="form-group review-field" style="margin-bottom: 2px!important">
                                            <label class="col-md-3 control-label txt-left font16 color-grey"
                                                   for="you_review">You Review</label>

                                            <div class="col-md-9">
                                                <textarea class="form-control" id="you_review" name="review"
                                                          rows="10"></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group review-field">
                                            <label class="col-md-3 control-label txt-left font16 color-grey"
                                                   for="review_title">Your Review</label>

                                            <div class="col-md-9">
                                                <span class="star-group rating">
                                                    <input type="radio" id="star5" name="rating" value="5"/><label
                                                        for="star5" title="Rocks!">5 stars</label>
                                                    <input type="radio" id="star4" name="rating" value="4"/><label
                                                        for="star4" title="Pretty good">4 stars</label>
                                                    <input type="radio" id="star3" name="rating" value="3"/><label
                                                        for="star3" title="Meh">3 stars</label>
                                                    <input type="radio" id="star2" name="rating" value="2"/><label
                                                        for="star2" title="Kinda bad">2 stars</label>
                                                    <input type="radio" id="star1" name="rating" value="1"/><label
                                                        for="star1" title="Sucks big time">1 star</label>
                                                </span>
                                                <span
                                                    class="color-grey font14 rate">(Click to rate on scale of 1-5) </span>

                                            </div>
                                        </div>

                                        <!-- Button -->
                                        <div class="form-group">
                                            <div class="col-md-4 no no-padding-left txt-left">
                                                <input type="submit" name="review_submit_form"
                                                       class="btn btn-info review-btn oswald-font bold" value="SUBMIT">
                                            </div>
                                        </div>

                                    </fieldset>
                                </form>


                            </div>
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12">

                                    <div class="reviewbox">
                                        <h3 class="raleway-font">Reviews of <?= $restaurant_detail->name; ?></h3>
                                        <?php if (!empty($restaurant_all_comments)) { ?>
                                            <?php foreach ($restaurant_all_comments as $reviews) { ?>
                                                <div class="review-item">
                                                    <div class="review-item-inner">
                                                        <p class="raleway-font color-yellow mb10 bold"><?= $reviews->date ?></p>

                                                        <p class="raleway-font mb10">
                                    <span class="star-group">
                                    <?php
                                    for ($i = 1; $i < 6; $i++) {
                                        if ($i <= $reviews->rating) {
                                            ?>
                                            <span class="glyphicon glyphicon-star" style="color:#FFC001;"></span>
                                        <?php } else { ?>
                                            <span class="glyphicon glyphicon-star-empty color-grey"></span>
                                            <?php
                                        }
                                    }
                                    ?>
                                </span>
                                                            <span
                                                                class="color-grey"> by <?= $reviews->first_name ?> <?= $reviews->last_name ?></span>
                                                        </p>

                                                        <p>
                                                            <?= $reviews->comment ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            <?php }
                                        } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade bg-white in" id="info">
                        <div class="clearfix">
                            <div class="col-lg-12">
                                <div class="infoinner" style="border-bottom: 1px solid #e5e5e5;padding: 20px;">
                                    <p class="font24 color-grey">
                                        <?= $restaurant_detail->name; ?>
                                    </p>

                                    <p class="roborto color-black font14 bold mb10">
                                        <?= $restaurant_detail->type; ?>-<?= $restaurant_detail->location; ?>
                                    </p>

                                    <p class="color-grey font16 pb15">
                                        <?= $restaurant_detail->descript; ?>
                                    </p>
                                </div>
                                <div class="row pb15" style="border-bottom: 1px solid #e5e5e5">
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 no-padding-left">
                                        <p class="color-yellow font18 mt20">Delivery Hours</p>
                                        <table class="info-table">
                                            <?php foreach ($restaurant_timing as $timing) { ?>
                                                <tr>
                                                    <td><i><?= $timing->day; ?></i></td>
                                                    <td><i><?= $timing->start_time; ?>-<?= $timing->end_time; ?></i>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        </table>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 no-padding-left">
                                        <p class="color-yellow font18 mt20">Delivery Fees</p>

                                        <p class="color-grey">
                                            KD <?= $restaurant_detail->delivery_charges; ?>
                                        </p>

                                        <p class="color-yellow font18 mt20">Discount</p>

                                        <p class="color-grey"><?= $restaurant_detail->discount; ?></p>

                                        <p class="color-yellow font18 mt20">Delivery Time</p>

                                        <p class="color-grey"><?= $restaurant_detail->delivery_time; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--  START :: Your Order-->
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 no-padding-left clearfix" id="sidebar">
                <div class="menu css3transition" id="menu_id">
                    <div class="headingbox">
                        Your Order
                    </div>
                    <div class="orderbox slim_scroll_area" style="max-height: 300px;">

                        <div class="orderbox-inner">


                            <div class="mt10"></div>
                            <!--  START :: cart item list-->
                            <div class="main_cart_item_div">
                                <?php if (isset($cart_view)) {
                                    echo $cart_view;
                                } ?>
                            </div>
                            <!--  END :: cart item list-->
                        </div>
                    </div>

                    <div class="menu_buttons" <?php if (!isset($items_count)) {
                        ; ?> style="display: none;" <?php } else {
                    } ?> >
                        <div class="orderboxdet">
                            <div class="orderboxdet-inner">
                                <span class="color-grey bold font12 ">Total will be rounded off</span>
                            </div>
                            <div class="orderboxdet-inner">
                                <span class="color-black bold font18">Total</span>
                                <span class="color-black bold font18 pull-right" id="cart_total">KD <?php
                                    if (!isset($items_count)) {
                                        echo '0';
                                    } else {
                                        echo number_format($total_cost, 3, '.', '');
                                    }
                                    ?></span>
                            </div>
                        </div>
                        <a class="btn2 btn2-black" href="<?= base_url() ?>main/search_result/">Try another Restaurant<i
                                style="top: 0px" class="glyphicon glyphicon-chevron-right"></i> </a><br/>
                        <a class="btn2 btn2-yellow checkout  proceed_to_checkout" style="cursor: pointer;margin-top: 5px;font-size: 18px">Proceed to
                            checkout <i style="top: 0px" class="glyphicon glyphicon-chevron-right"></i> </a>

                    </div>
                </div>
            </div>
        </div>
        <!--  END :: Your Order-->
    </div>
</div>
<div class="bottom_slider container no-padding mt40">
    <div class="row no-padding">
        <div class="col-lg-12 no-padding">
            <hr>
            <div id="owl-demo1" class="owl-carousel text-center">
                <?php
                if (isset($banners)) {
                    foreach ($banners as $ban) {
                        ?>
                        <div class="item">
                            <div class="col-md-4 fet-part">
                                <div class="feature-img-grid">
                                    <a href="<?= $ban->link_type == 1 ? base_url() . 'restaurant/' . $ban->link_url . '?promo=1' : $ban->link_url; ?>" <?= $ban->link_type != 1 ? 'target="_blank"' : '' ?>>
                                        <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;" alt="" class="responsive">
                                    </a>
                                </div>
                            </div>
                        </div>

                        <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>
</div>
<br/>
</div>
<div id="add_cart_modal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <form name="" id="" method="POST" action="" enctype="multipart/form-data" class="form-horizontal">
            <!-- Modal content-->
            <div class="container">
                <div class="col-lg-8 col-lg-pull-1">
                    <div class="con">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title center" style="color:white;">Your Choices</h4>
                        </div>
                        <div class="modal-body item_attr_div_model" style="     padding: 0px; ">
                        </div>
                        <span class=" validate_checkbox" style="margin-left: 25px;"></span>

                        <div class="modal-footer center">
                            <button class="btn btn-simple lognow add_attribute_to_cart" style="margin-top:20px;" onclick="return false">
                                Add To Cart
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script>

    $('.info').on('click', function () {

        $('.cat').addClass("des2");

    });
    $('.review').on('click', function () {

        $('.cat').addClass("des2");

    });
    $('.menu_head').on('click', function () {
        $('.cat').removeClass("des2");
        $('.head_menu').css("color", "white");

    });
    $(document).ready(function ($) {
        function adjustStyle(width) {
            width = parseInt(width);
            if (width < 901) {
                $("#menu_id").css("position", "relative");
                $('#sidebar').removeAttr('id');
                $("#desc").addClass("des");
                $("#cat_id").css("position", "relative");
            } else {
                $(".menu").addClass("css3transition");
                $("#desc").removeClass("des");
                $(".cat").addClass("css3transition");
            }
        }

        $(function () {
            adjustStyle($(this).width());
            $(window).resize(function () {
                adjustStyle($(this).width());
            });
        });
    });
</script>
<script type="text/javascript">
    var distance = $('#menu_head1').offset().top,
        $window = $(window);
    $window.scroll(function () {
        if ($(window).width() >= 1199) {
            if ($window.scrollTop() >= distance) {
                $('#menu_head1').addClass('hidden');
                $('#menu_head2').removeClass('hidden');
            } else if ($window.scrollTop() <= distance) {
                $('#menu_head1').removeClass('hidden');
                $('#menu_head2').addClass('hidden');
            }
        }
    });

    var base_url = '<?= base_url() ?>';

    $('.head-btn').on('click', function () {
        $('.head-btn').removeClass('current-head');
        $(this).addClass('current-head');
    });

    $('.orderbox').on('click', ".add-qty", function () {
        $('.whole_div').show();
        var it_rid = $(this).attr('value');
        var it_qty = parseInt($('#' + it_rid).attr('value'), 10) + 1;


        post_array =
        {
            "row_id": it_rid,
            "qty": it_qty
        };

        $.post(base_url + "main/update_menu_cart", post_array,
            function (data) {
                var res = jQuery.parseJSON(data);
                update_cart_items(res.cart_view, res.total_cost, res.items_count);

                $('.whole_div').hide();


            });


    });

    $('.orderbox').on('click', ".sub-qty", function () {
        $('.whole_div').show();
        var it_rid = $(this).attr('value');
        var it_qty = parseInt($('#' + it_rid).attr('value'), 10) - 1;


        post_array =
        {
            "row_id": it_rid,
            "qty": it_qty
        };

        $.post(base_url + "main/update_menu_cart", post_array,
            function (data) {
                var res = jQuery.parseJSON(data);
                update_cart_items(res.cart_view, res.total_cost, res.items_count);
                $('.whole_div').hide();
            });


    });

    function update_cart_items(cart, total, items_count) {
        $('.main_cart_item_div').empty();
        $('#cart_total').empty();
        $('#cart_sub_total').empty();
        $('.cartnum').empty();
        if (cart != null) {
            $(".main_cart_item_div").append(cart);
        } else {
            $('.whole_div').hide();
        }
        if (total != undefined) {
            $("#cart_total").append('KD ' + total);
        } else {
            $("#cart_total").append('KD 0');
        }
        $(".yesh").click(function () {
            $('#no-item').modal('show');
        });
        if (items_count == undefined) {
            $(".menu_buttons").hide();
            $("#itemed").removeAttr("href");
            $(".yesh").css("cursor", "pointer");
            $(".cartnum").append('0');


        } else if (items_count != 0 && items_count != undefined) {
            $('#no-item').remove();
            $(".menu_buttons").show();
            $("#itemed").attr("href", base_url + "main/checkout");
            $(".cartnum").append(items_count);
        }

    }

</script>
<script src="<?= base_url() ?>js/jquery.lockfixed.js"></script>
<script>
    (function ($) {
        $.lockfixed("#sidebar .cat", {offset: {top: 90, bottom: 620}});
        $.lockfixed("#sidebar .menu", {offset: {top: 90, bottom: 620}});
    })(jQuery);
</script>
<script src='<?= base_url() ?>js/jquery.scrollto.js'></script>
<script>
    $(document).ready(function () {
        $(window).scroll(function () {
            var window_top = $(window).scrollTop() + 12; // the "12" should equal the margin-top value for nav.stick
            var div_top = $('#nav-anchor').offset().top;
            if (window_top > div_top) {
                $('.navi').addClass('stick');
            } else {
                $('.navi').removeClass('stick');
            }
        });

        $(".navi a").click(function (evn) {
            debugger
            evn.preventDefault();
            $('html,body').scrollTo($(this.hash).offset().left, $(this.hash).offset().top - 90);
        });
        var aChildren = $(".navi li").children(); // find the a children of the list items
        var aArray = []; // create the empty aArray
        for (var i = 0; i < aChildren.length; i++) {
            var aChild = aChildren[i];
            var ahref = $(aChild).attr('href');
            aArray.push(ahref);
        } // this for loop fills the aArray with attribute href values

        $(window).scroll(function () {
            var windowPos = $(window).scrollTop(); // get the offset of the window from the top of page
            var windowHeight = $(window).height(); // get the height of the window
            var docHeight = $(document).height();

            for (var i = 0; i < aArray.length; i++) {
                var theID = aArray[i];
                var divPos = $(theID).offset().top - 100; // get the offset of the div from the top of page
                var divHeight = $(theID).height(); // get the height of the div in question
                if (windowPos >= divPos && windowPos < (divPos + divHeight)) {
                    $("a[href='" + theID + "']").addClass("nav-active");
                } else {
                    $("a[href='" + theID + "']").removeClass("nav-active");
                }
            }

            if (windowPos + windowHeight == docHeight) {
                if (!$(".navi li:last-child a").hasClass("nav-active")) {
                    var navActiveCurrent = $(".nav-active").attr("href");
                    $("a[href='" + navActiveCurrent + "']").removeClass("nav-active");
                    $(".navi li:last-child a").addClass("nav-active");
                }
            }
        });
        $('.main_favorite').on('click', '.add_fvrt', function (e) {
            var rest_id = encodeURIComponent($(this).attr('id'));

            $('.main_favorite').empty();
            $url_login = '<?= base_url() ?>main/login/';
            $url = '<?= base_url() ?>main/bookmark_restaurant/';
            $data = 'rest_id=' + rest_id;
            $.ajax({
                url: $url,
                type: "POST",
                dataType: 'json',
                data: $data,
                success: function (data) {
                    if (data == 'login') {
                        location.href = $url_login;
                    } else if (data == 'Added') {
                        var fvrt = '<i class="glyphicon glyphicon-heart color-yellow"></i><a class="add_fvrt" id="' + rest_id + '" style="cursor: pointer;">Remove Favorite</a>';

                        $('.main_favorite').append(fvrt);
                        $("#message").show().delay(5000).fadeOut();
                    } else if (data == 'Updated') {
                        var fvrt = ' <i class="glyphicon glyphicon-heart"></i><a class="add_fvrt" id="' + rest_id + '" style="cursor: pointer;">Add To Favorite</a>';

                        $('.main_favorite').append(fvrt);
                        $("#message").show().delay(5000).fadeOut();
                    }
                }
            });


        });
        $('.itembox').on('click', '.item_fvrt', function (e) {
            var ids = encodeURIComponent($(this).attr('id'));
            var split_ids = ids.split("-");
            var item_id = split_ids[0];
            var rest_id = split_ids[1];
            $('#itemdiv-' + item_id).empty();
            $url_login = '<?= base_url() ?>main/login/';
            $url = '<?= base_url() ?>main/bookmark_menu_item/';
            $data = 'rest_id=' + rest_id + '&item_id=' + item_id;
            $.ajax({
                url: $url,
                type: "POST",
                dataType: 'json',
                data: $data,
                success: function (data) {
                    if (data == 'login') {
                        location.href = $url_login;
                    } else if (data == 'Added') {
                        var fvrt = '<i class="glyphicon glyphicon-heart favorit-icon" style="color: grey;"></i> <a style="cursor: pointer;" class="favorit-text item_fvrt" id="' + item_id + '-' + rest_id + '">Remove Favorite</a>';

                        $('#itemdiv-' + item_id).append(fvrt);
//                    $("#message").show().delay(5000).fadeOut();
                    } else if (data == 'Updated') {
                        var fvrt = '<i class="glyphicon glyphicon-heart favorit-icon color-yellow" ></i><a style="cursor: pointer;" class="favorit-text item_fvrt" id="' + item_id + '-' + rest_id + '">Add To Favorite</a>';

                        $('#itemdiv-' + item_id).append(fvrt);
//                    $("#message").show().delay(5000).fadeOut();
                    }
                }
            });

        });

    });
</script>
<script src="<?= base_url() ?>js/jquery.slimscroll.min.js"></script>
<script type="text/javascript">
    $(function () {
        $('.slim_scroll_area').slimscroll({
            disableFadeOut: true,
            height: ''
        });
    });
    $(document).on('click', '.proceed_to_checkout', function (e) {
        $url = '<?= base_url() ?>main/check_minimum_order';
        $.ajax({
            url: $url,
            type: "POST",
            success: function (data) {
                if (data != null) {
                    var rest = jQuery.parseJSON(data);
                    if (rest.proceed_result == 1) {
                        toastr.error('Your Order is Less Then The Minimum Order in ' + rest.name);
                    } else if (rest.proceed_result == 2) {
                        toastr.error('No item in Cart');
                    } else {
                        var url = '<?= base_url() ?>main/checkout';
                        window.location.href = url;
                    }
                } else {
                    toastr.error('No item in Cart');
                }
            }
        });
    });


    $(document).on('click', '.add_cart_modal', function (e) {
        $('.item_attr_div_model').empty();
        var it_val = $(this).attr('value');
        $data = 'item_id=' + it_val;
        var rest_id = $("#restid-" + it_val).val();
        $url = '<?= base_url() ?>main/get_item_attributes';
        $.ajax({
            url: $url,
            type: "POST",
            dataType: 'json',
            data: $data,
            success: function (data) {
                if (data.item_options != null && data.group_attrib == '1') {
                    var item_group_data = '';
                    $.each(data.item_options, function (key, item) {
                        var item_attrib = '';
                        if (item.attributes != null) {
                            $.each(item.attributes, function (key, it_attrbues) {
                                item_attrib += '<div class="col-lg-4" style="margin-top: 10px;">' +
                                    '<div class="checkbox">' +
                                    '<input id="' + it_attrbues.name + '" type="checkbox" value="' + it_attrbues.id + '" class="options_ids" name="options[]" style="margin-right:5px">' +
                                    '<label style="padding-left: 25px;" class="label-radio oswald-font bold font22"for="' + it_attrbues.name + '">' + it_attrbues.name + ' (' + it_attrbues.price + ')</label>' +
                                    '</div>' +
                                    '</div>';
                            });
                        }
                        if (item.attributes != null) {
                            item_group_data += '<div class="col-lg-12 " style="margin-top:20px;">' +
                                '<h5 style="background-color: aliceblue;padding: 15px;"><b>' + item.group_name + '</b></h5>' +
                                '' + item_attrib + '</div>';
                        }
                    });
                    var item_attr_display = '<div>' +
                        '<div class="col-lg-12 center" style="margin-top:20px;">' +
                        '<div class="col-lg-8">' +
                        '<input name="item_id" id="attr_item_id" type="hidden" value="' + data.item_id + '" >' +
                        '<input name="item_name" id="attr_item_name" type="hidden" value="' + data.item_name + '" >' +
                        '<input name="item_price" id="attr_item_price" type="hidden" value="' + data.item_price + '" >' +
                        '<input name="rest_id" id="attr_rest_id" type="hidden" value="' + rest_id + '" >' +
                        '<h4 class="pull-left" style="color: #FFC000;margin-bottom: 10px;">' + data.item_name + '</h4><div class="clearfix"></div>' +
                        '<h6 style="text-align:left;float: left;">' + data.item_description + '</h6>' +
                        '</div>' +
                        '<div class="col-lg-4">' +
                        '<h4 style="color: #FFC000;margin-bottom: 10px;">Price</h4>' +
                        '<h5><span class="item-title font18">KD <span class="item-title font18">' + data.item_price + ' </span></span>' +
                        '</h5>' +
                        '</div>' +
                        '</div>' + item_group_data + '</div>';
                    $('.item_attr_div_model').append(item_attr_display);
                    $('#add_cart_modal').modal('show');
                } else {
                    var attribute_ids = '';
                    post_array =
                    {
                        "item_id": $("#id-" + it_val).val(),
                        "item_name": $('#name-' + it_val).val(),
                        "item_qty": $("#qty-" + it_val).val(),
                        "item_price": $("#price-" + it_val).val(),
                        "rest_id": $("#restid-" + it_val).val(),
                        "attribute_ids": attribute_ids
                    }
                    $.post(base_url + "main/add_item_to_cart", post_array,
                        function (data) {
                            var res = jQuery.parseJSON(data);
                            update_cart_items(res.cart_view, res.total_cost, res.items_count);
                            $('.whole_div').hide();
                        });
                }
            }
        });
    });

    $(document).on('click', '.add_attribute_to_cart', function (e) {
        $('.validate_checkbox').empty();
        $('.whole_div').show();
        var attr_item_id = $('#attr_item_id').attr('value');
        var item_qty = $("#qty-" + attr_item_id).val()
        var attr_item_name = $('#attr_item_name').attr('value');
        var attr_item_price = $('#attr_item_price').attr('value');
        var attr_rest_id = $('#attr_rest_id').attr('value');
        var attribute_ids = $('input:checkbox:checked.options_ids').map(function () {
            return this.value;
        }).get().join(",");
        $url = '<?= base_url() ?>main/add_item_to_cart';
        $data = 'attribute_ids=' + attribute_ids + '&item_id=' + attr_item_id + '&item_name=' + attr_item_name + '&item_price=' + attr_item_price + '&rest_id=' + attr_rest_id + '&item_qty=' + item_qty;
        $.ajax({
            url: $url,
            type: "POST",
            dataType: 'json',
            data: $data,
            success: function (data) {
                update_cart_items(data.cart_view, data.total_cost, data.items_count);
                $('#add_cart_modal').modal('toggle');
                $('#add_cart_modal').hide();
            }
        });
    });
    <?php if ($this->input->get('promo')) { ?>
    $(document).ready(function () {
        $('.list a').each(function (index) {
            if ($(this).text() == 'Promotions' || $(this).text() == 'Promotion') {
                $('html,body').scrollTo($(this.hash).offset().left, $(this.hash).offset().top + 40);
            }
        });
    });
    <?php } ?>
</script>