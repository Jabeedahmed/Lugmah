<style>
    hr {
        margin-top: 0px !important;
    }
</style>
<script>
    var total_cost_split = "<?php echo $total_cost; ?>";
</script>
<link href="<?= base_url() ?>css/custom.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url() ?>css/custom-select/select.css" rel="stylesheet" type="text/css"/>
<div class="content" style="padding: 2em 0;">

    <div class="container">
        <form class="form-horizontal" id="checkout" name="checkoutdata" method="POST">
            <div class="col-lg-12">
                <div class="image" style="margin-bottom: 40px;">
                    <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                    <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                        <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/privacy-img.png"
                                                             style="width: 50px; height: 50px;"> </a>

                        <div class="media-body" style="padding-top: 7px;">
                            <h4 class="oswald-font bold">1. CHECKOUT</h4>

                            <p style="font-size:12px;font-style: italic;">Select Delivery address and payment type</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 mb60">
                    <div class="address-detailbox">
                        <span class="font24 mb10">Address Details</span>
                        <a style="cursor: pointer;" class="checkout-label pull-right add_address" data-toggle="modal">Add
                            New Address</a>

                        <div class="form-horizontal raleway-font mt40">
                            <div class="form-group">
                                <label class="col-md-2 control-label txt-left font14">Address</label>

                                <div class="col-md-10">
                                    <section class="main">
                                        <select class="wrapper-dropdown-1" id="change_address_user"
                                                name="select_address_id" required>
                                            <option value="">Select Address</option>
                                            <?php if ($this->ion_auth->logged_in()) { ?>
                                                <?php foreach ($address_info as $row) { ?>
                                                    <option
                                                        value="<?php echo $row->id; ?>"><?php echo $row->address_title; ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>

                                    </section>

                                </div>
                            </div>
                            <?php if ($this->ion_auth->logged_in()) { ?>
                                <div class="form-group mt40" style="margin-bottom: 0!important">
                                    <label class="col-md-2 control-label txt-left font14 no-padding-top">Full
                                        Name</label>

                                    <div class="col-md-10 color-grey">
                                        <?php echo $user->first_name ?>&nbsp;<?php echo $user->last_name ?>
                                    </div>
                                </div>
                                <div class="form-group" style="margin-bottom: 0!important">
                                    <label class="col-md-2 control-label txt-left font14 no-padding-top">Email</label>

                                    <div class="col-md-10 color-grey">
                                        <?php echo $user->email ?>
                                    </div>
                                </div>
                                <div class="form-group" style="margin-bottom: 0!important">
                                    <label class="col-md-2 control-label txt-left font14 no-padding-top">Mobile</label>

                                    <div class="col-md-10 color-grey">
                                        <?php echo $user->phone ?>
                                    </div>
                                </div>
                            <?php } ?>
                            <div class="show_address_det"></div>
                        </div>
                    </div>
                    <div class="col-lg-12 no-padding mt20">
                        <div class="image" style="margin-bottom: 40px;">
                            <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                            <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/privacy-img.png"
                                                                     style="width: 50px; height: 50px;"> </a>

                                <div class="media-body" style="padding-top: 7px;">
                                    <h4 class="oswald-font bold">2. YOUR ORDER</h4>

                                    <p style="font-size:12px;font-style: italic;">Make sure everything is as you
                                        wish</p>
                                </div>
                            </div>
                        </div>
                        <div class="checkout_rest_items">
                            <?= $cart_view ?>
                        </div>

                        <div class="clear-fix"></div>
                        <div class="form-horizontal raleway-font mt40 user_points_area">
                            <?= $points_view ?>
                        </div>
                        <div class="col-lg-12 no-padding mt20">
                            <div class="image" style="margin-bottom: 40px;">
                                <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                                <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                                    <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/privacy-img.png"
                                                                         style="width: 50px; height: 50px;"> </a>

                                    <div class="media-body" style="padding-top: 7px;">
                                        <h4 class="oswald-font bold">3. PAYMENT METHOD</h4>

                                        <p style="font-size:12px;font-style: italic;">Select Delivery address and
                                            payment
                                            type</p>
                                    </div>
                                </div>
                            </div>
                            <div style="padding: 10px 0 30px">
                                <div class="radio">
                                    <input id="credit_card" type="radio" name="payment_method_id" value="1" checked="">
                                    <label class="label-radio oswald-font bold font22" for="credit_card">Knet / Credit Card</label>

                                    <input id="cod" type="radio" name="payment_method_id" value="2">
                                    <label class="label-radio oswald-font bold font22" for="cod">COD</label>
                                    <input id="split_payment" type="radio" name="payment_method_id" value="4">
                                    <label class="label-radio oswald-font bold font22" for="split_payment">SPLIT
                                        PAYMENT</label>
                                </div>
                            </div>
                            <table class="checkout-table">
                            </table>


                            <table class="checkout-table mt40">
                                <tr style="background-color: #f2f2f2;border: none;">
                                    <td colspan="3" class="txt-right">
                                    <span class="color-yellow bold font16">
                                        GRAND TOTAL
                                    </span>
                                    </td>
                                    <td class="txt-right" style="    width: 170px;">
                                    <span class="color-yellow bold font16 pr20 cart_total">
                                         KD <?php
                                        if (!empty($total_cost)) {
                                            echo number_format($total_cost,'3','.','');
                                        } else {
                                            echo '0.000';
                                        }
                                        ?>
                                    </span>
                                    </td>
                                </tr>
                            </table>
                            <div class="pull-right mt20 raleway-font txt-right" style="display: inline;">
                                <p class="color-grey mb10"><i>Total will be round off</i></p>
                                <input type="button" class="btn4-yellow  without_split" name="checkout_trans"
                                       value="Checkout" onclick="return check_action();">
                                <button class="btn4-yellow split" style="display:none;">
                                    Checkout
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="headingbox">
                        Order Information
                    </div>
                    <div class="order-infobox append_data_order_info">
                        <div class="radio">
                            <input id="delivery" type="radio" name="delivery_pickup" checked value="0">
                            <label class="label-radio oswald-font bold font22" for="delivery">Delivery</label>

                            <p class="color-grey font12 pl25"><i>Your order will be delivered to your address</i></p>
                        </div>
                        <div class="radio">
                            <?php
                            if (!empty($restaurant)) {
                                if (sizeof($restaurant) > 1) { ?>
                                    <!--                                    <input id="pickup" type="radio" disabled name="delivery_pickup">-->
                                    <!--                                    <label class="label-radio oswald-font bold font22" for="pickup">Pickup</label>-->
                                    <!---->
                                    <!--                                    <p class="color-grey font12 pl25"><i>You will be pick up the order yourself at-->
                                    <!--                                            restaurant </i><strong></strong></p>-->
                                <?php } else { ?>
                                    <input id="pickup" type="radio" name="delivery_pickup" value="1">
                                    <label class="label-radio oswald-font bold font22" for="pickup">Pickup</label>

                                    <p class="color-grey font12 pl25"><i>You will be pick up the order yourself at
                                            restaurant </i><strong></strong></p>
                                <?php }
                            } ?>

                        </div>
                        <div class="time_div">
                            <hr/>
                            <div class="radio">
                                <input id="standard_time" type="radio" name="order_time" value="0" checked="">
                                <label class="label-radio oswald-font bold font22" for="standard_time">Standard
                                    Time</label>
                                <?php
                                if (!empty($restaurant)) {
                                    if (sizeof($restaurant) > 1) { ?>
                                        <p class="color-grey font12 pl25"><i>As Per Standard Delievery Time</i></p>
                                    <?php } else { ?>
                                        <p class="color-grey font12 pl25"><i>Estimated
                                                time: <?php if (!empty($restaurant)) {
                                                    echo $restaurant[0]->delivery_time;
                                                } ?> Min</i></p>
                                    <?php }
                                } ?>
                            </div>
                            <div class="radio">
                                <input id="some_time" type="radio" name="order_time" value="1">
                                <label class="label-radio oswald-font bold font22" for="some_time">After Some
                                    Time</label>
                            </div>
                        </div>
                        <div class="address" style="display:none;">
                            <hr/>
                            <p class="font12 txt-center mb10"> please select your Address</p>

                            <div class="form-group p15">
                                <select name="pickup_address_id" class="form-control pickup_address_id_val">
                                    <?php if (!empty($branches)) {
                                        ?>
                                        <?php foreach ($branches as $row) { ?>
                                            <option
                                                value="<?php echo $row['id']; ?>"><?php echo $row['branch_name']; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="time" style="display:none">
                            <hr/>
                            <p class="font12 txt-center mb10"> please select your desire time</p>

                            <div class="form-group p15">
                                <select name="delivery_pickup_time" id="delivery_pickup_time_val" class="form-control">
                                    <option value="">Select a time</option>
                                    <option value="30">30 Minutes</option>
                                    <option value="60">1 Hour</option>
                                    <option value="120">2 Hour</option>
                                    <option value="180">3 Hour</option>
                                    <option value="240">4 Hour</option>
                                    <option value="300">5 Hour</option>
                                    <option value="360">6 Hour</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php include 'checkout_modals.php'; ?>
<script>
    var base_url = "<?php echo base_url()?>";
    $(document).ready(function () {
        $("#Homes").attr('checked', 'checked');
        $("#Homes").click(function () {
            $("#house_div").hide();
            $("#number").attr("placeholder", "House Number");
            $("#house_div").find('input').prop('disabled', true);
        });
        $("#Buildings").click(function () {
            $("#number").attr("placeholder", "Building Number");
            $("#house_div").find('input').prop('disabled', false);
            $("#house_div").show();
        });
        $("#Offices").click(function () {
            $("#number").attr("placeholder", "Office Number");
            $("#house_div").find('input').prop('disabled', false);
            $("#house_div").show();
        });
        $(".add_address").click(function () {
            $('#add_address')[0].reset();
            $('#add_address').data('formValidation').resetForm();
            $("#house_div").find('input').prop('disabled', true);
            $('#add_addressCheckout').modal('show');
        });
    });
</script>
<script type="text/javascript">

    function DropDown(el) {
        this.dd = el;
        this.placeholder = this.dd.children('span');
        this.opts = this.dd.find('ul.dropdown > li');
        this.val = '';
        this.index = -1;
        this.initEvents();
    }
    DropDown.prototype = {
        initEvents: function () {
            var obj = this;
            obj.dd.on('click', function (event) {
                $(this).toggleClass('active');
                return false;
            });
            obj.opts.on('click', function () {
                var opt = $(this);
                obj.val = opt.text();
                obj.index = opt.index();
                obj.placeholder.text(obj.val);
            });
        },
        getValue: function () {
            return this.val;
        },
        getIndex: function () {
            return this.index;
        }
    }

    $(function () {

        var dd = new DropDown($('#dd'));
        $(document).click(function () {
            // all dropdowns
            $('.wrapper-dropdown-1').removeClass('active');
        });
    });</script>
<script>
    $("#house").attr('checked', 'checked');
    $("#delivery").click(function () {
        if (($('#some_time').prop('checked'))) {
            $('.time').show();
        }
        $(".time_div").show();
        $(".address").hide();
    });
    $("#pickup").click(function () {
        $(".time_div").hide();
        $(".time").hide();
        $(".address").show();
    });
    $("#some_time").click(function () {
        $(".time").show();
    });
    $("#standard_time").click(function () {
        $(".time").hide();
    });</script>
<script>

    var base_url = '<?= base_url() ?>';
    $("#credit_card").click(function () {
        $('.without_split').show();
        $('.without_split').removeClass('disabled');
        $('.without_split').attr('disabled', false);
        $('.split').hide();
    });
    $("#debit_card").click(function () {
        $('.without_split').show();
        $('.without_split').removeClass('disabled');
        $('.without_split').attr('disabled', false);
        $('.split').hide();
    });
    $("#cod").click(function () {
        $('.without_split').show();
        $('.without_split').removeClass('disabled');
        $('.without_split').attr('disabled', false);
        $('.split').hide();

    });
    $("#split_payment").click(function () {
        var address_val_id = $("#change_address_user").val();
        var payment_method_id_val = $('input[name=payment_method_id]:checked').val();
        var split_points_used = $(".points_used_val").val();
        var delievery_pickup_val = $('input[name=delivery_pickup]:checked').val();
        if (delievery_pickup_val == '0') {
            var order_time_val = $('input[name=order_time]:checked').val();
            if (order_time_val == '1') {
                var order_time_val = $('#delivery_pickup_time_val').val();
            }
        } else {
            var pickup_address_id_val = $('.pickup_address_id_val').val();
        }

        if (address_val_id != "") {
            $('#address_val_id').val(address_val_id);
            $('#payment_method_id_val').val(payment_method_id_val);
            $('#split_points_used').val(split_points_used);
            $('#delievery_pickup_val').val(delievery_pickup_val);
            $('#pickup_address_id_val').val(pickup_address_id_val);
            $('#order_time_val').val(order_time_val);
            $('.without_split').hide();
            $('.split').show();
        } else {
            $("#credit_card").trigger('click');
            toastr.error('Please select Address first');
        }

    });
    $('.checkout_rest_items').on('click', ".btn-remove", function () {

        post_array =
        {
            "row_id": $(this).attr('value'),
            "qty": '0'
        }
        $.post(base_url + "main/update_cart", post_array,
            function (data) {
                var res = jQuery.parseJSON(data);
                if (res.status == 'OK') {
                    updateCheckoutCart(res.cart_view, res.total_cost, res.items_count);
                    if (typeof res.msg != 'undefined') {
                        toastr.warning(res.msg);
                    }
                } else {
                    toastr.error('No item in Cart');
                    window.location.href = '<?=base_url() ?>main/search_result';
                }
            });
    });

    $(document).on('change', '#change_address_user', function (e) {
        $('.show_address_det').empty();
        var address_id = $(this).val();
        if (address_id != '') {
            $url = '<?= base_url() ?>main/get_address_detail';
            $data = 'address_id=' + address_id;
            $.ajax({
                url: $url,
                type: "POST",
                dataType: 'json',
                data: $data,
                success: function (data) {
                    if (data !== null) {
                        var address_detail_data = '<div class="form-group" style="margin-bottom: 0!important">' +
                            '<label class="col-md-2 control-label txt-left font14 no-padding-top">Address</label>' +
                            '<div class="col-md-10 color-grey">' + data.address + '</div>' +
                            '</div>';
                        $(".show_address_det").append(address_detail_data);
                    }
                }
            });
        } else {
            toastr.error('Address is required');
            return false;

        }
    });


</script>
<script>
    function check_action() {
        if ($('#change_address_user').val() != '') {
            var payment_method = $('input[name=payment_method_id]:checked').val();
            if (payment_method == 2) {
                document.checkoutdata.action = "<?php echo base_url() ?>main/cod_checkout";
                document.checkoutdata.submit();
                return true;
            } else {
                document.checkoutdata.action = "<?php echo base_url() ?>main/payment_checkout";
                document.checkoutdata.submit();
                return true;
            }
        }else{
            $("html, body").animate({ scrollTop: $('#change_address_user').offset().top-200}, "slow");
            toastr.error('Please Select Address');
            return false;
        }

    }

</script>
<script>

    $(document).ready(function () {
        $(".split").click(function () {
            $('#split').modal('show');
        });

        $(document).on('click', '.voucher_btn', function (e) {

            var vou_code = $('#' + $(this).val()).val();
            if (vou_code != '' && vou_code.length == 6) {
                $url = '<?= base_url() ?>main/apply_voucher';
                $data = 'voucher_code=' + $(this).attr('data') + '|' + vou_code;
                $.ajax({
                    url: $url,
                    type: "POST",
                    dataType: 'json',
                    data: $data,
                    success: function (data) {
                        if (data.status == 'OK') {
                            updateCheckoutCart(data.cart_view, data.total_cost, data.items_count);

                            toastr.success('Voucher Applied');
                        }
                        else if (data.status == 'NO_VOUCHER') {
                            toastr.error('Voucher code not found');
                        }
                        else if (data.status == 'MIN_ORDER') {
                            toastr.error('Order is less than the minimum amount for this Voucher');
                        }
                        else {
                            toastr.error('Error while applying voucher');
                        }
                    }
                });
            } else {
                toastr.error('Please enter a valid Voucher Code');
            }

        });

        $(document).on('click', '#apply_points', function (e) {
            var user_points = parseFloat($('.points_used_val').val());
            if (user_points != '' && user_points != 0) {
                $url = '<?= base_url() ?>main/apply_points';
                $data = 'points=' + user_points;
                $.ajax({
                    url: $url,
                    type: "POST",
                    dataType: 'json',
                    data: $data,
                    success: function (data) {
                        if (data.status == 'OK') {
                            $('.user_points_area').empty();
                            $('.user_points_area').append(data.points_view);
                            $('.cart_total').empty();
                            $(".cart_total").append('KD ' + data.total_cost);
                            $('#total_split_amount').empty();
                            $('#total_split_amount').val(data.total_cost.toFixed(3));
                            total_cost_split = data.total_cost;
                            $('#split_details').find('input[type=text].split_auto_payee').first().val(data.total_cost);
                            $('#split_details').find('input[type=text].split_auto_payee').parents().find('.payee_content').slice(1).remove();
                            toastr.success(data.points_used + ' Points applied');

                        } else if (data.status == 'NO_POINTS') {
                            toastr.error('You do not have enough Points');
                        } else {
                            toastr.error('Please enter valid points');
                        }
                    }
                });
            } else {
                toastr.error('Please Enter Vaild Points');
            }
        });

        $(document).on('click', '#remove_points', function (e) {
            $url = '<?= base_url() ?>main/clear_points';

            $.ajax({
                url: $url,
                type: "POST",
                dataType: 'json',
                success: function (data) {
                    if (data.status == 'OK') {
                        $('.user_points_area').empty();
                        $('.user_points_area').append(data.points_view);
                        $('.cart_total').empty();
                        $(".cart_total").append('KD ' + data.total_cost);
                        $('#total_split_amount').empty();
                        $('#total_split_amount').val(data.total_cost);
                        total_cost_split = data.total_cost;
                        $('#split_details').find('input[type=text].split_auto_payee').first().val(data.total_cost);
                        $('#split_details').find('input[type=text].split_auto_payee').parents().find('.payee_content').slice(1).remove();

                        toastr.success('Points Cleared');

                    } else {
                        toastr.error('Error: Please try again');
                    }
                }
            });
        });
    });

</script>
<script>
    function updateCheckoutCart(cart, total, items_count) {
        $('.checkout_rest_items').empty();
        $('.cart_total').empty();
        $('#total_split_amount').empty();
        $('#split_amount_is').empty();
        $('.cartnum').empty();

        $('.checkout_rest_items').append(cart);
        $(".cart_total").append('KD ' + total);

        $('#total_split_amount').val(total);
        $('#split_amount_is').val(total);
        $(".split_model_val").val(total);
        $(".cartnum").append(items_count);
        $('#split_details').find('input[type=text].split_auto_payee').first().val(total);
        $('#split_details').find('input[type=text].split_auto_payee').parents().find('.payee_content').slice(1).remove();
    }

    $("[name='delivery_pickup']").on('change',function(){
        if($(this).val()==1){
            var amount = "KD "+ (parseFloat($('#restaurant_total').html().trim(' ').replace("KD",'')) - parseFloat($('#delivery_cost').html())).toFixed(3);
            $("#restaurant_total").html(amount);
            $('.cart_total').html(amount);
            $('#delivery_cost').closest('tr').hide();
        }else{
            var amount = 'KD '+ (parseFloat($('#restaurant_total').html().trim(' ').replace("KD",'')) + parseFloat($('#delivery_cost').html())).toFixed(3);
            $("#restaurant_total").html(amount );
            $('.cart_total').html(amount );
            $('#delivery_cost').closest('tr').show();
        }
    });
</script>