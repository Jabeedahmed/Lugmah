<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class main extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->lang->load('auth');
        $this->load->library('cart');
    }

    function index()
    {
        $this->load->model('main_banners_model');
        $this->load->model('restaurant_model');
        $this->load->model('banners_model');
        $this->load->model('cuisine_type_model');
        $this->load->model('cities_model');
        $this->load->model('general_setting_model');
        $this->load->model('split_transaction_model');
        $this->load->model('payment_method_model');

        if ($this->ion_auth->logged_in()) {
            $user_info = $this->ion_auth->user()->row();
            $data['split_payments'] = $this->split_transaction_model->get_active_splits($user_info->id);
        } else {
            $this->session->set_userdata('last_page', current_url());
        }
        $data['folder_name'] = 'main';
        $data['file_name'] = 'index';
        $data['header_name'] = 'header';
        $data['nav_name'] = 'nav_main';
        $data['login_url'] = $this->googleplus->loginURL();
        $data['cities'] = $this->cities_model->get_all();
        $data['capitals'] = $this->cities_model->get_all_capitals();
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['banners'] = $this->banners_model->get_promotion_banner(2);
        $data['discount_restaurants'] = $this->restaurant_model->get_discount_restaurants();
        $data['voucher_restaurants'] = $this->restaurant_model->get_voucher_restaurants();
        $data['header_banner'] = $this->banners_model->get_header_banner();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['cuisine_types'] = $this->cuisine_type_model->get_all();
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);

    }

    public function register()
    {

        $this->load->model('cuisine_type_model');
        $this->load->model('user_setting_model');
        $this->load->model('user_addresses_model');
        $this->load->model('cities_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['cities'] = $this->cities_model->get_all();
        $data['capitals'] = $this->cities_model->get_all_capitals();
        $data['login_url'] = $this->googleplus->loginURL();

        if ($this->input->post('register')) {
            $post_data = $this->input->post();
            $data['user_type_id'] = '2';
            $email = strtolower($post_data['email']);
            $username = $post_data['email'];
            $password = $post_data['password'];
            if ($this->ion_auth->email_check(strtolower($email))) {
                $this->session->set_flashdata('error', "Email address already Exists");
                redirect('main/register');
            } else {
                $data['first_name'] = $post_data['first_name'];
                $data['last_name'] = $post_data['last_name'];
                $data['dob'] = $post_data['year'] . '-' . $post_data['month'] . '-' . $post_data['day'];
                $data['phone'] = $post_data['mobile_number'];
                $data['gender'] = $post_data['gender'];
                $data['is_block'] = '0';
                $data['date_created'] = date('y-m-d h:i:s');
                $register_id = $this->ion_auth->register($username, $password, $email, $data, array('2'));

                $settings['user_id'] = $register_id;
                $settings['promo_setting'] = 1;
                $settings['update_by_sms_setting'] = 1;
                $this->user_setting_model->create($settings);
                $address['user_id'] = $register_id;
                $address['type_id'] = $post_data['address_type_id'];
                $address['area'] = $post_data['city_id'];
                $address['address_title'] = $post_data['address_name'];
                $address['block'] = $post_data['block'];
                $address['judda'] = $post_data['judda'];
                $address['street'] = $post_data['street'];
                $address['houseno_name'] = $post_data['office_name'];
                $address['floor'] = isset($post_data['floor']) ? $post_data['floor'] : '';
                $address['office_apt'] = isset($post_data['appartment']) ? $post_data['appartment'] : '';
                $address['extra_direction'] = $post_data['extra_direction'];
                $this->user_addresses_model->create($address);
                $errors_array = $this->ion_auth->errors_array();
                $messages_array = $this->ion_auth->messages_array();
                if (!empty($errors_array[0])) {
                    $this->session->set_flashdata('error', $errors_array[0]);
                    redirect('main/register');
                } elseif (!empty($messages_array[0])) {
                    $this->session->set_flashdata('success', "Signed Up successfully please verify your account through link sent to your email address");
                    redirect('main');
                }
            }
        }
        $data['folder_name'] = 'main';
        $data['file_name'] = 'register';
        $data['header_name'] = 'header_register';
        $data['nav_name'] = 'nav_main';
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    public function update_user_profile()
    {
        if ($this->ion_auth->logged_in()) {
            $post_data = $this->input->post();
            $logged_user = $this->ion_auth->user()->row();
            $data['first_name'] = $post_data['first_name'];
            $data['last_name'] = $post_data['last_name'];
            $data['phone'] = $post_data['phone'];
            $data['gender'] = $post_data['gender'];
            $data['dob'] = $post_data['year'] . '-' . $post_data['month'] . '-' . $post_data['day'];
            $this->ion_auth->update($logged_user->id, $data);
            $this->session->set_flashdata('success', "User Updated Successfully");
            redirect('main/my_account');
        } else {
            $this->session->set_flashdata('alert', "Please Login First to Proceed");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function logout()
    {

        $this->ion_auth->logout();
        redirect('main');
    }

    public function check_points()
    {
        $user = $this->ion_auth->user()->row();
        $user_id = $user->id;
        $points_used = $this->input->post('points_used');
        $this->load->model('user_points_model');

        $total_points = $this->user_points_model->get_user_points($user_id);
        $total = $total_points->points;
        if ($points_used < $total) {
            $isAvailable = true;
        } else {
            $isAvailable = false;
        }
        echo json_encode(array(
            'valid' => $isAvailable,
        ));
    }

    public function search_result()
    {
        $this->load->model('restaurant_model');
        $this->load->model('user_fav_restaurant_model');
        $this->load->model('cities_model');
        $this->load->model('cuisine_type_model');
        $this->load->model('payment_method_model');
        $this->load->model('banners_model');
        $this->load->model('general_setting_model');
        if ($this->ion_auth->logged_in()) {
            $user = $this->ion_auth->user()->row();
            $user_id = $user->id;
        } else {
            $user_id = 0;
            $this->session->set_userdata('last_page', current_url());
        }
        $catering = $this->input->get_post('catering');
        $cuisine = $this->input->get_post('cuisine');
        $area = $this->input->get_post('area');
        $filter['catering'] = isset($catering) ? $catering : null;
        $filter['cuisine'] = isset($cuisine) && !empty($cuisine) ? $cuisine : null;
        $filter['area'] = isset($area) && !empty($area) ? $area : null;
        $page = isset($page) && !empty($page) ? $page : 0;
        $result_per_page = 10;
        $restaurants = $this->restaurant_model->restaurant_search($filter, $result_per_page, $result_per_page * $page, $user_id);

        if (isset($restaurants['results'])) {
            foreach ($restaurants['results'] as $restau) {
                if (isset($restau->payment_methods) && !empty($restau->payment_methods)) {
                    $restau->payment_methods = $this->payment_method_model->get_by_ids(explode(',', $restau->payment_methods));
                } else {
                    $restau->payment_methods = null;
                }
                $search_rest[] = $restau;
            }
            $view_data['restaurants'] = $search_rest;
            $data['search_view'] = $this->load->view('util/search_view', $view_data, TRUE);
            $data['total_record'] = $restaurants['totalres'];
            $data['has_more'] = $restaurants['has_more'];
        } else {
            $data['total_record'] = 0;
            $data['has_more'] = false;

        }
        $data['cuisine_types'] = $this->cuisine_type_model->get_all();
        $data['selected_area'] = $this->cities_model->get_by_id($area);
        $data['selected_cuisine'] = $cuisine;
        $data['menu_promotions'] = $this->banners_model->get_search_promotion_banner();
        $data['banners'] = $this->banners_model->get_promotion_banner(4);
        $data['cities'] = $this->cities_model->get_all();
        $data['capitals'] = $this->cities_model->get_all_capitals();
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['folder_name'] = 'main';
        $data['file_name'] = 'search_result';
        $data['header_name'] = 'header_search';
        $data['nav_name'] = 'nav_main';
        $data['login_url'] = $this->googleplus->loginURL();

        $this->load->view('index', $data);
    }

    function get_address_detail()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $address_id = $this->input->post('address_id');
            $address = $this->user_addresses_model->get_by_id($address_id);
            $data['address'] = wordwrap($address->address, 30, '<br>');
            print_r(json_encode($data));
        }
    }

    public function get_search_results()
    {
        $this->load->model('restaurant_model');
        $this->load->model('user_fav_restaurant_model');
        $this->load->model('restaurant_cuisine_type_model');
        $this->load->model('payment_method_model');
        $this->load->model('cities_model');
        if ($this->ion_auth->logged_in()) {
            $user = $this->ion_auth->user()->row();
            $user_id = $user->id;
        } else {
            $user_id = 0;
        }
        $catering = $this->input->post('catering');
        $cuisine = $this->input->post('cuisine');
        $area = $this->input->post('area');
        $page = $this->input->post('page_number');
        $sort_by = $this->input->post('sort_by');
        $free_delivery = $this->input->post('free_delivery');
        $discount_avail = $this->input->post('discount_avail');
        $has_promotions = $this->input->post('has_promotions');
        $cod_avail = $this->input->post('cod_avail');
        $split_avail = $this->input->post('split_avail');
        $open_rest = $this->input->post('openrest');
        $rating = $this->input->post('rating');
        $min_price = $this->input->post('min_price');
        $max_price = $this->input->post('max_price');
        $search_term = $this->input->post('search_term');
        $filter['catering'] = isset($catering) && !empty($catering) ? $catering : null;
        $filter['cuisine'] = isset($cuisine) && !empty($cuisine) ? $cuisine : null;
        $filter['area'] = isset($area) && !empty($area) ? $area : null;
        $filter['sort_by'] = isset($sort_by) && !empty($sort_by) ? $sort_by : null;
        $filter['free_delivery'] = isset($free_delivery) && !empty($free_delivery) ? $free_delivery : null;
        $filter['discount_avail'] = isset($discount_avail) && !empty($discount_avail) ? $discount_avail : null;
        $filter['has_promotions'] = isset($has_promotions) && !empty($has_promotions) ? $has_promotions : null;
        $filter['cod_avail'] = isset($cod_avail) && !empty($cod_avail) ? $cod_avail : null;
        $filter['split_avail'] = isset($split_avail) && !empty($split_avail) ? $split_avail : null;
        $filter['openrest'] = isset($open_rest) && !empty($open_rest) ? $open_rest : null;
        $filter['rating'] = isset($rating) && !empty($rating) ? $rating : null;
        $filter['min_price'] = isset($min_price) && !empty($min_price) ? $min_price : null;
        $filter['max_price'] = isset($max_price) && !empty($max_price) ? $max_price : null;
        $filter['search_term'] = isset($search_term) && !empty($search_term) ? $search_term : null;
        $page = isset($page) && !empty($page) ? $page : 0;
        $result_per_page = 10;
        $restaurants = $this->restaurant_model->restaurant_search($filter, $result_per_page, $result_per_page * $page, $user_id);
        if (isset($area)) {
            $selected_area = $this->cities_model->get_by_id($area);
        }

        if (isset($restaurants['results'])) {
            foreach ($restaurants['results'] as $restau) {
                if (isset($restau->payment_methods) && !empty($restau->payment_methods)) {
                    $restau->payment_methods = $this->payment_method_model->get_by_ids(explode(',', $restau->payment_methods));
                } else {
                    $restau->payment_methods = null;
                }
                $search_rest[] = $restau;
            }

            $view_data['restaurants'] = $search_rest;
            $data['search_view'] = $this->load->view('util/search_view', $view_data, TRUE);
            $data['total_record'] = $restaurants['totalres'];
            if (isset($selected_area)) {
                $data['result_status'] = "Order from $restaurants[totalres] Restaurants in $selected_area->city_name";

            } else {
                $data['result_status'] = "Order from $restaurants[totalres] Restaurants";
            }
            $data['has_more'] = $restaurants['has_more'];
        } else {
            $data['total_record'] = 0;
            $data['has_more'] = false;
            $data['result_status'] = "No Restaurants Found in $selected_area->city_name";

        }

        print_r(json_encode($data));
    }

    function my_account()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $this->load->model('address_type_model');
            $this->load->model('transaction_model');
            $this->load->model('order_transactions_model');
            $this->load->model('restaurant_comments_model');
            $this->load->model('user_fav_items_model');
            $this->load->model('user_fav_restaurant_model');
            $this->load->model('user_points_model');
            $this->load->model('cities_model');
            $this->load->model('payment_method_model');
            $this->load->model('transaction_item_details_model');
            $data['payment_method_db'] = $this->payment_method_model->get_payment_images();

            $data['user_info'] = $this->ion_auth->user()->row();
            $data['change_pas_check'] = $data['user_info']->social_link;
            $data['address_type'] = $this->address_type_model->get_all();
            $data['address_info'] = $this->user_addresses_model->get_all_by_user_id($data['user_info']->id);
            $data['cities'] = $this->cities_model->get_all();

            $order_history = $this->transaction_model->get_user_orders($data['user_info']->id);
            if (isset($order_history)) {
                $orders = $this->transaction_model->get_user_order_by_id($order_history[0]['order_id']);
                foreach ($orders as $order) {
                    $order->items = $this->order_transactions_model->get_user_transaction_details($order->trans_id);
                    $order_ar[] = $order;
                }

                $view_data['latest_order'] = $order_ar;

                $data['latest_order_view'] = $this->load->view('util/account_order_view', $view_data, TRUE);
                $data['order_history'] = $order_history;
            } else {
                $data['latest_order_view'] = null;
                $data['order_history'] = null;
            }
            $data['fav_items'] = $this->user_fav_items_model->get_all_by_user_id($data['user_info']->id);
            $data['fav_restaurant'] = $this->user_fav_restaurant_model->get_all_fav_restaurants_user_id($data['user_info']->id);


            $points = $this->user_points_model->get_user_points($data['user_info']->id);
            $this->load->model('cuisine_type_model');
            $this->load->model('general_setting_model');
            $data['settings'] = $this->general_setting_model->get_setting();
            $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
            $data['user_points'] = $points->points;
            $data['login_url'] = $this->googleplus->loginURL();
            $data['folder_name'] = 'main';
            $data['file_name'] = 'my_account';
            $data['header_name'] = 'header_after';
            $data['nav_name'] = 'nav_main';
            $this->load->view('index', $data);
        } else {
            $this->session->set_flashdata('alert', "Please Login First to Proceed");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function delete_user_address()
    {

        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $address_id = $this->uri->segment(3);
            $logged_user = $this->ion_auth->user()->row();
            $user_id = $logged_user->id;
            $this->user_addresses_model->delete($address_id, $user_id);
            $this->session->set_flashdata('success', "Address Deleted Successfully");
            redirect('main/my_account');
        } else {
            $this->session->set_flashdata('alert', "Please Login First to Proceed");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function change_password()
    {
        if ($this->ion_auth->logged_in()) {
            if (isset($_POST['old_password']) && isset($_POST['new_password'])) {
                $logged_user = $this->ion_auth->user()->row();
                $old = $_POST['old_password'];
                $new = $_POST['new_password'];
                $email = $logged_user->email;
                $identity = $email;
                $change = $this->ion_auth->change_password($identity, $old, $new);
                if ($change) {
                    $this->session->set_flashdata('success', "Password Successfully Changed");
                    redirect('main/my_account');
                } else {
                    $this->session->set_flashdata('error', "Please insert Correct Information");
                    redirect('main/my_account');
                }
            } else {
                $this->session->set_flashdata('error', "Please insert Correct Information");
                redirect('main/my_account');
            }
        } else {
            $this->session->set_flashdata('alert', "Please Login First to Proceed");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function change_email()
    {
        if ($this->ion_auth->logged_in()) {
            if (isset($_POST['new_email']) && isset($_POST['old_email'])) {
                $logged_user = $this->ion_auth->user()->row();
                $email = $logged_user->email;
                if ($email == $_POST['old_email']) {
                    if ($this->ion_auth->email_check(strtolower($_POST['new_email']))) {
                        $this->session->set_flashdata('error', "EMAIL ALREADY EXISTS");
                        redirect('main/my_account');
                    } else {
                        $data['email'] = $_POST['new_email'];
                        if ($this->ion_auth->update($logged_user->id, $data)) {
                            $this->session->set_flashdata('success', "Email Change Successfully");
                            redirect('main/my_account');
                        } else {
                            $this->session->set_flashdata('error', "Please insert Correct Information");
                            redirect('main/my_account');
                        }
                    }
                } else {
                    $this->session->set_flashdata('error', "Please insert Correct Information");
                    redirect('main/my_account');
                }
            } else {
                $this->session->set_flashdata('error', "Please insert Correct Information");
                redirect('main/my_account');
            }
        } else {
            $this->session->set_flashdata('alert', "Please Login First to Proceed");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function add_user_address()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $post_data = $this->input->post();
            $logged_user = $this->ion_auth->user()->row();
            $address['user_id'] = $logged_user->user_id;
            $address['type_id'] = (isset($post_data['address_type_id']) && !empty($post_data['address_type_id'])) ? $post_data['address_type_id'] : '';
            $address['area'] = (isset($post_data['city_id']) && !empty($post_data['city_id'])) ? $post_data['city_id'] : '';
            $address['address_title'] = (isset($post_data['address_name']) && !empty($post_data['address_name'])) ? $post_data['address_name'] : '';
            $address['block'] = (isset($post_data['block']) && !empty($post_data['block'])) ? $post_data['block'] : '';
            $address['judda'] = (isset($post_data['judda']) && !empty($post_data['judda'])) ? $post_data['judda'] : '';
            $address['street'] = (isset($post_data['street']) && !empty($post_data['street'])) ? $post_data['street'] : '';
            $address['houseno_name'] = (isset($post_data['office_name']) && !empty($post_data['office_name'])) ? $post_data['office_name'] : '';
            $address['floor'] = (isset($post_data['floor']) && !empty($post_data['floor'])) ? $post_data['floor'] : '';
            $address['office_apt'] = (isset($post_data['appartment']) && !empty($post_data['appartment'])) ? $post_data['appartment'] : '';
            $address['extra_direction'] = (isset($post_data['extra_direction']) && !empty($post_data['extra_direction'])) ? $post_data['extra_direction'] : '';
            $this->user_addresses_model->create($address);
            $this->session->set_flashdata('success', "User Address Added Successfully");
            redirect('main/my_account');
        } else {
            $this->session->set_flashdata('alert', "Please Login First to Proceed");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function edit_user_address()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $post_data = $this->input->post();
            $logged_user = $this->ion_auth->user()->row();
            $address['user_id'] = $logged_user->user_id;
            $id = $post_data['id'];
            $address['type_id'] = (isset($post_data['address_type_id']) && !empty($post_data['address_type_id'])) ? $post_data['address_type_id'] : '';
            $address['area'] = (isset($post_data['city_id']) && !empty($post_data['city_id'])) ? $post_data['city_id'] : '';
            $address['address_title'] = (isset($post_data['address_name']) && !empty($post_data['address_name'])) ? $post_data['address_name'] : '';
            $address['block'] = (isset($post_data['block']) && !empty($post_data['block'])) ? $post_data['block'] : '';
            $address['judda'] = (isset($post_data['judda']) && !empty($post_data['judda'])) ? $post_data['judda'] : '';
            $address['street'] = (isset($post_data['street']) && !empty($post_data['street'])) ? $post_data['street'] : '';
            $address['houseno_name'] = (isset($post_data['office_name']) && !empty($post_data['office_name'])) ? $post_data['office_name'] : '';
            $address['floor'] = (isset($post_data['floor']) && !empty($post_data['floor'])) ? $post_data['floor'] : '';
            $address['office_apt'] = (isset($post_data['appartment']) && !empty($post_data['appartment'])) ? $post_data['appartment'] : '';
            $address['extra_direction'] = (isset($post_data['extra_direction']) && !empty($post_data['extra_direction'])) ? $post_data['extra_direction'] : '';
            $this->user_addresses_model->update($id, $address);
            $this->session->set_flashdata('success', "User Address Updated Successfully");
            redirect('main/my_account');
        } else {
            $this->session->set_flashdata('alert', "Please login to Proceed");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    function menu($slug)
    {
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('restaurant_menu_model');
        $this->load->model('restaurant_timing_model');
        $this->load->model('banners_model');
        $this->load->model('restaurant_menu_categories_model');
        $this->load->model('payment_method_model');
        $this->load->model('general_setting_model');
        $this->load->model('restaurant_banner_model');

        $restaurant_ids = $this->restaurant_model->get_id_by_slug($slug);
        $restaurant_id = $restaurant_ids->id;

        if ($this->ion_auth->logged_in()) {
            $logged_user = $this->ion_auth->user()->row();
            $user_id = $logged_user->id;
        } else {
            $user_id = 0;
            $this->session->set_userdata('last_page', current_url());
        }
        $restaurant = $this->restaurant_model->get_restaurant_detail_by_id($restaurant_id, $user_id);
        if (isset($restaurant->payment_methods) && !empty($restaurant->payment_methods)) {
            $restaurant->payment_methods = $this->payment_method_model->get_by_ids(explode(',', $restaurant->payment_methods));
        } else {
            $restaurant->payment_methods = null;
        }
        $data['banner_list'] = $this->restaurant_banner_model->get_banners_by_restaurant($restaurant_id);
        $data['restaurant_detail'] = $restaurant;
        $data['restaurant_timing'] = $this->restaurant_timing_model->get_by_id($restaurant_id);
        $data['restaurant_all_comments'] = $this->restaurant_comments_model->get_all_by_id($restaurant_id);
        $data['categories'] = $this->restaurant_menu_categories_model->get_by_restaurant_id($restaurant_id);

        if (isset($data['categories'])) {
            for ($i = 0; $i < sizeof($data['categories']); $i++) {
                $sub[] = $this->restaurant_menu_model->get_categories_items($data['categories'][$i]->category_id, $user_id);
            }
            $data['sub_categories'] = $sub;
        }
        $data['banners'] = $this->banners_model->get_promotion_banner(3);
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $cart = $this->prepareCart($this->cart->contents());
        if (isset($cart)) {
            $data['items_count'] = $cart['item_count'];
            $view_data['content'] = $cart['contents'];
            $data['cart_view'] = $this->load->view('util/menu_cart', $view_data, TRUE);
            $data['total_cost'] = $cart['total_cost'];
        }
        $data['slug'] = $slug;
        $data['login_url'] = $this->googleplus->loginURL();
        $data['restaurant_id'] = $restaurant_id;
        $data['folder_name'] = 'main';
        $data['file_name'] = 'menu';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->view('index', $data);
    }

    public function prepareCart($content)
    {
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('user_item_group_attributes_model');
        if (!empty($content)) {
            foreach ($content as $con_data) {
                $ids[] = $con_data['options']['restaurant_id'];
            }
            $restaurant_ids = array_unique($ids);
            $total_bill = 0;
            $cart_item_count = 0;
            foreach ($restaurant_ids as $row) {
                $restaurant = $this->restaurant_model->get_restaurant_detail_by_id($row);
                $resturant_rating = $this->restaurant_comments_model->get_restaurant_rating_by_id($row);
                $restaurant->rating = $resturant_rating->rating;
                $restaurant->total_rating = $resturant_rating->total_rating;

                $total_price = 0;
                foreach ($content as $content_data) {
                    if ($row == $content_data['options']['restaurant_id']) {
                        if ($content_data['id'] != 'voucher') {
                            $options_names = $this->user_item_group_attributes_model->get_by_id($content_data['options']['attribute_ids']);
                            $items['rowid'] = $content_data['rowid'];
                            $items['id'] = $content_data['id'];
                            $items['qty'] = $content_data['qty'];
                            $items['price'] = $content_data['price'];
                            $items['name'] = $content_data['name'];
                            $items['restaurant_id'] = $content_data['options']['restaurant_id'];
                            $items['attributes_name'] = $options_names->options_name;
                            $items['attributes_id'] = $content_data['options']['attribute_ids'];
                            $items['attributes_price'] = $options_names->option_price;
                            $items['subtotal'] = round($content_data['qty'] * ($content_data['price'] + $options_names->option_price), 3);
                            $cart_item[] = $items;
                            $total_price = round($total_price + $items['subtotal'], 3);
                            $cart_item_count++;
                        } else {
                            $has_voucher = TRUE;
                            $voucher_code = $content_data['name'];
                            $voucher_row_id = $content_data['rowid'];
                        }
                    }
                }
                if (isset($cart_item)) {
                    $restaurant->c_items = $cart_item;
                }
                $discount_type = $this->restaurant_model->check_restaurant_discount($row);

                if (isset($has_voucher)) {
                    $vou_discount = $this->restaurant_model->get_voucher_discount($voucher_code);
                    if ($vou_discount->voucher_min_amount <= $total_price) {

                        $restaurant->discount = $vou_discount->discount;
                        $restaurant->discount_type = 'voucher_used';
                        unset($has_voucher);

                    } else {
                        $data = array(
                            'rowid' => $voucher_row_id,
                            'qty' => 0
                        );
                        $this->cart->update($data);
                        $restaurant->discount = 0;
                        $restaurant->discount_type = 'voucher';
                        $data['voucher_status'] = 'discarded';
                        unset($has_voucher);
                    }

                } elseif ($restaurant->discount_type == 'flat') {
                    $restaurant->discount = $discount_type->discount;
                    $restaurant->discount_type = $discount_type->discount_type;
                } else {
                    $restaurant->discount = 0;
                    $restaurant->discount_type = $discount_type->discount_type;
                }

                $discount = $restaurant->discount;

                $restaurant->restaurant_total = $total_price;
                $total_price_discount = $total_price / 100 * $discount;
                $new_total_price = $total_price - $total_price_discount;
                $restaurant->rest_total = round($new_total_price + $restaurant->delivery_charges, 3);
                unset($cart_item);
                $total_bill = round($total_bill + $restaurant->rest_total, 3);
                $rest[] = $restaurant;
                $rest_totals['restaurant_id'] = $row;
                $rest_totals['total'] = $total_price;
                $rest_totals_ar[] = $rest_totals;
            }
            $data['contents'] = $rest;
            $data['subtotal_cost'] = $total_bill;
            $used_points = $this->session->userdata('used_points');
            $used_points = (isset($used_points) && !empty($used_points)) ? $used_points : 0;
            $data['total_cost'] = $total_bill - $used_points;
            $data['restaurant_subtotals'] = $rest_totals_ar;
            $data['item_count'] = $cart_item_count;

            return $data;

        } else {
            return null;
        }

    }

    public function add_restaurant_review($slug)
    {

        if ($this->ion_auth->logged_in()) {
            $this->load->model('restaurant_comments_model');
            $logged_user = $this->ion_auth->user()->row();
            $user_id = $logged_user->id;
            $data['user_id'] = $user_id;
            $data['restaurant_id'] = $this->input->post('restaurant_id');
            $data['comment'] = $this->input->post('review');
            $data['title'] = $this->input->post('title');
            $data['rating'] = $this->input->post('rating');
            $checked = $this->restaurant_comments_model->check_comment_exist($data['user_id'], $data['restaurant_id']);
            if (!empty($checked)) {
                $this->restaurant_comments_model->update($checked->id, $data);
                $this->session->set_flashdata('success', "Updated Successfully");
            } else {
                $this->restaurant_comments_model->create($data);
                $this->session->set_flashdata('success', "Added Successfully");
            }
            redirect('restaurant/' . $slug . '');
        } else {
            $this->session->set_flashdata('alert', "Please login first.");

            redirect('main/login');
        }
    }

    function bookmark_restaurant()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_fav_restaurant_model');
            $restaurant_id = $this->input->post('rest_id');
            $logged_user = $this->ion_auth->user()->row();
            $user_id = $logged_user->id;
            $checked = $this->user_fav_restaurant_model->check_res_bookmark($user_id, $restaurant_id);
            if (isset($checked)) {
                $this->user_fav_restaurant_model->delete($checked->id);
                $data = "Updated";
                echo json_encode($data);
            } else {
                $this->user_fav_restaurant_model->create($user_id, $restaurant_id);
                $data = "Added";
                echo json_encode($data);
            }
        } else {
            $data = "login";
            echo json_encode($data);
        }
    }

    function bookmark_menu_item()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_fav_items_model');
            $item_id = $this->input->post('item_id');
            $logged_user = $this->ion_auth->user()->row();
            $user_id = $logged_user->id;
            $checked = $this->user_fav_items_model->check_item_bookmark($user_id, $item_id);
            if (isset($checked)) {
                $this->user_fav_items_model->delete($checked->id);
                $data = "Updated";
                echo json_encode($data);
            } else {
                $this->user_fav_items_model->create($user_id, $item_id);
                $data = "Added";
                echo json_encode($data);
            }
        } else {
            $data = "login";
            echo json_encode($data);
        }
    }

    function unbookmark_menu_item($item_id = null)
    {
        if ($this->ion_auth->logged_in()) {
            if (isset($item_id) && !empty($item_id)) {
                $this->load->model('user_fav_items_model');
                $item_id = $this->uri->segment(3);
                $logged_user = $this->ion_auth->user()->row();
                $user_id = $logged_user->id;
                $checked = $this->user_fav_items_model->check_item_bookmark($user_id, $item_id);
                if (isset($checked)) {
                    $this->user_fav_items_model->delete($checked->id);
                    $this->session->set_flashdata('success', "Item Removed from favorite");
                    redirect('main/my_account');
                }
            } else {
                $this->session->set_flashdata('error', "No Item Selected");
                redirect('main/my_account');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    function thankyou()
    {
        $this->load->model('order_transactions_model');
        $this->load->model('general_setting_model');
        $this->load->model('transaction_model');
        $this->load->model('transaction_detail_model');
        $this->load->model('transaction_item_details_model');
        $this->load->model('user_item_group_attributes_model');
        $order_id = $this->input->get('order_id');
        if (!isset($order_id) || empty($order_id)) {
            redirect();
        }
        $item_names = 'Currently Eating';
        $restaurant_names = '';
        $total_bill = 0;
        $order_details = $this->order_transactions_model->get_user_transaction($order_id);
        if (isset($order_details) && !empty($order_details)) {
            foreach ($order_details as $order_detail) {
                $restaurant_names = $restaurant_names . ' ' . $order_detail->restaurant_name;
                $total_bill = $total_bill + $order_detail->total_amount;
                $trans_detail = $this->order_transactions_model->get_user_transaction_details($order_detail->id);
                $order_detail->c_items = $trans_detail;
                $rest[] = $order_detail;
            }
            $view_data['restaurant'] = $rest;
            $data['order_confirm_view'] = $this->load->view('util/order_confirm_view', $view_data, TRUE);
            $data['og_description'] = $item_names . ' From ' . $restaurant_names;
            $data['total_cost'] = $total_bill;
            $data['order_id'] = $order_id;
            $data['points_earned'] = isset($order_details[0]->earned_points) && !empty($order_details[0]->earned_points) && $order_details[0]->earned_points > 0 ? $order_details[0]->earned_points : 0;

            $user = new stdClass();
            $user->name = $order_details[0]->user_name;
            $user->email = $order_details[0]->user_email;
            $user->phone = $order_details[0]->user_contactno;
            $user->address = $order_details[0]->user_address;
            $data['user_detail'] = $user;

            $this->load->model('payment_method_model');
            $data['payment_method_db'] = $this->payment_method_model->get_payment_images();

            $data['folder_name'] = 'main';
            $data['file_name'] = 'thankyou';
            $data['header_name'] = 'header_after';
            $data['nav_name'] = 'nav_main';
            $this->load->model('cuisine_type_model');
            $data['login_url'] = $this->googleplus->loginURL();
            $data['settings'] = $this->general_setting_model->get_setting();
            $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
            $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
            $this->load->view('index', $data);

        } else {
            $this->session->set_flashdata('error', "No Order Found");
            redirect();
        }

    }

    function about_us()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'about_us';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $this->load->model('about_us_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['banners'] = $this->banners_model->get_promotion_banner(2);
        $abt_titles = $this->about_us_model->get_all_about_us_title();
        if (isset($abt_titles) && !empty($abt_titles)) {
            foreach ($abt_titles as $abt_title) {
                $abt_title->about_desc = $this->about_us_model->get_all_about_us_by_title($abt_title->id);
                $abt_ar[] = $abt_title;
            }
            $data['about_us'] = $abt_ar;
        } else {
            $data['about_us'] = null;
        }
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function privacy_policy()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'privacy_policy';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $this->load->model('privacy_policy_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['banners'] = $this->banners_model->get_promotion_banner(2);
        $data['login_url'] = $this->googleplus->loginURL();
        $data['privacy_poloice'] = $this->privacy_policy_model->get_privacy_polocy();
        $data['security_polices_types'] = $this->privacy_policy_model->get_all_policy_type();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();


        $this->load->view('index', $data);
    }

    function feedback()
    {
        if ($this->input->post('add_feedback')) {
            $this->load->model('feedback_model');
            $data = $this->input->post();
            if (($this->ion_auth->logged_in())) {
                $user_info = $this->ion_auth->user()->row();
                $data['user_id'] = $user_info->id;
                $data['subject'] = (empty($data['subject']) ? NULL : $data['subject']);
                $data['detail'] = (empty($data['detail']) ? NULL : $data['detail']);
                $data['email'] = (empty($data['email']) ? NULL : $data['email']);
                $data['name'] = (empty($data['name']) ? NULL : $data['name']);
                $this->feedback_model->create($data);
                $this->session->set_flashdata('success', "FeedBack Added Successfully");
                redirect('main');
            } else {
                $data['user_id'] = NULL;
                $data['subject'] = (empty($data['subject']) ? NULL : $data['subject']);
                $data['detail'] = (empty($data['detail']) ? NULL : $data['detail']);
                $data['email'] = (empty($data['email']) ? NULL : $data['email']);
                $data['name'] = (empty($data['name']) ? NULL : $data['name']);
                $this->feedback_model->create($data);
                $this->session->set_flashdata('success', "FeedBack Added Successfully");
                $this->session->set_userdata('last_page', current_url());
                redirect('main');
            }

        }
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['folder_name'] = 'main';
        $data['file_name'] = 'feedback';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $data['login_url'] = $this->googleplus->loginURL();
        $data['banners'] = $this->banners_model->get_promotion_banner(2);
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function faq()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'faq';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $this->load->model('faqs_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['faqs'] = $this->faqs_model->get_all();
        $data['login_url'] = $this->googleplus->loginURL();
        $data['banners'] = $this->banners_model->get_promotion_banner(2);
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function my_favorite()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'my_favorite';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->view('index', $data);
    }

    function track_order()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('transaction_model');
            $this->load->model('split_transaction_model');
            $user_id = $this->session->user_id;
            $data['order_history'] = $this->transaction_model->get_user_order_history($user_id);
            $data['split_payments'] = $this->split_transaction_model->get_active_splits($user_id);
            $data['folder_name'] = 'main';
            $this->load->model('cuisine_type_model');
            $this->load->model('banners_model');
            $this->load->model('general_setting_model');
            $data['settings'] = $this->general_setting_model->get_setting();
            $data['banners'] = $this->banners_model->get_promotion_banner(2);
            $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
            $data['file_name'] = 'track_order';
            $this->load->model('payment_method_model');
            $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
            $data['login_url'] = $this->googleplus->loginURL();
            $this->session->set_userdata('last_page', current_url());
            $data['header_name'] = 'header_after';
            $data['nav_name'] = 'nav_main';
            $this->load->view('index', $data);
        } else {
            $this->load->model('general_setting_model');
            $this->load->model('payment_method_model');
            $data['settings'] = $this->general_setting_model->get_setting();
            $data['folder_name'] = 'main';
            $data['file_name'] = 'track_order';
            $data['message'] = "This feature is only available for a registered user.";
            $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
            $data['login_url'] = $this->googleplus->loginURL();
            $this->session->set_userdata('last_page', current_url());
            $data['header_name'] = 'header_after';
            $data['nav_name'] = 'nav_main';
            $this->load->view('index', $data);
        }
    }

    function add_user_new_address()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $post_data = $this->input->post();
            $logged_user = $this->ion_auth->user()->row();
            $address['user_id'] = $logged_user->user_id;
            $address['type_id'] = (isset($post_data['address_type_id']) && !empty($post_data['address_type_id'])) ? $post_data['address_type_id'] : '';
            $address['area'] = (isset($post_data['city_id']) && !empty($post_data['city_id'])) ? $post_data['city_id'] : '';
            $address['address_title'] = (isset($post_data['address_name']) && !empty($post_data['address_name'])) ? $post_data['address_name'] : '';
            $address['block'] = (isset($post_data['block']) && !empty($post_data['block'])) ? $post_data['block'] : '';
            $address['judda'] = (isset($post_data['judda']) && !empty($post_data['judda'])) ? $post_data['judda'] : '';
            $address['street'] = (isset($post_data['street']) && !empty($post_data['street'])) ? $post_data['street'] : '';
            $address['houseno_name'] = (isset($post_data['office_name']) && !empty($post_data['office_name'])) ? $post_data['office_name'] : '';
            $address['floor'] = (isset($post_data['floor']) && !empty($post_data['floor'])) ? $post_data['floor'] : '';
            $post_data['floor'];
            $address['office_apt'] = (isset($post_data['appartment']) && !empty($post_data['appartment'])) ? $post_data['appartment'] : '';
            $address['extra_direction'] = (isset($post_data['extra_direction']) && !empty($post_data['extra_direction'])) ? $post_data['extra_direction'] : '';
            $this->user_addresses_model->create($address);
            $this->session->set_flashdata('success', "User Address Added Successfully");
            redirect('main/checkout');
        } else {
            $this->session->set_flashdata('message', "Please Login to Proceed");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function checkout()
    {

        if ($this->ion_auth->logged_in()) {
            if ($this->cart->total_items() > 0) {
                $this->load->model('general_setting_model');
                $this->load->model('address_type_model');
                $this->load->model('user_addresses_model');
                $this->load->model('user_points_model');
                $this->load->model('payment_method_model');
                $this->load->model('cities_model');
                $this->load->model('cuisine_type_model');
                $this->load->model('restaurant_coverage_area_model');
                $this->load->model('restaurant_branches_model');

                $data['settings'] = $this->general_setting_model->get_setting();
                $data['folder_name'] = 'main';
                $data['file_name'] = 'checkout';
                $data['header_name'] = 'header_after';
                $data['nav_name'] = 'nav_main';
                $data['login_url'] = $this->googleplus->loginURL();
                $data['address_type'] = $this->address_type_model->get_all();

                $cart = $this->prepareCart($this->cart->contents());
                $view_data['restaurant'] = $cart['contents'];
                $data['cart_view'] = $this->load->view('util/checkout_cart', $view_data, TRUE);

                $data['total_cost'] = $cart['total_cost'];

                if ($this->ion_auth->logged_in()) {
                    $data['user'] = $this->ion_auth->user()->row();
                    $data['address_info'] = $this->user_addresses_model->get_all_by_user_id($data['user']->id);
                    $points = $this->user_points_model->get_user_points($data['user']->id);
                    $data['user_points'] = $points->points;
                }
                $points_view_data['user_points'] = $data['user_points'];
                $data['points_view'] = $this->load->view('util/points_view', $points_view_data, TRUE);

//                $data['coverage'] = $this->restaurant_coverage_area_model->get_by_restaurant_id($cart['restaurant_ids'][0]);
                $data['branches'] = $this->restaurant_branches_model->get_all_by_id($cart['restaurant_subtotals'][0]['restaurant_id']);
                $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
                $data['cities'] = $this->cities_model->get_all();
                $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
                $this->load->view('index', $data);
            } else {
                $this->session->set_flashdata('error', "NO item in Cart");
                redirect('main');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function guest_checkout()
    {
        if (!$this->is_logged_in()) {
            if ($this->cart->total_items() > 0) {
                $this->load->model('general_setting_model');
                $this->load->model('address_type_model');
                $this->load->model('user_addresses_model');
                $this->load->model('user_points_model');
                $this->load->model('payment_method_model');
                $this->load->model('cities_model');
                $this->load->model('cuisine_type_model');
                $this->load->model('restaurant_coverage_area_model');
                $this->load->model('restaurant_branches_model');

                $data['settings'] = $this->general_setting_model->get_setting();
                $data['folder_name'] = 'main';
                $data['file_name'] = 'guest_checkout';
                $data['header_name'] = 'header_after';
                $data['nav_name'] = 'nav_main';
                $cart = $this->prepareCart($this->cart->contents());
                $view_data['restaurant'] = $cart['contents'];
                $data['cart_view'] = $this->load->view('util/checkout_cart', $view_data, TRUE);
                $data['total_cost'] = $cart['total_cost'];
                $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
                //            $data['coverage'] = $this->restaurant_coverage_area_model->get_by_restaurant_id($cart['restaurant_ids'][0]);
                $data['branches'] = $this->restaurant_branches_model->get_all_by_id($cart['restaurant_subtotals'][0]['restaurant_id']);
                $data['cities'] = $this->cities_model->get_all();
                $data['login_url'] = $this->googleplus->loginURL();
                $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
                $this->load->view('index', $data);
            } else {
                $this->session->set_flashdata('error', "NO item in Cart");
                redirect('main');
            }
        } else {
            redirect();
        }
    }

    function is_logged_in()
    {
        $user_id = $this->session->userdata('user_id');
        if ($user_id != '' && $user_id != null) {
            return true;
        } else {
            return false;
        }
    }

    public function guest_cod_checkout()
    {
        $user_cart = $this->prepareCart($this->cart->contents());
        if (isset($user_cart)) {
            $post_data = $this->input->post();

            if (isset($post_data['name']) && !empty($post_data['name']) && isset($post_data['address']) && !empty($post_data['address']) && isset($post_data['contact_no']) && !empty($post_data['contact_no']) && isset($post_data['payment_method_id']) && !empty($post_data['payment_method_id'])) {
                $user_order_data = $this->prepareUserOrderData($post_data);
                $place_order_info = $this->placeTempOrder($user_cart['contents'], $user_order_data, false);
                $order_id = $place_order_info['order_id'];
                redirect('main/thankyou?order_id=' . urlencode($order_id) . '');
            } else {
                $this->session->set_flashdata('error', "Required information not provided");
                redirect('main/guest_checkout');
            }
        } else {
            $this->session->set_flashdata('error', "No item in Cart");
            redirect('main/login');
        }

    }

    private function prepareUserOrderData($post_data)
    {
        $this->load->model('payment_method_model');

        if ($this->ion_auth->logged_in()) {

            $user_data = $this->ion_auth_model->get_user_contact_details($this->session->user_id, $post_data['select_address_id']);
            $user_order_data['user_id'] = $this->session->user_id;
            $user_order_data['user_name'] = $this->session->display_name;
            $user_order_data['user_address_id'] = $post_data['select_address_id'];
            $user_order_data['user_address'] = $user_data->address;
            $user_order_data['user_contactno'] = $user_data->phone;
            $user_order_data['user_email'] = $user_data->email;
            $user_order_data['order_other_info'] = null;
            $points = $this->session->used_points;
            $user_order_data['points_used'] = (isset($points) && !empty($points)) ? $points : 0;

        } else {
            $user_order_data['user_id'] = null;
            $user_order_data['user_name'] = $post_data['name'];
            $user_order_data['user_address_id'] = null;
            $user_order_data['user_address'] = $post_data['address'];
            $user_order_data['user_contactno'] = $post_data['contact_no'];
            $user_order_data['user_email'] = (isset($post_data['email']) && !empty($post_data['email'])) ? $post_data['email'] : null;
            $user_order_data['order_other_info'] = (isset($post_data['other_info']) && !empty($post_data['other_info'])) ? $post_data['other_info'] : null;
            $user_order_data['points_used'] = 0;
        }
        $user_order_data['payment_method_id'] = $post_data['payment_method_id'];
        $pay_name = $this->payment_method_model->get_name_id($post_data['payment_method_id']);
        $user_order_data['payment_method'] = $pay_name->name;
        $user_order_data['delivery_pickup'] = $post_data['delivery_pickup'];
        $user_order_data['delivery_pickup_time'] = (isset($post_data['delivery_pickup_time']) && !empty($post_data['delivery_pickup_time'])) ? $post_data['delivery_pickup_time'] : null;
        if ($post_data['delivery_pickup'] == 1) {
            $this->load->model('restaurant_branches_model');
            $branch_name = $this->restaurant_branches_model->get_branch_address_by_id($post_data['pickup_address_id']);
            $user_order_data['pickup_address_id'] = $post_data['pickup_address_id'];
            $user_order_data['pickup_address'] = $branch_name->branch_address;

        } else {
            $user_order_data['pickup_address_id'] = null;
            $user_order_data['pickup_address'] = null;
        }

        return $user_order_data;
    }

    private function placeTempOrder($cart_contents, $user_order_data, $temp_order = true)
    {
        $order_id = $this->generateRandomString();
        $total_bill = 0;

        foreach ($cart_contents as $cart_content) {
            $this->load->model('order_transactions_model');
            $t_data['order_id'] = $order_id;
            $t_data['user_id'] = $user_order_data['user_id'];
            $t_data['user_name'] = $user_order_data['user_name'];
            $t_data['user_address_id'] = $user_order_data['user_address_id'];
            $t_data['user_address'] = $user_order_data['user_address'];
            $t_data['user_contactno'] = $user_order_data['user_contactno'];
            $t_data['user_email'] = $user_order_data['user_email'];
            $t_data['order_other_info'] = $user_order_data['order_other_info'];
            $t_data['points_used'] = $user_order_data['points_used'];
            $t_data['payment_method_id'] = $user_order_data['payment_method_id'];
            $t_data['payment_method'] = $user_order_data['payment_method'];
            $t_data['delivery_pickup'] = $user_order_data['delivery_pickup'];
            $t_data['delivery_pickup_time'] = $user_order_data['delivery_pickup_time'];
            $t_data['pickup_address_id'] = $user_order_data['pickup_address_id'];
            $t_data['pickup_address'] = $user_order_data['pickup_address'];
            $t_data['discount'] = $cart_content->discount;
            $t_data['discount_type'] = $cart_content->discount_type;
            if ($user_order_data['delivery_pickup'] == 0) {
                $t_data['delivery_charges'] = $cart_content->delivery_charges;
                $t_data['total_amount'] = $cart_content->rest_total;

            } else {
                $t_data['total_amount'] = $cart_content->rest_total - $cart_content->delivery_charges;
                $t_data['delivery_charges'] = 0;
            }
            $t_data['subtotal'] = $cart_content->restaurant_total;
            $t_data['payment_transaction_id'] = null;
            $t_data['datetime'] = null;
            $t_data['restaurant_id'] = $cart_content->id;
            $t_data['restaurant_name'] = $cart_content->name;
            if (isset($cart_content->lug_commision) && !empty($cart_content->lug_commision)) {
                if ($cart_content->commision_type == 2) {
                    $t_data['lugmah_commission'] = round($t_data['total_amount'] * ($cart_content->lug_commision / 100), 3);
                } else {
                    $t_data['lugmah_commission'] = $cart_content->lug_commision;
                }
            } else {
                $t_data['lugmah_commission'] = 0;
            }
            $t_data['created_on'] = time();
            $total_bill = $total_bill + $t_data['total_amount'];
            if ($temp_order) {
                $trans_id = $this->order_transactions_model->create_temp_trans_rec($t_data);
            } else {
                $trans_id = $this->order_transactions_model->create_trans_rec($t_data);
            }
            foreach ($cart_content->c_items as $item) {
                $td_data['trans_id'] = $trans_id;
                $td_data['item_id'] = $item['id'];
                $td_data['item_name'] = $item['name'];
                $td_data['item_price'] = $item['price'];
                $td_data['item_quantity'] = $item['qty'];
                if ($temp_order) {
                    $trans_detail_id = $this->order_transactions_model->create_temp_trans_detail_rec($td_data);
                } else {
                    $trans_detail_id = $this->order_transactions_model->create_trans_detail_rec($td_data);
                }

                if (isset($item['attributes_id']) && !empty($item['attributes_id'])) {
                    $it_atr_ar = explode(',', $item['attributes_id']);
                    $this->load->model('user_item_group_attributes_model');
                    foreach ($it_atr_ar as $value) {
                        $atr_data = $this->user_item_group_attributes_model->get_detail_by_id($value);

                        if (isset($atr_data) && !empty($atr_data)) {
                            $tda_data['trans_detail_id'] = $trans_detail_id;
                            $tda_data['item_attribute_id'] = $value;
                            $tda_data['item_attribute_name'] = $atr_data->name;
                            $tda_data['item_attribute_price'] = $atr_data->price;
                            if ($temp_order) {
                                $this->order_transactions_model->create_temp_trans_item_detail_rec($tda_data);
                            } else {
                                $this->order_transactions_model->create_trans_item_detail_rec($tda_data);
                            }
                        }
                    }
                }
            }
        }
        if (!$temp_order) {
            if ($this->ion_auth->logged_in()) {
                if (isset($user_order_data['points_used']) && !empty($user_order_data['points_used'])) {
                    $up_data['transaction_order_id'] = $order_id;
                    $up_data['user_id'] = $user_order_data['user_id'];
                    $up_data['point'] = -$user_order_data['points_used'];
                    $this->order_transactions_model->user_order_points($up_data);
                    $this->session->unset_userdata('used_points');
                } else {
                    $up_data['transaction_order_id'] = $order_id;
                    $up_data['user_id'] = $user_order_data['user_id'];
                    $up_data['point'] = $total_bill * 0.1;
                    $this->order_transactions_model->user_order_points($up_data);
                }
            }
            $this->cart->destroy();
            $this->sendOrderMail($order_id,$user_order_data['user_email']);
        }
        $r_data['order_id'] = $order_id;
        $r_data['total_bill'] = round($total_bill - $user_order_data['points_used'], 3);
        return $r_data;
    }

    function generateRandomString($length = 22)
    {
        return substr(str_shuffle(str_repeat($x = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / strlen($x)))), 1, $length);
    }

    private function sendOrderMailOLD($order_id = null, $user_email = null)
    {
        if (isset($user_email) && !empty($user_email)) {
            $config['email_config'] = array(
                'mailtype' => 'html',
                'protocol' => 'smtp',
                'smtp_host' => 'mail.grape-studio.com',
                'smtp_port' => 26,
                'smtp_user' => 'master@grape-studio.com', // change it to yours
                'smtp_pass' => '123@..master', // change it to yours
                'charset' => 'iso-8859-1',
                'wordwrap' => TRUE
            );
            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");

            $this->email->clear();
            $this->email->from($this->config->item('info_email', 'ion_auth'), $this->config->item('site_title', 'ion_auth'));
            $this->email->to($user_email);
            $this->email->subject('Lugmah - Order Placed!');
            $view_data['order_id'] = $order_id;
            $email_view = $this->load->view('auth/email/order_placement', $view_data, TRUE);
            $this->email->message($email_view);
            $this->email->set_mailtype("html");

            if ($this->email->send()) {
                $this->session->set_flashdata('success', "Email Sent");
            } else {
                $this->session->set_flashdata('error', "could not sent email");
            }
        }

    }
    private function sendOrderMail($order_id = null, $user_email = null)
    {
        if (isset($user_email) && !empty($user_email)) {
            $config['email_config'] = array(
                'mailtype' => 'html',
                'protocol' => 'smtp',
                'smtp_host' => 'ssl://smtp.zoho.com',
                'smtp_port' => 465,
                'smtp_user' => 'info@lugmah.com', // change it to yours
                'smtp_pass' => 'Lugm@h123', // change it to yours
                'charset' => 'iso-8859-1',
                'wordwrap' => TRUE
            );
            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");

            $this->email->clear();
            $this->email->from('info@lugmah.com', $this->config->item('site_title', 'ion_auth'));
            $this->email->to($user_email);
            $this->email->subject('Lugmah - Order Placed!');
            $view_data['order_id'] = $order_id;
            $email_view = $this->load->view('auth/email/order_placement', $view_data, TRUE);
            $this->email->message($email_view);
            $this->email->set_mailtype("html");

            if ($this->email->send()) {
                $this->session->set_flashdata('success', "Email Sent");
            } else {
                $this->session->set_flashdata('error', "could not sent email");
            }
        }

    }

    public function cod_checkout()
    {
        if ($this->ion_auth->logged_in()) {
            $user_cart = $this->prepareCart($this->cart->contents());
            if (isset($user_cart)) {
                $post_data = $this->input->post();
                if (isset($post_data['select_address_id']) && !empty($post_data['select_address_id'])) {
                    if (isset($post_data['payment_method_id']) && !empty($post_data['payment_method_id'])) {
                        $user_order_data = $this->prepareUserOrderData($post_data);
                        $place_order_info = $this->placeTempOrder($user_cart['contents'], $user_order_data, false);
                        $order_id = $place_order_info['order_id'];
                        redirect('main/thankyou?order_id=' . urlencode($order_id) . '');
                    } else {
                        $this->session->set_flashdata('error', 'Please Select a Payment Method');
                        redirect('dashboard');
                    }
                } else {
                    $this->session->set_flashdata('error', "Please Select Address");
                    redirect('main/checkout');
                }
            } else {
                $this->session->set_flashdata('error', "No item in Cart");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    function order_history()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'order_history';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('general_setting_model');
        $this->load->model('payment_method_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->view('index', $data);
    }

    function see_all_cuisines()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'see_all_cuisines';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $this->load->model('cities_model');
        $this->load->model('general_setting_model');
        $this->load->model('payment_method_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['login_url'] = $this->googleplus->loginURL();
        $data['cities'] = $this->cities_model->get_all();
        $data['banners'] = $this->banners_model->get_promotion_banner(2);
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['cuisine_types'] = $this->cuisine_type_model->get_all();
        $this->load->view('index', $data);
    }

    function login()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'login';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function forget_password()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'forgot_password';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->view('index', $data);
    }

    function get_user_order_details()
    {
        $this->load->model('transaction_model');
        $this->load->model('order_transactions_model');
        $order_id = $this->input->post('order_id');
        if (isset($order_id) && !empty($order_id)) {
            $orders = $this->transaction_model->get_user_order_by_id($order_id);
            foreach ($orders as $order) {
                $order->items = $this->order_transactions_model->get_user_transaction_details($order->trans_id);
                $order_ar[] = $order;
            }
            $view_data['latest_order'] = $order_ar;
            $latest_order_view = $this->load->view('util/account_order_view', $view_data, TRUE);
        } else {
            $latest_order_view = null;
        }
        echo $latest_order_view;
    }

    function reorder()
    {
        $this->load->model('transaction_model');
        $this->load->model('transaction_detail_model');
        $this->load->model('transaction_item_details_model');
        $order_id = $this->input->post('order_id');
        $transaction = $this->transaction_model->get_transaction_by_order_id($order_id);
        $i = 0;
        foreach ($transaction as $row) {
            $transaction_id = $row->id;
            $restaurant_id = $row->restaurant_id;
            if (!empty($restaurant_id)) {
                $transitems = $this->transaction_detail_model->get_items_by_trans_id_two($transaction_id);
                foreach ($transitems as $items) {
                    $detail_data = $this->transaction_item_details_model->get_by_detail_id($items['detail_id']);
                    $data = array(
                        'id' => $items['item_id'],
                        'qty' => $items['item_quantity'],
                        'price' => $items['price'],
                        'name' => $items['name'],
                        'options' => array('restaurant_id' => $restaurant_id, 'attribute_ids' => $detail_data->options_ids)
                    );

                    $this->cart->insert($data);
                    $i++;
                }
            }

        }
        $json['status'] = "ok";
        $json['content'] = $this->cart->contents();
        $json['total'] = $this->cart->total();
        $json['count'] = $i;
        print_r(json_encode($json));

    }

    function add_item_to_cart()
    {
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('user_item_group_attributes_model');
        if (isset($_POST['item_id']) && isset($_POST['item_name']) && isset($_POST['item_price'])) {

            $data = array(
                'id' => $_POST['item_id'],
                'qty' => $_POST['item_qty'],
                'price' => $_POST['item_price'],
                'name' => $_POST['item_name'],
                'options' => array('restaurant_id' => $_POST['rest_id'], 'attribute_ids' => $_POST['attribute_ids'])
            );

            $this->cart->insert($data);

            $cart = $this->prepareCart($this->cart->contents());
            if (isset($cart)) {
                $view_data['content'] = $cart['contents'];
                $json['cart_view'] = $this->load->view('util/menu_cart', $view_data, TRUE);
                $json['items_count'] = $cart['item_count'];
                $json['total_cost'] = $cart['total_cost'];
                $json['status'] = 'OK';
            } else {
                $json['status'] = 'NO_ITEMS';
            }
        } else {
            $json['status'] = 'not allowed';
        }
        print_r(json_encode($json));
    }

    function update_cart()
    {
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('user_item_group_attributes_model');
        if (isset($_POST['row_id']) && isset($_POST['qty'])) {
            $data = array(
                'rowid' => $_POST['row_id'],
                'qty' => $_POST['qty']
            );
            $this->cart->update($data);

            $cart = $this->prepareCart($this->cart->contents());


            if (isset($cart)) {
                $view_data['restaurant'] = $cart['contents'];
                $json['cart_view'] = $this->load->view('util/checkout_cart', $view_data, TRUE);
                $json['items_count'] = $cart['item_count'];
                $json['total_cost'] = $cart['total_cost'];
                $json['status'] = 'OK';
                if (isset($cart['voucher_status'])) {
                    $json['msg'] = 'Voucher Discarded. Minimum amount less than required';
                }
            } else {
                $json['status'] = 'NO_ITEMS';
            }

        } else {

            $json['status'] = 'NOT_ALLOWED';
        }
        print_r(json_encode($json));
    }

    function update_menu_cart()
    {
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('user_item_group_attributes_model');
        if (isset($_POST['row_id']) && isset($_POST['qty'])) {
            $data = array(
                'rowid' => $_POST['row_id'],
                'qty' => $_POST['qty']
            );
            $this->cart->update($data);

            $cart = $this->prepareCart($this->cart->contents());


            if (isset($cart)) {
                $view_data['content'] = $cart['contents'];
                $json['cart_view'] = $this->load->view('util/menu_cart', $view_data, TRUE);
                $json['items_count'] = $cart['item_count'];
                $json['total_cost'] = $cart['total_cost'];
                $json['status'] = 'OK';
            } else {
                $json['status'] = 'NO_ITEMS';
            }

        } else {

            $json['status'] = 'NOT_ALLOWED';
        }
        print_r(json_encode($json));
    }

    public function get_item_attributes()
    {
        $this->load->model('restaurant_menu_items_model');
        $item_id = $this->input->post('item_id');
        $group_attrib = '0';
        if (!empty($item_id)) {
            $item_detail = $this->restaurant_menu_items_model->get_by_id($item_id);
            $item_groups = $this->restaurant_menu_items_model->get_item_groups($item_id);
            if (isset($item_groups)) {
                foreach ($item_groups as $group) {
                    $group->attributes = $this->restaurant_menu_items_model->get_item_group_attributes($group->id);
                    if (!empty($group->attributes)) {
                        $group_attrib = '1';
                    }
                    $groups_ar[] = $group;
                }
                $json['item_id'] = $item_id;
                $json['item_name'] = $item_detail->name;
                $json['item_price'] = $item_detail->price;
                $json['item_description'] = $item_detail->description;
                $json['item_options'] = $groups_ar;
                $json['group_attrib'] = $group_attrib;
            } else {
                $json['item_options'] = null;
            }
            print_r(json_encode($json));
        } else {
            die('NOT ALLOWED');
        }
    }

    function get_order_detail_by_id()
    {
        $this->load->model('transaction_model');
        $order_id = $this->input->post('order_id');
        $data = $this->transaction_model->get_order_detail_by_id($order_id);
        echo json_encode($data);
    }

    public function check_email_exist()
    {
        $user = $this->ion_auth->user()->row();
        $user_email = $user->email;
        $email = $this->input->post('old_email');
        if ($email == $user_email) {


            if ($this->ion_auth->email_check(strtolower($email))) {
                $isAvailable = true;
            } else {
                $isAvailable = false;
            }
            echo json_encode(array(
                'valid' => $isAvailable,
            ));
        } else {
            echo json_encode(array(
                'valid' => false,
            ));
        }
    }

    function fblogin($type = null)
    {

        if (isset($_GET['code'])) {
            $this->facebook_ion_auth->login();
            if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
                redirect('', 'refresh');
                exit();
            }
            redirect('main/login');
            // header('main');
        }
    }

    function delete_fav_user_restaurant()
    {
        $this->load->model('user_fav_restaurant_model');
        $fav_id = $this->uri->segment(3);
        $this->user_fav_restaurant_model->delete($fav_id);
        redirect('main/my_account');

    }

    public function check_minimum_order()
    {
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('user_item_group_attributes_model');
        $content = $this->cart->contents();

        if (!empty($content)) {
            foreach ($content as $con_data) {
                $ids[] = $con_data['options']['restaurant_id'];
            }
            $restaurant_ids = array_unique($ids);
            $total_bill = 0;
            foreach ($restaurant_ids as $row) {
                $restaurant = $this->restaurant_model->get_restaurant_detail_by_id($row);
                $resturant_rating = $this->restaurant_comments_model->get_restaurant_rating_by_id($row);
                $restaurant->rating = $resturant_rating->rating;
                $restaurant->total_rating = $resturant_rating->total_rating;
                $total_price = 0;
                foreach ($content as $content_data) {

                    if ($row == $content_data['options']['restaurant_id']) {
                        $options_names = $this->user_item_group_attributes_model->get_by_id($content_data['options']['attribute_ids']);
                        $items['rowid'] = $content_data['rowid'];
                        $items['id'] = $content_data['id'];
                        $items['qty'] = $content_data['qty'];
                        $items['price'] = $content_data['price'];
                        $items['name'] = $content_data['name'];
                        $items['restaurant_id'] = $content_data['options']['restaurant_id'];
                        $items['attributes_id'] = $content_data['options']['attribute_ids'];
                        $items['attributes_name'] = $options_names->options_name;
                        $items['attributes_price'] = $options_names->option_price;
                        $items['subtotal'] = round($content_data['qty'] * ($content_data['price'] + $options_names->option_price), 3);
                        $cart_item[] = $items;
                        $total_price = round($total_price + $items['subtotal'], 3);
                    }
                }
                $restaurant->c_items = $cart_item;
                $discount = $restaurant->discount;
                $restaurant->totalbill = round($total_price, 3);
                $total_price_discount = $total_price / 100 * $discount;
                $restaurant->discount = round($total_price_discount, 3);
                $new_total_price = $total_price - $total_price_discount;
                $restaurant->rest_total = round($new_total_price + $restaurant->delivery_charges, 3);
                unset($cart_item);
                $total_bill = round($total_bill + $restaurant->rest_total, 3);
                $rest[] = $restaurant;
            }

            $data['cart_num'] = sizeof($this->cart->contents());
            $data['content'] = $rest;
            $data['total_cost'] = $total_bill;
            $proceed_result = 0;
            foreach ($rest as $result) {
                $min_order[] = $result->min_order;
                $total[] = $result->rest_total;
                $rest_name[] = $result->name;
            }

            for ($i = 0; $i < sizeof($min_order); $i++) {
                if ($min_order[$i] > $total[$i]) {
                    $proceed_result = 1;
                    $r_name = $rest_name[$i];
                }
            }
            if ($proceed_result == 1) {
                $json['proceed_result'] = 1;
                $json['name'] = $r_name;
            } else {
                $json['proceed_result'] = 0;
            }

        } else {
            $json['proceed_result'] = 2;
        }
        print_r(json_encode($json));

    }

    public function payment_checkout()
    {
        if ($this->ion_auth->logged_in()) {

            $user_cart = $this->prepareCart($this->cart->contents());
            if (isset($user_cart)) {
                $post_data = $this->input->post();
                if (isset($post_data['select_address_id']) && !empty($post_data['select_address_id'])) {
                    if (isset($post_data['payment_method_id']) && !empty($post_data['payment_method_id'])) {
                        $user_order_data = $this->prepareUserOrderData($post_data);
                        $place_order_info = $this->placeTempOrder($user_cart['contents'], $user_order_data);
                        $order_id = $place_order_info['order_id'];
                        $total_bill = $place_order_info['total_bill'];

                        if ($total_bill == 0) {
                            $r_order_id = $this->placeUserOrder($order_id);
                            if (isset($r_order_id) && !empty($r_order_id)) {
                                redirect('main/thankyou?order_id=' . urlencode($r_order_id) . '');
                            } else {
                                $this->session->set_flashdata('error', "Error: Please try again");
                                redirect('main/checkout');
                            }

                        } else {
                            $encode_order_id = urlencode($order_id);
                            $success_url = base_url('main/success_checkout');
                            $error_url = base_url('main/error_checkout');
                            $url = 'http://www.hesabe.com/authpost';
                            $data = array('MerchantCode' => '502816', 'Amount' => number_format($total_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_order_id);
                            $options = array(
                                'http' => array(
                                    'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                                    'method' => 'POST',
                                    'content' => http_build_query($data)
                                )
                            );
                            $context = stream_context_create($options);
                            $result = file_get_contents($url, false, $context);
                            $json = json_decode($result);
                            if ($json->status === 'success') {
                                $token = $json->data->token;
                                $paymenturl = $json->data->paymenturl;
                                $url = $paymenturl . $token;
                                redirect($url);
                            } else {
                                redirect($error_url);
                            }
                        }
                    } else {
                        $this->session->set_flashdata('error', 'Please Select a Payment Method');
                        redirect('dashboard');
                    }
                } else {
                    $this->session->set_flashdata('error', "Please Select Address First");
                    redirect('main/checkout');
                }
            } else {
                $this->session->set_flashdata('error', "No item in Cart");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    private function placeUserOrder($cart_order_id = null, $payment_transaction_id = null, $payment_datetime = null)
    {

        if (isset($cart_order_id) && !empty($cart_order_id)) {
            $this->load->model('order_transactions_model');
            $temp_orders = $this->order_transactions_model->get_user_temp_transaction($cart_order_id);
            if (isset($temp_orders)) {
                $order_id = $this->generateRandomString();
                $total_bill = 0;
                $user_email = null;
                foreach ($temp_orders as $temp_order) {
                    $t_data['order_id'] = $order_id;
                    $t_data['user_id'] = $temp_order->user_id;
                    $t_data['user_name'] = $temp_order->user_name;
                    $t_data['user_address_id'] = $temp_order->user_address_id;
                    $t_data['user_address'] = $temp_order->user_address;
                    $t_data['user_contactno'] = $temp_order->user_contactno;
                    $t_data['user_email'] = $temp_order->user_email;
                    $user_email = $temp_order->user_email;
                    $t_data['order_other_info'] = $temp_order->order_other_info;
                    $t_data['points_used'] = $temp_order->points_used;
                    $t_data['payment_method_id'] = $temp_order->payment_method_id;
                    $t_data['payment_method'] = $temp_order->payment_method;
                    $t_data['delivery_pickup'] = $temp_order->delivery_pickup;
                    $t_data['delivery_pickup_time'] = $temp_order->delivery_pickup_time;
                    $t_data['pickup_address_id'] = $temp_order->pickup_address_id;
                    $t_data['pickup_address'] = $temp_order->pickup_address;
                    $t_data['discount'] = $temp_order->discount;
                    $t_data['discount_type'] = $temp_order->discount_type;
                    $t_data['delivery_charges'] = $temp_order->delivery_charges;
                    $t_data['total_amount'] = $temp_order->total_amount;
                    $t_data['subtotal'] = $temp_order->subtotal;
                    $t_data['payment_transaction_id'] = (isset($payment_transaction_id) && !empty($payment_transaction_id)) ? $payment_transaction_id : null;
                    $t_data['datetime'] = (isset($payment_datetime) && !empty($payment_datetime)) ? $payment_datetime : null;
                    $t_data['restaurant_id'] = $temp_order->restaurant_id;
                    $t_data['restaurant_name'] = $temp_order->restaurant_name;
                    $t_data['lugmah_commission'] = $temp_order->lugmah_commission;
                    $t_data['created_on'] = time();
                    $total_bill = $total_bill + $t_data['total_amount'];
                    $trans_id = $this->order_transactions_model->create_trans_rec($t_data);
                    $temp_order_details = $this->order_transactions_model->get_user_temp_transaction_detail($temp_order->id);
                    if (isset($temp_order_details)) {
                        foreach ($temp_order_details as $temp_order_detail) {
                            $td_data['trans_id'] = $trans_id;
                            $td_data['item_id'] = $temp_order_detail->item_id;
                            $td_data['item_name'] = $temp_order_detail->item_name;
                            $td_data['item_price'] = $temp_order_detail->item_price;
                            $td_data['item_quantity'] = $temp_order_detail->item_quantity;
                            $trans_detail_id = $this->order_transactions_model->create_trans_detail_rec($td_data);
                            $temp_order_item_details = $this->order_transactions_model->get_user_temp_transaction_item_details($temp_order_detail->id);
                            if (isset($temp_order_item_details)) {
                                foreach ($temp_order_item_details as $temp_order_item_detail) {
                                    $tda_data['trans_detail_id'] = $trans_detail_id;
                                    $tda_data['item_attribute_id'] = $temp_order_item_detail->item_attribute_id;
                                    $tda_data['item_attribute_name'] = $temp_order_item_detail->item_attribute_name;
                                    $tda_data['item_attribute_price'] = $temp_order_item_detail->item_attribute_price;
                                    $this->order_transactions_model->create_trans_item_detail_rec($tda_data);
                                }
                            }
                        }
                    }
                }
                if ($this->ion_auth->logged_in()) {
                    if (isset($t_data['points_used']) && !empty($t_data['points_used']) && $t_data['points_used'] > 0) {
                        $up_data['transaction_order_id'] = $order_id;
                        $up_data['user_id'] = $t_data['user_id'];
                        $up_data['point'] = -$t_data['points_used'];
                        $this->order_transactions_model->user_order_points($up_data);
                        $this->session->unset_userdata('used_points');
                    } else {
                        $up_data['transaction_order_id'] = $order_id;
                        $up_data['user_id'] = $t_data['user_id'];
                        $up_data['point'] = $total_bill * 0.1;
                        $this->order_transactions_model->user_order_points($up_data);
                    }
                }
                $this->cart->destroy();
                $this->order_transactions_model->delete_temp_cart($cart_order_id);
                $this->sendOrderMail($order_id, $user_email);
                return $order_id;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    public function success_checkout()
    {
        if ($this->ion_auth->logged_in()) {
            $status = $this->input->get('Status');
            if ($status == '1') {
                $order_id = urldecode($this->input->get('Variable1'));
                $payment_transaction_id = $this->input->get('PaymentId');
                $payment_datetime = urldecode($this->input->get('PaidOn'));
                if (!empty($order_id)) {
                    $r_order_id = $this->placeUserOrder($order_id, $payment_transaction_id, $payment_datetime);
                    if (isset($r_order_id) && !empty($r_order_id)) {
                        redirect('main/thankyou?order_id=' . urlencode($r_order_id) . '');
                    } else {
                        $this->session->set_flashdata('error', "Error: Please try again");
                        redirect('main/checkout');
                    }
                } else {
                    $this->session->set_flashdata('error', "No order Id Returned");
                    redirect('main/checkout');
                }
            } else {
                $this->session->set_flashdata('error', "Something Went Wrong");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function error_checkout()
    {

        $order_id = urldecode($this->input->get('Variable1'));
        if ($this->ion_auth->logged_in()) {
            if (!empty($order_id)) {
                $this->load->model('order_transactions_model');
                $this->order_transactions_model->delete_temp_cart($order_id);
                $this->session->set_flashdata('error', "Error: Payment Unsuccessful");
                redirect('main/checkout');
            } else {
                $this->session->set_flashdata('error', "Error: Payment Unsuccessful");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function guest_payment_checkout()
    {
        $user_cart = $this->prepareCart($this->cart->contents());
        if (isset($user_cart)) {
            $post_data = $this->input->post();
            if (isset($post_data['name']) && !empty($post_data['name']) && isset($post_data['address']) && !empty($post_data['address']) && isset($post_data['contact_no']) && !empty($post_data['contact_no']) && isset($post_data['payment_method_id']) && !empty($post_data['payment_method_id'])) {
                $user_order_data = $this->prepareUserOrderData($post_data);
                $place_order_info = $this->placeTempOrder($user_cart['contents'], $user_order_data);
                $order_id = $place_order_info['order_id'];
                $new_tot_bill = $place_order_info['total_bill'];

                $encode_order_id = urlencode($order_id);
                $success_url = base_url('main/guest_success_checkout');
                $error_url = base_url('main/guest_error_checkout');
                $url = 'http://www.hesabe.com/authpost';
                $data = array('MerchantCode' => '502816', 'Amount' => number_format($new_tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_order_id);
                $options = array(
                    'http' => array(
                        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                        'method' => 'POST',
                        'content' => http_build_query($data)
                    )
                );
                $context = stream_context_create($options);
                $result = file_get_contents($url, false, $context);
                $json = json_decode($result);
                if ($json->status === 'success') {
                    $token = $json->data->token;
                    $paymenturl = $json->data->paymenturl;
                    $url = $paymenturl . $token;
                    redirect($url);
                } else {
                    redirect($error_url . '?Variable1=' . $order_id . '');
                }
            } else {
                $this->session->set_flashdata('error', "Required information not provided");
                redirect('main/guest_checkout');
            }
        } else {
            $this->session->set_flashdata('error', "No item in Cart");
            redirect('main/checkout');
        }
    }

    public function guest_success_checkout()
    {
        $status = $this->input->get('Status');
        if ($status == '1') {
            $order_id = urldecode($this->input->get('Variable1'));
            $payment_transaction_id = $this->input->get('PaymentId');
            $payment_datetime = urldecode($this->input->get('PaidOn'));
            if (!empty($order_id)) {

                $r_order_id = $this->placeUserOrder($order_id, $payment_transaction_id, $payment_datetime);
                if (isset($r_order_id) && !empty($r_order_id)) {
                    redirect('main/thankyou?order_id=' . urlencode($r_order_id) . '');
                } else {
                    $this->session->set_flashdata('error', "Error: Please try again");
                    redirect();
                }
            } else {
                $this->session->set_flashdata('error', "No order Id Returned");
                redirect('main/guest_checkout');
            }
        } else {
            $this->session->set_flashdata('error', "Error: No Payment Status Found");
            redirect('main/guest_checkout');
        }
    }

    public function guest_error_checkout()
    {
        $order_id = urldecode($this->input->get('Variable1'));
        if (!empty($order_id)) {
            $this->load->model('order_transactions_model');
            $this->order_transactions_model->delete_temp_cart($order_id);
            $this->session->set_flashdata('error', "Error: Payment Unsuccessful");
            redirect('main/guest_checkout');
        } else {
            $this->session->set_flashdata('error', "Error: Payment Unsuccessful");
            redirect('main/guest_checkout');
        }
    }

    function split_payment()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->library('twilio');
            $this->load->model('split_transaction_model');
            $this->load->model('split_transaction_detail_model');
            $user_cart = $this->prepareCart($this->cart->contents());

            if (isset($user_cart)) {
                $f_data = $this->input->post();
                if (isset($f_data['select_address_id']) && !empty($f_data['select_address_id']) && isset($f_data['payment_method_id']) && !empty($f_data['payment_method_id']) && isset($f_data['phone_no']) && !empty($f_data['phone_no'])) {
                    $user_order_data = $this->prepareUserOrderData($f_data);
                    $place_order_info = $this->placeTempOrder($user_cart['contents'], $user_order_data);
                    if (isset($place_order_info['order_id']) && !empty($place_order_info['order_id'])) {
                        $cart_id = $place_order_info['order_id'];
                        $split_transaction['cart_id'] = $cart_id;
                        $split_transaction['total_amount'] = $place_order_info['total_bill'];
                        $split_id = $this->split_transaction_model->create($split_transaction);
                        $phone_no = $f_data['phone_no'];
                        $price = $f_data['price'];
                        for ($i = 0; $i < sizeof($phone_no); $i++) {
                            $entry[$i]['phone_no'] = $phone_no[$i];
                            $entry[$i]['price'] = $price[$i];
                        }
                        foreach ($entry as $row) {
                            $split_trans_id = $this->generateRandomString();
                            $from = '+1 224-334-3232';
                            $to = '+965'.$row['phone_no'];
                            $s_trans_url = base_url() . 'main/split_transaction_payment?split_transaction_id=' . urlencode($split_trans_id);
                            $message = $s_trans_url;
                            $response = $this->twilio->sms($from, $to, $message);
                            if ($response->IsError) {
                                $split_detail['sms_status'] = '2';
                            } else {
                                $split_detail['sms_status'] = '1';
                            }
                            $split_detail['split_id'] = $split_id;
                            $split_detail['split_trans_id'] = $split_trans_id;
                            $split_detail['amount'] = $row['price'];
                            $split_detail['username_no'] = '+965'.$row['phone_no'];
                            $this->split_transaction_detail_model->create($split_detail);
                        }
                        $admin_detail_data = $this->split_transaction_detail_model->get_by_split_email_id($split_id);
                        $tot_bill = round($admin_detail_data[0]->amount, 3);
                        $encode_split_trans_id = urlencode($admin_detail_data[0]->split_trans_id);
                        $success_url = base_url('main/split_payment_status');
                        $error_url = base_url('main/split_payment_status');
                        $url = 'http://www.hesabe.com/authpost';
                        $data = array('MerchantCode' => '502816', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
                        $options = array(
                            'http' => array(
                                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                                'method' => 'POST',
                                'content' => http_build_query($data)
                            )
                        );
                        $context = stream_context_create($options);
                        $result = file_get_contents($url, false, $context);
                        $json = json_decode($result);
                        if ($json->status === 'success') {
                            $token = $json->data->token;
                            $paymenturl = $json->data->paymenturl;
                            $url = $paymenturl . $token;
                            redirect($url);
                        } else {
                            $this->session->set_flashdata('error', "Can not process Payment at this momment");
                            redirect('main/split_payment_status?split_transaction_id=' . $admin_detail_data[0]->split_trans_id . '');
                        }
                        $data['split_data'] = $this->split_transaction_detail_model->get_by_split_id($split_id);
                        $this->load->model('general_setting_model');
                        $data['settings'] = $this->general_setting_model->get_setting();
                        $data['folder_name'] = 'main';
                        $data['file_name'] = 'split_after';
                        $data['header_name'] = 'header_after';
                        $data['nav_name'] = 'nav_main';
                        $this->load->model('cuisine_type_model');
                        $this->load->model('banners_model');
                        $data['login_url'] = $this->googleplus->loginURL();
                        $data['banners'] = $this->banners_model->get_promotion_banner(2);
                        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
                        $this->load->model('payment_method_model');
                        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
                        $this->load->view('index', $data);
                    } else {
                        $this->session->set_flashdata('error', "Order could not be made");
                        redirect('main/checkout');
                    }
                } else {
                    $this->session->set_flashdata('error', "Required Information not ptovided");
                    redirect('main/checkout');
                }
            } else {
                $this->session->set_flashdata('error', "No item in cart");
                redirect();
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function split_transaction_payment()
    {
        $split_trans_id = $this->input->get('split_transaction_id');
        if (isset($split_trans_id)) {
            $split_status = $this->checkUserSplitStatus($split_trans_id);
            if ($split_status['status'] == 'active') {
                $this->load->model('split_transaction_model');
                $this->load->model('split_transaction_detail_model');
                $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
                $tot_bill = round($split_trans_data->amount, 3);
                $encode_split_trans_id = urlencode($split_trans_id);
                $success_url = base_url('main/split_payment_status');
                $error_url = base_url('main/split_payment_status');
                $url = 'http://www.hesabe.com/authpost';
                $data = array('MerchantCode' => '502816', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
                $options = array(
                    'http' => array(
                        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                        'method' => 'POST',
                        'content' => http_build_query($data)
                    )
                );
                $context = stream_context_create($options);
                $result = file_get_contents($url, false, $context);
                $json = json_decode($result);
                if ($json->status === 'success') {
                    $token = $json->data->token;
                    $paymenturl = $json->data->paymenturl;
                    $url = $paymenturl . $token;
                    redirect($url);
                } else {
                    $this->session->set_flashdata('error', "Something Went Wrong");
                    redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
                }
            } else if ($split_status['status'] == 'expired') {
                $this->session->set_flashdata('error', "Expired link");
                redirect('main/expired');
            } else if ($split_status['status'] == 'completed') {

                $this->session->set_flashdata('success', "Your Order has been placed");
                redirect('main');
            } else if ($split_status['status'] == 'pay_admin') {
                $this->load->model('split_transaction_model');
                $this->load->model('split_transaction_detail_model');
                $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
                $tot_bill = round($split_trans_data->amount, 3);
                $encode_split_trans_id = urlencode($split_trans_id);
                $success_url = base_url('main/split_payment_status');
                $error_url = base_url('main/split_payment_status');
                $url = 'http://www.hesabe.com/authpost';
                $data = array('MerchantCode' => '502816', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
                $options = array(
                    'http' => array(
                        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                        'method' => 'POST',
                        'content' => http_build_query($data)
                    )
                );
                $context = stream_context_create($options);
                $result = file_get_contents($url, false, $context);
                $json = json_decode($result);
                if ($json->status === 'success') {
                    $token = $json->data->token;
                    $paymenturl = $json->data->paymenturl;
                    $url = $paymenturl . $token;
                    redirect($url);
                } else {
                    $this->session->set_flashdata('error', "Something Went Wrong");
                    redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
                }
            } elseif ($split_status['status'] == 'admin_link') {
                $this->load->model('split_transaction_model');
                $this->load->model('split_transaction_detail_model');
                $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
                $tot_bill = round($split_trans_data->amount, 3);
                $encode_split_trans_id = urlencode($split_trans_id);
                $success_url = base_url('main/split_payment_status');
                $error_url = base_url('main/split_payment_status');
                $url = 'http://www.hesabe.com/authpost';
                $data = array('MerchantCode' => '502816', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
                $options = array(
                    'http' => array(
                        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                        'method' => 'POST',
                        'content' => http_build_query($data)
                    )
                );
                $context = stream_context_create($options);
                $result = file_get_contents($url, false, $context);
                $json = json_decode($result);
                if ($json->status === 'success') {
                    $token = $json->data->token;
                    $paymenturl = $json->data->paymenturl;
                    $url = $paymenturl . $token;
                    redirect($url);
                } else {
                    $this->session->set_flashdata('error', "Something Went Wrong");
                    redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
                }
            } elseif ($split_status['status'] == 'Error: ORDER NOT PLACED') {
                $this->session->set_flashdata('error', "Something Went Wrong");
                redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
            } elseif ($split_status == 'DB ERROR') {
                $this->session->set_flashdata('error', "Something Went Wrong");
                redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
            } else {
                $this->session->set_flashdata('error', "Something Went Wrong");
                redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
            }
        } else {
            redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
        }
    }

    public function checkUserSplitStatus($split_id = null)
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_status = $this->split_transaction_detail_model->get_split_transaction_status($split_id);
        $com_status = $this->split_transaction_detail_model->check_if_complete($split_status->id);
        if ($com_status->val == 0 && $split_status->user_status != 'completed') {
            $cart = $this->split_transaction_model->get_cart_id($split_status->id);
            $order_id = $this->placeUserOrder($cart->cart_id, 'split,' . $split_status->id, 'split,' . $split_status->id);
            if (isset($order_id)) {
                $this->split_transaction_model->update_split_status($split_status->id, '2');
                $return['status'] = 'completed';
            } else {
                $return['status'] = 'Error: ORDER NOT PLACED';
            }
        } else {
            if ($split_status->user_status == 'exp_split') {
                if ($this->split_transaction_detail_model->expire_split_transaction($split_status->id)) {
                    $return['status'] = 'expired';
                } else {
                    echo 'DB ERROR';
                }

            } else if ($split_status->user_status == 'admin_pay') {
                $admin_link_status = $this->split_transaction_detail_model->check_admin_link($split_status->id);
                if ($admin_link_status->val == 0) {
                    $split_trans_id = $this->generateRandomString();

                    $this->split_transaction_detail_model->expire_users_split($split_status->id);
                    $split_admin = $this->split_transaction_detail_model->get_split_admin($split_status->id);

                    $split_detail['split_id'] = $split_status->id;
                    $split_detail['username_no'] = '+965'.$split_admin->number;
                    $split_detail['amount'] = $com_status->amount;
                    $from = '+1 224-334-3232';
                    $to = '+965'.$split_admin->number;
                    $s_trans_url = base_url() . 'main/split_transaction_payment?split_transaction_id=' . urlencode($split_trans_id);
                    $message = $s_trans_url;
                    $response = $this->twilio->sms($from, $to, $message);
                    if ($response->IsError) {
                        $split_detail['sms_status'] = '2';
                    } else {
                        $split_detail['sms_status'] = '1';
                    }
                    $split_detail['split_trans_id'] = $split_trans_id;

                    $id = $this->split_transaction_detail_model->create_admin_link($split_detail);
                    $admin_link = $this->split_transaction_detail_model->get_by_id($id);
                    $return['status'] = 'pay_admin';
                    $return['split_id'] = $admin_link->split_trans_id;
                    $return['amount'] = $admin_link->amount;
                    $return['time_remaining'] = $admin_link->time_remaining;

                } else {
                    $user_link = $this->split_transaction_detail_model->get_admin_time_by_split_transaction_id($split_id);
                    $return['status'] = 'admin_link';
                    $return['time_remaining'] = $user_link->time_remaining;
                    $return['users_status'] = $this->split_transaction_detail_model->get_split_user_status($split_status->id);
                }

            } else if ($split_status->user_status == 'active') {
                $user_link = $this->split_transaction_detail_model->get_time_by_split_transaction_id($split_id);
                $return['status'] = 'active';
                $return['users_status'] = $this->split_transaction_detail_model->get_split_user_status($split_status->id);
                $return['time_remaining'] = $user_link->time_remaining;

            } else if ($split_status->user_status == 'completed') {
                $return['status'] = 'completed';

            } else {
                $return['status'] = 'expired';
            }
        }

        return $return;

    }

    public function split_transaction_payment_expired()
    {

        $split_trans_id = $this->input->get('split_transaction_id');
        if (isset($split_trans_id)) {
            $this->load->model('split_transaction_model');
            $this->load->model('split_transaction_detail_model');
            $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
            $start_time = $split_trans_data->start_time;
            $check_status = $this->check_active_expired($start_time);
            if ($check_status == '1') {
                $check_payment_status = $this->check_payment_status($split_trans_data->id);
                if ($check_payment_status == true) {
                    $tot_bill = round($split_trans_data->amount, 3);
                    $encode_split_trans_id = urlencode($split_trans_id);
                    $success_url = base_url('main/split_payment_status');
                    $error_url = base_url('main/split_payment_status');
                    $url = 'http://www.hesabe.com/authpost';
                    $data = array('MerchantCode' => '502816', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
                    $options = array(
                        'http' => array(
                            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                            'method' => 'POST',
                            'content' => http_build_query($data)
                        )
                    );
                    $context = stream_context_create($options);
                    $result = file_get_contents($url, false, $context);
                    $json = json_decode($result);
                    if ($json->status === 'success') {
                        //$this->cart->destroy();
                        $token = $json->data->token;
                        $paymenturl = $json->data->paymenturl;
                        $url = $paymenturl . $token;
                        redirect($url);
                    } else {
                        $this->session->set_flashdata('error', "Something Went Wrong");
                        redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
                    }
                } else {
                    $this->session->set_flashdata('success', "Your transaction already completed");
                    redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
                }
            } else {
                redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
            }
        } else {
            redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
        }
    }

    public function check_active_expired($start_time)
    {
        $current_time = date("Y-m-d H:i:s");
        $to_time = strtotime($current_time);
        $from_time = strtotime($start_time);
        $minutes_of_trans = round(abs($to_time - $from_time) / 60, 2);
        if ($minutes_of_trans < '60') {
            return '1';
        } else {
            return '2';
        }

    }

    public function check_payment_status($trans_detail_id)
    {
        $this->load->model('split_transaction_detail_model');
        $split_trans_data = $this->split_transaction_detail_model->get_by_id($trans_detail_id);
        if ($split_trans_data->completed_time == "" && $split_trans_data->completed_time == "") {
            return true;
        } else {
            return false;
        }

    }

    function split_payment_status()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_status = $this->input->get('Status');
        $split_trn_id = urldecode($this->input->get('split_transaction_id'));
        if (!empty($split_trn_id)) {
            $split_trans_id = $this->input->get('split_transaction_id');
        } elseif (!empty($split_status)) {
            $split_status = $this->input->get('Status');
            $split_trans = $this->input->get('Variable1');
            $split_trans_id = urldecode($split_trans);
            $payment_id = $this->input->get('PaymentId');
            if ($split_status == '1') {
                $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
                $check_payment_status = $this->check_payment_status($split_trans_data->id);
                if ($check_payment_status == true) {
                    $this->split_transaction_detail_model->update($split_trans_id, $payment_id);
                }
            }
        } else {
            $this->session->set_flashdata('error', "Please use link again to pay");
            redirect('main');
        }
        $data['split_data'] = $this->checkUserSplitStatus($split_trans_id);
        $this->load->model('general_setting_model');
        $data['split_id'] = $split_trans_id;
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['folder_name'] = 'main';
        $data['file_name'] = 'split_after';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $data['login_url'] = $this->googleplus->loginURL();
        $data['banners'] = $this->banners_model->get_promotion_banner(2);
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function split_payment_status_ajax()
    {
        $split_trans_id = $this->input->get('split_id');
        if (isset($split_trans_id)) {
            $json = $this->checkUserSplitStatus($split_trans_id);
        } else {
            $json = null;
        }
        print_r(json_encode($json));
    }

    function split_status()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_id = $this->input->get('split_id');
        $split_data = $this->split_transaction_model->get_by_id($split_id);
        $start_time = $split_data->start_time;
        $check_status2 = $this->check_active_expired($start_time);
        if ($check_status2 == '1') {
            $json['sp_status'] = '1';
        } else {
            $json['sp_status'] = '2';
        }

        print_r(json_encode($json));
    }

    public function place_split_order()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_id = $this->input->get('split_id');
        if ($this->ion_auth->logged_in()) {
            if (isset($split_id)) {
                $split_data = $this->split_transaction_model->get_by_id($split_id);
                $order_id = $split_data->cart_id;
                if (!empty($order_id)) {
                    $this->cart->destroy();
                    $this->load->model('user_addresses_model');
                    $this->load->model('restaurant_model');
                    $this->load->model('restaurant_comments_model');
                    $this->load->model('cities_model');
                    $this->load->model('user_points_model');
                    $this->load->model('restaurant_coverage_area_model');
                    $this->load->model('general_setting_model');
                    $this->load->model('transaction_model');
                    $this->load->model('transaction_detail_model');
                    $this->load->model('transaction_item_details_model');
                    $this->load->model('temp_transaction_model');
                    $this->load->model('temp_transaction_detail_model');
                    $this->load->model('temp_transaction_item_details_model');
                    $this->load->model('user_item_group_attributes_model');
                    $total_bill = 0;
                    $order_detail = $this->temp_transaction_model->get_by_order($order_id);
                    $points_used = $order_detail[0]->points_used;
                    $user_id = $order_detail[0]->user_id;

                    if (!empty($order_detail)) {
                        foreach ($order_detail as $order) {
                            $trans_data['user_id'] = $order->user_id;
                            $trans_data['status'] = '1';
                            $trans_data['discount'] = round($order->discount, 3);
                            $trans_data['total_amount'] = round($order->total_amount, 3);
                            $trans_data['delivery_charges'] = $order->delivery_charges;
                            $trans_data['select_address_id'] = $order->select_address_id;
                            $trans_data['paymant_method_id'] = $order->paymant_method_id;
                            $trans_data['delivery_pickup'] = $order->delivery_pickup;
                            $trans_data['delivery_pickup_time'] = (empty($order->delivery_pickup_time) ? NULL : $order->delivery_pickup_time);
                            $trans_data['pickup_address_id'] = (empty($order->pickup_address_id) ? NULL : $order->pickup_address_id);
                            $trans_data['subtotal'] = round($order->subtotal, 3);
                            $trans_data['points_used'] = (empty($order->points_used) ? 0 : $order->points_used);
                            $trans_data['order_id'] = $order_id;
                            $trans_data['restaurant_id'] = $order->restaurant_id;
                            $t_id = $this->transaction_model->create_new($trans_data);
                            $total_bill = $total_bill + $order->subtotal;
                            $order_items = $this->temp_transaction_detail_model->get_by_trans_id($order->id);
                            foreach ($order_items as $item) {
                                $trans_details['transaction_id'] = $t_id;
                                $trans_details['item_id'] = $item->item_id;
                                $trans_details['item_quantity'] = $item->item_quantity;
                                $td_id = $this->transaction_detail_model->create($trans_details);
                                $order_item_attrib = $this->temp_transaction_item_details_model->get_by_trans_detail_id($item->id);
                                foreach ($order_item_attrib as $trans_attr) {
                                    $trans_attr_details['trans_detail_id'] = $td_id;
                                    $trans_attr_details['item_attribute_id'] = $trans_attr->item_attribute_id;
                                    $this->transaction_item_details_model->create($trans_attr_details);
                                }
                                $this->temp_transaction_item_details_model->delete($item->id);
                            }
                            $this->temp_transaction_detail_model->delete($order->id);
                        }
                        $this->temp_transaction_model->delete($order_id);
                        $use_point = (empty($points_used) ? 0 : $points_used);
                        if ($use_point == '0') {
                            $user_point['user_id'] = $user_id;
                            $user_point['point'] = round($total_bill * .1, 2);
                            $user_point['transaction_order_id'] = $order_id;
                            $this->user_points_model->create($user_point);
                        } else {
                            $user_point['user_id'] = $user_id;
                            $user_point['point'] = -($use_point);
                            $user_point['transaction_order_id'] = $order_id;
                            $this->user_points_model->create($user_point);
                        }
                        $this->split_transaction_model->update_split($split_id);
                        $this->cart->destroy();
                    }
                    if (!empty($order_id)) {
                        redirect('main/thankyou?order_id=' . urlencode($order_id) . '');
                    } else {
                        $this->session->set_flashdata('error', "Something Went Wrong");
                        redirect('main/checkout');
                    }
                } else {
                    $this->session->set_flashdata('error', "Something Went Wrong");
                    redirect('main/checkout');
                }
            } else {
                $this->session->set_flashdata('error', "Something Went Wrong");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function place_split_order_expire()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_id = $this->input->get('split_id');
        if ($this->ion_auth->logged_in()) {
            if (isset($split_id)) {
                $split_data = $this->split_transaction_model->get_by_id($split_id);
                $order_id = $split_data->cart_id;
                if (!empty($order_id)) {
                    $this->cart->destroy();
                    $this->load->model('temp_transaction_model');
                    $this->load->model('temp_transaction_detail_model');
                    $this->load->model('temp_transaction_item_details_model');
                    $this->load->model('user_item_group_attributes_model');
                    $order_detail = $this->temp_transaction_model->get_by_order($order_id);
                    if (!empty($order_detail)) {
                        foreach ($order_detail as $order) {
                            $order_items = $this->temp_transaction_detail_model->get_by_trans_id($order->id);
                            foreach ($order_items as $item) {
                                $this->temp_transaction_item_details_model->delete($item->id);
                            }
                            $this->temp_transaction_detail_model->delete($order->id);
                        }
                        $this->temp_transaction_model->delete($order_id);
                        $this->split_transaction_model->update_expire_split($split_id);
                        $this->cart->destroy();
                        $this->session->set_flashdata('error', "Split payment Expired");
                        redirect('main');
                    }
                } else {
                    $this->session->set_flashdata('error', "Something Went Wrong");
                    redirect('main/checkout');
                }
            } else {
                $this->session->set_flashdata('error', "Something Went Wrong");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    function guest_split_payment()
    {
        $this->load->library('twilio');
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $user_cart = $this->prepareCart($this->cart->contents());

        if (isset($user_cart)) {
            $f_data = $this->input->post();
            if (isset($f_data['name']) && !empty($f_data['name']) && isset($f_data['address']) && !empty($f_data['address']) && isset($f_data['contact_no']) && !empty($f_data['contact_no']) && isset($f_data['payment_method_id']) && !empty($f_data['payment_method_id']) && isset($f_data['phone_no']) && !empty($f_data['phone_no'])) {
                $user_order_data = $this->prepareUserOrderData($f_data);
                $place_order_info = $this->placeTempOrder($user_cart['contents'], $user_order_data);
                if (isset($place_order_info['order_id']) && !empty($place_order_info['order_id'])) {
                    $cart_id = $place_order_info['order_id'];
                    $split_transaction['cart_id'] = $cart_id;
                    $split_transaction['total_amount'] = $place_order_info['total_bill'];
                    $split_id = $this->split_transaction_model->create($split_transaction);
                    $phone_no = $f_data['phone_no'];
                    $price = $f_data['price'];
                    for ($i = 0; $i < sizeof($phone_no); $i++) {
                        $entry[$i]['phone_no'] = $phone_no[$i];
                        $entry[$i]['price'] = $price[$i];
                    }
                    foreach ($entry as $row) {
                        $split_trans_id = $this->generateRandomString();
                        $from = '+1 224-334-3232';
                        $to = '+965'.$row['phone_no'];
                        $s_trans_url = base_url() . 'main/guest_split_transaction_payment?split_transaction_id=' . urlencode($split_trans_id);
                        $message = $s_trans_url;
                        $response = $this->twilio->sms($from, $to, $message);
                        if ($response->IsError) {
                            $split_detail['sms_status'] = '2';
                        } else {
                            $split_detail['sms_status'] = '1';
                        }
                        $split_detail['split_id'] = $split_id;
                        $split_detail['split_trans_id'] = $split_trans_id;
                        $split_detail['amount'] = $row['price'];
                        $split_detail['username_no'] = '+965'.$row['phone_no'];
                        $this->split_transaction_detail_model->create($split_detail);
                    }
                    $admin_detail_data = $this->split_transaction_detail_model->get_by_split_email_id($split_id);
                    $tot_bill = round($admin_detail_data[0]->amount, 3);
                    $encode_split_trans_id = urlencode($admin_detail_data[0]->split_trans_id);
                    $success_url = base_url('main/guest_split_payment_status');
                    $error_url = base_url('main/guest_split_payment_status');
                    $url = 'http://www.hesabe.com/authpost';
                    $data = array('MerchantCode' => '502816', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
                    $options = array(
                        'http' => array(
                            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                            'method' => 'POST',
                            'content' => http_build_query($data)
                        )
                    );
                    $context = stream_context_create($options);
                    $result = file_get_contents($url, false, $context);
                    $json = json_decode($result);
                    if ($json->status === 'success') {
                        $token = $json->data->token;
                        $paymenturl = $json->data->paymenturl;
                        $url = $paymenturl . $token;
                        redirect($url);
                    } else {
                        $this->session->set_flashdata('error', "Can not process Payment at this momment");
                        redirect('main/guest_split_payment_status?split_transaction_id=' . $admin_detail_data[0]->split_trans_id . '');
                    }
                    $data['split_data'] = $this->split_transaction_detail_model->get_by_split_id($split_id);
                    $this->load->model('general_setting_model');
                    $data['settings'] = $this->general_setting_model->get_setting();
                    $data['folder_name'] = 'main';
                    $data['file_name'] = 'split_after';
                    $data['header_name'] = 'header_after';
                    $data['nav_name'] = 'nav_main';
                    $this->load->model('cuisine_type_model');
                    $this->load->model('banners_model');
                    $data['login_url'] = $this->googleplus->loginURL();
                    $data['banners'] = $this->banners_model->get_promotion_banner(2);
                    $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
                    $this->load->model('payment_method_model');
                    $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
                    $this->load->view('index', $data);
                } else {
                    $this->session->set_flashdata('error', "Order could not be made");
                    redirect('main/checkout');
                }
            } else {
                $this->session->set_flashdata('error', "Required Information not ptovided");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_flashdata('error', "No item in cart");
            redirect();
        }

    }

    public function create_guest_temp_cart($cart_data)
    {
        $this->load->model('user_addresses_model');
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('cities_model');
        $this->load->model('user_points_model');
        $this->load->model('temp_guests_model');
        $this->load->model('temp_guest_order_details_model');
        $this->load->model('restaurant_coverage_area_model');
        $this->load->model('temp_transaction_model');
        $this->load->model('temp_transaction_detail_model');
        $this->load->model('user_item_group_attributes_model');
        $this->load->model('temp_transaction_item_details_model');
        if (sizeof($this->cart->contents()) != '0') {
            $content = $this->cart->contents();
            if (!empty($content)) {
                foreach ($content as $con_data) {
                    $ids[] = $con_data['options']['restaurant_id'];
                }
                $restaurant_ids = array_unique($ids);
                $total_bill = 0;
                foreach ($restaurant_ids as $row) {
                    $restaurant = $this->restaurant_model->get_restaurant_detail_by_id($row);
                    $resturant_rating = $this->restaurant_comments_model->get_restaurant_rating_by_id($row);
                    $restaurant->rating = $resturant_rating->rating;
                    $restaurant->total_rating = $resturant_rating->total_rating;
                    $total_price = 0;
                    foreach ($content as $content_data) {
                        if ($row == $content_data['options']['restaurant_id']) {
                            $options_names = $this->user_item_group_attributes_model->get_by_id($content_data['options']['attribute_ids']);
                            $items['rowid'] = $content_data['rowid'];
                            $items['id'] = $content_data['id'];
                            $items['qty'] = $content_data['qty'];
                            $items['price'] = $content_data['price'];
                            $items['name'] = $content_data['name'];
                            $items['restaurant_id'] = $content_data['options']['restaurant_id'];
                            $items['attributes_id'] = $content_data['options']['attribute_ids'];
                            $items['attributes_name'] = $options_names->options_name;
                            $items['attributes_price'] = $options_names->option_price;
                            $items['subtotal'] = round($content_data['qty'] * ($content_data['price'] + $options_names->option_price), 3);
                            $cart_item[] = $items;
                            $total_price = round($total_price + $items['subtotal'], 3);
                        }
                    }
                    $restaurant->c_items = $cart_item;
                    $discount = $restaurant->discount;
                    $restaurant->totalbill = round($total_price, 3);
                    $total_price_discount = $total_price / 100 * $discount;
                    $restaurant->discount = round($total_price_discount, 3);
                    $new_total_price = $total_price - $total_price_discount;
                    $restaurant->rest_total = round($new_total_price + $restaurant->delivery_charges, 3);
                    unset($cart_item);
                    $total_bill = round($total_bill + $restaurant->rest_total, 3);
                    $rest[] = $restaurant;
                }
                $data['restaurant'] = $rest;
                $data['total_cost'] = $total_bill;
            }
            $payment_method_id = $cart_data['payment_method_id'];
            $pickup_address_id = $cart_data['pickup_address_id'];
            $delivery_pickup = $cart_data['delivery_pickup'];
            $order_time = $cart_data['order_time'];
            $order_id = base64_encode(mcrypt_create_iv("12", MCRYPT_DEV_URANDOM));
            foreach ($data['restaurant'] as $key) {
                if ($order_time == 1) {
                    $delivery_pickup_time = $this->input->post('delivery_pickup_time');
                } else {
                    $delivery_pickup_time = $key->delivery_time;
                }
                if ($delivery_pickup == 0) {
                    $restaurant_total = $key->totalbill + $key->delivery_charges;
                } else {
                    $restaurant_total = $key->totalbill - $key->delivery_charges;
                }
                $subtotal = $restaurant_total - $key->discount;
                $trans_data['user_id'] = NULL;
                $trans_data['status'] = '1';
                $trans_data['discount'] = round($key->discount, 2);
                $trans_data['total_amount'] = round($key->totalbill, 3);
                $trans_data['delivery_charges'] = $key->delivery_charges;
                $trans_data['select_address_id'] = NULL;
                $trans_data['paymant_method_id'] = $payment_method_id;
                $trans_data['delivery_pickup'] = $delivery_pickup;
                $trans_data['delivery_pickup_time'] = (empty($delivery_pickup_time) ? NULL : $delivery_pickup_time);
                $trans_data['pickup_address_id'] = (empty($pickup_address_id) ? NULL : $pickup_address_id);
                $trans_data['subtotal'] = round($subtotal, 3);
                $trans_data['points_used'] = (empty($points_used) ? 0 : $points_used);
                $trans_data['order_id'] = $order_id;
                $trans_data['restaurant_id'] = $key->id;
                $t_id = $this->temp_transaction_model->create_new($trans_data);
                foreach ($key->c_items as $item) {
                    $trans_details['transaction_id'] = $t_id;
                    $trans_details['item_id'] = $item['id'];
                    $trans_details['item_quantity'] = $item['qty'];
                    $td_id = $this->temp_transaction_detail_model->create($trans_details);
                    $attribute_ids = $item['attributes_id'];
                    if (!empty($attribute_ids)) {
                        $attr_id = explode(',', $attribute_ids);
                        foreach ($attr_id as $trans_attr) {
                            $trans_attr_details['trans_detail_id'] = $td_id;
                            $trans_attr_details['item_attribute_id'] = $trans_attr;
                            $this->temp_transaction_item_details_model->create($trans_attr_details);
                        }
                    }
                }
            }
            $name = $cart_data['name'];
            $address = $cart_data['address'];
            $contact_no = $cart_data['contact_no'];
            $email = $cart_data['email'];
            $other_info = $cart_data['other_info'];
            $guest_id = $this->temp_guests_model->create(array(
                'name' => $name,
                'address' => $address,
                'contact_no' => $contact_no,
                'email' => $email,
                'other_info' => $other_info
            ));
            $this->temp_guest_order_details_model->create(array(
                'guest_id' => $guest_id,
                'order_id' => $order_id
            ));
            $this->cart->destroy();
            return $order_id;
        } else {
            return false;
        }
    }

    public function guest_split_transaction_payment()
    {
        $split_trans_id = $this->input->get('split_transaction_id');
        if (isset($split_trans_id)) {
            $this->load->model('split_transaction_model');
            $this->load->model('split_transaction_detail_model');
            $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
            $split_tran_status = $this->check_splitt_status($split_trans_data->split_id);
            if ($split_tran_status == true) {
                $start_time = $split_trans_data->start_time;
                $check_status = $this->check_active($start_time);
                if ($check_status == 'Active') {
                    $check_payment_status = $this->check_payment_status($split_trans_data->id);
                    if ($check_payment_status == true) {
                        $tot_bill = round($split_trans_data->amount, 3);
                        $encode_split_trans_id = urlencode($split_trans_id);
                        $success_url = base_url('main/guest_split_payment_status');
                        $error_url = base_url('main/guest_split_payment_status');
                        $url = 'http://www.hesabe.com/authpost';
                        $data = array('MerchantCode' => '502816', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
                        $options = array(
                            'http' => array(
                                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                                'method' => 'POST',
                                'content' => http_build_query($data)
                            )
                        );
                        $context = stream_context_create($options);
                        $result = file_get_contents($url, false, $context);
                        $json = json_decode($result);
                        if ($json->status === 'success') {
                            //$this->cart->destroy();
                            $token = $json->data->token;
                            $paymenturl = $json->data->paymenturl;
                            $url = $paymenturl . $token;
                            redirect($url);
                        } else {
                            $this->session->set_flashdata('error', "Something Went Wrong");
                            redirect('main/guest_split_payment_status?split_transaction_id=' . $split_trans_id . '');
                        }
                    } else {
                        $this->session->set_flashdata('success', "Your transaction already completed");
                        redirect('main/guest_split_payment_status?split_transaction_id=' . $split_trans_id . '');
                    }
                } else {
                    redirect('main/guest_split_payment_status?split_transaction_id=' . $split_trans_id . '');
                }
            } else {
                $this->session->set_flashdata('error', "Expired Link");
                redirect('main/expired');
            }
        } else {
            redirect('main/guest_split_payment_status?split_transaction_id=' . $split_trans_id . '');
        }
    }

    public function check_splitt_status($split_id)
    {
        $this->load->model('split_transaction_model');
        $split_data = $this->split_transaction_model->get_by_id($split_id);
        if ($split_data->status == '1') {
            return true;
        } else {
            return false;
        }

    }

    public function check_active($start_time)
    {
        $current_time = date("Y-m-d H:i:s");
        $to_time = strtotime($current_time);
        $from_time = strtotime($start_time);
        $minutes_of_trans = round(abs($to_time - $from_time) / 60, 2);
        if ($minutes_of_trans < '45') {
            return 'Active';
        } else {
            return 'Expired';
        }

    }

    function guest_split_payment_status()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_status = $this->input->get('Status');
        $split_trn_id = urldecode($this->input->get('split_transaction_id'));
        if (!empty($split_trn_id)) {
            $split_trans_id = $this->input->get('split_transaction_id');
        } elseif (!empty($split_status)) {
            $split_status = $this->input->get('Status');
            $split_trans = $this->input->get('Variable1');
            $split_trans_id = urldecode($split_trans);
            $payment_id = $this->input->get('PaymentId');
            if ($split_status == '1') {
                $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
                $check_payment_status = $this->check_payment_status($split_trans_data->id);
                if ($check_payment_status == true) {
                    $this->split_transaction_detail_model->update($split_trans_id, $payment_id);
                }
            }
        } else {
            $this->session->set_flashdata('error', "Please use link again to pay");
            redirect('main');
        }
        $data['split_data'] = $this->checkUserSplitStatus($split_trans_id);
        $this->load->model('general_setting_model');
        $data['split_id'] = $split_trans_id;
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['folder_name'] = 'main';
        $data['file_name'] = 'split_after';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $data['login_url'] = $this->googleplus->loginURL();
        $data['banners'] = $this->banners_model->get_promotion_banner(2);
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function guest_split_payment_status_ajax()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_id = $this->input->get('split_id');
        $split_data = $this->split_transaction_detail_model->get_by_split_id($split_id);
        $split_admin = $this->split_transaction_model->get_user_by_split_id($split_id);
        foreach ($split_data as $row) {
            $status_sp['status'] = $row->status;
            $status_sp['username_no'] = $row->username_no;
            $status_sp['split_trans_id'] = $row->split_trans_id;
            $start_time = $row->start_time;
            $split_data_all[] = $status_sp;

        }
        $json['split_data'] = $split_data_all;
        $status_split = $this->split_transaction_detail_model->get_split_status($split_id);
        if (empty($status_split)) {
            $json['status'] = '2';
        } else {
            $json['status'] = '1';
        }

        print_r(json_encode($json));
    }

    public function place_guest_split_order()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_id = $this->input->get('split_id');
        if (isset($split_id)) {
            $split_data = $this->split_transaction_model->get_by_id($split_id);
            $order_id = $split_data->cart_id;
            if (!empty($order_id)) {
                $this->cart->destroy();
                $this->load->model('temp_guests_model');
                $this->load->model('temp_guest_order_details_model');
                $this->load->model('user_addresses_model');
                $this->load->model('restaurant_model');
                $this->load->model('restaurant_comments_model');
                $this->load->model('cities_model');
                $this->load->model('user_points_model');
                $this->load->model('restaurant_coverage_area_model');
                $this->load->model('general_setting_model');
                $this->load->model('transaction_model');
                $this->load->model('transaction_detail_model');
                $this->load->model('transaction_item_details_model');
                $this->load->model('temp_transaction_model');
                $this->load->model('temp_transaction_detail_model');
                $this->load->model('temp_transaction_item_details_model');
                $this->load->model('user_item_group_attributes_model');
                $total_bill = 0;
                $order_detail = $this->temp_transaction_model->get_by_order($order_id);
                $points_used = $order_detail[0]->points_used;

                if (!empty($order_detail)) {
                    foreach ($order_detail as $order) {
                        $trans_data['user_id'] = NULL;
                        $trans_data['status'] = '1';
                        $trans_data['discount'] = round($order->discount, 3);
                        $trans_data['total_amount'] = round($order->total_amount, 3);
                        $trans_data['delivery_charges'] = $order->delivery_charges;
                        $trans_data['select_address_id'] = NULL;
                        $trans_data['paymant_method_id'] = $order->paymant_method_id;
                        $trans_data['delivery_pickup'] = $order->delivery_pickup;
                        $trans_data['delivery_pickup_time'] = (empty($order->delivery_pickup_time) ? NULL : $order->delivery_pickup_time);
                        $trans_data['pickup_address_id'] = (empty($order->pickup_address_id) ? NULL : $order->pickup_address_id);
                        $trans_data['subtotal'] = round($order->subtotal, 3);
                        $trans_data['points_used'] = (empty($order->points_used) ? 0 : $order->points_used);
                        $trans_data['order_id'] = $order_id;
                        $trans_data['restaurant_id'] = $order->restaurant_id;
                        $t_id = $this->transaction_model->create_new($trans_data);
                        $total_bill = $total_bill + $order->subtotal;
                        $order_items = $this->temp_transaction_detail_model->get_by_trans_id($order->id);
                        foreach ($order_items as $item) {
                            $trans_details['transaction_id'] = $t_id;
                            $trans_details['item_id'] = $item->item_id;
                            $trans_details['item_quantity'] = $item->item_quantity;
                            $td_id = $this->transaction_detail_model->create($trans_details);
                            $order_item_attrib = $this->temp_transaction_item_details_model->get_by_trans_detail_id($item->id);
                            foreach ($order_item_attrib as $trans_attr) {
                                $trans_attr_details['trans_detail_id'] = $td_id;
                                $trans_attr_details['item_attribute_id'] = $trans_attr->item_attribute_id;
                                $this->transaction_item_details_model->create($trans_attr_details);
                            }
                            $this->temp_transaction_item_details_model->delete($item->id);
                        }
                        $this->temp_transaction_detail_model->delete($order->id);
                    }
                    $temp_guest_detail = $this->temp_guest_order_details_model->get_by_order_id($order_id);
                    $temp_guest = $this->temp_guests_model->get_by_id($temp_guest_detail->guest_id);
                    $guest['name'] = $temp_guest->name;
                    $guest['address'] = $temp_guest->address;
                    $guest['contact_no'] = $temp_guest->contact_no;
                    $guest['email'] = $temp_guest->email;
                    $guest['other_info'] = $temp_guest->other_info;
                    $g_id = $this->transaction_model->create_guest($guest);
                    $guest_detail['guest_id'] = $g_id;
                    $guest_detail['order_id'] = $order_id;
                    $this->transaction_model->create_guest_details($guest_detail);
                    $this->temp_guest_order_details_model->delete($temp_guest_detail->guest_id);
                    $this->temp_guests_model->delete($temp_guest_detail->guest_id);
                    $this->temp_transaction_model->delete($order_id);
                    $this->split_transaction_model->update_split($split_id);
                    $this->cart->destroy();
                }
                if (!empty($order_id)) {
                    redirect('main/thankyou?order_id=' . urlencode($order_id) . '');
                } else {
                    $this->session->set_flashdata('error', "Something Went Wrong");
                    redirect('main/guest_checkout');
                }
            } else {
                $this->session->set_flashdata('error', "Something Went Wrong");
                redirect('main/guest_checkout');
            }
        } else {
            $this->session->set_flashdata('error', "Something Went Wrong");
            redirect('main/guest_checkout');
        }
    }

    public function place_guest_split_order_expire()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_id = $this->input->get('split_id');
        if (isset($split_id)) {
            $split_data = $this->split_transaction_model->get_by_id($split_id);
            $order_id = $split_data->cart_id;
            if (!empty($order_id)) {
                $this->cart->destroy();
                $this->load->model('temp_transaction_model');
                $this->load->model('temp_transaction_detail_model');
                $this->load->model('temp_transaction_item_details_model');
                $this->load->model('user_item_group_attributes_model');
                $order_detail = $this->temp_transaction_model->get_by_order($order_id);
                if (!empty($order_detail)) {
                    foreach ($order_detail as $order) {
                        $order_items = $this->temp_transaction_detail_model->get_by_trans_id($order->id);
                        foreach ($order_items as $item) {
                            $this->temp_transaction_item_details_model->delete($item->id);
                        }
                        $this->temp_transaction_detail_model->delete($order->id);
                    }
                    $this->temp_transaction_model->delete($order_id);
                    $this->split_transaction_model->update_expire_split($split_id);
                    $this->cart->destroy();
                    $this->session->set_flashdata('error', "Split payment Expired");
                    redirect('main');
                }
            } else {
                $this->session->set_flashdata('error', "Something Went Wrong");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_flashdata('error', "Something Went Wrong");
            redirect('main/checkout');
        }
    }

    function guest_split_status()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_id = $this->input->get('split_id');
        $split_data = $this->split_transaction_model->get_by_id($split_id);
        $start_time = $split_data->start_time;
        $check_status = $this->check_active($start_time);
        if ($check_status == 'Active') {
            $json['sp_status'] = '1';
        } else {
            $json['sp_status'] = '2';
        }

        print_r(json_encode($json));
    }

    function expired()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'expired';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('payment_method_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->model('cuisine_type_model');
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->view('index', $data);
    }

    public function get_restaurants_name()
    {
        $this->load->model('restaurant_model');
        if (isset($_GET['term'])) {
            $q = strtolower($_GET['term']);
            $this->restaurant_model->get_restaurant($q);
        }
    }

    public function apply_voucher()
    {

        $this->load->model('restaurant_model');
        $post_code = $this->input->post('voucher_code');
        $voucher_data = explode('|', $post_code);
        $voucher = $this->restaurant_model->check_restaurant_promotion($voucher_data[0], $voucher_data[1]);

        if (isset($voucher)) {
            $min_check = $this->minimumOrderCheck($voucher_data[0], $voucher->minimum_amount);
            if ($min_check) {
                $data = array(
                    'id' => 'voucher',
                    'qty' => '1',
                    'price' => '0',
                    'name' => $voucher_data[1],
                    'options' => array('restaurant_id' => $voucher_data[0], 'attribute_ids' => '')
                );

                $this->cart->insert($data);

                $cart = $this->prepareCart($this->cart->contents());
                if (isset($cart)) {
                    $view_data['restaurant'] = $cart['contents'];
                    $json['cart_view'] = $this->load->view('util/checkout_cart', $view_data, TRUE);
                    $json['items_count'] = $cart['item_count'];
                    $json['total_cost'] = $cart['total_cost'];
                    $json['status'] = 'OK';
                } else {
                    $json['status'] = 'NO_ITEMS';
                }
            } else {
                $json['status'] = 'MIN_ORDER';
            }
        } else {
            $json['status'] = 'NO_VOUCHER';
        }

        print_r(json_encode($json));
    }

    public function minimumOrderCheck($id, $amount)
    {
        $check = FALSE;
        $cart = $this->prepareCart($this->cart->contents());
        foreach ($cart['restaurant_subtotals'] as $total) {
            if ($total['restaurant_id'] == $id && $total['total'] >= $amount) {
                $check = TRUE;
            }
        }
        return $check;
    }

    public function apply_points()
    {

        $this->load->model('user_points_model');
        $points = $this->input->post('points');
        if (isset($points) && !empty($points)) {
            if ($this->ion_auth->logged_in()) {
                $data['user'] = $this->ion_auth->user()->row();
                $points_data = $this->user_points_model->get_user_points($data['user']->id);
                $user_points = $points_data->points;
            }
            if (isset($user_points) && !empty($user_points)) {

                if ($user_points >= $points) {
                    $cart = $this->prepareCart($this->cart->contents());
                    if ($points <= $cart['subtotal_cost']) {
                        $this->session->set_userdata('used_points', $points);
                        $points_view_data['user_points'] = $user_points;
                        $json['points_view'] = $this->load->view('util/points_view', $points_view_data, TRUE);
                        $json['total_cost'] = $cart['subtotal_cost'] - $points;
                        $json['points_used'] = $points;
                        $json['status'] = 'OK';
                    } else {
                        $points = $cart['subtotal_cost'];
                        $this->session->set_userdata('used_points', $points);
                        $points_view_data['user_points'] = $user_points;
                        $json['points_view'] = $this->load->view('util/points_view', $points_view_data, TRUE);
                        $json['total_cost'] = $cart['subtotal_cost'] - $points;
                        $json['points_used'] = $points;
                        $json['status'] = 'OK';
                    }

                } else {
                    $json['status'] = 'NO_POINTS';
                }

            } else {
                $json['status'] = 'ERROR';

            }
            print_r(json_encode($json));
        } else {
            die('NOT_ALLOWED');
        }
    }

    public function clear_points()
    {
        $this->load->model('user_points_model');
        if ($this->ion_auth->logged_in()) {
            $cart = $this->prepareCart($this->cart->contents());
            $data['user'] = $this->ion_auth->user()->row();
            $points_data = $this->user_points_model->get_user_points($data['user']->id);
            $user_points = $points_data->points;
            $this->session->unset_userdata('used_points');
            $points_view_data['user_points'] = $user_points;
            $json['points_view'] = $this->load->view('util/points_view', $points_view_data, TRUE);
            $json['total_cost'] = $cart['subtotal_cost'];
            $json['status'] = 'OK';
        } else {
            $json['status'] = 'ERROR';
        }
        print_r(json_encode($json));

    }
}