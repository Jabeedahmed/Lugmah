<?php
class Transaction_item_details_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'trans_detail_id' => $item['trans_detail_id'],
			'item_attribute_id' => $item['item_attribute_id']
			 ); 

		$this->db->insert('transaction_item_details', $data);
	}

	function get_by_detail_id($id)
	{
		$this->db->select('GROUP_CONCAT(user_item_group_attributes.id SEPARATOR ",") AS options_ids,GROUP_CONCAT(user_item_group_attributes.name SEPARATOR ",") AS options_name,SUM(user_item_group_attributes.price) AS option_price');
		$this->db->from('transaction_item_details');
	$this->db->join("user_item_group_attributes", "transaction_item_details.item_attribute_id = user_item_group_attributes.id", "INNER");
		$this->db->where('trans_detail_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('transaction_item_details');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'trans_detail_id' => $item['trans_detail_id'],
			'item_attribute_id' => $item['item_attribute_id']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('transaction_item_details', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('transaction_item_details');
	}
}