<?php

class About_us_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    function create($item)
    {
        $data = array(
            'description' => $item['description']
        );

        $this->db->insert('about_us', $data);
    }

    function get_by_id($id)
    {
        $this->db->select('*');
        $this->db->from('about_us');
        $this->db->where('id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_all()
    {
        $this->db->select('*');
        $this->db->from('about_us');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_all_about_us_title()
    {
        $this->db->select('about_us_title.id,about_us_title.main_title');
        $this->db->from('about_us_title');
        $this->db->join('about_us','about_us_title.id = about_us.title','inner');
        $this->db->group_by('about_us_title.id');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_all_about_us_by_title($title_id)
    {
        $this->db->select('description');
        $this->db->from('about_us');
        $this->db->where('title',$title_id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function update($id, $item)
    {
        $data = array(
            'description' => $item['description']
        );

        $this->db->where('id', $id);
        $this->db->update('about_us', $data);
    }

    function delete($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('about_us');
    }

    function get_all_about_us()
    {
        $this->db->select('description');
        $this->db->from('about_us');
        $this->db->where('title', '3');

        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_all_quick_fact()
    {
        $this->db->select('description');
        $this->db->from('about_us');
        $this->db->where('title', 'quick_facts');

        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_all_why_lughma()
    {
        $this->db->select('description');
        $this->db->from('about_us');
        $this->db->where('title', 'why_lugmah');

        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

}