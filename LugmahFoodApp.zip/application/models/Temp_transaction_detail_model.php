<?php
class Temp_transaction_detail_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
				'transaction_id' => $item['transaction_id'],
				'item_id' => $item['item_id'],
				'item_quantity' => $item['item_quantity']
		);

		$this->db->insert('temp_transaction_detail', $data);
		return $this->db->insert_id();
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('temp_transaction_detail');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_by_trans_id($id)
	{
		$this->db->select('*');
		$this->db->from('temp_transaction_detail');
		$this->db->where('transaction_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('temp_transaction_detail');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function get_items_by_trans_id($id)
	{
		$this->db->select('temp_transaction_detail.id as detail_id,restaurant_menu_items.name,restaurant_menu_items.price,temp_transaction_detail.item_quantity');
		$this->db->from('temp_transaction_detail');
		$this->db->join("restaurant_menu_items", "temp_transaction_detail.item_id = restaurant_menu_items.id", "INNER");
		$this->db->where('temp_transaction_detail.transaction_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function get_items_by_trans_id_two($id)
	{
		$this->db->select('*,temp_transaction_detail.id as detail_id');
		$this->db->from('temp_transaction_detail');
		$this->db->join("restaurant_menu_items", "temp_transaction_detail.item_id = restaurant_menu_items.id", "INNER");
		$this->db->where('temp_transaction_detail.transaction_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
				'transaction_id' => $item['transaction_id'],
				'item_id' => $item['item_id'],
				'item_quantity' => $item['item_quantity']
		);

		$this->db->where('id', $id);
		$this->db->update('temp_transaction_detail', $data);
	}

	function delete($id)
	{
		$this->db->where('transaction_id', $id);
		$this->db->delete('temp_transaction_detail');
	}
}