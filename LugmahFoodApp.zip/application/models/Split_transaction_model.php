<?php

class Split_transaction_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    function create($item)
    {
        $data = array(
            'status' => '1',
            'total_amount' => $item['total_amount'],
            'cart_id' => $item['cart_id']
        );
        $this->db->set('start_time', 'NOW()', FALSE);
        $this->db->insert('split_transaction', $data);
        return $this->db->insert_id();
    }

    function get_by_id($id)
    {
        $this->db->select('*');
        $this->db->from('split_transaction');
        $this->db->where('id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_cart_id($id)
    {
        $this->db->select('cart_id,complete_time');
        $this->db->from('split_transaction');
        $this->db->where('id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_active_splits($id)
    {
        $this->db->select("split_trans_id, GROUP_CONCAT(DISTINCT restaurant.name SEPARATOR ',') AS name, t.amount ,(CASE
	                        WHEN t.status = '1' THEN 'active'
                        	WHEN t.status = '2' THEN 'completed'
                            WHEN t.status = '3' THEN 'expired'
                            WHEN t.status = '4' THEN 'admin_link'
                            ELSE 'expired'
                            END)AS user_status,split_transaction.start_time", false);
        $this->db->from('split_transaction');
        $this->db->join("(SELECT * FROM ( SELECT * FROM split_transaction_detail ORDER BY STATUS <> '4', split_id,id) st GROUP BY split_id) AS t", 'split_transaction.id = t.split_id', 'left', false);
        $this->db->join('temp_transaction', 'split_transaction.cart_id = temp_transaction.order_id', 'left');
        $this->db->join('restaurant', 'temp_transaction.restaurant_id = restaurant.id', 'left');
        $this->db->where('temp_transaction.user_id', $id);
        $this->db->where('TIMESTAMPDIFF(MINUTE,split_transaction.start_time,NOW()) <=', '60', false);
        $this->db->group_by('split_transaction.id');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_user_by_split_id($id)
    {
        $this->db->select('temp_transaction.user_id');
        $this->db->from('split_transaction');
        $this->db->join('temp_transaction', 'split_transaction.cart_id = temp_transaction.order_id', 'left');
        $this->db->where('split_transaction.id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function update_split($id)
    {
        $data = array(
            'status' => '2',
        );
        $this->db->set('complete_time', 'NOW()', FALSE);
        $this->db->where('id', $id);
        $this->db->update('split_transaction', $data);
    }

    function update_split_status($id, $status)
    {

        $this->db->set('complete_time', 'NOW()', FALSE);
        $this->db->set('status', $status);
        $this->db->where('id', $id);
        $this->db->update('split_transaction');
    }

    function update_expire_split($id)
    {
        $data = array(
            'status' => '3',
        );
        $this->db->set('complete_time', 'NOW()', FALSE);
        $this->db->where('id', $id);
        $this->db->update('split_transaction', $data);
    }


    function delete($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('split_transaction');
    }
}