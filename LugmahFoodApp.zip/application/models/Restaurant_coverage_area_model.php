<?php
class Restaurant_coverage_area_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'restaurant_id' => $item['restaurant_id'],
			'area_id' => $item['area_id'],
			'delivery_time' => $item['delivery_time'],
			'delivery_fee' => $item['delivery_fee']
			 ); 

		$this->db->insert('restaurant_coverage_area', $data);
	}

	function get_by_restaurant_id($id)
	{
		$this->db->select('*');
		$this->db->from('restaurant_coverage_area');
                $this->db->join("cities", "restaurant_coverage_area.area_id = cities.city_id", "LEFT");
		$this->db->where('restaurant_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('restaurant_coverage_area');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'restaurant_id' => $item['restaurant_id'],
			'area_id' => $item['area_id'],
			'delivery_time' => $item['delivery_time'],
			'delivery_fee' => $item['delivery_fee']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('restaurant_coverage_area', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('restaurant_coverage_area');
	}
}