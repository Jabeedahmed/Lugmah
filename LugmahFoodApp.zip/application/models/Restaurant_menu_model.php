<?php
class Restaurant_menu_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'category_id' => $item['category_id'],
			'restaurant_id' => $item['restaurant_id']
			 ); 

		$this->db->insert('restaurant_menu', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('restaurant_menu');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('restaurant_menu');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'category_id' => $item['category_id'],
			'restaurant_id' => $item['restaurant_id']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('restaurant_menu', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('restaurant_menu');
	}
        
        function get_categories_items($id,$uid)
	{
		$this->db->select("restaurant_menu_items.*,IF(t.item_id IS NULL,'NO','YES') AS fav_status",FALSE);
		$this->db->from('restaurant_menu');
                $this->db->join("restaurant_menu_items", "restaurant_menu.id = restaurant_menu_items.menu_id", "INNER");
                $this->db->join("(SELECT item_id FROM user_fav_items WHERE user_id=$uid) AS t", "restaurant_menu_items.id =t.item_id", "LEFT",NULL,FALSE);
		$this->db->where('restaurant_menu.category_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}
}