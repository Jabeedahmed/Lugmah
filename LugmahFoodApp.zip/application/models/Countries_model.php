<?php
class Countries_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'country_code' => $item['country_code'],
			'country_name' => $item['country_name']
			 ); 

		$this->db->insert('countries', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('countries');
		$this->db->where('country_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('countries');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'country_code' => $item['country_code'],
			'country_name' => $item['country_name']
			 ); 

		$this->db->where('country_id', $id);
		$this->db->update('countries', $data);
	}

	function delete($id)
	{
		$this->db->where('country_id', $id);
		$this->db->delete('countries');
	}
}