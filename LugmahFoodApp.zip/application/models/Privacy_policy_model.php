<?php
class Privacy_policy_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'heading' => $item['heading'],
			'description' => $item['description']
			 ); 

		$this->db->insert('privacy_policy', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('privacy_policy');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('heading,description');
		$this->db->from('privacy_policy');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'heading' => $item['question'],
			'description' => $item['answer']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('privacy_policy', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('privacy_policy');
	}

	function get_privacy_polocy()
	{
		$this->db->select('*');
		$this->db->from('privacy_policy');
		$this->db->where('heading', 'privacy_policy');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}


	function get_all_policy_type()
	{
		$this->db->select('heading,description');
		$this->db->from('privacy_policy');
		$this->db->where('heading !=','privacy_policy');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}





}