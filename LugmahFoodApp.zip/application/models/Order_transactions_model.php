<?php

class Order_transactions_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    function create_temp_trans_rec($data)
    {
        $this->db->insert('temp_transaction', $data);
        return $this->db->insert_id();
    }

    function create_temp_trans_detail_rec($data)
    {
        $this->db->insert('temp_transaction_detail', $data);
        return $this->db->insert_id();
    }

    function create_temp_trans_item_detail_rec($data)
    {
        $this->db->insert('temp_transaction_item_details', $data);
    }

    function create_trans_rec($data)
    {
        $this->db->insert('transaction', $data);
        return $this->db->insert_id();
    }

    function create_trans_detail_rec($data)
    {
        $this->db->insert('transaction_detail', $data);
        return $this->db->insert_id();
    }

    function create_trans_item_detail_rec($data)
    {
        $this->db->insert('transaction_item_details', $data);
    }

    function user_order_points($data)
    {
        $this->db->insert('user_points', $data);
    }

    function get_user_temp_transaction($order_id)
    {
        $query = $this->db->select('*')
            ->from('temp_transaction')
            ->where('order_id', $order_id)
            ->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_user_transaction($order_id)
    {
        $query = $this->db->select('transaction.*,restaurant.logo_url,restaurant.cover_image_url,restaurant.slug,restaurant.delivery_time,user_points.point AS earned_points')
            ->from('transaction')
            ->join('restaurant', 'transaction.restaurant_id = restaurant.id', 'left')
            ->join('user_points', 'transaction.order_id = user_points.transaction_order_id', 'left')
            ->where('order_id', $order_id)
            ->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_user_transaction_details($trans_id)
    {
        $query = $this->db->select("transaction_detail.item_name,transaction_detail.item_price,transaction_detail.item_quantity,
                                    GROUP_CONCAT(transaction_item_details.item_attribute_name SEPARATOR ', ') AS attr_name,
                                    COALESCE(SUM(transaction_item_details.item_attribute_price),0) AS attr_price", false)
            ->from('transaction_detail')
            ->join('transaction_item_details', 'transaction_detail.id = transaction_item_details.trans_detail_id', 'left')
            ->where('transaction_detail.trans_id', $trans_id)
            ->group_by('transaction_detail.id')
            ->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_user_temp_transaction_detail($trans_id)
    {
        $query = $this->db->select('*')
            ->from('temp_transaction_detail')
            ->where('trans_id', $trans_id)
            ->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_user_temp_transaction_item_details($trans_detail_id)
    {
        $query = $this->db->select('*')
            ->from('temp_transaction_item_details')
            ->where('trans_detail_id', $trans_detail_id)
            ->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function delete_temp_cart($cart_id)
    {
        $this->db->where('order_id', $cart_id);
        $this->db->delete('temp_transaction');
    }

}