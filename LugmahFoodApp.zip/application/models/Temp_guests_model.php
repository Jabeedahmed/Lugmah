<?php
class Temp_guests_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'name' => $item['name'],
			'address' => $item['address'],
			'contact_no' => $item['contact_no'],
			'email' => $item['email'],
			'other_info' => $item['other_info']
			 ); 

		$this->db->insert('temp_guests', $data);
		return $this->db->insert_id();
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('temp_guests');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('temp_guests');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'name' => $item['name'],
			'address' => $item['address'],
			'contact_no' => $item['contact_no'],
			'email' => $item['email'],
			'other_info' => $item['other_info']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('temp_guests', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('temp_guests');
	}
}