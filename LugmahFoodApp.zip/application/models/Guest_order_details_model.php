<?php
class Guest_order_details_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'guest_id' => $item['guest_id'],
			'order_id' => $item['order_id']
			 ); 

		$this->db->insert('guest_order_details', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('guest_order_details');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('guest_order_details');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'guest_id' => $item['guest_id'],
			'order_id' => $item['order_id']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('guest_order_details', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('guest_order_details');
	}
}