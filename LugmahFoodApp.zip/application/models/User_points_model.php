<?php
class User_points_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'user_id' => $item['user_id'],
			'point' => $item['point'],
			'transaction_order_id' => $item['transaction_order_id']
			 ); 

		$this->db->insert('user_points', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('user_points');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}
        
        function get_user_points($id)
	{
		$this->db->select('sum(point) as points');
		$this->db->from('user_points');
		$this->db->where('user_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('user_points');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'user_id' => $item['user_id'],
			'point' => $item['point'],
			'transaction_order_id' => $item['transaction_order_id']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('user_points', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('user_points');
	}
}