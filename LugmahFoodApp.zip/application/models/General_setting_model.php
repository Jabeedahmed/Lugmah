<?php
class General_setting_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    function create($item)
    {
        $data = array(
            'start_year' => $item['start_year'],
            'end_year' => $item['end_year'],
            'fb_link' => $item['fb_link'],
            'twitter_link' => $item['twitter_link'],
            'insta_link' => $item['insta_link'],
            'youtube_link' => $item['youtube_link']
        );

        $this->db->insert('general_setting', $data);
    }

    function get_by_id($id)
    {
        $this->db->select('*');
        $this->db->from('general_setting');
        $this->db->where('id', $id);
        $query = $this->db->get();

        if($query->num_rows()<1){
            return null;
        }
        else{
            return $query->row();
        }
    }

    function get_setting()
    {
        $this->db->select('*');
        $this->db->from('general_setting');
        $query = $this->db->get();

        if($query->num_rows()<1){
            return null;
        }
        else{
            return $query->row();
        }
    }

    function update($id, $item)
    {
        $data = array(
            'start_year' => $item['start_year'],
            'end_year' => $item['end_year'],
            'fb_link' => $item['fb_link'],
            'twitter_link' => $item['twitter_link'],
            'insta_link' => $item['insta_link'],
            'youtube_link' => $item['youtube_link']
        );
      //  echo "<pre>"; print_r($data);  exit;
        $this->db->where('id', $id);
        $this->db->update('general_setting',$data);
    }

    function delete($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('general_setting');
    }
}