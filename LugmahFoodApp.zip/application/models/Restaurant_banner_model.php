<?php
class Restaurant_banner_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{

		$data = array(
			'banner_url' => $item['banner_url'],
			'restaurant_id' => $item['restaurant_id']
			 ); 

		$this->db->insert('restaurant_banner', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('restaurant_banner');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('restaurant_banner');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'banner_url' => $item['banner_url'],
			'restaurant_id' => $item['restaurant_id']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('restaurant_banner', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('restaurant_banner');
	}

	function get_images_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('restaurant_banner');
		$this->db->where('restaurant_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function delete_banner_images($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('restaurant_banner');
	}
	public function get_banners_by_restaurant($id){
		$this->db->select('*');
		$this->db->from('restaurant_banner');
		$this->db->where('restaurant_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}
}