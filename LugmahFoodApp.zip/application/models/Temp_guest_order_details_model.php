<?php
class Temp_guest_order_details_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'guest_id' => $item['guest_id'],
			'order_id' => $item['order_id']
			 ); 

		$this->db->insert('temp_guest_order_details', $data);
	}

	function get_by_order_id($id)
	{
		$this->db->select('*');
		$this->db->from('temp_guest_order_details');
		$this->db->where('order_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('temp_guest_order_details');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'guest_id' => $item['guest_id'],
			'order_id' => $item['order_id']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('temp_guest_order_details', $data);
	}

	function delete($id)
	{
		$this->db->where('order_id', $id);
		$this->db->delete('temp_guest_order_details');
	}
}