<?php

class User_fav_items_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    function create($id, $id2)
    {
        $data = array(
            'user_id' => $id,
            'item_id' => $id2
        );
        $this->db->insert('user_fav_items', $data);
    }

    function get_by_id($id)
    {
        $this->db->select('*');
        $this->db->from('user_fav_items');
        $this->db->where('id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_all_by_user_id($uid)
    {
        $this->db->select("restaurant_menu_items.*,restaurant.id AS rest_id,restaurant.slug,restaurant.name AS rest_name,IF(t.item_id IS NULL,'NO','YES') AS fav_status,ct.cuisine_type AS rest_type", FALSE);
        $this->db->from('user_fav_items');
        $this->db->join("restaurant_menu_items", "user_fav_items.item_id = restaurant_menu_items.id", "INNER");
        $this->db->join("(SELECT item_id FROM user_fav_items WHERE user_id=$uid) AS t", "restaurant_menu_items.id =t.item_id", "LEFT", NULL, FALSE);
        $this->db->join("restaurant_menu", "restaurant_menu_items.menu_id = restaurant_menu.id", "INNER");
        $this->db->join("restaurant", "restaurant_menu.restaurant_id =restaurant.id", "INNER");
        $this->db->join("(SELECT GROUP_CONCAT(NAME SEPARATOR ', ') AS cuisine_type,restaurant_id FROM restaurant_cuisine_type INNER JOIN cuisine_type ON restaurant_cuisine_type.cuisine_type_id = cuisine_type.id GROUP BY restaurant_id) AS ct", "restaurant.id = ct.restaurant_id", "LEFT");

        $this->db->where('user_fav_items.user_id', $uid);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_count_by_user_id($uid)
    {
        $this->db->select('count(*) as total');
        $this->db->from('user_fav_items');
        $this->db->where('user_id', $uid);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_all()
    {
        $this->db->select('*');
        $this->db->from('user_fav_items');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result_array();
        }
    }

    function update($id, $item)
    {
        $data = array(
            'user_id' => $item['user_id'],
            'item_id' => $item['item_id']
        );

        $this->db->where('id', $id);
        $this->db->update('user_fav_items', $data);
    }

    function delete($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('user_fav_items');
    }

    function check_item_bookmark($id, $itid)
    {
        $this->db->select('*');
        $this->db->from('user_fav_items');
        $this->db->where('user_id', $id);
        $this->db->where('item_id', $itid);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }
}