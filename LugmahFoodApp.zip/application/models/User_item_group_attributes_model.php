<?php
class User_item_group_attributes_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'group_id' => $item['group_id'],
			'name' => $item['name'],
			'price' => $item['price']
			 ); 

		$this->db->insert('user_item_group_attributes', $data);
	}

	function get_by_id($ids)
	{
		$attrib_array = explode(',',$ids);
		$this->db->select('GROUP_CONCAT(name SEPARATOR ",") AS options_name,SUM(price) AS option_price', false);
		$this->db->from('user_item_group_attributes');
		$this->db->where_in('id', $attrib_array);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_detail_by_id($id)
	{
		$this->db->select('name,price');
		$this->db->from('user_item_group_attributes');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if ($query->num_rows() < 1) {
			return null;
		} else {
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('user_item_group_attributes');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'group_id' => $item['group_id'],
			'name' => $item['name'],
			'price' => $item['price']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('user_item_group_attributes', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('user_item_group_attributes');
	}
}