<?php
class Restaurant_comments_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'user_id' => $item['user_id'],
			'restaurant_id' => $item['restaurant_id'],
			'comment' => $item['comment'],
			'rating' => $item['rating'],
                        'title' => $item['title']
			 ); 
                $this->db->set('date', 'NOW()', FALSE);
		$this->db->insert('restaurant_comments', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('restaurant_comments');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}
        
        function get_all_by_id($rid)
	{
		$this->db->select('restaurant_comments.*,users.first_name,users.last_name');
		$this->db->from('restaurant_comments');
                $this->db->join("users", "restaurant_comments.user_id = users.id", "LEFT");
                $this->db->where('restaurant_id', $rid);
                $this->db->where('reply_comment_id', '0');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}
        function get_all_reply_by_id($rcid)
	{
		$this->db->select('comment as reply_comment,date as reply_date');
		$this->db->from('restaurant_comments');
                $this->db->where('reply_comment_id', $rcid);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}
	
	   function check_comment_exist($id,$id2)
	{
		$this->db->select('*');
		$this->db->from('restaurant_comments');
		$this->db->where('user_id', $id);
                $this->db->where('restaurant_id', $id2);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

        
	function get_all()
	{
		$this->db->select('*');
		$this->db->from('restaurant_comments');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'user_id' => $item['user_id'],
			'restaurant_id' => $item['restaurant_id'],
			'comment' => $item['comment'],
			'rating' => $item['rating'],
                        'title' => $item['title']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('restaurant_comments', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('restaurant_comments');
	}
        
        function get_restaurant_rating_by_id($rid)
	{
		$this->db->select('ROUND(SUM(rating)/(COUNT(rating)*5)*5,1) as rating,count(rating) as total_rating',false);
		$this->db->from('restaurant_comments');
                $this->db->where('restaurant_id', $rid);
                $this->db->where('reply_comment_id', '0');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}
}