<?php
class User_setting_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'user_id' => $item['user_id'],
			'promo_setting' => $item['promo_setting'],
			'update_by_sms_setting' => $item['update_by_sms_setting']
			 ); 

		$this->db->insert('user_setting', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('user_setting');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('user_setting');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'user_id' => $item['user_id'],
			'promo_setting' => $item['promo_setting'],
			'update_by_sms_setting' => $item['update_by_sms_setting']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('user_setting', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('user_setting');
	}
}