<?php
class Main_banners_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'banner_url' => $item['image_url']
			//'image_desc' => $item['image_desc']
			 ); 

		$this->db->insert('main_banners', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('main_banners');
		$this->db->where('banner_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('main_banners');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'image_url' => $item['image_url']
			 ); 

		$this->db->where('banner_id', $id);
		$this->db->update('main_banners', $data);
	}


	function delete($id)
	{
		$this->db->where('banner_id', $id);
		$this->db->delete('main_banners');
	}
}