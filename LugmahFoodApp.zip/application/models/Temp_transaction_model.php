<?php

class Temp_transaction_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    function create($item)
    {
        $data = array(
            'user_id' => $item['user_id'],
            'status' => $item['status'],
            'discount' => $item['discount'],
            'total_amount' => $item['total_amount'],
            'delivery_charges' => $item['delivery_charges'],
            'select_address_id' => $item['select_address_id'],
            'paymant_method_id' => $item['paymant_method_id'],
            'delivery_pickup' => $item['delivery_pickup'],
            'delivery_pickup_time' => $item['delivery_pickup_time'],
            'pickup_address_id' => $item['pickup_address_id'],
            'subtotal' => $item['subtotal'],
            'points_used' => $item['points_used']
        );
        $this->db->set('datetime', 'NOW()', FALSE);
        $this->db->insert('temp_transaction', $data);
        return $this->db->insert_id();
    }

    function create_temp_trans_rec($data)
    {
        $this->db->insert('temp_transaction_new', $data);
        return $this->db->insert_id();
    }

    function create_temp_trans_detail_rec($data)
    {
        $this->db->insert('temp_transaction_detail_new', $data);
        return $this->db->insert_id();
    }

    function create_temp_trans_item_detail_rec($data)
    {
        $this->db->insert('temp_transaction_item_details_new', $data);
    }

    function create_new($item)
    {
        $data = array(
            'user_id' => $item['user_id'],
            'status' => $item['status'],
            'discount' => $item['discount'],
            'total_amount' => $item['total_amount'],
            'delivery_charges' => $item['delivery_charges'],
            'select_address_id' => $item['select_address_id'],
            'paymant_method_id' => $item['paymant_method_id'],
            'delivery_pickup' => $item['delivery_pickup'],
            'delivery_pickup_time' => $item['delivery_pickup_time'],
            'pickup_address_id' => $item['pickup_address_id'],
            'subtotal' => $item['subtotal'],
            'points_used' => $item['points_used'],
            'restaurant_id' => $item['restaurant_id'],
            'order_id' => $item['order_id']
        );
        $this->db->set('datetime', 'NOW()', FALSE);
        $this->db->insert('temp_transaction', $data);
        return $this->db->insert_id();
    }

    function create_guest($item)
    {
        $data = array(
            'name' => $item['name'],
            'address' => $item['address'],
            'contact_no' => $item['contact_no'],
            'email' => $item['email'],
            'other_info' => $item['other_info']
        );
        $this->db->insert('guests', $data);
        return $this->db->insert_id();
    }

    function create_guest_details($item)
    {
        $data = array(
            'guest_id' => $item['guest_id'],
            'order_id' => $item['order_id']
        );
        $this->db->insert('guest_order_details', $data);

    }

    function get_by_id($id)
    {
        $this->db->select('*');
        $this->db->from('temp_transaction');
        $this->db->where('id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_by_order($id)
    {
        $this->db->select('*');
        $this->db->from('temp_transaction');
        $this->db->where('order_id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_by_order_id($id, $day)
    {
        $this->db->select("restaurant.id AS rest_id,restaurant.name AS rest_name,cuisine_type.name AS rest_type,restaurant.logo_url AS rest_logo,restaurant.cover_image_url AS rest_cover,restaurant_timing.start_time AS rest_opening_time,restaurant_timing.end_time AS rest_closing_time,temp_transaction.id AS order_id,temp_transaction.datetime,payment_method.name AS payment_method,CONCAT(user_addresses.block,' ',user_addresses.judda,' ',user_addresses.street,' ',user_addresses.houseno_name,' ',user_addresses.floor,user_addresses.office_apt,' ',user_addresses.extra_direction) AS delivery_address,temp_transaction.discount,temp_transaction.delivery_charges,temp_transaction.subtotal,order_status.status_name AS order_status,temp_transaction.total_amount", false);
        $this->db->from('temp_transaction');
        $this->db->join("restaurant_branches", "temp_transaction.pickup_address_id=restaurant_branches.id", "LEFT");
        $this->db->join("restaurant", "restaurant_branches.restaurant_id = restaurant.id", "LEFT");
        $this->db->join("cuisine_type", "restaurant.cuisine_type_id = cuisine_type.id", "INNER");
        $this->db->join("payment_method", "temp_transaction.paymant_method_id = payment_method.id", "INNER");
        $this->db->join("user_addresses", "temp_transaction.select_address_id = user_addresses.id", "LEFT");
        $this->db->join("order_status", "temp_transaction.status = order_status.status_id", "INNER");
        $this->db->join("restaurant_timing", "restaurant.id = restaurant_timing.restaurant_id AND restaurant_timing.day='$day'", "LEFT");
        $this->db->where('temp_transaction.id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_by_order_id_new($id, $day)
    {
        $this->db->select("restaurant.id AS rest_id,restaurant.name AS rest_name,restaurant.logo_url AS rest_logo,restaurant.cover_image_url AS rest_cover,restaurant.min_order AS rest_min_order,restaurant.discount AS rest_discount,restaurant_timing.start_time AS rest_opening_time,restaurant_timing.end_time AS rest_closing_time,temp_transaction.id as trans_id,temp_transaction.order_id,temp_transaction.datetime,payment_method.name AS payment_method,CONCAT(user_addresses.block,' ',user_addresses.judda,' ',user_addresses.street,' ',user_addresses.houseno_name,' ',user_addresses.floor,user_addresses.office_apt,' ',user_addresses.extra_direction) AS delivery_address,temp_transaction.discount,temp_transaction.delivery_charges,temp_transaction.subtotal,temp_transaction.total_amount,order_status.status_name AS order_status", false);
        $this->db->from('temp_transaction');
        $this->db->join("restaurant", "temp_transaction.restaurant_id = restaurant.id", "INNER");
        $this->db->join("payment_method", "temp_transaction.paymant_method_id = payment_method.id", "INNER");
        $this->db->join("user_addresses", "temp_transaction.select_address_id = user_addresses.id", "left");
        $this->db->join("order_status", "temp_transaction.status = order_status.status_id", "INNER");
        $this->db->join("restaurant_timing", "restaurant.id = restaurant_timing.restaurant_id AND restaurant_timing.day='$day'", "left");
        $this->db->where('temp_transaction.order_id', $id);
        $this->db->group_by('temp_transaction.restaurant_id');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }


    function get_user_order_history($uid)
    {
        $this->db->select("temp_transaction.id AS order_id,restaurant.name AS rest_name,temp_transaction.datetime, order_status.status_name AS order_status", FALSE);
        $this->db->from('temp_transaction');
//        $this->db->join("restaurant_branches", "temp_transaction.pickup_address_id=restaurant_branches.id", "INNER");
        $this->db->join("restaurant", "temp_transaction.restaurant_id = restaurant.id", "INNER");
        $this->db->join("order_status", "temp_transaction.status = order_status.status_id", "INNER");
        $this->db->where('temp_transaction.user_id', $uid);
        $this->db->order_by('temp_transaction.id', 'desc');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_temp_transaction_by_order_id($id)
    {
        $this->db->select("*");
        $this->db->from('temp_transaction');
        $this->db->where('order_id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_user_order_history_new($uid)
    {
        $this->db->select("temp_transaction.order_id,GROUP_CONCAT(restaurant.name) AS rest_name,temp_transaction.datetime, order_status.status_name AS order_status", FALSE);
        $this->db->from('temp_transaction');
        $this->db->join("restaurant", "temp_transaction.restaurant_id = restaurant.id", "INNER");
        $this->db->join("order_status", "temp_transaction.status = order_status.status_id", "INNER");
        $this->db->where('temp_transaction.user_id', $uid);
        $this->db->order_by('temp_transaction.id', 'desc');
        $this->db->group_by('order_id', 'ASEC');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result_array();
        }
    }

    function get_order_detail_by_id($uid, $oid)
    {
        $this->db->select("order_status.status_name AS order_status");
        $this->db->from('temp_transaction');
//        $this->db->join("restaurant_branches", "temp_transaction.pickup_address_id=restaurant_branches.id", "INNER");
        $this->db->join("restaurant", "temp_transaction.restaurant_id = restaurant.id", "INNER");
        $this->db->join("order_status", "temp_transaction.status = order_status.status_id", "INNER");
        $this->db->where('temp_transaction.user_id', $uid);
        $this->db->where('temp_transaction.id', $oid);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }


    function get_all()
    {
        $this->db->select('*');
        $this->db->from('temp_transaction');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result_array();
        }
    }

    function update($id, $item)
    {
        $data = array(
            'user_id' => $item['user_id'],
            'datetime' => $item['datetime'],
            'status' => $item['status'],
            'discount' => $item['discount'],
            'total_amount' => $item['total_amount'],
            'delivery_charges' => $item['delivery_charges'],
            'select_address_id' => $item['select_address_id'],
            'paymant_method_id' => $item['paymant_method_id'],
            'delivery_pickup' => $item['delivery_pickup'],
            'delivery_pickup_time' => $item['delivery_pickup_time'],
            'pickup_address_id' => $item['pickup_address_id'],
            'subtotal' => $item['subtotal'],
            'points_used' => $item['points_used']
        );

        $this->db->where('id', $id);
        $this->db->update('temp_transaction', $data);
    }

    function delete($id)
    {
        $this->db->where('order_id', $id);
        $this->db->delete('temp_transaction');
    }
}