<?php

class Transaction_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    function create($item)
    {
        $data = array(
            'user_id' => $item['user_id'],
            'status' => $item['status'],
            'discount' => $item['discount'],
            'total_amount' => $item['total_amount'],
            'delivery_charges' => $item['delivery_charges'],
            'select_address_id' => $item['select_address_id'],
            'paymant_method_id' => $item['paymant_method_id'],
            'delivery_pickup' => $item['delivery_pickup'],
            'delivery_pickup_time' => $item['delivery_pickup_time'],
            'pickup_address_id' => $item['pickup_address_id'],
            'subtotal' => $item['subtotal'],
            'points_used' => $item['points_used']
        );
        $this->db->set('datetime', 'NOW()', FALSE);
        $this->db->insert('transaction', $data);
        return $this->db->insert_id();
    }

    function create_new($item)
    {
        $data = array(
            'user_id' => $item['user_id'],
            'status' => $item['status'],
            'discount' => $item['discount'],
            'total_amount' => $item['total_amount'],
            'delivery_charges' => $item['delivery_charges'],
            'select_address_id' => $item['select_address_id'],
            'paymant_method_id' => $item['paymant_method_id'],
            'delivery_pickup' => $item['delivery_pickup'],
            'delivery_pickup_time' => $item['delivery_pickup_time'],
            'pickup_address_id' => $item['pickup_address_id'],
            'subtotal' => $item['subtotal'],
            'points_used' => $item['points_used'],
            'restaurant_id' => $item['restaurant_id'],
            'order_id' => $item['order_id']
        );
        $this->db->set('datetime', 'NOW()', FALSE);
        $this->db->insert('transaction', $data);
        return $this->db->insert_id();
    }

    function create_guest($item)
    {
        $data = array(
            'name' => $item['name'],
            'address' => $item['address'],
            'contact_no' => $item['contact_no'],
            'email' => $item['email'],
            'other_info' => $item['other_info']
        );
        $this->db->insert('guests', $data);
        return $this->db->insert_id();
    }

    function create_guest_details($item)
    {
        $data = array(
            'guest_id' => $item['guest_id'],
            'order_id' => $item['order_id']
        );
        $this->db->insert('guest_order_details', $data);

    }

    function get_by_id($id)
    {
        $this->db->select('*');
        $this->db->from('transaction');
        $this->db->where('id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_by_order_id($id, $day)
    {
        $this->db->select("restaurant.id AS rest_id,restaurant.name AS rest_name,cuisine_type.name AS rest_type,restaurant.logo_url AS rest_logo,restaurant.cover_image_url AS rest_cover,restaurant_timing.start_time AS rest_opening_time,restaurant_timing.end_time AS rest_closing_time,transaction.id AS order_id,transaction.datetime,payment_method.name AS payment_method,CONCAT(user_addresses.block,' ',user_addresses.judda,' ',user_addresses.street,' ',user_addresses.houseno_name,' ',user_addresses.floor,user_addresses.office_apt,' ',user_addresses.extra_direction) AS delivery_address,transaction.discount,transaction.delivery_charges,transaction.subtotal,order_status.status_name AS order_status,transaction.total_amount", false);
        $this->db->from('transaction');
        $this->db->join("restaurant_branches", "transaction.pickup_address_id=restaurant_branches.id", "LEFT");
        $this->db->join("restaurant", "restaurant_branches.restaurant_id = restaurant.id", "LEFT");
        $this->db->join("cuisine_type", "restaurant.cuisine_type_id = cuisine_type.id", "INNER");
        $this->db->join("payment_method", "transaction.paymant_method_id = payment_method.id", "INNER");
        $this->db->join("user_addresses", "transaction.select_address_id = user_addresses.id", "LEFT");
        $this->db->join("order_status", "transaction.status = order_status.status_id", "INNER");
        $this->db->join("restaurant_timing", "restaurant.id = restaurant_timing.restaurant_id AND restaurant_timing.day='$day'", "LEFT");
        $this->db->where('transaction.id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_by_order_id_new($id, $day)
    {
        $this->db->select("restaurant.id AS rest_id,restaurant.name AS rest_name,restaurant.logo_url AS rest_logo,
        restaurant.cover_image_url AS rest_cover,restaurant.min_order AS rest_min_order,restaurant.discount AS rest_discount,
        restaurant_timing.start_time AS rest_opening_time,restaurant_timing.end_time AS rest_closing_time,transaction.id as trans_id,transaction.order_id,
        transaction.datetime,payment_method.name AS payment_method,CONCAT(user_addresses.block,' ',user_addresses.judda,' ',user_addresses.street,' ',user_addresses.houseno_name,' ',user_addresses.floor,user_addresses.office_apt,' ',user_addresses.extra_direction) AS delivery_address,
        transaction.discount,transaction.delivery_charges,transaction.payment_method_id AS t_paymant_method,transaction.subtotal,transaction.total_amount,order_status.status_name AS order_status", false);
        $this->db->from('transaction');
        $this->db->join("restaurant", "transaction.restaurant_id = restaurant.id", "INNER");
        $this->db->join("payment_method", "transaction.payment_method_id = payment_method.id", "INNER");
        $this->db->join("user_addresses", "transaction.user_address_id = user_addresses.id", "left");
        $this->db->join("order_status", "transaction.status = order_status.status_id", "INNER");
        $this->db->join("restaurant_timing", "restaurant.id = restaurant_timing.restaurant_id AND restaurant_timing.day='$day'", "left");
        $this->db->where('transaction.order_id', $id);
        $this->db->group_by('transaction.restaurant_id');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_user_order_by_id($id)
    {
        $this->db->select("transaction.restaurant_id AS rest_id,transaction.restaurant_name AS rest_name, transaction.id as trans_id,
        transaction.order_id,transaction.payment_method,transaction.user_address AS delivery_address,
        transaction.discount,transaction.discount_type,transaction.delivery_charges,transaction.subtotal,
        transaction.total_amount,restaurant.logo_url AS rest_logo,rt.rating AS rating,COALESCE(rt.rating_count,0) AS rating_count,order_status.status_name AS order_status", false);
        $this->db->from('transaction');
        $this->db->join("restaurant", "transaction.restaurant_id = restaurant.id", "INNER");
        $this->db->join("(SELECT ROUND(AVG(rating),1) AS rating,restaurant_id,COUNT(rating) AS rating_count FROM restaurant_comments GROUP BY restaurant_id)AS rt", "restaurant.id = rt.restaurant_id", "LEFT");
       $this->db->join("order_status", "transaction.status = order_status.status_id", "INNER");
        $this->db->where('transaction.order_id', $id);
        $this->db->group_by('transaction.restaurant_id');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }



    function get_confirm_order_details($id, $day)
    {
        $this->db->select("restaurant.name,restaurant.logo_url,restaurant.cover_image_url,restaurant.slug,restaurant.delivery_time,
                            restaurant_timing.start_time AS rest_opening_time,restaurant_timing.end_time AS rest_closing_time,
                            transaction.id as trans_id,transaction.order_id,transaction.datetime,payment_method.name AS payment_method,
                            transaction.discount,transaction.delivery_charges,transaction.select_address_id,
                            transaction.subtotal,transaction.total_amount,transaction.user_id,user_points.point", false);
        $this->db->from('transaction');
        $this->db->join("restaurant", "transaction.restaurant_id = restaurant.id", "left");
        $this->db->join("payment_method", "transaction.paymant_method_id = payment_method.id", "left");
        $this->db->join("user_points", "transaction.order_id = user_points.transaction_order_id", "left");
        $this->db->join("restaurant_timing", "restaurant.id = restaurant_timing.restaurant_id AND restaurant_timing.day = DAYNAME(NOW()) AND restaurant_timing.status !=2", "LEFT");
        $this->db->where('transaction.order_id', $id);
        $this->db->group_by('transaction.restaurant_id');
        $this->db->order_by('transaction.id');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }


    function get_user_order_history($uid)
    {
        $this->db->select("transaction.id AS order_id,restaurant.name AS rest_name,FROM_UNIXTIME(transaction.created_on-7200) AS datetime");
        $this->db->from('transaction');
        $this->db->join("restaurant", "transaction.restaurant_id = restaurant.id", "INNER");
        $this->db->where('transaction.user_id', $uid);
        $this->db->order_by('transaction.id', 'desc');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_transaction_by_order_id($id)
    {
        $this->db->select("*");
        $this->db->from('transaction');
        $this->db->where('order_id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_user_order_history_new($uid)
    {
        $this->db->select("transaction.order_id,GROUP_CONCAT(restaurant.name) AS rest_name,transaction.datetime, order_status.status_name AS order_status", FALSE);
        $this->db->from('transaction');
        $this->db->join("restaurant", "transaction.restaurant_id = restaurant.id", "INNER");
        $this->db->join("order_status", "transaction.status = order_status.status_id", "INNER");
        $this->db->where('transaction.user_id', $uid);
        $this->db->order_by('transaction.id', 'desc');
        $this->db->group_by('order_id', 'ASEC');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result_array();
        }
    }

    function get_user_orders($uid)
    {
        $this->db->select("order_id, GROUP_CONCAT(restaurant_name SEPARATOR ', ') AS restaurant, CONVERT_TZ(FROM_UNIXTIME(created_on), @@session.time_zone, '+03:00') AS order_time", FALSE);
        $this->db->from('transaction');
        $this->db->where('transaction.user_id', $uid);
        $this->db->order_by('transaction.id', 'desc');
        $this->db->group_by('order_id');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result_array();
        }
    }

    function get_order_detail_by_id($order_id)
    {
        $this->db->select("order_status.status_code AS order_status");
        $this->db->from('transaction');
        $this->db->join("order_status", "transaction.status = order_status.status_id", "INNER");
        $this->db->where('transaction.id', $order_id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }


    function get_all()
    {
        $this->db->select('*');
        $this->db->from('transaction');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result_array();
        }
    }

    function update($id, $item)
    {
        $data = array(
            'user_id' => $item['user_id'],
            'datetime' => $item['datetime'],
            'status' => $item['status'],
            'discount' => $item['discount'],
            'total_amount' => $item['total_amount'],
            'delivery_charges' => $item['delivery_charges'],
            'select_address_id' => $item['select_address_id'],
            'paymant_method_id' => $item['paymant_method_id'],
            'delivery_pickup' => $item['delivery_pickup'],
            'delivery_pickup_time' => $item['delivery_pickup_time'],
            'pickup_address_id' => $item['pickup_address_id'],
            'subtotal' => $item['subtotal'],
            'points_used' => $item['points_used']
        );

        $this->db->where('id', $id);
        $this->db->update('transaction', $data);
    }

    function delete($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('transaction');
    }
}