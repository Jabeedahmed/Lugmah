<?php
class Restaurant_menu_categories_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'name' => $item['name'],
			'restaurant_id' => $item['restaurant_id'],
			'image' => $item['image'],
			'logo' => $item['logo'],
			'color_code' => $item['color_code']
			 ); 

		$this->db->insert('restaurant_menu_categories', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('restaurant_menu_categories');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}
        function get_by_restaurant_id($rid)
	{
		$this->db->select('id as category_id,name as category_name');
		$this->db->from('restaurant_menu_categories');
		$this->db->where('restaurant_id', $rid);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('restaurant_menu_categories');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'name' => $item['name'],
			'restaurant_id' => $item['restaurant_id'],
			'image' => $item['image'],
			'logo' => $item['logo'],
			'color_code' => $item['color_code']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('restaurant_menu_categories', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('restaurant_menu_categories');
	}
}