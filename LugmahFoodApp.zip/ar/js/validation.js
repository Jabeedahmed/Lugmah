$(document).ready(function () {
    $('#register_user').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            first_name: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب الاسم الأول'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z]+$',
                        message: 'يجب أن تكون الأبجدية'
                    },
                    stringLength: {
                        max: 50,
                        message: 'يجب أن يكون الاسم أقل من 50 حرفا'
                    }
                }
            },
            last_name: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب اسم العائلة'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z]+$',
                        message: 'يجب أن تكون الأبجدية'
                    },
                    stringLength: {
                        max: 50,
                        message: 'يجب أن يكون الاسم أقل من 50 حرفا'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب البريد الإلكتروني'
                    },
                    emailAddress: {
                        message: 'القيمة ليست عنوان بريد إلكتروني صالح'
                    }
                }
            },
            mobile_number: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب رقم الاتصال'
                    },
                    stringLength: {
                        max: 8,
                        min: 8,
                        message: 'يجب أن يكون 8 أرقام'
                    },
                    digits: {
                        message: 'جب أن يكون عدد'
                    }
                }
            },
            password: {
                validators: {
                    notEmpty: {
                        message: 'كلمة المرور مطلوبة'
                    },
                    stringLength: {
                        min: 6,
                        message: 'كلمة السر يجب أن تكون على الأقل 6 أحرف'
                    }
                }
            },
            confirm_pass: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب تأكيد كلمة المرور'
                    },
                    identical: {
                        field: 'password',
                        message: 'كلمة المرور و تأكيد ليست هي نفسها'
                    }
                }
            },
            gender: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب الجنس'
                    }
                }
            },
            month: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب الشهر'
                    }
                }
            },
            day: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب اليوم'
                    }
                }
            },
            year: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب العام'
                    }
                }
            },
            city_id: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب المنطقة'
                    }
                }
            },
            address_name: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب اسم عنوان'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'يجب أن يكون ألفا الرقمية'
                    }
                }
            },
            block: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب كتلة'
                    },
                    integer: {
                        message: 'كتلة يجب أن يكون رقمية'
                    }
                }
            },
            judda: {
                validators: {
                    integer: {
                        message: 'كتلة يجب أن يكون رقمية'
                    }
                }
            },
            office_name: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب رقم'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'يجب أن يكون ألفا الرقمية'
                    }
                }
            },
            street: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب الشارع'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'يجب أن يكون ألفا الرقمية'
                    }
                }
            },
            floor: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب الكلمة'
                    },
                    integer: {
                        message: 'الكلمة يجب أن يكون رقمية'
                    }
                }
            },
            appartment: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب شقة'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'يجب أن يكون ألفا الرقمية'
                    }
                }
            },
            terms: {
                validators: {
                    notEmpty: {
                        message: 'يجب أن تقبل هذا المجال'
                    }
                }
            }
        }
    });
    $('#edit_userProfile').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            first_name: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب الاسم الأول'
                    },
                    stringLength: {
                        max: 20,
                        message: 'يجب أن يكون الاسم أقل من 20 حرفا'
                    }
                }
            },
            last_name: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب اسم العائلة'
                    },
                    stringLength: {
                        max: 20,
                        message: 'يجب أن يكون الاسم أقل من 20 حرفا'
                    }
                }
            },
            phone: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب رقم الاتصال'
                    },
                    stringLength: {
                        max: 8,
                        min: 8,
                        message: 'يجب أن يكون 8 أرقام'
                    }
                }
            },
            house_phone: {
                validators: {
                    stringLength: {
                        max: 8,
                        min: 8,
                        message: 'يجب أن يكون 8 أرقام'
                    }
                }
            },
            work_phone: {
                validators: {
                    stringLength: {
                        max: 8,
                        min: 8,
                        message: 'يجب أن يكون 8 أرقام'
                    }
                }
            },
            gender: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب الجنس'
                    }
                }
            },
            month: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب الشهر'
                    }
                }
            },
            day: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب اليوم'
                    }
                }
            },
            year: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب العام'
                    }
                }
            }
        }
    });
    $('#edit_address').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            city_id: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب المدينة'
                    }
                }
            },
            address_name: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب اسم عنوان'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'يجب أن يكون ألفا الرقمية'
                    }
                }
            },
            block: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب كتلة'
                    },
                    integer: {
                        message: 'كتلة يجب أن يكون رقمية'
                    }
                }
            },
            judda: {
                validators: {
                    integer: {
                        message: 'كتلة يجب أن يكون رقمية'
                    }
                }
            },
            office_name: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب رقم'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'يجب أن يكون ألفا الرقمية'
                    }
                }
            },
            street: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب الشارع'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'يجب أن يكون ألفا الرقمية'
                    }
                }
            },
            floor: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب الكلمة'
                    },
                    integer: {
                        message: 'الكلمة يجب أن يكون رقمية'
                    }
                }
            },
            appartment: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب شقة'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'يجب أن يكون ألفا الرقمية'
                    }
                }
            }
        }
    });
    $('#add_address').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            city_id: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب المدينة'
                    }
                }
            },
            address_name: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب اسم عنوان'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'يجب أن يكون ألفا الرقمية'
                    }
                }
            },
            block: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب كتلة'
                    },
                    integer: {
                        message: 'كتلة يجب أن يكون رقمية'
                    }
                }
            },
            judda: {
                validators: {
                    integer: {
                        message: 'كتلة يجب أن يكون رقمية'
                    }
                }
            },
            office_name: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب رقم'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'يجب أن يكون ألفا الرقمية'
                    }
                }
            },
            street: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب الشارع'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'يجب أن يكون ألفا الرقمية'
                    }
                }
            },
            floor: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب الكلمة'
                    },
                    integer: {
                        message: 'الكلمة يجب أن يكون رقمية'
                    }
                }
            },
            appartment: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب شقة'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'يجب أن يكون ألفا الرقمية'
                    }
                }
            }
        }
    });

    $('#guest_checkout').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            name: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب اسم'
                    },
                    //regexp: {
                    //    regexp: '^[a-zA-Z]+$',
                    //    message: 'يجب أن تكون الأبجدية'
                    //},
                    //stringLength: {
                    //    max: 20,
                    //    message: 'يجب أن يكون الاسم أقل من 20 حرفا'
                    //}
                }
            },
            email: {
                validators: {

                    emailAddress: {
                        message: 'القيمة ليست عنوان بريد إلكتروني صالح'
                    }
                }
            },
            contact_no: {
                validators: {
                    regexp: {
                        regexp: '^[0-9]*$',
                        message: 'يجب أن تكون الأرقام'
                    },
                    notEmpty: {
                        message: 'مطلوب رقم الاتصال'
                    },
                    stringLength: {
                        max: 8,
                        min: 8,
                        message: 'يجب أن يكون 8 أرقام'
                    }
                }
            },
            address: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب عنوان'
                    }
                }
            }
        }
    });
    $('#contact_us').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            name: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب اسم'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z]+$',
                        message: 'يجب أن تكون الأبجدية'
                    },
                    stringLength: {
                        max: 50,
                        message: 'يجب أن يكون الاسم أقل من 50 حرفا'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب البريد الإلكتروني'
                    },
                    emailAddress: {
                        message: 'القيمة ليست عنوان بريد إلكتروني صالح'
                    }
                }
            },

            subject: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب شركة'
                    }
                }
            }

        }
    });
    $('#r_add_feedback').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            name: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب اسم'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z]+$',
                        message: 'يجب أن تكون الأبجدية'
                    },
                    stringLength: {
                        max: 50,
                        message: 'يجب أن يكون الاسم أقل من 20 حرفا'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب البريد الإلكتروني'
                    },
                    emailAddress: {
                        message: 'القيمة ليست عنوان بريد إلكتروني صالح'
                    }
                }
            },
            subject: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب عنوان'
                    },
                    stringLength: {

                        max: 60,
                        message: 'يجب أن يكون عنوان 60 حرفا '
                    }
                }
            },
            detail: {
                // The messages for this field are shown as usual
                validators: {
                    notEmpty: {
                        message: 'مطلوب استعراض'
                    },
                    stringLength: {

                        max: 100,
                        message: 'يرجى التأكد من رأيك يحتوي على 100 حرفا على الأقل'
                    }
                }
            }


        }
    });
    $('#reviews_validate').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            title: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب عنوان'
                    },
                }
            },
            review: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب مراجعة'
                    },
                }
            },
            rating: {
                validators: {
                    notEmpty: {
                        message: ' التقييمات المطلوبة'
                    }
                }
            }


        }
    });
    $('#login').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            email: {
                validators: {
                    notEmpty: {
                        message: 'مطلوب البريد الإلكتروني'
                    }
                }
            },
            password: {
                validators: {
                    notEmpty: {
                        message: ' كلمة المرور مطلوبة'
                    }
                }
            }


        }
    });
});