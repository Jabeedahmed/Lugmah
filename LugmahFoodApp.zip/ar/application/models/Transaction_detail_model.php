<?php
class Transaction_detail_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
				'transaction_id' => $item['transaction_id'],
				'item_id' => $item['item_id'],
				'item_quantity' => $item['item_quantity']
		);

		$this->db->insert('transaction_detail', $data);
		return $this->db->insert_id();
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('transaction_detail');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('transaction_detail');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}
        
        function get_items_by_trans_id($id)
	{
		$this->db->select('transaction_detail.id as detail_id,restaurant_menu_items.name_ar as name,restaurant_menu_items.price,transaction_detail.item_quantity');
		$this->db->from('transaction_detail');
                $this->db->join("restaurant_menu_items", "transaction_detail.item_id = restaurant_menu_items.id", "INNER");
                $this->db->where('transaction_detail.transaction_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function get_order_items($id)
	{
		$this->db->select('restaurant_menu_items.name_ar as name,restaurant_menu_items.price,transaction_detail.item_quantity,GROUP_CONCAT(user_item_group_attributes.name_ar) AS options_name,SUM(user_item_group_attributes.price) AS options_price');
		$this->db->from('transaction_detail');
		$this->db->join("restaurant_menu_items", "transaction_detail.item_id = restaurant_menu_items.id", "left");
		$this->db->join("transaction_item_details", "transaction_detail.id = transaction_item_details.trans_detail_id", "left");
		$this->db->join("user_item_group_attributes", "transaction_item_details.item_attribute_id = user_item_group_attributes.id", "left");
		$this->db->where('transaction_detail.transaction_id', $id);
		$this->db->group_by('transaction_detail.id');
		$query = $this->db->get();

		if ($query->num_rows() < 1) {
			return null;
		} else {
			return $query->result_array();
		}
	}

	function get_items_by_trans_id_two($id)
	{
		$this->db->select('transaction_detail.id as detail_id,restaurant_menu_items.name_ar as name,restaurant_menu_items.price,transaction_detail.item_quantity,transaction_detail.item_id');
		$this->db->from('transaction_detail');
		$this->db->join("restaurant_menu_items", "transaction_detail.item_id = restaurant_menu_items.id", "INNER");
		$this->db->where('transaction_detail.transaction_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'transaction_id' => $item['transaction_id'],
			'item_id' => $item['item_id'],
			'item_quantity' => $item['item_quantity']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('transaction_detail', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('transaction_detail');
	}
}