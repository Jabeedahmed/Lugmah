<?php
class Address_type_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'name' => $item['name']
			 ); 

		$this->db->insert('address_type', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('address_type');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('id,name_ar as name');
		$this->db->from('address_type');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'name' => $item['name']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('address_type', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('address_type');
	}
}