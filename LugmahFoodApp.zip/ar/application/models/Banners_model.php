<?php

class Banners_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    function create($item)
    {
        $data = array(
            'banner_id' => $item['banner_id'],
            'zone_id' => $item['zone_id']
        );

        $this->db->insert('banners', $data);
    }

    function get_by_id($id)
    {
        $this->db->select('*');
        $this->db->from('banners');
        $this->db->where('banner_id', $id);
        $this->db->select('*');
        $this->db->from('banners');
        $this->db->where('zone_id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_all()
    {
        $this->db->select('*');
        $this->db->from('banners');
        $this->db->join("main_banners", "banners.banner_id = main_banners.banner_id", "INNER");
        $this->db->join('banner_zones', 'banners.zone_id = banner_zones.id', 'left');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_header_banner()
    {
        $this->db->select('banner_url');
        $this->db->from('banners');
        $this->db->join("main_banners", "banners.banner_id = main_banners.banner_id", "INNER");
        $this->db->join('banner_zones', 'banners.zone_id = banner_zones.id', 'left');
        $this->db->where('banners.zone_id', '1');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_promotion_banner()
    {
        $this->db->select('*');
        $this->db->from('banners');
        $this->db->join("main_banners", "banners.banner_id = main_banners.banner_id", "INNER");
        $this->db->join('banner_zones', 'banners.zone_id = banner_zones.id', 'left');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_search_promotion_banner()
    {
        $this->db->select('banner_url');
        $this->db->from('banners');
        $this->db->join("main_banners", "banners.banner_id = main_banners.banner_id", "INNER");
        $this->db->join('banner_zones', 'banners.zone_id = banner_zones.id', 'left');
        $this->db->where('banners.zone_id', '3');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_menu_promotion_banner()
    {
        $this->db->select('banner_url');
        $this->db->from('banners');
        $this->db->join("main_banners", "banners.banner_id = main_banners.banner_id", "INNER");
        $this->db->join('banner_zones', 'banners.zone_id = banner_zones.id', 'left');
        $this->db->where('banners.zone_id', '4');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function update($id, $item)
    {
        $data = array();

        $this->db->where('zone_id', $id);
        $this->db->update('banners', $data);
    }

    function delete($id, $id2)
    {
        $this->db->where('banner_id', $id);
        $this->db->where('zone_id', $id2);
        $this->db->delete('banners');
    }
}