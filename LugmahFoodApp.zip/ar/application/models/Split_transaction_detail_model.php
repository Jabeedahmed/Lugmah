<?php
class Split_transaction_detail_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'split_id' => $item['split_id'],
			'username_no' => $item['username_no'],
			'status' => '1',
			'amount' => $item['amount'],
			'sms_status' => $item['sms_status'],
			'split_trans_id' => $item['split_trans_id']
			 );
		$this->db->set('start_time', 'NOW()', FALSE);
		$this->db->insert('split_transaction_detail', $data);
	}

	function get_by_id($id)
	{
		$this->db->select("username_no as number,split_trans_id,amount,IF(TIMESTAMPDIFF(MINUTE,start_time,NOW()) <15,15-TIMESTAMPDIFF(MINUTE,start_time,NOW()),0)AS time_remaining", false);
		$this->db->from('split_transaction_detail');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if ($query->num_rows() < 1) {
			return null;
		} else {
			return $query->row();
		}
	}

	function get_by_split_trans_id($id)
	{
		$this->db->select('*');
		$this->db->from('split_transaction_detail');
		$this->db->where('split_trans_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_by_split_id($id)
	{
		$this->db->select('*');
		$this->db->from('split_transaction_detail');
		$this->db->where('split_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function get_by_split_email_id($id)
	{
		$this->db->select('*');
		$this->db->from('split_transaction_detail');
		$this->db->where('split_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function get_split_status($id)
	{
		$this->db->select('*');
		$this->db->from('split_transaction_detail');
		$this->db->where('split_id', $id);
		$this->db->where('status', '1');
		$this->db->or_where('status', '3');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('split_transaction_detail');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'status' => '2',
			'completed_payment_id' => $item
			 );
		$this->db->set('completed_time', 'NOW()', FALSE);
		$this->db->where('split_trans_id', $id);
		$this->db->update('split_transaction_detail', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('split_transaction_detail');
	}

	function check_if_complete($id)
	{
		$this->db->select('COUNT(status) AS val,SUM(amount) AS amount');
		$this->db->from('split_transaction_detail');
		$this->db->where('(status = 1 OR status = 4)');
		$this->db->where('split_id', $id);

		$query = $this->db->get();

		if ($query->num_rows() < 1) {
			return null;
		} else {
			return $query->row();
		}

	}

	function expire_split_transaction($id)
	{
		$this->db->select('*');
		$this->db->from('split_transaction_detail');
		$this->db->where('split_id', $id);
		$this->db->where('status', '2');

		$query = $this->db->get();

		if ($query->num_rows() < 1) {
			$data = array(
					'status' => '4'
			);
			$this->db->set('complete_time', 'NOW()', FALSE);
			$this->db->where('id', $id);
			$this->db->update('split_transaction', $data);
			if ($this->db->affected_rows() > 0) {
				return TRUE;
			} else {
				return FALSE;
			}

		} else {
			$data = array(
					'status' => '3'
			);
			$this->db->set('complete_time', 'NOW()', FALSE);
			$this->db->where('id', $id);
			$this->db->update('split_transaction', $data);
			if ($this->db->affected_rows() > 0) {
				return TRUE;
			} else {
				return FALSE;
			}
		}
	}

	function check_admin_link($id)
	{
		$this->db->select('COUNT(status) AS val');
		$this->db->from('split_transaction_detail');
		$this->db->where('status', '4');
		$this->db->where('split_id', $id);

		$query = $this->db->get();

		if ($query->num_rows() < 1) {
			return null;
		} else {
			return $query->row();
		}

	}

	function expire_users_split($id)
	{

		$this->db->set('completed_time', 'NOW()', FALSE);
		$this->db->set('status', '3');
		$this->db->where('split_id', $id);
		$this->db->where('status !=', '2');
		$this->db->where('status !=', '4');
		$this->db->update('split_transaction_detail');
	}

	function get_split_admin($id)
	{
		$this->db->select('username_no as number,split_trans_id,amount');
		$this->db->from('split_transaction_detail');
		$this->db->where('split_id', $id);
		$this->db->order_by('id', 'ASEC');
		$query = $this->db->get();

		if ($query->num_rows() < 1) {
			return null;
		} else {
			return $query->row();
		}
	}

	function create_admin_link($item)
	{
		$data = array(
				'split_id' => $item['split_id'],
				'username_no' => $item['username_no'],
				'status' => '4',
				'amount' => $item['amount'],
				'sms_status' => $item['sms_status'],
				'split_trans_id' => $item['split_trans_id']
		);
		$this->db->set('start_time', 'NOW()', FALSE);
		$this->db->insert('split_transaction_detail', $data);
		return $this->db->insert_id();
	}



	function get_split_transaction_status($id)
	{
		$this->db->select("sp.id,(CASE
	    WHEN sp.status = '2' THEN 'completed'
	    WHEN sp.status = '3' THEN 'exp_with_payment'
	    WHEN sp.status = '4' THEN 'exp_without_payment'
	    WHEN sp.status = '1' AND TIMESTAMPDIFF(MINUTE,sp.start_time,NOW()) <45 THEN 'active'
        WHEN sp.status = '1' AND TIMESTAMPDIFF(MINUTE,sp.start_time,NOW()) <60 THEN 'admin_pay'
        WHEN sp.status = '1' AND TIMESTAMPDIFF(MINUTE,sp.start_time,NOW()) >60 THEN 'exp_split'
	    ELSE 'expired'
        END)AS user_status,
         IF(TIMESTAMPDIFF(MINUTE,sp.start_time,NOW()) <45,45-TIMESTAMPDIFF(MINUTE,sp.start_time,NOW()),0)AS time_remaining", false);
		$this->db->from('split_transaction_detail AS spd');
		$this->db->join('split_transaction AS sp', 'spd.split_id = sp.id', 'LEFT');
		$this->db->where('spd.split_trans_id', "'" . $id . "'", false);
		$query = $this->db->get();

		if ($query->num_rows() < 1) {
			return null;
		} else {
			return $query->row();
		}
	}

	function get_split_user_status($id)
	{
		$this->db->select("split_trans_id,username_no AS number, (CASE WHEN STATUS = '2' THEN 'completed' WHEN STATUS = '1' THEN 'active' WHEN STATUS = '4' THEN 'admin_link' ELSE 'expired' END)AS status", false);
		$this->db->from('split_transaction_detail');
		$this->db->where('split_id', $id);
		$query = $this->db->get();

		if ($query->num_rows() < 1) {
			return null;
		} else {
			return $query->result_array();
		}
	}

	function get_time_by_split_transaction_id($id)
	{
		$this->db->select("IF(TIMESTAMPDIFF(MINUTE,sp.start_time,NOW()) <45,45-TIMESTAMPDIFF(MINUTE,sp.start_time,NOW()),0)AS time_remaining", false);
		$this->db->from('split_transaction_detail');
		$this->db->join('split_transaction AS sp', 'split_transaction_detail.split_id = sp.id', 'LEFT');
		$this->db->where('split_trans_id', "'" . $id . "'", false);
		$query = $this->db->get();

		if ($query->num_rows() < 1) {
			return null;
		} else {
			return $query->row();
		}
	}


	function get_admin_time_by_split_transaction_id($id)
	{
		$this->db->select("IF(TIMESTAMPDIFF(MINUTE,sp.start_time,NOW()) <60,60-TIMESTAMPDIFF(MINUTE,sp.start_time,NOW()),0)AS time_remaining", false);
		$this->db->from('split_transaction_detail');
		$this->db->join('split_transaction AS sp', 'split_transaction_detail.split_id = sp.id', 'LEFT');
		$this->db->where('split_trans_id', "'" . $id . "'", false);
		$query = $this->db->get();

		if ($query->num_rows() < 1) {
			return null;
		} else {
			return $query->row();
		}
	}
}