<?php
class User_addresses_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'user_id' => $item['user_id'],
			'type_id' => $item['type_id'],
			'area' => $item['area'],
			'address_title' => $item['address_title'],
			'block' => $item['block'],
			'judda' => $item['judda'],
			'street' => $item['street'],
			'houseno_name' => $item['houseno_name'],
			'floor' => $item['floor'],
			'office_apt' => $item['office_apt'],
			'extra_direction' => $item['extra_direction']
			 ); 

		$this->db->insert('user_addresses', $data);
	}

	function get_by_id($id)
	{
		$this->db->select("CONCAT('Block No: ',block,IF(judda!='', CONCAT(', Judda: ',judda), ''),', Street No: ',street,
		CASE type_id WHEN '1' THEN ', House No: ' WHEN '2' THEN ', Building No: ' ELSE ', Office No: ' END, houseno_name,
		IF(`floor`!='', CONCAT(', Floor No: ',`floor`), ''),IF(office_apt!='', CONCAT(', Office No: ',office_apt), ''),
		IF(extra_direction!='', CONCAT(', Extra Directions: ',extra_direction), '')
		) AS address",false);
		$this->db->from('user_addresses');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('user_addresses');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}
        
        function get_all_by_user_id($uid)
	{
		$this->db->select('user_addresses.id,user_addresses.type_id,user_addresses.area as area_id,user_addresses.address_title,user_addresses.block,user_addresses.judda,user_addresses.street,user_addresses.houseno_name,user_addresses.floor,user_addresses.office_apt,user_addresses.extra_direction,address_type.name_ar as type_name,cities.city_name_ar as area_name');
		$this->db->from('user_addresses');
                $this->db->join("cities", "user_addresses.area = cities.city_id", "INNER");
                $this->db->join("address_type", "user_addresses.type_id = address_type.id", "INNER");
                $this->db->where('user_id', $uid);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'user_id' => $item['user_id'],
			'type_id' => $item['type_id'],
			'area' => $item['area'],
			'address_title' => $item['address_title'],
			'block' => $item['block'],
			'judda' => $item['judda'],
			'street' => $item['street'],
			'houseno_name' => $item['houseno_name'],
			'floor' => $item['floor'],
			'office_apt' => $item['office_apt'],
			'extra_direction' => $item['extra_direction']
			 ); 

		$this->db->where('id', $id);
                $this->db->update('user_addresses', $data);
                if($this->db->affected_rows()>=1){
                    return true;
                }
                else{
                    return false;
                }
	}

	function delete($id,$uid)
	{
		$this->db->where('id', $id);
		$this->db->where('user_id', $uid);
                $this->db->delete('user_addresses');
                if($this->db->affected_rows()>=1){
                    return true;
                }
                else{
                    return false;
                }
	}
}