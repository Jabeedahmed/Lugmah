<?php
class Restaurant_branches_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'restaurant_id' => $item['restaurant_id'],
			'branch_name' => $item['branch_name'],
			'branch_address' => $item['branch_address']
			 ); 

		$this->db->insert('restaurant_branches', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('restaurant_branches');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('restaurant_branches');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}
        
        function get_all_by_id($rid)
	{
		$this->db->select('id,restaurant_id,city,branch_name_ar as branch_name,branch_address_ar as branch_address');
		$this->db->from('restaurant_branches');
                $this->db->where('restaurant_id', $rid);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'restaurant_id' => $item['restaurant_id'],
			'branch_name' => $item['branch_name'],
			'branch_address' => $item['branch_address']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('restaurant_branches', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('restaurant_branches');
	}
}