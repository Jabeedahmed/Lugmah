<?php
class Restaurant_menu_items_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'menu_id' => $item['menu_id'],
			'name' => $item['name'],
			'price' => $item['price'],
			'description' => $item['description']
			 ); 

		$this->db->insert('restaurant_menu_items', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('id,menu_id,price,image_url,name_ar as name,description_ar as description');
		$this->db->from('restaurant_menu_items');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('restaurant_menu_items');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'menu_id' => $item['menu_id'],
			'name' => $item['name'],
			'price' => $item['price'],
			'description' => $item['description']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('restaurant_menu_items', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('restaurant_menu_items');
	}
        
        function get_by_category_menu_id($id)
	{
		$this->db->select('*');
		$this->db->from('restaurant_menu_items');
		$this->db->where('menu_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function get_item_groups($id)
	{
		$this->db->select('id,item_id,group_name_ar as group_name');
		$this->db->from('user_item_groups');
		$this->db->where('item_id', $id);
		$query = $this->db->get();

		if ($query->num_rows() < 1) {
			return null;
		} else {
			return $query->result();
		}
	}

	function get_item_group_attributes($id)
	{
		$this->db->select('id,group_id,price,name_ar as name');
		$this->db->from('user_item_group_attributes');
		$this->db->where('group_id', $id);
		$query = $this->db->get();

		if ($query->num_rows() < 1) {
			return null;
		} else {
			return $query->result();
		}
	}
}