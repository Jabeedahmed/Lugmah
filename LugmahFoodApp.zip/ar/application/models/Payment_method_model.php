<?php

class Payment_method_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    function create($item)
    {
        $data = array(
            'name' => $item['name']
        );

        $this->db->insert('payment_method', $data);
    }

    function get_by_id($id)
    {
        $this->db->select('*');
        $this->db->from('payment_method');
        $this->db->where('id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_by_ids($id)
    {
        $this->db->select('id,name_ar as name,image_url');
        $this->db->from('payment_method');
        $this->db->where_in('id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_all()
    {
        $this->db->select('*');
        $this->db->from('payment_method');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function update($id, $item)
    {
        $data = array(
            'name' => $item['name']
        );

        $this->db->where('id', $id);
        $this->db->update('payment_method', $data);
    }

    function delete($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('payment_method');
    }

    function get_payment_images()
    {
        $this->db->select('image_url');
        $this->db->from('payment_method');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }


}