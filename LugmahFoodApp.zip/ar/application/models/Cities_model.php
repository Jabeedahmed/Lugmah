<?php
class Cities_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'city_name' => $item['city_name']
			 ); 

		$this->db->insert('cities', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('city_id,city_name_ar as city_name,capital_id');
		$this->db->from('cities');
		$this->db->where('city_id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('city_id,city_name_ar as city_name,capital_id');
		$this->db->from('cities');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'city_name' => $item['city_name']
			 ); 

		$this->db->where('city_id', $id);
		$this->db->update('cities', $data);
	}

	function delete($id)
	{
		$this->db->where('city_id', $id);
		$this->db->delete('cities');
	}

	function get_all_capitals()
	{
		$this->db->select('id,capital_name_ar as capital_name');
		$this->db->from('capital');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

}