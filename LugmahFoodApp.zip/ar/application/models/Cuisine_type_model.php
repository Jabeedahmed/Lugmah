<?php
class Cuisine_type_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($item)
	{
		$data = array(
			'name' => $item['name']
			 ); 

		$this->db->insert('cuisine_type', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('cuisine_type');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}
	function get_all_for_search()
	{
		$this->db->select('*');
		$this->db->from('cuisine_type');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function get_all()
	{
		$this->db->select('id,name_ar as name,image_url');
		$this->db->from('cuisine_type');
		$this->db->order_by('id','RANDOM');
		$this->db->limit(24);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function get_all_cuisines()
	{
		$this->db->select('id,name_ar as name,image_url');
		$this->db->from('cuisine_type');
		$this->db->order_by('id');
//		$this->db->limit(3);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}
        
        function get_all_by_limit()
	{
		$this->db->select('id,name_ar as name,image_url');
		$this->db->from('cuisine_type');
                $this->db->order_by('id','RANDOM');
                $this->db->limit(4);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'name' => $item['name']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('cuisine_type', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('cuisine_type');
	}

	function get_cuicines_by_limits($limit)
	{
		$limit_end = 3;
		$this->db->select('*');
		$this->db->from('cuisine_type');
		$this->db->order_by('id');
		$this->db->limit($limit_end,$limit);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}
}