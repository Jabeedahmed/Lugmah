<?php
class User_fav_restaurant_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function create($id,$id2)
	{
		$data = array(
			'user_id' => $id,
			'restaurant_id' => $id2
			 ); 
                $this->db->set('date_added', 'NOW()', FALSE);
		$this->db->insert('user_fav_restaurant', $data);
	}

	function get_by_id($id)
	{
		$this->db->select('*');
		$this->db->from('user_fav_restaurant');
		$this->db->where('id', $id);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}
        
        function get_all_by_user_id($uid)
	{
		$this->db->select('restaurant_id');
		$this->db->from('user_fav_restaurant');
		$this->db->where('user_id', $uid);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}
        	
	function get_count_by_user_id($uid)
	{
		$this->db->select('count(*) as total');
		$this->db->from('user_fav_restaurant');
		$this->db->where('user_id', $uid);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}

	function get_all()
	{
		$this->db->select('*');
		$this->db->from('user_fav_restaurant');
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result_array();
		}
	}

	function update($id, $item)
	{
		$data = array(
			'user_id' => $item['user_id'],
			'restaurant_id' => $item['restaurant_id'],
			'date_added' => $item['date_added']
			 ); 

		$this->db->where('id', $id);
		$this->db->update('user_fav_restaurant', $data);
	}

	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('user_fav_restaurant');
	}
        
        
        function check_res_bookmark($id,$rid)
	{
		$this->db->select('*');
		$this->db->from('user_fav_restaurant');
		$this->db->where('user_id', $id);
                $this->db->where('restaurant_id', $rid);
		$query = $this->db->get();

		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->row();
		}
	}


	function get_all_fav_restaurants_user_id($uid)
	{
		$this->db->select('*,restaurant.name_ar as rest_name,restaurant.description_ar as rest_description, user_fav_restaurant.id as fav_id,cuisine_type.name_ar as type_name, restaurant.slug');
		$this->db->from('user_fav_restaurant');
		$this->db->join('restaurant','user_fav_restaurant.restaurant_id = restaurant.id ');
		$this->db->join('restaurant_cuisine_type','restaurant_cuisine_type.restaurant_id = restaurant.id ');
		$this->db->join('cuisine_type','cuisine_type.id = restaurant_cuisine_type.cuisine_type_id ');
		$this->db->where('user_fav_restaurant.user_id', $uid);
		$this->db->group_by('restaurant.id');

		$query = $this->db->get();


		if($query->num_rows()<1){
			return null;
		}
		else{
			return $query->result();
		}
	}
}