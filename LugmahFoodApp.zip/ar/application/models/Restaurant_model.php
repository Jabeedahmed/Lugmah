<?php

class Restaurant_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    function create($item)
    {
        $data = array(
            'name' => $item['name'],
            'logo_url' => $item['logo_url'],
            'cover_image_url' => $item['cover_image_url'],
            'description' => $item['description'],
            'phone_number' => $item['phone_number'],
            'website_address' => $item['website_address'],
            'cuisine_type_id' => $item['cuisine_type_id'],
            'server' => $item['server'],
            'price_range' => $item['price_range'],
            'payment_methods' => $item['payment_methods'],
            'country_id' => $item['country_id'],
            'min_order' => $item['min_order'],
            'delivery_charges' => $item['delivery_charges'],
            'user_id' => $item['user_id']
        );

        $this->db->insert('restaurant', $data);
    }

    function get_by_id($id)
    {
        $this->db->select('*');
        $this->db->from('restaurant');
        $this->db->where('id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_discount_restaurants()
    {
        $this->db->select('slug,logo_url');
        $this->db->from('restaurant');
        $this->db->where('discount IS NOT NULL AND discount != 0', null, false);
        $this->db->limit(12);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_voucher_restaurants()
    {
        $this->db->select('slug,logo_url');
        $this->db->from('restaurant_promotion');
        $this->db->join("restaurant", " restaurant_promotion.restaurant_id = restaurant.id AND restaurant_promotion.status = 1", "inner");
        $this->db->where('restaurant_promotion.discount_precentage != 0', null, false);
        $this->db->limit(12);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function get_all()
    {
        $this->db->select('*');
        $this->db->from('restaurant');
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result_array();
        }
    }

    function update($id, $item)
    {
        $data = array(
            'name' => $item['name'],
            'logo_url' => $item['logo_url'],
            'cover_image_url' => $item['cover_image_url'],
            'description' => $item['description'],
            'phone_number' => $item['phone_number'],
            'website_address' => $item['website_address'],
            'cuisine_type_id' => $item['cuisine_type_id'],
            'server' => $item['server'],
            'price_range' => $item['price_range'],
            'payment_methods' => $item['payment_methods'],
            'country_id' => $item['country_id'],
            'min_order' => $item['min_order'],
            'delivery_charges' => $item['delivery_charges'],
            'user_id' => $item['user_id']
        );

        $this->db->where('id', $id);
        $this->db->update('restaurant', $data);
    }

    function delete($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('restaurant');
    }

    function get_restaurant_detail_by_id($id,$user_id = 0)
    {
        $this->db->select("restaurant.id,restaurant.name_ar as name,restaurant.logo_url,
                            restaurant.cover_image_url,restaurant.min_order,restaurant.delivery_charges,
                            restaurant.delivery_time,(CASE
	                        WHEN restaurant.discount !=0 AND restaurant.discount IS NOT NULL THEN restaurant.discount
                            WHEN restaurant_promotion.discount_precentage !='' AND restaurant_promotion.discount_precentage !=0 THEN restaurant_promotion.discount_precentage
                            ELSE 0
                            END)AS discount,(CASE
                            WHEN restaurant.discount !=0 AND restaurant.discount IS NOT NULL THEN 'flat'
                            WHEN restaurant_promotion.discount_precentage !='' AND restaurant_promotion.discount_precentage !=0 THEN 'voucher'
                            ELSE 'none'
                            END)AS discount_type,ct.cuisine_type AS type, branch_address_ar AS location,restaurant.payment_methods,restaurant.description_ar as descript,restaurant.slug,rt.rating,IFNULL(rt.rating_count,0) AS rating_count,restaurant_promotion.minimum_amount AS voucher_min_amount,restaurant_promotion.promotion_code,IF(user_fav_restaurant.id IS NULL, 'NO', 'YES') AS bookmark_status");
        $this->db->from('restaurant');
        $this->db->join("(SELECT GROUP_CONCAT(name_ar SEPARATOR ', ') AS cuisine_type,restaurant_id FROM restaurant_cuisine_type INNER JOIN cuisine_type ON restaurant_cuisine_type.cuisine_type_id = cuisine_type.id GROUP BY restaurant_id) AS ct", "restaurant.id = ct.restaurant_id", "LEFT");
        $this->db->join("(SELECT * FROM `restaurant_branches` WHERE `restaurant_id`=$id GROUP BY `restaurant_id`) t", "restaurant.id=t.restaurant_id", "LEFT", NULL, FALSE);
        $this->db->join("(SELECT ROUND(SUM(rating)/(COUNT(rating)*5)*5, 1) AS rating,COUNT(rating) AS rating_count, restaurant_id FROM (restaurant_comments) WHERE reply_comment_id =  '0' GROUP BY restaurant_id) AS rt", "restaurant.id = rt.restaurant_id", "LEFT", NULL, FALSE);
        $this->db->join("user_fav_restaurant", "restaurant.id = user_fav_restaurant.restaurant_id AND user_fav_restaurant.user_id = $user_id", "LEFT");
        $this->db->join("restaurant_promotion", "restaurant.id = restaurant_promotion.restaurant_id AND restaurant_promotion.status = 1", "LEFT");
        $this->db->where('restaurant.id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_search()
    {
        $this->db->select('restaurant.id,restaurant.name,restaurant.logo_url,restaurant.cover_image_url,restaurant.min_order,restaurant.delivery_charges,restaurant.delivery_time,restaurant.discount,restaurant.payment_methods');
//        $Linkearray = array('restaurant.name' => $q);
//        $this->db->or_like($Linkearray);
        $this->db->from('restaurant');
        $this->db->join("cuisine_type", "restaurant.cuisine_type_id = cuisine_type.id", "LEFT");
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->result();
        }
    }

    function restaurant_search($filter, $limit = 10, $start = 0,$user_id = 0)
    {
        $this->db->select("SQL_CALC_FOUND_ROWS null as rows, restaurant.id,restaurant.slug,restaurant.name_ar as name,restaurant.logo_url,restaurant.cover_image_url,restaurant.min_order,restaurant.delivery_charges,restaurant.delivery_time,(CASE
	                        WHEN restaurant.discount !=0 AND restaurant.discount IS NOT NULL THEN restaurant.discount
                            WHEN restaurant_promotion.discount_precentage !='' AND restaurant_promotion.discount_precentage !=0 THEN restaurant_promotion.discount_precentage
                            ELSE 0
                            END)AS discount,(CASE
                            WHEN restaurant.discount !=0 AND restaurant.discount IS NOT NULL THEN 'flat'
                            WHEN restaurant_promotion.discount_precentage !='' AND restaurant_promotion.discount_precentage !=0 THEN 'voucher'
                            ELSE 'none'
                            END)AS discount_type,ct.cuisine_type AS type,restaurant.payment_methods,rt.rating,IFNULL(rt.rating_count,0) AS rating_count,restaurant_promotion.promotion_code,IF(user_fav_restaurant.id IS NULL, 'NO', 'YES') AS bookmark_status,
                            IF(NOW() >= start_time AND (NOW()<= end_time OR end_time = 0),'open','closed') AS open_status", false);
        $this->db->from('restaurant');
        $this->db->join("restaurant_branches", "restaurant.id = restaurant_branches.restaurant_id", "LEFT");
        $this->db->join("(SELECT GROUP_CONCAT(name_ar SEPARATOR ', ') AS cuisine_type,restaurant_id FROM restaurant_cuisine_type INNER JOIN cuisine_type ON restaurant_cuisine_type.cuisine_type_id = cuisine_type.id GROUP BY restaurant_id) AS ct", "restaurant.id = ct.restaurant_id", "LEFT");
        $this->db->join("restaurant_promotion", "restaurant.id = restaurant_promotion.restaurant_id AND restaurant_promotion.status = 1", "LEFT");
        $this->db->join("user_fav_restaurant", "restaurant.id = user_fav_restaurant.restaurant_id AND user_fav_restaurant.user_id = $user_id", "LEFT");
        $this->db->join("(SELECT ROUND(SUM(rating)/(COUNT(rating)*5)*5, 1) AS rating,COUNT(rating) AS rating_count, restaurant_id FROM (restaurant_comments) WHERE reply_comment_id =  '0' GROUP BY restaurant_id) AS rt", "restaurant.id = rt.restaurant_id", "LEFT", NULL, FALSE);
        $this->db->join("restaurant_timing", "restaurant.id = restaurant_timing.restaurant_id AND restaurant_timing.day = DAYNAME(NOW()) AND restaurant_timing.status !=2", "LEFT");
        if (isset($filter['cuisine'])) {
            $this->db->join("(SELECT restaurant_id FROM restaurant_cuisine_type WHERE cuisine_type_id IN ($filter[cuisine]))AS t", "restaurant.id = t.restaurant_id", "INNER", NULL, FALSE);
        }
        if (isset($filter['search_term'])) {
            $this->db->like('name', $filter['search_term']);
        }
        if (isset($filter['area'])) {
            $this->db->where('restaurant_branches.city', $filter['area']);
        }
        if (isset($filter['catering'])) {
            $this->db->where('restaurant.server', '1');
        }
        if (isset($filter['free_delivery'])) {
            $this->db->where('restaurant.delivery_charges', '0');
        }
        if (isset($filter['discount_avail'])) {
            $this->db->where('restaurant.discount >', '0');
        }
        if (isset($filter['has_promotions'])) {
            $this->db->where('discount_type', 'voucher');
        }
        if (isset($filter['openrest'])) {
            $this->db->where("IF(NOW() >= start_time AND (NOW()<= end_time OR end_time = 0), 'open', 'closed') = ", 'open');
        }
        if (isset($filter['cod_avail'])) {
            $this->db->where('FIND_IN_SET("2", CAST(payment_methods AS CHAR))>', '0');
        }
        if (isset($filter['split_avail'])) {
            $this->db->where('FIND_IN_SET("4", CAST(payment_methods AS CHAR))>', '0');
        }
        if (isset($filter['min_price'])) {
            $this->db->where('restaurant.price_min >=', $filter['min_price']);
        }
        if (isset($filter['max_price'])) {
            $this->db->where('restaurant.price_max <=', $filter['max_price']);
        }
        if (isset($filter['rating'])) {
            $this->db->where('rt.rating >=', $filter['rating']);
        }
        $this->db->group_by('restaurant.id');
        if ($limit) {
            $this->db->limit($limit, $start);
        }
        if (isset($filter['sort_by'])) {
            if ($filter['sort_by'] == 'name_asce') {
                $this->db->order_by("restaurant.name", "asc");
            } elseif ($filter['sort_by'] == 'name_desc') {
                $this->db->order_by("restaurant.name", "desc");
            } elseif ($filter['sort_by'] == 'rating_asce') {
                $this->db->order_by("rt.rating", "asc");
            } elseif ($filter['sort_by'] == 'rating_desc') {
                $this->db->order_by("rt.rating", "desc");
            } elseif ($filter['sort_by'] == 'price_asce') {
                $this->db->order_by("restaurant.price_min", "asc");
            } elseif ($filter['sort_by'] == 'price_desc') {
                $this->db->order_by("restaurant.price_min", "desc");
            }
        }
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            $return['results'] = $query->result();
            $query = $this->db->query('SELECT FOUND_ROWS() AS `Count`');
            $return["totalres"] = $query->row()->Count;
            if ($start + $limit >= $return["totalres"]) {
                $return['has_more'] = false;
            } else {
                $return['has_more'] = true;
            }
            return $return;
        }
    }

    public function get_id_by_slug($slug)
    {
        $this->db->select('id');
        $this->db->from('restaurant');
        $this->db->where('slug', $slug);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function search_by_restaurant_name($filter, $limit = 10, $start = 0)
    {
        $this->db->select('restaurant.id,restaurant.slug,restaurant.name,restaurant.logo_url,restaurant.cover_image_url,restaurant.min_order,restaurant.delivery_charges,restaurant.delivery_time,restaurant.discount,restaurant.payment_methods');
        $this->db->from('restaurant');
        $this->db->join("restaurant_branches", "restaurant.id = restaurant_branches.restaurant_id", "left");
        $this->db->like('name', $filter);
        $this->db->group_by('restaurant.id');

        if ($limit) {
            $this->db->limit($limit, $start);
        }
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            $return['results'] = $query->result();
            $query = $this->db->query('SELECT FOUND_ROWS() AS `Count`');
            $return["totalres"] = $query->row()->Count;
            if ($start + $limit >= $return["totalres"]) {
                $return['has_more'] = false;
            } else {
                $return['has_more'] = true;
            }
            return $return;
        }
    }

    function get_restaurant($q)
    {
        $this->db->select('name_ar as name');
        $this->db->from('restaurant');
        $this->db->like('restaurant.name', $q);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            foreach ($query->result_array() as $row) {
                $row_set[] = htmlentities(stripslashes($row['name'])); //build an array
            }
            echo json_encode($row_set); //format the array into json data
        } else {
            $row_set[] = "No records found";
            echo json_encode($row_set);
        }
    }

    function check_restaurant_promotion($id, $code)
    {
        $this->db->select('id,promotion_name,discount_precentage,minimum_amount');
        $this->db->from('restaurant_promotion');
        $this->db->where('restaurant_id', $id);
        $this->db->where('promotion_code', $code);
        $query = $this->db->get();
        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function check_restaurant_discount($id)
    {
        $this->db->select("(CASE
	                        WHEN restaurant.discount !=0 AND restaurant.discount IS NOT NULL THEN restaurant.discount
                            WHEN restaurant_promotion.discount_precentage !='' AND restaurant_promotion.discount_precentage !=0 THEN restaurant_promotion.discount_precentage
                            ELSE 0
                            END)AS discount,(CASE
                            WHEN restaurant.discount !=0 AND restaurant.discount IS NOT NULL THEN 'flat'
                            WHEN restaurant_promotion.discount_precentage !='' AND restaurant_promotion.discount_precentage !=0 THEN 'voucher'
                            ELSE 'none'
                            END)AS discount_type ", false);
        $this->db->from('restaurant');
        $this->db->join("restaurant_promotion", "restaurant.id = restaurant_promotion.restaurant_id AND restaurant_promotion.status = 1", "LEFT");
        $this->db->where('restaurant.id', $id);
        $query = $this->db->get();

        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

    function get_voucher_discount($code)
    {
        $this->db->select('discount_precentage AS discount,minimum_amount AS voucher_min_amount');
        $this->db->from('restaurant_promotion');
        $this->db->where('promotion_code', $code);
        $query = $this->db->get();
        if ($query->num_rows() < 1) {
            return null;
        } else {
            return $query->row();
        }
    }

}