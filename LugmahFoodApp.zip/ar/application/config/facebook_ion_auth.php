<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| Settings.
| -------------------------------------------------------------------------
*/
$config['app_id'] 		= '568835063287629'; 		// Your app id
$config['app_secret'] 	= 'd07824c3810bbf72f4f4c7de5ec516a0'; 		// Your app secret key
$config['scope'] 		= 'email'; 	// custom permissions check - http://developers.facebook.com/docs/reference/login/#permissions
$config['redirect_uri'] = 'http://www.dotsnpixelz.com/demo/lugma_new92/main/fblogin'; 		// url to redirect back from facebook. If set to '', site_url('') will be used