<script type="text/javascript" src="<?= base_url() ?>js/formValidation.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/framework/bootstrap.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/validation.js"></script>
<!--bootstrap-js-->
<script src="<?= base_url() ?>js/bootstrap.min.js"></script>
<!--script-->
<script type="text/javascript" src="<?= base_url() ?>js/move-top.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/easing.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/toastr.js"></script>
<script type="text/javascript" src="<?= base_url() ?>js/instafeed.min.js"></script>


<?php if ($this->session->flashdata('success') != ""): ?>

    <script type="text/javascript">
        $(document).ready(function () {
            toastr.success('<?php echo $this->session->flashdata("success"); ?>');
        });
    </script>
<?php endif; ?>
<?php if ($this->session->flashdata('error') != ""): ?>
    <script type="text/javascript">
        $(document).ready(function () {
            toastr.error('<?php echo $this->session->flashdata("error"); ?>');
        });
    </script>
<?php endif; ?>

<script type="text/javascript">
    $(document).ready(function () {
        $().UItoTop({easingType: 'easeOutQuart'});

    });

</script>
<script>
    $(function(){
        var test = localStorage.input === 'true'? true: false;
        $('.check').prop('checked', test || false);
    });

    $('.check').on('change', function() {
        localStorage.input = $(this).is(':checked');
    });
</script>
<script>
    $(document).ready(function () {
        $(".no-item").click(function () {
            $('#no-item').modal('show');
        });
        $(".promotions").click(function () {
            $('#promotions').modal('show');
        });

        $(".editpass").click(function () {
            $('#editpass').modal('show');
        });
        $(".editemail").click(function () {
            $('#editemail').modal('show');
        });

        $(".thankyou").click(function () {
            $('#thankyou').modal('show');
        });
        $(".split").click(function () {
            $('#split').modal('show');
        });
        $(".customer_support").click(function () {
            $('#customer_support').modal('show');
        });

    });
</script>
<script>
    setTimeout(function () {
        $('.alert').fadeOut('fast');
    }, 5000);
    $(".close").click(function () {
        $(".alert").hide();
    });
</script>
<script src="<?php echo base_url() ?>js/owl.carousel.js"></script>
<script>

    $(document).ready(function () {
        $("#owl-demo2").owlCarousel({
            items: 1,
            lazyLoad: true,
            autoPlay: true,
            navigation: true,
            pagination: false,
            navigationText: [
                "<i class='glyphicon glyphicon-chevron-left'></i>",
                "<i class='glyphicon glyphicon-chevron-right'></i>"
            ],
        });
        $("#owl-demo1").owlCarousel({
            items: 3,
            lazyLoad: true,
            autoPlay: true,
            navigation: true,
            pagination: false,
            navigationText: [
                "<i class='glyphicon glyphicon-chevron-left'></i>",
                "<i class='glyphicon glyphicon-chevron-right'></i>"
            ],
        });
    });
</script>
<script>

    $(document).ready(function () {
        $("#owl-demo").owlCarousel({
            items: 4,
            lazyLoad: true,
            autoPlay: true,
            navigation: true,
            pagination: false,
            navigationText: [
                "<i class='glyphicon glyphicon-chevron-left'></i>",
                "<i class='glyphicon glyphicon-chevron-right'></i>"
            ],
        });
    });
</script>

<script>
    $( document ).ready(function() {
        $(document).ajaxStart(function() {
            $(".whole_div").show();
        });

        $(document).ajaxStop(function() {
            $(".whole_div").hide();
        });
    });
</script>








