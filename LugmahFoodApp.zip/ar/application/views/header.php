<link rel="stylesheet" href="<?= base_url() ?>css/header_search.css"/>
<style>
    .navbar-default .navbar-nav > li > a {
        color: white !important;
        font-size: 17px !important;
    }

    .dropdown-submenu {
        position: relative;
    }

    .dropdown-submenu > .dropdown-menu {
        top: 0;
        left: 100%;
        margin-top: -6px;
        margin-left: -1px;
        -webkit-border-radius: 0 6px 6px 6px;
        -moz-border-radius: 0 6px 6px;
        border-radius: 0 6px 6px 6px;
    }

    .dropdown-submenu:hover > .dropdown-menu {
        display: block;
    }

    .dropdown-submenu > a:after {
        display: block;
        content: " ";
        float: right;
        width: 0;
        height: 0;
        border-color: transparent;
        border-style: solid;
        border-width: 5px 0 5px 5px;
        border-left-color: #ccc;
        margin-top: 5px;
        margin-right: -10px;
    }

    .dropdown-submenu:hover > a:after {
        border-left-color: #fff;
    }

    .dropdown-submenu.pull-left {
        float: none;
    }

    .dropdown-submenu.pull-left > .dropdown-menu {
        left: -100%;
        margin-left: 10px;
        -webkit-border-radius: 6px 0 6px 6px;
        -moz-border-radius: 6px 0 6px 6px;
        border-radius: 6px 0 6px 6px;
    }

    }</style>
<style>
    ul.tabs li {
        background: #FFC000;
        color: #222222;
        display: inline-block;
        padding: 10px 90px;
        cursor: pointer;
        background-repeat: repeat-x;
        border: 1px solid #FFC000;
        -ms-border-top-left-radius: 5px;
        -webkit-border-top-left-radius: 5px;
        border-top-left-radius: 5px;
        -ms-border-top-right-radius: 5px;
        -webkit-border-top-right-radius: 5px;
        border-top-right-radius: 5px;
        position: relative;
    }

    li.current::after {
        color: #222222;
        content: "";
        position: absolute;
        bottom: -30px;
        left: 95px;
        border-width: 15px 15px 0;
        border-style: solid;
        border-color: #FFC000 transparent;
        background-repeat: repeat-x;
        display: block;
        width: 0;
    }

    .tab-content {
        display: none;
        padding: 15px;
    }

    .tab-content.current {
        display: inherit;
    }

    .divider {
        background-color: white !important;
        height: 0px !important;
        margin: 0px 0 !important;
        overflow: hidden;
    }

    .dropdown-header {
        font-size: 17px !important;
    }

</style>
<div class="before">
    <nav class="navbar navbar-default" role="navigation"
         style="min-height: 660px;opacity:1;border-top: 0px;border-right: 0px;border-left: 0px;">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand img-responsive" style="height: auto;padding-bottom: 13px" href="<?= base_url() ?>"><img
                        src="<?= base_url() ?>img/lugmahlogo.png" style="height: 60px;"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="margin-top: 30px;">
                <ul class="nav navbar-nav navbar-right torq-menu nav_list_before">
                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <li><a href="<?= base_url() ?>main/my_account">حسابي</a></li>
                    <?php } ?>

                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <ul class="nav navbar-nav">
                            <li>
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">متابعة الطلب<span class="caret "></span></a>
                                <ul class="dropdown-menu multi-level">
                                    <li><a href="<?= base_url() ?>main/track_order"><strong>متابعة الطلب</strong> </a></li>
                                    <li class="dropdown-submenu">
                                        <a href="#" tabindex="-1"><strong>الإنشقاقات النشطة</strong></a>
                                        <ul class="dropdown-menu" style="width:250px; margin-top: 1px;">
                                            <?php
                                            if (!empty($split_payments)) {
                                                foreach ($split_payments as $split_row) { ?>
                                                    <li>
                                                        <a href="<?= base_url() ?>main/split_payment_status?split_transaction_id=<?= urlencode($split_row->split_trans_id); ?>"><strong><?= ucfirst($split_row->name) . ' (' .  date('H:i:s',strtotime($split_row->start_time)).')'; ?></strong></a>
                                                    </li>
                                                <?php }
                                            } else { ?>
                                                <li><a><strong>لا سبليت النشط متاح</strong></a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    <?php } else { ?>
                        <li><a href="<?= base_url() ?>main/track_order">متابعة الطلب</a></li>
                    <?php } ?>

                    <li><a href="" class="customer_support" data-toggle="modal">دعم العملاء</a></li>

                    <?php if (sizeof($this->cart->contents()) == '0') { ?>
                        <li><a id="itemsss" class="no-item cart_button_proceed" style="cursor: pointer;">
                                <div class="cart"><img class="cart_img" src="<?= base_url() ?>img/cart 5.png"><span
                                        class="cartnum"><?php echo sizeof($this->cart->contents()); ?></span></div>
                            </a></li>
                    <?php } else { ?>
                        <li><a id="itemed" class="yesh cart_button_proceed" style="cursor: pointer;">
                                <div class="cart"><img class="cart_img" src="<?= base_url() ?>img/cart 5.png"><span
                                        class="cartnum"><?php echo sizeof($this->cart->contents()); ?></span></div>
                            </a></li>
                    <?php } ?>
                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <li>
                            <form action="<?= base_url() ?>main/logout" method="get">
                                <button class=" btn btn-warning">خروج</button>
                            </form>
                        </li>
                    <?php } else { ?>
                        <li>
                            <button class=" btn btn-danger dan" data-toggle="modal" data-target="#myModal">الدخول عن طريق</button>
                        </li>
                        <li>
                            <form action="<?= base_url() ?>main/register" method="get">
                                <button class=" btn btn-warning">سجل الان</button>
                            </form>
                        </li>
                    <?php } ?>
                </ul>
            </div><!-- /.navbar-collapse -->
            <div class="clearfix"></div>
        </div><!-- /.container-fluid -->
        <!--navbar-->
        <div class="banner-info" id="banner">
            <div class="container">
                <form class="form-horizontal" method="GET" action="<?= base_url() ?>main/search_result"
                      enctype="multipart/form-data">
                    <ul class="bn-in-txt">
                        <li><h2>استلم طعام لذيذ وجودة عالية</h2></li>
                        <div class="col-lg-6 col-lg-offset-3">
                            <hr style="margin-top:15px;margin-bottom:5px; ">
                            <hr style="margin-top:0px;margin-bottom:0px; ">
                        </div>
<!--                        <div class="col-lg-12 center" style="padding-top: 25px;margin-left: 10px;">-->
<!--                            <label class="toggler toggler--is-active" id="filt-css">مطعم</label>-->
<!---->
<!--                            <div class="toggle">-->
<!--                                <input type="checkbox" value="1" name="catering" id="switcher" class="check"-->
<!--                                       style="display:block;">-->
<!--                                <!--                            <input type="hidden" name="catering" value="0" />-->-->
<!--                                <b class="b switch"></b>-->
<!--                            </div>-->
<!--                            <label class="toggler" id="filt-javascript">خدمات المطاعم</label>-->
<!--                        </div>-->

                    </ul>
                    <div class="bn-in-buttons">
                        <div class="col-md-11 col-md-offset-2" style="padding-left: 0px;">
                            <div class="row">
                                <div class="col-md-4" style="padding-right: 1px;padding-left: 1px;">
                                    <div class="form-group">
                                        <select name="cuisine" data-show-icon="true"
                                                class="form-control selectpicker select_color cuisine_selected_val_area" data-live-search="true">
                                            <option value="">اختار طبقك</option>
                                            <?php foreach ($cuisine_types as $cuisinesz) { ?>
                                                <option value="<?= $cuisinesz->id; ?>"><?= $cuisinesz->name; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-4" style="padding-right: 1px;padding-left: 1px;">
                                    <div class="form-group">
                                        <select name="area" id="city_area" class="form-control selectpicker select_color city_area"
                                                data-show-subtext="true" data-live-search="true">
                                            <option value="" data-icon="glyphicon glyphicon-map-marker marker">اختار  مكانك</option>
                                            <?php if (!empty($capitals)) {
                                                foreach ($capitals as $capital) {
                                                    ?>
                                                    <optgroup label="<?php echo ucwords($capital->capital_name); ?>">
                                                        <?php if (!empty($cities)) {
                                                            foreach ($cities as $row) {
                                                                if ($row->capital_id == $capital->id) {
                                                                    ?>
                                                                    <option value="<?php echo $row->city_id; ?>"><?php echo $row->city_name; ?></option>
                                                                <?php }
                                                            }
                                                        } ?>
                                                    </optgroup>
                                                <?php }
                                            } ?>
                                        </select>
                                    </div>
                                    <span id="error1" style="color:yellow; margin-left: 30px;font-size: 16px;"></span>
                                </div>
                                <div class="col-md-2" style="    padding-right: 1px;
                                 padding-left: 1px;">
                                    <div class="form-group">
<!--                                        <input type="hidden" name="city" id="city_search_id">-->
                                        <input class="btn btn-success search_data" type="submit" role="button" value="بحث">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </form>
            </div>
        </div>
    </nav>

</div>

<div class="after" style="display: none;">
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="min-height: 120px;">
        <!-- Collect the nav links, forms, and other content for toggling -->

        <div class="col-md-12 col-lg-offset-1">
            <form class="form-horizontal" method="GET" action="<?= base_url() ?>main/search_result"
                  enctype="multipart/form-data">
                <div class="row" style="padding-top: 30px;">
                    <div class="col-lg-12" style="padding-top: 8px;">
<!--                        <div class="col-md-2 center"-->
<!--                             style="padding-right: 1px;padding-left: 1px;padding-top: 10px;padding-bottom: 10px;">-->
<!--                            <label class="toggler toggler--is-active" id="filt-css">مطعم</label>-->
<!---->
<!--                            <div class="toggle">-->
<!--                                <input type="checkbox" id="switcher" value="1"-->
<!--                                       name="catering" --><?php //if (isset($_POST['catering'])) echo "checked='checked'"; ?>
<!--                                       class="check" style="display:block;">-->
<!--                                <b class="b switch"></b>-->
<!--                            </div>-->
<!--                            <label class="toggler" id="filt-javascript">خدمات المطاعم</label>-->
<!--                        </div>-->
                        <div class="col-md-3" style="padding-right: 1px;padding-left: 1px;">
                            <div class="form-group">
                                <select name="cuisine" data-show-icon="true" id="" class="form-control selectpicker select_color cuisine_selected_val_area2"
                                        data-live-search="true">
                                    <option value="">اختار طبقك</option>
                                    <?php foreach ($cuisine_types as $cuisinesz) { ?>
                                        <option value="<?= $cuisinesz->id; ?>"><?= $cuisinesz->name; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3" style="padding-right: 1px;padding-left: 1px;">
                            <div class="form-group">
                                <select name="area" id="search_area2" class="form-control selectpicker select_color search_area2" data-show-subtext="true"
                                        data-live-search="true">
                                    <option value="" data-icon="glyphicon glyphicon-map-marker marker">اختار  مكانك</option>
                                    <?php if (!empty($capitals)) {
                                        foreach ($capitals as $capital) {
                                            ?>
                                            <optgroup label="<?php echo ucwords($capital->capital_name); ?>">
                                                <?php if (!empty($cities)) {
                                                    foreach ($cities as $row) {
                                                        if ($row->capital_id == $capital->id) {
                                                            ?>
                                                            <option value="<?php echo $row->city_id; ?>"><?php echo $row->city_name; ?></option>
                                                        <?php }
                                                    }
                                                } ?>
                                            </optgroup>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                            <span id="error2" style="color:yellow;margin-left: 30px; text-align: center; font-size: 16px;"></span>
                        </div>

                        <div class="col-md-2" style="    padding-right: 1px;
                         padding-left: 1px;">
                            <div class="form-group">
                                <input type="hidden" name="city" id="city_search_value">
                                <input class="btn btn-success search_data1" type="submit" role="button" value="بحث">
                            </div>
                        </div>

                    </div>
                </div>
            </form>
        </div>
        <div class="clearfix"></div>

    </nav>

</div>
<!--default-js-->
<script src="<?= base_url() ?>js/jquery-2.1.4.min.js"></script>
<!-- Modal -->
<?php if (!$this->ion_auth->logged_in()) { ?>
    <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <form name="" id="login" method="POST" action="<?= base_url('auth/login'); ?>" enctype="multipart/form-data"
                  class="form-horizontal">
                <!-- Modal content-->
                <div class="col-lg-8 col-lg-offset-2">
                    <div class="well">
                        <div class="con">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title" style="color:white;">تسجيل الدخول</h4>
                            </div>
                            <div class="modal-body" style="     padding: 0px; ">
                                <div class="col-lg-12" style="margin-top:20px;">
                                    <div class="form-group ">
                                        <input type="text" name="email" placeholder="البريد الإلكتروني" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group ">
                                        <input type="password" name="password" placeholder="كلمه السر" class="form-control">
                                    </div>
                                </div>
                                <div class="">

                                    <div class="col-lg-12 checkbox">
                                        <input id="remember" type="checkbox" value="1" name="remember"
                                               style="margin-right:5px">
                                        <label class="label-radio oswald-font bold font22" for="remember">تذكر كلمة المرور</label>

                                        <div class=" pull-right">
                                            <a href="<?= base_url('main/forget_password'); ?>">هل نسيت كلمة المرور؟</a>
                                        </div>
                                    </div>

                                    <div class="col-lg-12 " style="margin-bottom: 5px;">
                                        <p class="pull-right">
                                            <a class="btn btn-primary social-login-btn social-facebook" href="<?= base_url('auth/loginfacebook'); ?>"><i class="fa fa-facebook"></i></a>
                                            <!--                                                            <a class="btn btn-primary social-login-btn social-twitter" href="/auth/twitter"><i class="fa fa-twitter"></i></a>-->
                                            <a class="btn btn-primary social-login-btn social-google" href="<?php echo $login_url; ?>"><i class="fa fa-google-plus"></i></a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-simple lognow btn-block"
                                        type="submit">
                                    تسجيل الدخول الآن
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php } ?>
<div class="modal fade" id="customer_support" tabindex="-2" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog">
        <div class="col-lg-8 col-lg-offset-2" style="margin-top: 150px;">
            <div class="con">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style="color:white; text-align: center;">دعم العملاء</h4>
                </div>
                <div class="modal-body" style=" text-align: center; ">
                    <div class="col-lg-12 center">
                        <span>+956 000 456 1234<br></span>
                    </div>
                    <div class="clearfix"></div>


                </div>
                <div class="modal-footer">
                    <button class="btn btn-simple lognow btn-block"
                            type="submit" data-dismiss="modal">
                        Ok
                    </button>
                </div>
            </div>
        </div>

    </div>
</div>

<div id="promotions" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="col-lg-12">
            <div class="con">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                    <ul class="tabs">
                        <li class="tab-link modal-title current" data-tab="tab-1"><h4 style="color:white;">خصم</h4></li>
                        <li class="tab-link modal-title" data-tab="tab-2"><h4 style="color:white;">قسيمة</h4></li>
                    </ul>
                </div>
                <div class="modal-body" style="     padding: 0px; ">

                    <div id="tab-1" class="tab-content current">
                        <div class="row" style="margin-top: 30px;">
                            <div class='list-group gallery'>
                                <?php $i = 1;
                                foreach ($discount_restaurants as $row) { ?>

                                    <div class='col-sm-3 col-xs-6 col-md-3 col-lg-3' style="margin-top: 10px;">
                                        <a href="<?= base_url() ?>restaurant/<?= $row->slug ?>" class="cart "><img class="pro_img" src="<?= $row->logo_url ?>"><span
                                                class="pronum"><?php echo $i; ?></span></a>

                                    </div> <!-- col-6 / end -->

                                    <?php $i++;
                                } ?>
                            </div> <!-- list-group / end -->
                        </div> <!-- row / end -->
                    </div>
                    <div id="tab-2" class="tab-content">
                        <div class="row" style="margin-top: 30px;">
                            <div class='list-group gallery'>
                                <?php $i = 1;
                                foreach ($voucher_restaurants as $row) { ?>

                                    <div class='col-sm-3 col-xs-6 col-md-3 col-lg-3' style="margin-top: 10px;">
                                        <a href="<?= base_url() ?>restaurant/<?= $row->slug ?>" class="cart "><img class="pro_img" src="<?= $row->logo_url ?>"><span
                                                class="pronum"><?php echo $i; ?></span></a>

                                    </div> <!-- col-6 / end -->

                                    <?php $i++;
                                } ?>
                            </div> <!-- list-group / end -->
                        </div> <!-- row / end -->
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="modal fade" id="your_credit" tabindex="-2" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog">
        <div class="col-lg-8 col-lg-offset-2" style="margin-top: 150px;">
            <div class="con">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style="color:white;">Credits</h4>
                </div>
                <div class="modal-body" style=" text-align: center; ">
                    <div class="media" style="margin-bottom: 20px;margin-top: 10px;">
                        <a class="" href="#"> <img src="<?= base_url() ?>img/Moneybag.png" style="width: 30px; height: 30px;"> </a>

                        <div class="media-body" style="padding-top: 7px;">
                            <h4>Credit in bag: <?php if (!empty($user_points)) {
                                    echo $user_points;
                                } ?> KD</h4>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-simple lognow btn-block"
                            type="submit" data-dismiss="modal">
                        Ok
                    </button>
                </div>
            </div>
        </div>

    </div>
</div>


<script>
    $(window).scroll(function () {
        if ($(document).scrollTop() > 538) {
            $('.after').show();


        } else {
            $('.before').show('slow');
            $('.after').hide();
        }
    });
</script>
<script>
    $('ul.tabs li').click(function () {
        var tab_id = $(this).attr('data-tab');

        $('ul.tabs li').removeClass('current');
        $('.tab-content').removeClass('current');

        $(this).addClass('current');
        $("#" + tab_id).addClass('current');
    });
</script>

<script>

    $(".search_data").click(function () {

        if ($("#city_area").val() == "") {
            $('#error1').empty();
            document.getElementById("error1").innerHTML = "الرجاء اختيار المنطقة";
            $('#error1').show();
            $('#error1').fadeOut(2000);
            return false;
        } else {
            var city_pick_id = $("#city_area").val();
            document.getElementById("city_search_id").value = city_pick_id;
        }
    });

    $(".search_data1").click(function () {
        if ($("#search_area2").val() == "") {
            $('#error2').empty();
            document.getElementById("error2").innerHTML = "الرجاء اختيار المنطقة";
            $('#error2').show();
            $('#error2').fadeOut(2000);
            return false;
        } else {
            var city_pick_id = $("#search_area2").val();
            document.getElementById("city_search_value").value = city_pick_id;
        }
    });

    $(document).on('click', '.search_area2', function (e) {
        $(".city_area").val($('.search_area2').val()).change();
    });
    $(document).on('click', '.city_area', function (e) {
        $(".search_area2").val($('.city_area').val()).change();

    });

    $(document).on('click', '.cuisine_selected_val_area', function (e) {
        $(".cuisine_selected_val_area2").val($('.cuisine_selected_val_area').val()).change();
    });
    $(document).on('click', '.cuisine_selected_val_area2', function (e) {
        $(".cuisine_selected_val_area").val($('.cuisine_selected_val_area2').val()).change();
    });


</script>