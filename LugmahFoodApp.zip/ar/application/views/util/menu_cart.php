<?php if (!empty($content)) {
    foreach ($content as $restaurant_items) { ?>
        <div>
            <h4 style="background-color:#b81100;color:white;padding-top: 16px;padding-bottom: 16px;padding-left: 5px;padding-right: 5px;"><?php echo $restaurant_items->name; ?><br/>
                <span class="roborto "
                      style="font-size: 10px;float: right;padding-top: 5px;">
                                متوسط ​​تسليم: <?php echo $restaurant_items->delivery_time ?> دقيقة
                            </span>
                </h4>
        </div>
        <div>
            <?php foreach ($restaurant_items->c_items as $items) { ?>
                <div class="order-item border-bottom border-top pt15">
                    <div class="roborto">
                        <span class="order-item-qty" id='<?php echo $items['rowid']; ?>' value='<?php echo $items['qty']; ?>'><?php echo $items['qty']; ?></span>

                        <div class="col-lg-8 pull-right" style="padding-right: 0px;">
                            <div class="row">
                                <span class="font12 bold pull-right"><?php echo $items['name']; ?> </span><br>
                            </div>
                        </div>
                        <div class="col-lg-8 pull-right" style="padding-right: 0px;">
                            <div class="row">
                                <span class="font12 bold pull-right"><?php echo $items['attributes_name']; ?></span>
                            </div>
                        </div>
                    </div>
                    <br/>

                    <div class="clearfix"></div>

                    <div class="btn-group btn-group-sm">
                        <a class="btn btn-default order-qty-btn sub-qty"
                           value='<?php echo $items['rowid']; ?>'>-</a>
                        <a class="btn btn-default order-qty-btn add-qty"
                           value='<?php echo $items['rowid']; ?>'>+</a>
                    </div>
                                        <span
                                            class="roborto bold font16 pull-right">د.ك <?php echo number_format($items['subtotal'],3); ?></span>
                </div>
            <?php } ?>
        </div>
        <div>
            <span class="color-yellow bold font12">رسوم التوصيل</span>
                        <span class="color-yellow bold font12 pull-right"
                              value="<?php echo $restaurant_items->delivery_charges ?>"><?php echo number_format($restaurant_items->delivery_charges,3) ?></span>
        </div>
        <?php if ($restaurant_items->discount_type == 'flat') { ?>
            <div>
                <span class="color-yellow bold font12">خصم شقة</span>
                        <span class="color-yellow bold font12 pull-right"
                              value="<?php echo $restaurant_items->delivery_charges ?>"><?php echo (float)$restaurant_items->discount ?>
                            %</span>
            </div>
        <?php } else if ($restaurant_items->discount_type == 'voucher_used') { ?>
            <div>
                <span class="color-yellow bold font12">خصم القسيمة</span>
                        <span class="color-yellow bold font12 pull-right"
                              value="<?php echo $restaurant_items->delivery_charges ?>"><?php echo (float)$restaurant_items->discount ?>
                            %</span>
            </div>
        <?php } ?>
        <div>
            <span class="color-grey bold font12">مطعم إجمالي</span>
                        <span class="color-grey bold font12 pull-right"
                              id="cart_sub_total"><?php echo number_format($restaurant_items->rest_total,3); ?></span>
        </div>

    <?php }
} ?>