<div class="checkout_main_outer">
    <?php
    if (!empty($restaurant)) {
        foreach ($restaurant as $rest_data) {
            ?>
            <div class="checkout-main" style="margin-top: 20px">
                <img class="checkout-img" src="<?= $rest_data->logo_url ?>"/>

                <p class="checkout-title raleway-font">
                    <a href="<?= base_url() ?>restaurant/<?= $rest_data->slug; ?>"><span
                            class="color-yellow font16 bold"><?= $rest_data->name ?></span></a><br/>
                    <span class="color-grey font13">مفتوحة من 11:00 - 23:00</span>
                </p>
                <span class="font13 pull-right" style="margin-right: 20px;">متوسط ​​تسليم: <?= $rest_data->delivery_time ?> دقيقة</span>


            </div>
            <div class="checkout-item">
                <table class="checkout-table checkout_items">

                    <?php if(isset($rest_data->c_items)){ foreach ($rest_data->c_items as $items) { ?>

                        <tr class='check-out-items' style="border: none;">
                            <td width="50%">
                                                            <span
                                                                class="color-black oswald-font bold" style="margin-left: 10px;"><?php echo $items['name']; ?>
                                                                <?php if(isset($items['options_name'])&& !empty($items['options_name'])){
                                                                    echo '('.$items['options_name'].')';
                                                                } ?></span>
                            </td>
                            <td width="25%" class=" txt-right">
                                <label class="checkout-label">كمية. <?= $items['item_quantity'] ?></label>
                            </td>
                            <td class="txt-right" width="25%">
                                                            <span class="color-yellow bold font16 pr20">
                                                                د.ك <?= number_format(($items['price']+$items['options_price'])*$items['item_quantity'],3); ?>
                                                            </span>
                            </td>

                        </tr>

                    <?php }} ?>

                    <tr style="line-height: 0.429 !important; margin-top: 25px;">
                        <?php if($rest_data->discount>0){?>
                        <td></td>

                        <td class="txt-right">
                                                        <span class="color-grey bold font14">
                                                            خصم
                                                        </span>
                        </td>
                        <td class="txt-right">
                                                        <span class="color-black bold font14 pr20 sub-total">
                                                            <?= (float)$rest_data->discount; ?> %
                                                        </span>
                        </td>
                        <?php }?>
                    </tr>
                    <tr style="background-color: #f2f2f2;border: none; line-height: 0.429 !important; margin-top: 25px;">
                        <td></td>

                        <td class="txt-right">
                                                        <span class="color-yellow bold font16">
                                                            مطعم توتال
                                                        </span>
                        </td>
                        <td class="txt-right">
                                                        <span class="color-yellow bold font16 pr20 sub-total">
                                                            د.ك <?= number_format($rest_data->subtotal,3); ?>
                                                        </span>
                        </td>
                    </tr>
                </table>

            </div>
            <?php
        }
    }
    ?>
</div>