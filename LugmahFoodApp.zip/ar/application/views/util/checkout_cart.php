<div class="checkout_main_outer">

    <?php

    if (!empty($restaurant)) {

        foreach ($restaurant as $rest_data) {

            ?>

            <div class="checkout-main" style="margin-top: 10px">

                <img class="checkout-img" src="<?= $rest_data->logo_url ?>"/>



                <p class="checkout-title raleway-font">

                                                <a href="<?= base_url() ?>restaurant/<?= $rest_data->slug; ?>"><span

                                                    class="color-yellow font16 bold"><?= $rest_data->name ?></span></a><br/>

                    <span class="color-grey font13">مفتوحة من 11:00 - 23:00</span>

                </p>

                <span class="font13 pull-leftar" style="margin-right: 20px;">متوسط ​​تسليم: <?= $rest_data->delivery_time ?> دقيقة</span>





            </div>

            <div class="checkout-item">

                <table class="checkout-table checkout_items">



                    <?php if(isset($rest_data->c_items)){ foreach ($rest_data->c_items as $items) { ?>



                        <tr class='check-out-items'>

                            

                            

                            

                            <td class="txt-right" width="25%">

                                                            <span class="color-yellow bold font16 pr20">

                                                                ‎د.ك <?php echo number_format($items['subtotal'],3); ?>

                                                            </span>

                            </td>



       <td class="txt-right" width="25%">

                                <label class="checkout-label">كمية. <?= $items['qty'] ?></label>

                            </td>  <td width="45%">

                                                            <span

                                                                class="color-black oswald-font bold"><?php echo $items['name']; ?>

                                                                <?php if(isset($items['attributes_name'])&& !empty($items['attributes_name'])){

                                                                echo '('.$items['attributes_name'].')';

                                                                } ?></span>

                            </td>    <td width="5%"><input type="hidden" value="<?php echo $items['id']; ?>"

                                       name="item_id[]">

                                <a class="btn btn-sm btn-remove"

                                   value='<?php echo $items['rowid']; ?>'>X</a>

                            </td>           </tr>



                    <?php }} ?>



                    <tr style="border: none;">

                        

                        

                        <td class="txt-right" style="padding: 5px 20px;"><span

                                class="color-black"><?= number_format($rest_data->restaurant_total,3); ?></span>

                        </td>
                        <td class="txt-right" style="padding: 5px 0; "><span

                                class="color-black">حاصل الجمع</span>

                        </td>
                        <td></td>

                        <td></td>

                    </tr>

                    <tr style="border: none;">

                        

                        

                        <td class="txt-right" style="padding: 5px 20px;"><span

                                class="color-black"

                                id="delivery_cost"><?= number_format($rest_data->delivery_charges,3); ?></span>

                        </td>
                        <td class="txt-right" style="padding: 5px 0;"><span

                                class="color-black">خدمه توصيل</span></td>
                                <td></td>

                        <td></td>

                    </tr>

                    <?php if($rest_data->discount_type == 'flat'){?>

                        <tr style="border: none;">

                            

                            

                            <td class="txt-right" style="padding: 5px 20px;"><span

                                    class="color-black"

                                    id="delivery_cost"><?= $rest_data->discount; ?>%</span></td>
						<td class="txt-right" style="padding: 5px 0;"><span

                                    class="color-black">خصم شقة</span></td>
                                    <td></td>

                            <td></td>


                        </tr>

                    <?php } else if($rest_data->discount_type == 'voucher_used'){?>

                        <tr style="border: none;">

                           

                            

                            <td class="txt-right" style="padding: 5px 20px;"><span

                                    class="color-black"><?= $rest_data->discount; ?>%</span></td>
<td class="txt-right" style="padding: 5px 0;"><span

                                    class="color-black">خصم القسيمة</span></td>

 <td></td>

                            <td></td>
                        </tr>

                    <?php } else if($rest_data->discount_type == 'voucher'){?>

                        <tr style="border: none;">

                           



                            

                            

                            <td class="txt-right" style="    width: 100px;" >

                                <button type="button" class="btn btn-simple voucher_btn" data="<?=$rest_data->id?>" value="<?=$rest_data->id.'_voucher' ?>">تطبيق</button>

                            </td>


 <td colspan="2">    <input id="<?=$rest_data->id.'_voucher' ?>" type="text"  placeholder="" class="form-control  inputvoucher"> <small><strong>كود القسيمة</strong></small></td>
                        </tr>

                    <?php } ?>

                    <tr style="background-color: #f2f2f2;border: none; line-height: 0.429 !important;">

                       



                        

                        <td class="txt-right">

                                                        <span class="color-yellow bold font16 pr20 sub-total">

                                                            ‎د.ك <?php echo number_format($rest_data->rest_total,3); ?>

                                                        </span>

                        </td>
                        <td colspan="" class="txt-right col-lg-2">

                                                        <span class="color-yellow bold font16">

                                                            مطعم توتال

                                                        </span>

                        </td>
                         <td></td>

                        <td></td>

                    </tr>

                </table>



            </div>

            <?php

        }

    }

    ?>

</div>