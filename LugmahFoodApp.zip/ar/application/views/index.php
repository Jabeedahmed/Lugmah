<?php
$folder_name = $folder_name;
$page_name = $file_name;
?>
<!DOCTYPE html>
<html lang="en">
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<?php include 'top.php';
if (!empty($header_banner->banner_url)){
    $header_file = $header_banner->banner_url;
    ?>

    <style>
        .navbar-default {
            background:linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(<?=$header_file; ?>) center !important;
            background-size: cover;
            border-bottom: 3px solid #FFC001;
            min-height: 80px;
        }
    </style>
<?php }else{ ?>
<style>
    .navbar-default {
        background:linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(<?=base_url() ?>images/b2.jpg);
        background-size: cover;
        border-bottom: 3px solid #FFC001;
        min-height: 80px;
    }
</style>
<?php } ?>
<body>
<div class="whole_div"
     style="width:100%;height:100%;display: none;position: fixed;z-index: 99999; background:url(<?= base_url() ?>img/loading.gif) no-repeat center center;"></div>
<?php include $header_name . '.php'; ?>
<?php include $folder_name . '/' . $page_name . '.php'; ?>
<div class="footer">
    <div class="container">
        <div class="div1 col-md-12">
            <div class="col-md-5 head">
                <h3>طريقة الدفع</h3>
                <ul class="customer">
                    <?php  if(!empty($payment_method_db)){
                        foreach($payment_method_db as $payment_method){
                    ?>
                    <a style="cursor: pointer;"> <img style="height: 40px;width: 70px;float: left;" class="img-responsive"
                                      src="<?=$payment_method->image_url; ?>"></a>
                    <?php }}?>

                </ul>
            </div>
            <div class="col-md-4 head">
                <h3>اتصل بنا</h3>
                <ul class="contents">
                    <p style="color:white" href="products.html">مؤامرة لا 447-44B عامة
                         الوقوف رافي وصلة الطريق الكويت</p>
                </ul>
            </div>
            <div class="col-md-3 mail_soc">
                <div class="form_data">
                    <h3>كن على اتصال بنا</h3>
                </div>
                <ul class="social-network social-circle">
                    <li><a href="<?=$settings->fb_link ?>" target="_blank" title="Facebook"><img class="img-responsive"
                                                          src="<?= base_url() ?>img/facebook-256.png"></a></li>
                    <li><a href="<?=$settings->twitter_link ?>" target="_blank" title="Twitter"><img class=" img-responsive"
                                                         src="<?= base_url() ?>img/twitter-256.png"></a></li>
                    <li><a href="<?=$settings->insta_link ?>" target="_blank" title="Instagram"><img class=" img-responsive "
                                                           src="<?= base_url() ?>img/instagram-256.png"></a></li>
                    <li><a href="<?=$settings->youtube_link ?>" target="_blank" title="Youtube"><img class=" img-responsive "
                                                         src="<?= base_url() ?>img/youtube-256.png"></a></li>
                </ul>

            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <a href="#home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover"
                                                                             style="opacity: 1;"> </span></a>
</div>
<div class="div2">
    <ul class="social-network">
        <li><a href="<?= base_url() ?>main/about_us">حول الموقع</a></li>
        <li><a href="<?= base_url() ?>main/feedback">ردود الفعل</a></li>
        <li><a href="<?= base_url() ?>main/faq">قاموس</a></li>
        <li><a href="<?= base_url() ?>main/privacy_policy">الخصوصية</a></li>
<!--        <li><a href="--><?//= base_url() ?><!--main/contact_us">Contact Us</a></li>-->
    </ul>
    <p>لشروط الاستخدام برجاء قراءة سياسة الخصوصية @2015</p>
</div>
</body>
</html>
<?php include 'bottom.php'; ?>

<script>
    $(document).on('click', '.cart_button_proceed', function (e) {
        $url = '<?= base_url() ?>main/check_minimum_order';
        $.ajax({
            url: $url,
            type: "POST",
            success: function (data){
                if(data != null){
                    var rest = jQuery.parseJSON(data);
                    if(rest.proceed_result == 1){
                        toastr.error('النظام الخاص بك هو أقل من الحد الأدنى للطلب في '+ rest.name );
                    }else if(rest.proceed_result == 2){
                        toastr.error('أي بند في سلة التسوق');
                    }else if(rest.proceed_result == 0){
                        var url =  '<?= base_url() ?>main/checkout';
                        window.location.href = url;
                    }
                }
            }
        });
    });

</script>