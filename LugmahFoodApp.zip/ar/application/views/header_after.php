<style>
    .navbar-default .navbar-nav > li > a {
        color: white !important;
        font-size: 17px !important;
    }
    .dropdown-submenu {
        position: relative;
    }

    .dropdown-submenu>.dropdown-menu {
        top: 0;
        left: 100%;
        margin-top: -6px;
        margin-left: -1px;
        -webkit-border-radius: 0 6px 6px 6px;
        -moz-border-radius: 0 6px 6px;
        border-radius: 0 6px 6px 6px;
    }

    .dropdown-submenu:hover>.dropdown-menu {
        display: block;
    }

    .dropdown-submenu>a:after {
        display: block;
        content: " ";
        float: right;
        width: 0;
        height: 0;
        border-color: transparent;
        border-style: solid;
        border-width: 5px 0 5px 5px;
        border-left-color: #ccc;
        margin-top: 5px;
        margin-right: -10px;
    }

    .dropdown-submenu:hover>a:after {
        border-left-color: #fff;
    }

    .dropdown-submenu.pull-left {
        float: none;
    }

    .dropdown-submenu.pull-left>.dropdown-menu {
        left: -100%;
        margin-left: 10px;
        -webkit-border-radius: 6px 0 6px 6px;
        -moz-border-radius: 6px 0 6px 6px;
        border-radius: 6px 0 6px 6px;
    }
    }</style>

<div class="" id="home" style=" margin-bottom: 100px;">
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand img-responsive" style="height: auto;padding-bottom: 13px" href="<?= base_url() ?>"><img src="<?= base_url() ?>img/lugmahlogo.png" style="height: 60px;"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="margin-top: 20px;">
                <ul class="nav navbar-nav navbar-right torq-menu">
                    <?php if ($this->ion_auth->logged_in()) { ?>
                    <li><a href="<?= base_url() ?>main/my_account">حسابي</a></li>
                   <?php } ?>

                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <ul class="nav navbar-nav">
                            <li>
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">متابعة الطلب<span class="caret "></span></a>
                                <ul class="dropdown-menu multi-level">
                                    <li><a href="<?= base_url() ?>main/track_order"><strong>متابعة الطلب</strong> </a></li>
                                    <li class="dropdown-submenu">
                                        <a href="#" tabindex="-1"><strong>الإنشقاقات النشطة</strong></a>
                                        <ul class="dropdown-menu" style="width:250px; margin-top: 1px;">
                                            <?php
                                            if(!empty($split_payments)){
                                            foreach($split_payments as $split_row){ ?>
                                                <li ><a href="<?=base_url() ?>main/split_payment_status?split_transaction_id=<?= urlencode($split_row->split_trans_id); ?>"><strong><?=ucfirst($split_row->name).'  '.$split_row->start_time; ?></strong></a></li>
                                            <?php } }else{ ?>
                                                <li><a><strong>لا سبليت النشط متاح</strong></a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    <?php }else{ ?>
                        <li><a href="<?= base_url() ?>main/track_order">متابعة الطلب</a></li>
                    <?php } ?>
                    <li><a href="" class="customer_support" data-toggle="modal">دعم العملاء</a></li>
                    <?php if(sizeof($this->cart->contents()) == '0') { ?>
                        <li><a id="itemsss"  class="no-item cart_button_proceed" style="cursor: pointer;">
                                <div class="cart "><img class="cart_img" src="<?= base_url() ?>img/cart 5.png"><span
                                        class="cartnum"><?php echo sizeof($this->cart->contents()); ?></span></div>
                            </a></li>
                    <?php } else { ?>
                        <li><a id="itemed" class="yesh cart_button_proceed" style="cursor: pointer;" >
                                <div class="cart"><img class="cart_img" src="<?= base_url() ?>img/cart 5.png"><span
                                        class="cartnum"><?php echo sizeof($this->cart->contents()); ?></span></div>
                            </a></li>
                    <?php } ?>



                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <li><form action="<?= base_url() ?>main/logout" method="get"><button class=" btn btn-warning" >خروج</button></form></li>
                    <?php } else { ?>
                        <li><button class="btn btn-danger dan" data-toggle="modal" data-target="#myModal">الدخول عن طريق</button></li>
                        <li> <form action="<?= base_url() ?>main/register" method="get"><button class=" btn btn-warning" >سجل الان</button></form>
                    <?php } ?>
                </ul>
            </div><!-- /.navbar-collapse -->
            <div class="clearfix"></div>
        </div><!-- /.container-fluid -->

    </nav>

</div>
<!--head-top-->
<!--default-js-->
<script src="<?= base_url() ?>js/jquery-2.1.4.min.js"></script>

<!-- Modal -->
<?php if (!$this->ion_auth->logged_in()) {?>
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <form name="" id="login" method="POST" action="<?= base_url('auth/login'); ?>" enctype="multipart/form-data" class="form-horizontal">
            <!-- Modal content-->
            <div class="col-lg-8 col-lg-offset-2">
                <div class="well">
                    <div class="con" >
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title" style="color:white;">الدخول عن طريق</h4>
                        </div>
                        <div class="modal-body" style="     padding: 0px; ">
                            <div class="col-lg-12" style="margin-top:20px;">
                                <div class="form-group ">
                                    <input type="text" name="email" placeholder="Email" class="form-control">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group ">
                                    <input type="password" name="password" placeholder="Password" class="form-control">
                                </div>
                            </div>
                            <div class="">

                                <div class="col-lg-12 checkbox">
                                    <input id="remember" type="checkbox" value="1" name="remember"
                                           style="margin-right:5px">
                                    <label class="label-radio oswald-font bold font22" for="remember">تذكر كلمة المرور</label>
                                    <div class=" pull-right">
                                        <a href="<?= base_url('main/forget_password'); ?>">هل نسيت كلمة المرور؟</a>
                                    </div>
                                </div>

                                <div class="col-lg-12 " style="margin-bottom: 5px;">
                                    <p class="pull-right">
                                        <a class="btn btn-primary social-login-btn social-facebook" href="<?= base_url('auth/loginfacebook'); ?>"><i class="fa fa-facebook"></i></a>
                                        <!--                                                            <a class="btn btn-primary social-login-btn social-twitter" href="/auth/twitter"><i class="fa fa-twitter"></i></a>-->
                                        <a class="btn btn-primary social-login-btn social-google" href="<?php echo $login_url;?>"><i class="fa fa-google-plus"></i></a>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-simple lognow btn-block" type="submit">
                                الدخول عن طريق
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php }?>

<div class="modal fade" id="customer_support" tabindex="-2" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog">
        <div class="col-lg-8 col-lg-offset-2" style="margin-top: 150px;">
            <div class="con" >
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style="color:white;  text-align: center;">دعم العملاء</h4>
                </div>
                <div class="modal-body" style=" text-align: center; ">
                        <div class="col-lg-12 center">
                            <span>+956 000 456 1234<br></span>
                        </div>
                        <div class="clearfix"></div>


                </div>
                <div class="modal-footer">
                    <button class="btn btn-simple lognow btn-block"
                            type="submit"  data-dismiss="modal">
                        Ok
                    </button>
                </div>
            </div>
        </div>

    </div>
</div>
