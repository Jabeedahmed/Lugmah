<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <form  method="post" action="#" name="r_add_feedback" id="r_add_feedback"  >
                    <div id="pg-content" class="row">
                    <div class="col-lg-12">
                        <div class="image" >
                            <img class="responsive" src="<?= base_url() ?>img/registerBack.png">
                            <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png" style="width: 50px; height: 50px;"> </a>
                                <div class="media-body">
                                    <h4><b>إعطاء ردود الفعل</b></h4>
                                    <p style="font-style: italic;">ساعد الاخرين! إرسال استعراضنا</p>
                                </div>
                            </div>
                        </div>
                    </div>
                        <?php  if (!($this->ion_auth->logged_in())) { ?>
                            <div class="col-lg-6" style="margin-top:40px;">
                                <div class="clearfix"></div>
                                <div class="well">
                                    <div class="media">
                                        <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png" style="width: 30px; height: 30px;"> </a>
                                        <div class="media-body">
                                            <h4 style="margin-bottom:10px;"><b>اسم</b></h4>
                                            <input type="text" class="form-control" name="name" id="name" >
                                            <p style="font-style: italic; margin-top: 10px;"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <div class="col-lg-6" style="margin-top:40px;">
                            <div class="clearfix"></div>
                            <div class="well">
                                <div class="media">
                                    <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png" style="width: 30px; height: 30px;"> </a>
                                    <div class="media-body">
                                        <h4 style="margin-bottom:10px;"><b>البريد الإلكتروني</b></h4>
                                        <input type="email" class="form-control" name="email"  >
                                        <p style="font-style: italic; margin-top: 10px;"></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php } ?>

                    <div class="col-lg-9" style="margin-top:40px;">
                        <div class="clearfix"></div>
                        <div class="well">
                            <div class="media">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png" style="width: 30px; height: 30px;"> </a>
                                <div class="media-body">
                                    <h4 style="margin-bottom:10px;"><b>عنوان المراجعة</b></h4>
                                    <input type="text" class="form-control" name="subject" id="subject" >
                                    <p style="font-style: italic; margin-top: 10px;">( 60 حرف كحد أقصى)</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="clearfix"></div>
                        <div class="well">
                            <div class="media">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png" style="width: 30px; height: 30px;"> </a>
                                <div class="media-body">
                                    <h4 style="margin-bottom:10px;"><b>مراجعتك:</b></h4>
                                    <textarea type="text" rows="8" class="form-control" name="detail"  ></textarea>
                                    <p style="font-style: italic; margin-top: 10px;">(الرجاء التأكد من رأيك يحتوي على 100 حرفا على الأقل)</p>
                                </div>
                            </div>  
                        </div>
                    </div>

                    <div class="col-lg-4" align="right">
                        <input type="submit" class="btn btn-contact " value="ارسال" name="add_feedback">
                        </div>
                    <hr/>

                </div>
                </form>
            </div>
              <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top: 50px;">
                <hr>
                <div id="owl-demo1" class="owl-carousel text-center">
                    <?php
                    if (isset($banners)) {
                        foreach ($banners as $ban) {
                            ?>
                            <div class="item">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                    <a href="<?= base_url() . 'restaurant/' . $ban->link_url ?>">
                                        <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;"
                                             alt="" class="responsive"></a>
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                    }
                    ?>
                </div>

            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $("#name").keypress(function(event){
            var inputValue = event.charCode;
            if((inputValue > 47 && inputValue < 58) && (inputValue != 32)){
                event.preventDefault();
            }
        });
        $("#subject").keypress(function(event){
            var inputValue = event.charCode;
            if((inputValue > 47 && inputValue < 58) && (inputValue != 32)){
                event.preventDefault();
            }
        });
    });
</script>













