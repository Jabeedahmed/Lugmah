<?php
$post_cuisine = isset($selected_cuisine) ? $selected_cuisine : '';
$post_area = isset($selected_area->city_id) ? $selected_area->city_id : null;
?>
<script>
    var post_array =
    {
        "cuisine": '<?=$post_cuisine?>',
        "area": '<?=$post_area?>',
        "catering": localStorage.input === 'true' ? 1 : null,
        "page_number": 0
    };
</script>
<link rel="stylesheet" href="<?= base_url() ?>css/header_search.css"/>
<style>
    .media-heading a {
        color: #848486;
    }

    .table > tbody > tr > td, .table > tbody > tr > th, .table > tfoot > tr > td, .table > tfoot > tr > th, .table > thead > tr > td, .table > thead > tr > th {

        vertical-align: inherit !important;
    }

    .table > tbody > tr > td, .table > tfoot > tr > td {
        vertical-align: middle;
    }

    .grey {
        cursor: pointer;
        color: grey;
    }

    .yellow {
        cursor: pointer;
        color: #FFC000;
    }

    .add_fvrt:hover {
        color: #FFC000 !important;
    }
</style>

<div class="whole_div"
     style="width:100%;height:100%;display: none;position: fixed;z-index: 99999; background:url(<?= base_url() ?>img/loading.gif) no-repeat center center;"></div>
<div class="content" style="margin-top:120px;">
    <div class="container">
        <div class="row" style="margin-top:40px;">
            <div class="col-md-3">
                <ul class="nav nav-pills nav-stacked" style="border: 1px solid #E1E1E1;padding: 5px;">
                    <li class="active show"><a href="#">الترشيحات</a></li>
                    <div class="slidingDiv">
                        <label class="sort">:تصنيف عن طريق</label>

                        <div class="form-group">
                            <select name="sort_by" data-show-icon="true" id="sort_by_what" class="form-control ">
                                <option value="name_asce">اسم المطعم تصاعدي</option>
                                <option value="name_desc">اسم المطعم الهابطة</option>
                                <option value="rating_asce">تصنيف تصاعدي</option>
                                <option value="rating_desc">تصنيف تنازلي</option>
                                <option value="price_asce"> سعر تصاعدي</option>
                                <option value="price_desc">سعر تنازلي</option>
                            </select>

                        </div>
                    </div>
                    <li class="active show" style="margin-top: 2px;"><a href="#">على حسب الخصائص</a></li>
                    <div class="slidingDiv">
                        <form>
                            <li>
                                <div class="form-group checkbox">
                                    <input type="checkbox" name="discount_avail" id="discount_avail">
                                    <label class="label-radio oswald-font bold font22" for="discount_avail">خصم متاح</label>
                                </div>
                            </li>
                            <li>
                                <div class="form-group checkbox">
                                    <input id="free_delivery" type="checkbox" name="free_delivery" value="6">
                                    <label class="label-radio oswald-font bold font22" for="free_delivery">توصيل مجانا</label>
                                </div>
                            </li>
                            <li>
                                <div class="form-group checkbox">
                                    <input id="has_promotions" type="checkbox" name="has_promotions" value="9">
                                    <label class="label-radio oswald-font bold font22" for="has_promotions">الحملات الترويجية</label>
                                </div>
                            </li>
                            <li>
                                <div class="form-group checkbox">
                                    <input id="cod_avail" type="checkbox" name="cod_avail" value="9">
                                    <label class="label-radio oswald-font bold font22" for="cod_avail">نقدا عند التسليم متاح</label>
                                </div>
                            </li>
                            <li>
                                <div class="form-group checkbox">
                                    <input id="split_avail" type="checkbox" name="split_avail" value="9">
                                    <label class="label-radio oswald-font bold font22" for="split_avail">دفع الانقسام متاح</label>
                                </div>
                            </li>
                            <li>
                                <div class="form-group checkbox">
                                    <input id="openrest" type="checkbox" name="openrest" value="9">
                                    <label class="label-radio oswald-font bold font22" for="openrest">المطاعم المفتوحة</label>
                                </div>
                            </li>
                            <li><a class="my-button" style="cursor:pointer;">واضح</a></li>
                        </form>
                    </div>
                    <li class="active show" style="margin-top: 2px;"><a href="#">على حسب التصنيف</a></li>
                    <div class="slidingDiv">
                        <form>
                            <li>
                                <span class="star-group rating">
                                    <input type="radio" id="star5" name="rating" value="5"/><label for="star5"
                                                                                                   title="Rocks!">5
                                        stars</label>
                                    <input type="radio" id="star4" name="rating" value="4"/><label for="star4"
                                                                                                   title="Pretty good">4
                                        stars</label>
                                    <input type="radio" id="star3" name="rating" value="3"/><label for="star3"
                                                                                                   title="Meh">3
                                        stars</label>
                                    <input type="radio" id="star2" name="rating" value="2"/><label for="star2"
                                                                                                   title="Kinda bad">2
                                        stars</label>
                                    <input type="radio" id="star1" name="rating" value="1"/><label for="star1"
                                                                                                   title="Sucks big time">1
                                        star</label>
                                </span>
                            </li>
                            <br>
                            <li><a class="clear star clearfix">واضح</a></li>
                        </form>
                    </div>
                    <li class="active show" style="margin-top: 2px;"><a href="#">على حسب السعر</a></li>
                    <div class="slidingDiv">
                        <li class="margin">
                            <label class="col-lg-12 center">السعر</label>

                            <div class="clearfix"></div>
                            <div id="slider-range"></div>
                            <p>
                                <input type="text" id="amount" readonly style="border:0;padding-left: 75px;">
                            </p>
                        </li>
                    </div>
                    <a class="btn btn-simple btn-block do_search">تقديم طلب</a>

                    <div class="clearfix" style="margin-bottom: 10px;"></div>
                </ul>
            </div>
            <div class="col-sm-9 col-md-9 ">
                <div class="count_area">
                    <?php if ($total_record) { ?>
                        <div class="col-lg-12" style="margin-bottom: 10px;">
                            <div class="col-sm-8 col-md-8 col-lg-8 no-padding margin-bottom">
                                <h4 id="res_status" class="orderfrom">أمر من <?= $total_record ?> المطاعم <?php if (!empty($selected_area)) {
                                        echo 'في ' . $selected_area->city_name;
                                    } ?> &nbsp;&nbsp;&nbsp;</h4>
                            </div>
                            <div class="col-sm-4 pull-right searchproducts">
                                <div class=" col-sm-10 ">
                                    <input style="height: 35px;" name="search_restaurant_name" id="search_input" type="text" class="form-control input-sm" placeholder="بحث"/>
                                </div>
                                <div class="col-sm-2  no-padding ">
                                    <button type="button" id="search_by_name" class="  btn btn-simple ">بحث</button>
                                </div>
                            </div>
                        </div>
                    <?php } else { ?>
                        <div class="col-lg-12">
                            <div class="col-sm-8 col-md-8 margin-bottom restutantheading">
                                <h4>لا توجد في مطعم <?php if (!empty($selected_area)) {
                                        echo $selected_area->city_name;
                                    } ?> &nbsp;&nbsp;&nbsp;</h4>
                            </div>
                            <div class="col-sm-4 pull-right ">
                               <div class="col-sm-2  no-padding ">
                                    <button type="button" class="searchbuttoncat btn btn-simple search_name_from_db">بحث</button>
                                </div> <div class=" col-sm-10 ">
                                    <input style="height: 35px;" name="search_restaurant_name" id="search-input" type="text" class="form-control input-sm" placeholder="بحث"/>
                                </div>
                                
                            </div>
                        </div>
                    <?php } ?>
                </div>
                <table id="cart" class="table table-hover table-condensed" style="border:1px solid #DFDFDF;">
                    <tbody id="search-content">
                    <?php if (isset($search_view)) {
                        print_r($search_view);
                    } ?>
                    </tbody>
                </table>
                <div class="col-sm-offset-4 col-sm-4 col-sm-offset-4" style="<?php if ($has_more) {
                    echo "display:block";
                } else {
                    echo "display:none";
                } ?>" id="load_more_results">
                    <a class="btn btn-simple btn-block" id="load_results">حمل أكثر</a>

                </div>
            </div>
            <div class="clearfix"></div>
            <div class="col-lg-12" style="margin-top: 50px;">
                <hr>
                <div id="owl-demo1" class="owl-carousel text-center">
                    <?php
                    if (isset($banners)) {
                        foreach ($banners as $ban) {
                            ?>
                            <div class="item">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;"
                                             alt="" class="responsive">
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $('.my-button').click(
        function () {
            $(this).parents('form').find('input:checkbox').removeAttr('checked');
        }
    );
    $('.star').click(
        function () {
            $(this).parents('form').find('input:radio').removeAttr('checked');
        }
    );
    $(document).ready(function () {
        $(".slidingDiv").show();
        $(".show").show();

        $('.show').click(function () {
            $(this).next().slideToggle();
        });
    });
</script>
<link rel="stylesheet" href="<?= base_url() ?>css/jquery.ui.css">
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script>
    $(function () {
        $("#slider-range").slider({
            range: true,
            min: 0,
            max: 500,
            values: [0, 300],
            slide: function (event, ui) {
                $("#amount").val(+ui.values[0] + "د.ك  " + ui.values[1] + "د.ك");
            }
        });
        $("#amount").val(+$("#slider-range").slider("values", 0) +
            "د.ك "  + $("#slider-range").slider("values", 1) + "د.ك");
    });
</script>
<script>
    var base_url = '<?php echo base_url()?>';
    $(document).ready(function () {
        $('.do_search').on('click', function () {
            var area = $('#city_area').val();
            if (area == "") {
                $('#error1').empty();
                document.getElementById("error1").innerHTML = "اختار  مكانك";
                $('#error1').show();
                $('#error1').fadeOut(2000);
                return false;
            } else {
                post_array =
                {
                    "sort_by": $('#sort_by_what').val(),
                    "cuisine": $('#cuisine_types').val() != "" && $('#cuisine_types').val() != undefined ? $('#cuisine_types').val().join(",") : null,
                    "area": area,
                    "catering": ($('#switcher').prop('checked')) ? 1 : null,
                    "free_delivery": ($('#free_delivery').prop('checked')) ? '1' : '0',
                    "discount_avail": ($('#discount_avail').prop('checked')) ? '1' : '0',
                    "has_promotions": ($('#has_promotions').prop('checked')) ? '1' : '0',
                    "cod_avail": ($('#cod_avail').prop('checked')) ? '1' : '0',
                    "split_avail": ($('#split_avail').prop('checked')) ? '1' : '0',
                    "openrest": ($('#openrest').prop('checked')) ? '1' : '0',
                    "rating": typeof($('input[name=rating]:checked').val()) === "undefined" ? '' : $('input[name=rating]:checked').val(),
                    "min_price": $("#slider-range").slider("values", 0),
                    "max_price": $("#slider-range").slider("values", 1),
                    "page_number": 0
                };
                $('#search-content').empty();
                $('#res_status').empty();
                update_search_content(post_array)
            }
        });
    });

    $('#load_results').on('click', function () {
        post_array.page_number++;
        $('#res_status').empty();
        update_search_content(post_array);
    });
    $('#search_by_name').on('click', function () {
        post_array = [];
        post_array =
        {
            "search_term": $('#search_input').val(),
            "page_number": 0
        };
        $('#res_status').empty();
        $('#search-content').empty();

        update_search_content(post_array);
    });

    function update_search_content(filters) {
        $('#load_more_results').hide();
        $url = '<?= base_url() ?>main/get_search_results';
        $.ajax({
            url: $url,
            type: "POST",
            dataType: 'json',
            data: filters,
            success: function (data) {
                $('#search-content').append(data.search_view);
                $('#res_status').append(data.result_status);
                if (data.has_more) {
                    $('#load_more_results').show();
                }
            }
        });
    }

    $(document).on('click', '.add_fvrt', function (e) {
        var rest_id = encodeURIComponent($(this).attr('id'));

        $('#main-' + rest_id).empty();
        $url_login = '<?= base_url() ?>main/login/';
        $url = '<?= base_url() ?>main/bookmark_restaurant/';
        $data = 'rest_id=' + rest_id;
        $.ajax({
            url: $url,
            type: "POST",
            dataType: 'json',
            data: $data,
            success: function (data) {
                if (data == 'login') {
                    location.href = $url_login;
                } else if (data == 'Added') {
                    var fvrt = ' <a style="text-decoration: none;color: #FFC000;" class="glyphicon glyphicon-heart add_fvrt " id="' + rest_id + '"><span class="fav "> إزالة المفضلة</span></a>';
                    $('#main-' + rest_id).append(fvrt);
                    $("#message-" + rest_id).show().delay(1000).fadeOut();
                } else if (data == 'Updated') {
                    var fvrt = ' <a style="text-decoration: none;color: grey;" class="glyphicon glyphicon-heart add_fvrt " id="' + rest_id + '"><span class="fav "> اضافة الى المفضلة</span></a>';
                    $('#main-' + rest_id).append(fvrt);
                    $("#message-" + rest_id).show().delay(1000).fadeOut();
                }
            }
        });
    });
</script>
<script>
    $("#search_input").autocomplete({
        source: "<?php echo base_url('main/get_restaurants_name'); ?>"
    });
</script>