<link rel="stylesheet" href="<?= base_url() ?>css/header_search.css"/>
<style>
    .media-heading a {
        color: #848486;
    }

    .table > tbody > tr > td, .table > tbody > tr > th, .table > tfoot > tr > td, .table > tfoot > tr > th, .table > thead > tr > td, .table > thead > tr > th {

        vertical-align: inherit !important;
    }

    .table > tbody > tr > td, .table > tfoot > tr > td {
        vertical-align: middle;
    }

    .grey {
        cursor: pointer;
        color: grey;
    }

    .yellow {
        cursor: pointer;
        color: #FFC000;
    }

    .add_fvrt:hover {
        color: #FFC000 !important;
    }
</style>
<div class="content margin-top" style="margin-top: 200px;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="item">
                    <div class="col-lg-12">
                        <div class="col-lg-3">
                            <a href="<?= base_url() ?>main/search_result?cuisine=<?php echo $cuisine_banner[0]->id; ?>">
                                <div class="col-lg-12 no-padding">
                                    <div class="cuadro_intro_hover " style="background-color:#cccccc;">
                                        <p style="text-align:center;">
                                            <img class="lazyOwl img-responsive tem-g" style="height: 200px;object-fit: cover;"
                                                 src="<?php echo $cuisine_banner[0]->image_url; ?>" alt="name">
                                        </p>

                                        <div class="caption">
                                            <div class="blur"></div>
                                            <div class="caption-text">
                                                <h3><?php echo $cuisine_banner[0]->name; ?></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <a href="<?= base_url() ?>main/search_result?cuisine=<?php echo $cuisine_banner[1]->id; ?>">
                                <div class="col-lg-12 no-padding" style="margin-top:15px;">
                                    <div class="cuadro_intro_hover " style="background-color:#cccccc;">
                                        <p style="text-align:center;">
                                            <img class="lazyOwl img-responsive tem-g" style="height: 200px;object-fit: cover;"
                                                 src="<?php echo $cuisine_banner[1]->image_url; ?>" alt="name">
                                        </p>

                                        <div class="caption">
                                            <div class="blur"></div>
                                            <div class="caption-text">
                                                <h3><?php echo $cuisine_banner[1]->name; ?></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                        </div>
                        </a>
                        <a href="<?= base_url() ?>main/search_result?cuisine=<?php echo $cuisine_banner[2]->id; ?>">
                            <div class="col-lg-3">
                                <div class="cuadro_intro_hover " style="background-color:#cccccc;">
                                    <p style="text-align:center;">
                                        <img class="lazyOwl img-responsive tem-g" style="height: 415px;object-fit: cover;"
                                             src="<?php echo $cuisine_banner[2]->image_url; ?>" alt="name">
                                    </p>

                                    <div class="caption">
                                        <div class="blur"></div>
                                        <div class="caption-text">
                                            <h3 style="margin-top:150px;"><?php echo $cuisine_banner[2]->name; ?></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="<?= base_url() ?>main/search_result?cuisine=<?php echo $cuisine_banner[3]->id; ?>">
                            <div class="col-lg-6">
                                <div class="cuadro_intro_hover " style="background-color:#cccccc;">
                                    <p style="text-align:center;">
                                        <img class="lazyOwl img-responsive tem-g" style="height: 415px;object-fit: cover;"
                                             src="<?php echo $cuisine_banner[3]->image_url; ?>" alt="name">
                                    </p>

                                    <div class="caption">
                                        <div class="blur"></div>
                                        <div class="caption-text">
                                            <h3 style="margin-top:150px;"><?php echo $cuisine_banner[3]->name; ?></h3>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>

                    </div>
                </div>


            </div>
            <div class="col-lg-12 lists" style="margin-top: 40px;">

                <ul>
                    <?php $count = 1;
                    foreach ($cuisine_types as $row) { ?>
                        <div class="col-lg-2 ">
                            <li class="vertical_line">
                                <a href="<?= base_url() ?>main/search_result?cuisine=<?php echo $row->id; ?>"><?php echo $row->name; ?></a>
                            </li>
                        </div>
                        <?php
                        if($count % 6 == 0){
                            echo '<div style="height:10px; clear: both;"></div>';
                        }
                        $count++;
                    }
                    ?>
                </ul>


            </div>


            <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top: 50px;">
                <hr>
                <div id="owl-demo1" class="owl-carousel text-center">
                    <?php
                    if (isset($banners)) {
                        foreach ($banners as $ban) {
                            ?>
                            <div class="item">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;"
                                             alt="" class="responsive">
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                    }
                    ?>
                </div>

            </div>
        </div>

    </div>
</div>
<script>
    $(document).ready(function ($) {
        function adjustStyle(width) {
            width = parseInt(width);
            if (width < 701) {
                $(".vertical_line").removeClass("vertical_line");
            } else {
                $(".vertical_line").addClass("vertical_line");
            }
        }

        $(function () {
            adjustStyle($(this).width());
            $(window).resize(function () {
                adjustStyle($(this).width());
            });
        });
    });
</script>















