<style>
    .buttons {
        margin-bottom: -20px !important;
    }

    .media-heading {
        margin-top: 5px;
    }

    .selected {
        color: white;
        background: green
    }

    .tableform {
        border-radius: 5px;
    }

    .delivery {
        margin-bottom: 20px;
    }

    .favorite {
        margin-bottom: 20px;
    }

    .text-center a {
        background-color: #FFC000;
        border-color: #FFC000;
        margin-right: 20px;
        padding-right: 25px;
        padding-left: 25px;
        float: right;
    }

    a {
        color: #D6D6D6;
    }

    .media-body {
        padding-top: 40px;
    }

    .media-object {
        width: 100px !important;
        height: 100px !important;
    }

    .media-body hr {
        transform: rotate(90deg);
        width: 50px;
        margin-top: -20px;
        float: right;
        margin-bottom: 50px;
    }

    .btn-active {
        background-color: #FFC000;
        color: white;
    }
</style>
<div class="whole_div"
     style="width:100%;height:100%;display: none;position: fixed;z-index: 99999; background:url(<?= base_url() ?>img/loading.gif) no-repeat center center;"></div>
<div class="content">
    <div class="container">
        <div class="col-lg-12">
            <div class="col-lg-12">
                <?php if ($this->session->flashdata('message')) { ?>
                    <div class="alert alert-success">
                        <h6><?= strip_tags($this->session->flashdata('message')); ?><a class="close fa fa-times"
                                                                                       href="#"></a></h6>
                    </div>
                <?php } ?>
                <div class="image">
                    <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                    <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                        <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/registerlogo.png"
                                                             style="width: 50px; height: 50px;"> </a>

                        <div class="media-body" style="padding-top: 7px;">
                            <h4><b>حسابي</b></h4>

                            <p style="font-size:12px;font-style: italic;">حسابي الصفحة</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="well" style="padding:0px; margin-top: 50px;">
                    <h4 class="color1"> <?= $user_info->first_name ?>&nbsp;<?= $user_info->last_name ?>
                        (<?= $user_info->email ?>)مرحبا
                    </h4>

                    <div class="media" style="margin-left: 15px;margin-bottom: 20px;">
                        <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/Moneybag.png"
                                                             style="width: 30px; height: 30px;"> </a>

                        <div class="media-body" style="padding-top: 7px;">
                            <h4> <?= $user_points; ?> رصيد في الحقيبة : د.ك </h4>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-lg-12 col-sm-12">
                <div class="well">
                    <div class="btn-pref btn-group buttons" role="group" aria-label="...">
                        <div class="btn-group" role="group">
                            <a type="button" id="stars" class="btn tab-btn-grey account btn-active" href="#tab1"
                               data-toggle="tab">
                                <div>معلومات الحساب</div>
                            </a>
                        </div>
                        <div class="btn-group" role="group">
                            <a type="button" id="favorites" class="btn tab-btn-grey order" href="#tab2"
                               data-toggle="tab">
                                <div>سجل الطلب</div>
                            </a>
                        </div>
                        <div class="btn-group" role="group">
                            <a type="button" id="following" class="btn tab-btn-grey favorite favr" href="#tab3"
                               data-toggle="tab">
                                <div>مفضلاتي</div>
                            </a>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade in active" style="background-color:white;" id="tab1">
                            <div class="color account">
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <h4 style="margin-top:10px;">ملخص الحساب</h4>
                                    </div>
                                    <div class="col-lg-6 row">
                                        <?php if ($change_pas_check == NULL) { ?>
                                            <a class="btn btn-default editpass" data-toggle="modal" style="float:right;">
                                                تغيير كلمة المرور</a>
                                            <a class="btn btn-default editemail" data-toggle="modal"
                                               style="float:right;margin-right: 10px;">تعيير البريد الالكتروني</a>
                                        <?php } ?>
                                        <a class="btn btn-default editprofile" data-toggle="modal"
                                           data-id="<?= $user_info->id ?>"
                                           data-firstname="<?= $user_info->first_name ?>"
                                           data-lastname="<?= $user_info->last_name ?>"
                                           data-mobileno="<?= $user_info->phone ?>"
                                           data-housephone="<?= $user_info->house_phone ?>"
                                           data-workphone="<?= $user_info->work_phone ?>"
                                           data-company="<?= $user_info->company ?>"
                                           data-gender="<?= $user_info->gender ?>" data-dob="<?= $user_info->dob ?>"
                                           style="float:right;margin-right: 10px;">تعديل الملف الشخصي</a>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group col-lg-12">
                                            <label class="col-lg-4">الاسم الاول</label>

                                            <div class="col-lg-7">
                                                <p><?= $user_info->first_name ?></p>
                                            </div>
                                        </div>
                                        <div class="form-group col-lg-12">
                                            <label class="col-lg-4">رقم الهاتف المحمول</label>

                                            <div class="col-lg-7">
                                                <p><?= $user_info->phone ?></p>
                                            </div>
                                        </div>
                                        <div class="form-group col-lg-12">
                                            <label class="col-lg-4">رقم الهاتف</label>

                                            <div class="col-lg-7">
                                                <p><?= $user_info->work_phone ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group col-lg-12">
                                            <label class="col-lg-4">اسم العائلة </label>

                                            <div class="col-lg-7">
                                                <p><?= $user_info->last_name ?></p>
                                            </div>
                                        </div>
                                        <div class="form-group col-lg-12">
                                            <label class="col-lg-4">هاتف المنزل</label>

                                            <div class="col-lg-7">
                                                <p><?= $user_info->house_phone ?></p>
                                            </div>
                                        </div>
                                        <div class="form-group col-lg-12">
                                            <label class="col-lg-4">شركة</label>

                                            <div class="col-lg-7">
                                                <p><?= $user_info->company ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <hr>
                                    <div class="col-lg-12">
                                        <div class="form-group col-lg-6">
                                            <label class="col-lg-12">النوع</label>

                                            <div class="col-lg-7">
                                                <div class="radio">
                                                    <input id="female" type="radio" name="gender"
                                                           value="female" <?php if ($user_info->gender == 'female') echo 'checked=checked'; ?>>
                                                    <label class="label-radio oswald-font bold font22" for="female">انثى</label>

                                                    <input id="male" type="radio" name="gender"
                                                           value="male" <?php if ($user_info->gender == 'male') echo 'checked=checked'; ?> >
                                                    <label class="label-radio oswald-font bold font22"
                                                           for="male">ذكر</label>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group col-lg-12">
                                                <label class="col-lg-12">يوم الميلاد</label>

                                                <p class="col-lg-12"><?= $user_info->dob ?></p>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="color account">
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <h4 style="margin-top:10px;">معلومات التوصيل</h4>
                                    </div>
                                    <div class="col-lg-6">
                                        <a class="btn btn-default addaddress" data-toggle="modal" style="float:right;">
                                            اضافة عنوان</a>

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="col-lg-12">
                                        <div class="col-lg-12">
                                            <div class="table-responsive myaccounttable">
                                                <table class="table">
                                                    <thead>
                                                    <tr>
                                                        <th class="text-center"></th>
                                                        <th>اسم عنوان</th>
                                                        <th>معلومات العنوان</th>
                                                        <th>معلومات اضافية</th>

                                                    </tr>
                                                    </thead>
                                                    <?php
                                                    if (!empty($address_info)) {
                                                        foreach ($address_info as $address) {
                                                            ?>
                                                            <tr>
                                                                <td class=""><a
                                                                        href="<?= base_url() ?>main/delete_user_address/<?= $address->id ?>" onclick="return confirm('Are you sure you want to delete?');" class="btn btn-simple ">حذف</a>
                                                                    <a class="btn btn-simple edit_useraddress"
                                                                       data-id="<?= $address->id ?>"
                                                                       data-type_id="<?= $address->type_id ?>"
                                                                       data-area_id="<?= $address->area_id ?>"
                                                                       data-address_title="<?= $address->address_title ?>"
                                                                       data-block="<?= $address->block ?>"
                                                                       data-judda="<?= $address->judda ?>"
                                                                       data-street="<?= $address->street ?>"
                                                                       data-houseno_name="<?= $address->houseno_name ?>"
                                                                       data-extra_direction="<?= $address->extra_direction ?>"
                                                                       data-floor="<?= $address->floor ?>"
                                                                       data-office_apt="<?= $address->office_apt ?>"
                                                                       data-type_name="<?= $address->type_name ?>"
                                                                       data-area_name="<?= $address->area_name ?>"
                                                                       data-toggle="modal"> تحرير</a></td>
                                                                <td class="col-lg-2"><?= $address->address_title ?></td>
                                                                <td class="col-lg-4"><?php
                                                                    if (!empty($address->houseno_name)) {
                                                                        $address->houseno_name;
                                                                    } elseif (!empty($address->office_apt)) {
                                                                        $address->office_apt;
                                                                    } else {
                                                                        '';
                                                                    }
                                                                    ?>&nbsp;<?= $address->street ?>
                                                                    ,<?= $address->judda ?>,<?= $address->block ?></td>
                                                                <td class="col-lg-4"><?php echo $stringCut = substr($address->extra_direction, 0, 30); ?></td>

                                                            </tr>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- START::  Tab Order History-->
                        <div class="tab-pane fade in bg-white" id="tab2">
                            <div class="row">
                                <div class="col-lg-12 pt15">
                                    <div class="col-lg-12 ">
                                        <div class="outer_div">
                                            <?php if (isset($latest_order)) {
                                                foreach ($latest_order as $order) {
                                                    ?>
                                                    <div class="order_detail_div">
                                                        <label
                                                            class="checkout-label pull-left2"> <?= $order->order_status; ?> : الحالة</label>

                                                        <div class="checkout-main roborto mt40" style="border: none">
                                                            <img class="checkout-img" src="<?= $order->rest_logo; ?>"/>

                                                            <p class="checkout-title">
                                                                <a style="cursor: pointer;"><span
                                                                        class="color-yellow font16 bold"><?= $order->rest_name; ?></span></a><br/>
                                                                <span
                                                                    class="color-light-grey font13">مفتوحة من  <?= $order->rest_opening_time; ?>
                                                                    - <?= $order->rest_closing_time; ?></span>
                                                            </p>

                                                            <p style="padding-top: 25px;padding-left: 30px;">
                                                            <span class="">
                                                                <?php
                                                                for ($i = 1; $i < 6; $i++) {
                                                                    if ($i < $order->rating) {
                                                                        ?>
                                                                        <a onclick="return false"
                                                                           class="glyphicon glyphicon-star color-yellow font12 nodec"></a>
                                                                    <?php } else { ?>
                                                                        <a onclick="return false"
                                                                           class="glyphicon glyphicon-star color-grey font12 nodec"></a>
                                                                        <?php
                                                                    }
                                                                }
                                                                ?>
                                                                <br/>

                                                            </span>
                                                            <span class="color-light-grey font12">
                                                                <?= $order->rating_count; ?> التصنيفات
                                                            </span>
                                                            </p>
                                                        </div>
                                                        <div class="checkout-item mt20">
                                                            <table class="checkout-table">
                                                                <?php
                                                                if (!empty($order->items_attr)) {
                                                                    foreach ($order->items_attr as $item_row) {
                                                                        ?>
                                                                        <tr>
                                                                        <td class="">
                                                                            <span class="color-yellow bold font16 pr20">
                                                                                د.ك <?= round($item_row['item_quantity'] * ($item_row['price'] + $item_row['option_price']), 3); ?>
                                                                            </span>
                                                                            </td>
                                                                            
                                                                            <td>
                                                                                <label
                                                                                    class="checkout-label"><?= $item_row['item_quantity']; ?></label>
                                                                            </td>
                                                                            <td>
                                                                                <span
                                                                                    class="color-black oswald-font bold"><?= $item_row['name']; ?> (<?= $item_row['options_name']; ?>)</span>
                                                                            </td>
                                                                        </tr>
                                                                        <?php
                                                                    }
                                                                }
                                                                ?>
                                                            </table>
                                                            <div class="col-lg-12 roborto font16 no-padding-left"
                                                                 style="padding: 20px 16px 20px 0;">
                                                                <div
                                                                    class="col-lg-4 col-md-4 col-sm-12 col-xs-12 no-padding-right  pt20 pb20 ">
                                                                    <p class="color-light-grey">
                                                                         <?= $order->order_id; ?> : هوية النظام <br/>
                                                                        <?php if ($order->t_paymant_method == '1' || $order->t_paymant_method == '3') {
                                                                            echo "Credit Card/Knet";
                                                                        } else {
                                                                            echo $order->payment_method;
                                                                        } ?>: طريقة الدفع
                                                                    </p>
                                                                </div>
                                                                <div
                                                                    class="col-lg-4 col-md-4 col-sm-12 col-xs-12 pt20 pb20 history-into">
                                                                    <p class="color-light-grey">

                                                                        :عنوان التوصيل<br/>
                                                                        <?= $order->delivery_address; ?>
                                                                    </p>
                                                                </div>
                                                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 pt20 pb20">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                        <td class="color-yellow bold txt-right-ar2">
                                                                            د.ك <?= $order->total_amount; ?></td>
                                                                            <td class="color-light-grey"><p>المجموع</p></td>
                                                                            
                                                                        </tr>
                                                                        <tr>
                                                                        <td class="color-yellow bold txt-right-ar2">
                                                                            د.ك <?= $order->discount; ?></td>
                                                                            <td class="color-light-grey"><p>خصم</p></td>
                                                                            
                                                                        </tr>
                                                                        <tr>
                                                                        <td class="color-yellow bold txt-right-ar2">
                                                                            د.ك <?= $order->delivery_charges; ?></td>
                                                                            <td class="color-light-grey">
                                                                                رسوم التسليم
                                                                            </td>
                                                                            
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                            <table style="width:100% ">
                                                                <tr class="subtotal-head">
                                                                    
                                                                    <td class="subtotal-ar" align="left"
                                                                        style="">
                                                                    <span class="color-yellow bold font16 pr20">
                                                                        د.ك <?= $order->subtotal; ?>
                                                                    </span>
                                                                    </td>
                                                                    
                                                                    <td class="" align="left">
                                                                    <span class="color-yellow bold font16">
                                                                        المبلغ الاجمالي
                                                                    </span>
                                                                    </td>
                                                                </tr>
                                                            </table>

                                                        </div>
                                                        <div class="pull-leftar mt30 raleway-font txt-right"
                                                             style="display: inline;">
                                                            <!--                                                    <a class="btn3-green round20" href="">RATE YOUR ORDER </a>-->
                                                            <a class="btn3-grey round20 ml15 reorder_class" href="#" onclick="return false" id="<?= $order->order_id; ?>">اعادة الطلب </a>
                                                        </div>
                                                        <br/><br/>
                                                    </div>
                                                    <?php
                                                }
                                            } else {
                                                echo 'العثور على أي أمر';
                                            }
                                            ?>
                                        </div>
                                        <div class="history-itembox mt40 border-top pb20 pt20">
                                            <?php
                                            if (!empty($order_history)) {
                                                $i = 0;

                                                foreach ($order_history as $user_order) {
                                                    ?>
                                                    <table class="list-table table-responsive table">
                                                        <tr class="<?php if ($i == 0) {
                                                            echo "selected";
                                                        } else {
                                                            echo "orders_order_id";
                                                        } ?>" id="new_hello-<?php echo $i ?>">
                                                            <td class="txt-right-ar">
                                                                <p> <span class="color-yellow"><?= $user_order['order_status']; ?></span>
                                                               : الحالة </p>
                                                            </td>
                                                            <td>
                                                                <p class="color-black">
                                                                    <?= $user_order['datetime']; ?> : تاريخ</p>
                                                            </td><td style="width:500px;">
                                                                <p>
                                                                    
                                                                    <span class="color-yellow"><a href="#"
                                                                                                  id="<?= $user_order['order_id']; ?>"
                                                                                                  class="orders_order_id color-yellow"><?= $user_order['rest_name']; ?></a></span> <i style="top: 0px;" class="glyphicon glyphicon-chevron-left  list-icon-red"></i>
                                                                </p>
                                                            </td>
                                                            
                                                        </tr>
                                                    </table>
                                                    <?php
                                                    $i++;
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- END::  Tab Order History-->
                        <div class="tab-pane fade in" style="background-color:white;" id="tab3">
                            <!-- -->
                            <div class="row">
                                <div class="btn-pref btn-group buttons" role="group">
                                    <div class="btn-group" role="group">
                                        <a type="button" class="btn tab-btn-grey favorite_item" href="#tab4"
                                           data-toggle="tab">
                                            <div>السلعة المفضلة</div>
                                        </a>
                                    </div>
                                    <div class="btn-group" role="group">
                                        <a type="button" class="btn tab-btn-grey favorite_restaurant" href="#tab5"
                                           data-toggle="tab">
                                            <div>المطعم المفضل</div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="col-lg-12">
                                        <div class="col-lg-12">
                                            <div class="table-responsive">
                                                <table class="table">

                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-content">
                                <div class="tab-pane fade in active item-active" style="background-color:white;" id="tab4">
                                    <div class="color favorite_item">
                                        <div class="col-lg-12">
                                            <div class="col-lg-6">
                                                <h4 style="margin-top:10px;">قائمة افضل السلع</h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="col-lg-12">
                                                <div class="col-lg-12">
                                                    <div class="table-responsive">
                                                        <table class="table">
                                                            <?php
                                                            if (!empty($fav_items)) {
                                                                foreach ($fav_items as $items_data) {
                                                                    ?>
                                                                    <tr>
                                                                        

                                                                        

                                                                        
                                                                        <td class="col-sm-2 col-md-2 ">
                                                                            <div class="media-body">
                                                                                <a href="<?= base_url() ?>main/bookmark_menu_item?item_id = <?= $items_data->id; ?>"
                                                                                   class="btn btn-active btn-block">إزالة</a>
                                                                            </div>
                                                                        </td>
                                                                        <td class="col-sm-2 col-md-2 ">
                                                                            <div class="media-body">
                                                                                <h4>السعر</h4>
                                                                                <h5 class="media-heading">
                                                                                    د.ك <?= $items_data->price; ?></h5>
                                                                                <hr>
                                                                            </div>
                                                                        </td>
                                                                        <td class="col-sm-2 col-md-2 ">
                                                                            <div class="media-body">
                                                                                <h4>
                                                                                    <a href="<?= base_url() ?>restaurant/<?= $items_data->slug; ?>"
                                                                                       class="color-yellow"><?= $items_data->rest_name; ?></a>
                                                                                </h4>
                                                                                <h5 class="media-heading"><?= $items_data->rest_type; ?></h5>
                                                                                <hr>

                                                                            </div>
                                                                        </td>
                                                                        
                                                                        <td class="col-sm-5 col-md-5">
                                                                            <div class="media">
                                                                                <a class=" pull-left" href="<?= base_url() ?>restaurant/<?= $items_data->slug; ?>"
                                                                                   style="margin-right: 10px;"> <img
                                                                                        class="media-object"
                                                                                        src="<?= $items_data->image_url; ?>">
                                                                                </a>

                                                                                <div class="media-body">
                                                                                    <h4><a href="<?= base_url() ?>restaurant/<?= $items_data->slug; ?>"
                                                                                           class="color-yellow"><?= $items_data->name; ?></a>
                                                                                    </h4>
                                                                                    <h5 class="media-heading"
                                                                                        style="word-wrap: break-word;"><?php echo $stringCut = substr($items_data->description, 0, 50); ?>..</h5>
                                                                                    <hr>
                                                                                </div>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade in rest-active" style="background-color:white;" id="tab5">
                                    <div class="color favorite_restaurant">
                                        <div class="col-lg-12">
                                            <div class="col-lg-6">
                                                <h4 style="margin-top:10px;">قائمة افضل المطاعم</h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="col-lg-12">
                                                <div class="col-lg-12">
                                                    <div class="table-responsive">
                                                        <table class="table">
                                                            <?php
                                                            if (!empty($fav_restaurant)) {
                                                                foreach ($fav_restaurant as $restaurant_data) {
                                                                    ?>
                                                                    <tr>
                                                                      <td class="col-sm-2 col-md-2 ">
                                                                            <div class="media-body">
                                                                                <a href="<?= base_url() ?>main/delete_fav_user_restaurant/<?= $restaurant_data->fav_id; ?>"
                                                                                   class="btn btn-active btn-block">إزالة</a>
                                                                            </div>
                                                                        </td>  

                                                                        

                                                                        <td class="col-sm-3 col-md-3 ">

                                                                        </td>
                                                                        <td class="col-sm-1 col-md-1">

                                                                        </td>
                                                                        
                                                                        <td class="col-sm-4 col-md-6">
                                                                            <div class="media">
                                                                                <a class=" pull-left" href="<?= base_url() ?>restaurant/<?= $restaurant_data->slug; ?>"
                                                                                   style="margin-right: 10px;"> <img
                                                                                        class="media-object"
                                                                                        src="<?= $restaurant_data->logo_url; ?>">
                                                                                </a>

                                                                                <div class="media-body">
                                                                                    <h4><a href="<?= base_url() ?>restaurant/<?= $restaurant_data->slug; ?>"
                                                                                           class="color-yellow"><?= $restaurant_data->rest_name; ?></a>
                                                                                    </h4>
                                                                                    <h5 class="media-heading"
                                                                                        style="word-wrap: break-word;">..<?php echo $stringCut = substr($restaurant_data->rest_description, 0, 50); ?></h5>
                                                                                    <hr>
                                                                                </div>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<?php include 'myaccount_modals.php'; ?>
<script>
    $(document).ready(function () {
        $("#editHomes").click(function () {
            $("#house_divs").hide();
            $('#edit_address').data('formValidation').resetForm();
            $("#house_divs").find('input').prop('disabled', true);
            $("#houseno_name").attr("placeholder", "رقم الدار");
        });
        $("#editBuildings").click(function () {
            $("#houseno_name").attr("placeholder", "رقم المبنى");
            $("#house_divs").find('input').prop('disabled', false);
            $("#house_divs").show();
        });
        $("#editOffices").click(function () {
            $("#houseno_name").attr("placeholder", "عدد المكاتب");
            $("#house_divs").find('input').prop('disabled', false);
            $("#house_divs").show();
        });
        $(".addaddress").click(function () {
            $('#add_address')[0].reset();
            $('#add_address').data('formValidation').resetForm();
            $('#addaddress').modal('show');
        });
        $(".edit_useraddress").click(function () {
            $('#edit_address')[0].reset();
            $('#edit_address').data('formValidation').resetForm();
            var area = $(this).data('area_id');
            $("#area").val(area);
            $("#address_title").val($(this).data('address_title'));
            $("#block").val($(this).data('block'));
            $("#judda").val($(this).data('judda'));
            $("#street").val($(this).data('street'));
            $("#houseno_name").val($(this).data('houseno_name'));
            $("#extra_direction").val($(this).data('extra_direction'));
            $("#floor").val($(this).data('floor'));
            $("#office_apt").val($(this).data('office_apt'));
            $("#type_name").val($(this).data('type_name'));
            $("#area_name").val($(this).data('area_name'));
            $("#id").val($(this).data('id'));
            var type = $(this).data('type_id');
            if (type == 1) {
                $("#editHomes").attr('checked', 'checked');
                $("#house_divs").hide();
                $("#house_divs").find('input').prop('disabled', true);
            } else if (type == 2) {
                $("#house_divs").find('input').prop('disabled', false);
                $("#house_divs").show();
                $("#editOffices").attr('checked', 'checked');
            } else if (type == 3) {
                $("#house_divs").find('input').prop('disabled', false);
                $("#house_divs").show();
                $("#editBuildings").attr('checked', 'checked');
            }

            $('#edit_useraddress').modal('show');
        });
        $("#Homes").click(function () {
            $("#house_div").hide();
            $('#add_address').data('formValidation').resetForm();
            $("#house_div").find('input').prop('disabled', true);
            $("#number").attr("placeholder", "رقم الدار");
        });
        $("#Buildings").click(function () {

            $("#number").attr("placeholder", "رقم المبنى");
            $("#house_div").find('input').prop('disabled', false);
            $("#house_div").show();
        });
        $("#Offices").click(function () {
            $("#number").attr("placeholder", "عدد المكاتب");
            $("#house_div").find('input').prop('disabled', false);
            $("#house_div").show();
        });

        $(".editprofile").click(function () {
            $("#userid").val($(this).data('id'));
            $("#firstname").val($(this).data('firstname'));
            $("#lastname").val($(this).data('lastname'));
            $("#mobileno").val($(this).data('mobileno'));
            $("#housephone").val($(this).data('housephone'));
            $("#workphone").val($(this).data('workphone'));
            $("#company").val($(this).data('company'));
            var gender = $(this).data('gender');
            if (gender == 'male') {
                $("#males").attr('checked', 'checked');
            } else {
                $("#females").attr('checked', 'checked');
            }
            var dateofbirth = $(this).data('dob');
            var dobdata = dateofbirth.split('-');
            var year_selected = dobdata[0];
            var month_selected = dobdata[1];
            var day_selected = dobdata[2];
            $("#year_sel").val(year_selected);
            $("#month_sel").val(month_selected);
            $("#day_sel").val(day_selected);
            $('#editprofile').modal('show');
        });
    });
</script>
<script type="text/javascript">
    $('.account').on('click', function () {
        $('.favorite').removeClass('btn-active');
        $('.account').addClass('btn-active');
        $('.order').removeClass('btn-active');
    });
    $('.order').on('click', function () {
        $('.favorite').removeClass('btn-active');
        $('.account').removeClass('btn-active');
        $('.order').addClass('btn-active');
    });
    $('.favorite').on('click', function () {
        $('.favorite').addClass('btn-active');
        $('.account').removeClass('btn-active');
        $('.order').removeClass('btn-active');
        $('.favorite_item').addClass('btn-active');
    });
    $('.favorite_item').on('click', function () {
        $('.favorite').addClass('btn-active');
        $('.favorite_item').addClass('btn-active');
        $('.account').removeClass('btn-active');
        $('.order').removeClass('btn-active');
        $('.favorite_restaurant').removeClass('btn-active');

    });
    $('.favorite_restaurant').on('click', function () {
        $('.favorite').addClass('btn-active');
        $('.favorite_restaurant').addClass('btn-active');
        $('.account').removeClass('btn-active');
        $('.order').removeClass('btn-active');
        $('.favorite_item').removeClass('btn-active');


    });
    $(document).ready(function () {
        $(document).on('click', '.orders_order_id', function (e) {
            var selected_id = $(this).attr('id');
            var name_id = selected_id.split('-');
            var names = name_id[0];
            var select_id = name_id[1];
            $('.list-table tr').removeClass('selected');
            $('#new_hello-' + select_id).addClass('selected');

        });
    });
    $(document).ready(function () {
        $(document).on('click', '.favr', function (e) {
            $('.favorite_restaurant').removeClass('btn-active');

            $('.item-active').addClass('active');
            $('.item-active').addClass('in');
            $('.rest-active').removeClass('active');
        });
    });
    $(document).ready(function () {
        $(document).on('click', '.orders_order_id', function (e) {
            $('.whole_div').show();
            $('.order_detail_div').empty();
            var order_id = encodeURIComponent($(this).attr('id'));
            $url = '<?= base_url() ?>main/user_order_history';
            $data = 'order_id=' + order_id;
            $.ajax({
                url: $url,
                type: "POST",
                dataType: 'json',
                data: $data,
                success: function (data) {
                    if (data !== null) {
                        $.each(data, function (key, val) {
                            var attrib_data_all = '';
                            if (val.items != null) {
                                $.each(val.items_attr, function (key, val_itm) {
                                    attrib_data_all += '<tr>' +
                                        '<td style="width:500px;">' +
                                        '<span class = "color-black oswald-font bold" >' + val_itm.name + '</span>' +
                                        '</td>' +
                                        '<td >' +
                                        '<label class = "checkout-label" >' + val_itm.item_quantity + '</label>' +
                                        '</td>' +
                                        '<td class = "txt-right" >' +
                                        '<span class = "color-yellow bold font16 pr20" >د.ك ' + val_itm.total_price_item + '</span>' +
                                        '</td>' +
                                        '</tr>';
                                });
                            }
                            if (val.t_paymant_method == '1' || val.t_paymant_method == '3') {
                                var payment_selecteion = 'Credit Card/Knet';
                            } else {
                                var payment_selecteion = val.payment_method;
                            }

                            var order_detail_data = '<div class="order_detail_div">' +
                                '<label class="checkout-label pull-right"> ' + val.order_status + ' : الحالة</label>' +
                                '<div class="checkout-main roborto mt40" style="border: none">' +
                                '<img class="checkout-img" src="' + val.rest_logo + '"/>' +
                                '<p class="checkout-title">' +
                                '<span class="color-yellow font16 bold">' + val.rest_name + '</span><br/>' +
                                '<span class="color-light-grey font13">مفتوحة من ' + val.rest_opening_time + ' - ' + val.rest_closing_time + '</span>' +
                                '</p>' +
                                '<p style="padding-top: 25px;padding-left: 30px;">' +
                                '<span class="star-group">' +
                                '<br/>' +
                                '</span>' +
                                '<span class="color-light-grey font12">' + val.rating_count + 'Ratings </span>' +
                                '</p>' +
                                '</div>' +
                                '<div class="checkout-item mt20">' +
                                '<table class ="checkout-table orders_item_table" >' + attrib_data_all +
                                '</table>' +
                                '<div class="col-lg-12 roborto font16 no-padding-left" style="padding: 20px 16px 20px 0;">' +
                                '<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12  pt20 pb20 history-into">' +
                                '<p class="color-light-grey"> ' + val.order_id + ' : هوية النظام <br/>  ' + payment_selecteion + ': طريقة الدفع </p>' +
                                '</div>' +
                                '<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 pt20 pb20 history-into">' +
                                '<p class="color-light-grey">: عنوان التوصيل<br/>' + val.delivery_address + '</p>' +
                                '</div>' +
                                '<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 pt20 pb20 no-padding-left">' +
                                '<table style="width: 100%">' +
                                '<tr>' +
                                '<td class="color-light-grey"><p>المجموع</p></td>' +
                                '<td class="color-yellow bold txt-right">د.ك ' + val.total_amount + '</td>' +
                                '</tr>' +
                                '<tr>' +
                                '<td class="color-light-grey"><p>خصم</p></td>' +
                                '<td class="color-yellow bold txt-right">د.ك ' + val.discount + '</td>' +
                                '</tr>' +
                                '<tr>' +
                                '<td class="color-light-grey">رسوم التسليم</td>' +
                                '<td class="color-yellow bold txt-right">د.ك ' + val.delivery_charges + '</td>' +
                                '</tr>' +
                                '</table>' +
                                '</div>' +
                                '</div>' +
                                '<table style="width:100% ">' +
                                '<tr class="subtotal-head">' +
                                '<td class="txt-right">' +
                                '<span class="color-yellow bold font16">المبلغ الاجمالي</span>' +
                                '</td>' +
                                '<td class="txt-right" style="width:250px;padding: 15px 0;">' +
                                '<span class="color-yellow bold font16 pr20">د.ك ' + val.subtotal + '</span>' +
                                '</td>' +
                                '</tr>' +
                                '</table>' +
                                '</div>' +
                                '<div class="pull-right mt30 raleway-font txt-right" style="display: inline;">' +
                                '<a class="btn3-grey round20 ml15 reorder_class" href="#" onclick="return false" id="' + val.order_id + '">اعادة الطلب </a>' +
                                '</div><br/><br/>' +
                                '</div>';
                            $(".outer_div").append(order_detail_data);
                            $('.whole_div').hide();
                        });
                    }
                }
            });
        });

    });

    $(document).ready(function () {
        $(document).on('click', '.reorder_class', function (e) {
            $(".cartnum").empty();
            $('.whole_div').show();
            $('.order_detail_div').empty();
            var order_id = $(this).attr('id');
            $url = '<?= base_url() ?>main/reorder';
            $data = 'order_id=' + order_id;
            $.ajax({
                url: $url,
                type: "POST",
                dataType: 'json',
                data: $data,
                success: function (data) {
                    $(".cartnum").append(data.count);
                    $('.whole_div').hide();
                    var url_redirect = "<?=base_url(); ?>main/checkout/";
                    window.location.href = url_redirect;
                }
            });
        });

    });

</script>











