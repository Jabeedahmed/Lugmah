<style>
    .progress-bar {
        background-color: #E1E1E1 !important;
    }

    .well {
        background-color: #F9F9F9;
    }

    .one, .two, .three {
        position: absolute;
        margin-top: -5px;
        z-index: 1;
        height: 30px;
        width: 30px;
        border-radius: 19px;

    }

    .progress {
        margin: 40px;
    }

    .one {
        left: 25%;
    }

    .two {
        left: 50%;
    }

    .three {
        left: 75%;
    }

    .primary-color {
        background-color: #FFC000;
    }

    .success-color {
        background-color: #5cb85c;
    }

    .danger-color {
        background-color: #d9534f;
    }

    .warning-color {
        background-color: #f0ad4e;
    }

    .info-color {
        background-color: #5bc0de;
    }

    .no-color {
        background-color: inherit;
    }

</style>
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div id="pg-content">
                    <div class="col-lg-12">
                        <div class="image">
                            <img class="responsive" src="<?= base_url() ?>img/registerBack.png">

                            <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png"
                                                                     style="width: 50px; height: 50px;"> </a>

                                <div class="media-body">
                                    <h4><b>متابعة الطلب</b></h4>

                                    <p style="font-style: italic;">سيتم توصيل طلبك في اقرب وقت</p>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-12" style="margin-top:40px;">

                            <?php if (!empty($message)) { ?>
                                <div class="panel" style="background-color: red;color: white;padding: 10px;">
                                    <h6><?= $message ?></h6>
                                </div>
                            <?php }else{ ?>

                        <div class="col-lg-8">
                            <div class="col-lg-3">
                                <label class="sort">متابعة الطلب:</label></div>

                            <div class="form-group col-lg-5">
                                <select name="country" class="form-control order_details">
                                    <option value="">حدد ترتيب</option>
                                    <?php if (!empty($order_history)) {
                                        foreach ($order_history as $item) { ?>
                                            <option value="<?= $item->order_id ?>"><?= $item->rest_name ?>
                                                &nbsp;<?= $item->datetime; ?></option>
                                        <?php }
                                    } ?>
                                </select>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="well">
                            <div class="progress ">
                                <div class="one primary-color"></div>
                                <div class="two primary-color"></div>
                                <div class="three primary-color"></div>

                                <div class="order_outerdiv">

                                </div>
                            </div>
                            <div class="row progresbar01">
                                <div class="col-lg-12" style="margin-right: 77px;">
                                    <div class="col-lg-3 ">
                                        <img class="img-responsive" src="<?= base_url() ?>img/orderOutOfdelivery.png"
                                             style="width: 200px; height: 150px;">
                                    </div>
                                    <div class="col-lg-3 ">
                                        <img class="img-responsive" src="<?= base_url() ?>img/orderReady.png"
                                             style="margin-left: -24px;width: 200px; height: 150px;">
                                    </div>
                                    
                                    
                                    <div class="col-lg-3 ">
                                        <img class="img-responsive" src="<?= base_url() ?>img/orderRecievedBy.png"
                                             style="margin-left:-55px;  width: 250px; height: 150px;">
                                    </div>


                                </div>
                            </div>
                            
                        </div>
                        <?php }?>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top:50px;">
                <hr>
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner" role="listbox">
                        <div class="item active">
                            <div class="featured-partners">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-01.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-02.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-03.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="featured-partners">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-01.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-02.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-03.jpg" alt=""
                                             class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Left and right controls -->
                    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {

        $(document).on("change", '.order_details', function () {
            $('.order_outerdiv').css('width','0%');
            var order_id = $(this).val();
            $url = '<?= base_url() ?>index.php/main/get_order_detail_by_id';
            $data = 'order_id=' + order_id;

            $.ajax({
                url: $url,
                type: "POST",
                dataType: 'json',
                data: $data,
                success: function (data) {
                    if (data.order_status === 'Pending') {
                        $(".order_outerdiv").addClass('progress-bar');
                        $(".order_outerdiv").css('width','23%');
                    } else if (data.order_status === 'Recieved') {
                        $(".order_outerdiv").addClass('progress-bar');
                        $(".order_outerdiv").css('width','23%');
                    } else if (data.order_status === 'Inprocess') {
                        $(".order_outerdiv").addClass('progress-bar');
                        $(".order_outerdiv").css('width','53%');
                    } else if (data.order_status === 'Delivered') {
                        $(".order_outerdiv").addClass('progress-bar');
                        $(".order_outerdiv").css('width','81%');
                    }
                }

            });


        });
    });
</script>

















