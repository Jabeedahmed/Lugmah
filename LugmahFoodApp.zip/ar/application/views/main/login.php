<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div id="pg-content" class="row">
                    <div class="col-lg-12">
                        <div class="image" >
                            <img class="responsive" src="<?= base_url() ?>img/registerBack.png">
                            <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png" style="width: 50px; height: 50px;"> </a>
                                <div class="media-body">
                                    <h4><b>تسجيل الدخول</b></h4>
                                    <p style="font-style: italic;">تسجيل الدخول للطلب</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12" style="margin-top:40px;">
                        <div class="clearfix"></div>
                        <div class="well">
                            <div class="row">
                                <form class="form-horizontal" action="<?= base_url('auth/login'); ?>" id="login" method="post">
                                    <div class="col-lg-7">
                                        <div class="" style="background-color:white;" >
                                            <div class="color login_head">
                                                <div class="col-lg-12">
                                                    <div class="col-lg-6">
                                                        <h4 style="margin-top:10px;">اعداد حساب</h4>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="col-lg-12">
                                                        <p><b>عميل جديد؟</b></p>
                                                        <p> انشئ حساب وتمتع بافضل تجربة توصيل طعام على الانترنت</p>
                                                    </div>
                                                    <div class="col-lg-12 margin-bottom center">
                                                        <a href="<?=base_url()?>main/register" class="btn btn-danger" >سجل الان</a>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6 vertical_linee">
                                                    <div class="col-lg-12" style="margin-top: 50px;">
                                                        <p class="center">الدخول عن طريق</p>
                                                    </div>
                                                    <div class="col-lg-12 center" style="margin-top: 10px;">
                                                        <p>
                                                            <a class="btn btn-primary social-login-btn social-facebook" href="<?= base_url('auth/loginfacebook'); ?>"><i class="fa fa-facebook"></i></a>
<!--                                                            <a class="btn btn-primary social-login-btn social-twitter" href="/auth/twitter"><i class="fa fa-twitter"></i></a>-->
                                                            <a class="btn btn-primary social-login-btn social-google" href="<?php echo $login_url;?>"><i class="fa fa-google-plus"></i></a>
                                                        </p>
                                                    </div>
                                                </div>
                                               <?php if(sizeof($this->cart->contents()) != '0') { ?>
                                                <div class="col-lg-12 margin-bottom center" style="margin-top: 10px;">
                                                    <a href="<?=base_url() ?>main/guest_checkout"  class="btn btn-simple" >الخروج كضيف</a>
                                                </div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-5">
                                        <div class="" style="background-color:white;" >
                                            <div class="color login_head">
                                                <div class="col-lg-12">
                                                    <div class="col-lg-6">
                                                        <h4 style="margin-top:10px;">تسجيل الدخول</h4>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">

                                                <div class="col-lg-12">
                                                    <div class="col-lg-12">
                                                        <?php if ($this->session->flashdata('error')) { ?>
                                                            <div class="alert alert-error">
                                                                <h6><?= strip_tags($this->session->flashdata('error')); ?><a class="close fa fa-times" href="#"></a></h6>
                                                            </div>
                                                        <?php }if ($this->session->flashdata('alert')) { ?>
                                                            <div class="alert alert-waring">
                                                                <h6><?= strip_tags($this->session->flashdata('alert')); ?><a class="close fa fa-times" href="#"></a></h6>
                                                            </div>
                                                        <?php }if ($this->session->flashdata('message')) { ?>
                                                            <div class="alert alert-success">
                                                                <h6><?= strip_tags($this->session->flashdata('message')); ?><a class="close fa fa-times" href="#"></a></h6>
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <p>برجاء تفقد بريدك الالكتروني</p>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="form-group ">
                                                            <input type="text" placeholder="البريد الإلكتروني" name="email" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="form-group ">
                                                            <input type="password" placeholder="كلمه السر" name="password" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <a href="<?= base_url() ?>main/forget_password" style="cursor: pointer;"><span>هل نسيت كلمة المرور؟</span></a>
                                                    </div>
                                                    <div class="col-lg-6 col-lg-push-1">
                                                        <div class="checkbox">
                                                            <input id="remembers" type="checkbox" value="1" name="remember" style="margin-right:5px">
                                                            <label class="label-radio oswald-font bold font22" for="remembers">تذكرني</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12 margin-bottom" >
                                                        <input style="float: right" type="submit" class="btn btn-contact " value="ارسال">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>


                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top:50px;">
                <hr>
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner" role="listbox">
                        <div class="item active">
                            <div class="featured-partners">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-01.jpg" alt="" class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-02.jpg" alt="" class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-03.jpg" alt="" class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="featured-partners">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-01.jpg" alt="" class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-02.jpg" alt="" class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= base_url() ?>img/promotion-03.jpg" alt="" class="img-responsive feat-img">
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Left and right controls -->
                    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>

    </div>
</div>