  <link rel="stylesheet" href="<?= base_url()?>css/app.css">
<div class="content">
    <div class="container">
        <div class="row">
             <div class="col-lg-12">
                    <div class="image" >
                        <img class="responsive" src="<?= base_url() ?>img/registerBack.png">
                        <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                            <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/privacy-img.png" style="width: 50px; height: 50px;"> </a>
                            <div class="media-body">
                                <h4><b>سياسة الخصوصية</b></h4>
                                <p style="font-style: italic;">ونحن نقدر الثقة التي منحتنا</p>
                            </div>
                        </div>
                    </div>
               
            <div id="pg-content" class="row">
               
                <div id="description" class="small-12 columns">
                    <p>
                        <?php if(!empty($privacy_poloice)){ echo $privacy_poloice->description;}?>
                    </p>
                </div><!-- Description End -->
                <div id="about-us-list" class="small-12 columns">
                    <ul class="small-12 columns">
                        <?php if(!empty($security_polices_types)){
                        foreach($security_polices_types as $policy){
                        ?>
                        <li >
                            <div class="section-heading">
                                <a href="javascript:void(0)"><?=$policy->heading;?></a>
                            </div>
                            <div id="feature-list">
                                <p>
                                    <?=$policy->description;?>
                                </p>
                            </div>
                        </li>
                        <?php } } ?>

                    </ul>
                </div>
            </div>
           
        </div>
              <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top: 50px;">
                <hr>
                <div id="owl-demo1" class="owl-carousel text-center">
                    <?php
                    if (isset($banners)) {
                        foreach ($banners as $ban) {
                            ?>
                            <div class="item">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                    <a href="<?= base_url() . 'restaurant/' . $ban->link_url ?>">
                                        <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;"
                                             alt="" class="responsive"></a>
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                    }
                    ?>
                </div>

            </div>
    </div>
</div>
</div>













