<div class="modal fade" id="addaddress" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form name="" id="add_address" method="POST" action="<?= base_url() ?>main/add_user_address" enctype="multipart/form-data" class="form-horizontal">
            <!-- Modal content-->
            <div class="col-lg-12">
                <div class="well">
                    <div class="con">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title" style="color:white;">تغيير العنوان</h4>
                        </div>
                        <div class="modal-body" style="padding: 0px; ">
                            <div class="col-lg-12">
                                <div class="col-lg-12" style="margin-bottom:10px;">
                                    <div class="form-group">
                                        <div class="col-lg-12">
                                            <div class="radio">
                                                <input id="Offices" type="radio" name="address_type_id" value="3" >
                                                <label class="label-radio oswald-font bold font22" for="Offices">مكتب</label>
                                                <input id="Buildings" type="radio" name="address_type_id" value="2" >
                                                <label class="label-radio oswald-font bold font22" for="Buildings">بناء</label>

                                                <input id="Homes" type="radio" name="address_type_id" value="1" checked>
                                                <label class="label-radio oswald-font bold font22" for="Homes">الصفحة الرئيسية</label>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <select name="city_id" class="form-control">
                                                <option value="">اختار  مكانك</option>
                                                <?php foreach ($cities as $row) { ?>
                                                    <option value="<?php echo $row->city_id; ?>"><?php echo $row->city_name; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="address_name" placeholder="عنوان*" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="block" placeholder="القطعة*" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="judda" placeholder="الكامنة" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="street" placeholder="شارع*" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="office_name" id="number" placeholder="رقم المنزل*" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div id="house_div" style="display:none;">
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="floor" placeholder="أرضية*" class="form-control" disabled>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="appartment" id="apartment_office" placeholder="مكتب شقة*" class="form-control" disabled>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-12">
                                        <div class="form-group ">
                                            <textarea type="text" name="extra_direction" class="form-control"
                                                      placeholder="اتجاه اضافي ( اضف تفاصيل اكثر لسائق المطعم حتى يجدك اسرع )"></textarea>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="modal-footer">
                            <div class="col-lg-12">
                                <input type="submit" class="btn btn-default lognow btn-block" name="submit_new_address" value="اضافة عنوان">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="modal fade" id="edit_useraddress" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form name="" id="edit_address" method="POST" action="<?= base_url() ?>main/edit_user_address" enctype="multipart/form-data" class="form-horizontal">
            <!-- Modal content-->
            <div class="col-lg-12">
                <div class="well">
                    <div class="con">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title" style="color:white;">عنوان التغيير</h4>
                        </div>
                        <div class="modal-body" style="padding: 0px; ">
                            <input type="hidden" id="id" name="id">

                            <div class="col-lg-12">
                                <div class="col-lg-12" style="margin-bottom:10px;">
                                    <div class="form-group">
                                        <div class="col-lg-12">
                                            <div class="radio">
                                                <input id="editOffices" type="radio" name="address_type_id" value="3" >
                                                <label class="label-radio oswald-font bold font22" for="editOffices">مكتب</label>

                                                    <input id="editBuildings" type="radio" name="address_type_id" value="2" >
                                                    <label class="label-radio oswald-font bold font22" for="editBuildings">بناء</label>

                                                <input id="editHomes" type="radio" name="address_type_id" value="1" checked>
                                                <label class="label-radio oswald-font bold font22" for="editHomes">الصفحة الرئيسية</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <select name="city_id" id="area" class="form-control ">
                                                <option value="">اختار  مكانك</option>
                                                <?php foreach ($cities as $row) { ?>
                                                    <option value="<?php echo $row->city_id; ?>"><?php echo $row->city_name; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="address_name" id="address_title" data-toggle="tooltip" title="عنوان" placeholder="عنوان*" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="block" id="block" placeholder="القطعة*" data-toggle="tooltip" title="القطعة" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="judda" id="judda" placeholder="الكامنة" data-toggle="tooltip" title="الكامنة" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="street" id="street" placeholder="شارع*" data-toggle="tooltip" title="شارع" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="office_name" id="houseno_name" id="numbers" placeholder="رقم المنزل"  data-toggle="tooltip" title="رقم المنزل"
                                                   class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div id="house_divs" style="display:none;">
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="floor" id="floor" placeholder="أرضية*" data-toggle="tooltip" title="أرضية" class="form-control" disabled>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="appartment" id="office_apt" placeholder="مكتب شقة*" data-toggle="tooltip" title="مكتب شقة"
                                                       class="form-control" disabled>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-12">
                                        <div class="form-group ">
                                        <textarea type="text" id="extra_direction" name="extra_direction" data-toggle="tooltip"
                                                  title="اتجاه اضافي ( اضف تفاصيل اكثر لسائق المطعم حتى يجدك اسرع )" class="form-control"
                                                  placeholder="اتجاه اضافي ( اضف تفاصيل اكثر لسائق المطعم حتى يجدك اسرع )"></textarea>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="modal-footer">
                            <div class="col-lg-12">
                                <input type="submit" class="btn btn-default lognow btn-block" name="submit_new_address" value="عنوان التحديث">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Modal -->
<div id="editprofile" class="modal fade" role="dialog">
    <div class="modal-dialog" style="width: 680px">
        <form id="edit_userProfile" method="POST" action="<?= base_url() ?>main/update_user_profile" enctype="multipart/form-data" class="form-horizontal">
            <!-- Modal content-->
            <div class="col-lg-12">
                <div class="well">
                    <div class="con">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title" style="color:white;">تعديل الملف الشخصي</h4>
                        </div>
                        <div class="modal-body" style="padding: 0px; ">
                            <div class="col-lg-12" style="margin-top:10px">
                                <div class="form-group ">
                                    <label class="col-lg-3">الاسم الاول</label>

                                    <div class="col-lg-9">
                                        <input type="text" id="firstname" name="first_name" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label class="col-lg-3">اسم العائلة </label>

                                    <div class="col-lg-9">
                                        <input type="text" id="lastname" name="last_name" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label class="col-lg-3">الاتصال المحمول</label>

                                    <div class="col-lg-9">
                                        <input type="text" id="mobileno" name="phone" class="form-control">&nbsp;<span class="errmsg"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-3">هاتف المنزل</label>

                                    <div class="col-lg-9">
                                        <input type="text" id="housephone" name="house_phone" class="form-control">&nbsp;<span id="errmsg"></span>
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label class="col-lg-3">هاتف عمل</label>

                                    <div class="col-lg-9">
                                        <input type="text" id="workphone" name="work_phone" class="form-control">&nbsp;<span id="error"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-3">شركة</label>

                                    <div class="col-lg-9">
                                        <input type="text" id="company" name="company" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-3">النوع</label>

                                    <div class="col-lg-9">
                                        <div class="radio">
                                            <input id="males" type="radio" name="gender" value="male">
                                            <label class="label-radio oswald-font bold font22" for="males">ذكر</label>
                                            <input id="females" type="radio" name="gender" value="female">
                                            <label class="label-radio oswald-font bold font22" for="females">انثى</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-3">تاريخ الميلاد</label>

                                    <div class="">
                                        <div class="col-lg-4">
                                            <select id="month_sel" class="form-control" name="month">
                                                <option value="">شهر</option>
                                                <option value="01">كانون الثاني</option>
                                                <option value="02">فبراير</option>
                                                <option value="03">مارس</option>
                                                <option value="04">أبريل</option>
                                                <option value="05">قد</option>
                                                <option value="06">يونيو</option>
                                                <option value="07">يوليو</option>
                                                <option value="08">أغسطس</option>
                                                <option value="09">سبتمبر</option>
                                                <option value="10">شهر اكتوبر</option>
                                                <option value="11">تشرين الثاني</option>
                                                <option value="12">ديسمبر</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-2">
                                            <select id="day_sel" class="form-control" name="day">
                                                <option value="">يوم</option>
                                                <?php for ($i = 01; $i < 32; $i++) { ?>
                                                    <option value="<?php if ($i < 10) {
                                                        echo 0 . $i;
                                                    } else {
                                                        echo $i;
                                                    } ?>"><?= $i; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <div class="col-lg-3">
                                            <select id="year_sel" class="form-control" name="year">
                                                <option value="">عام</option>
                                                <?php for ($i = $settings->start_year; $i <= $settings->end_year; $i++) { ?>
                                                    <option value="<?= $i ?>"><?= $i ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-default lognow btn-block" href="<?= base_url() ?>main/my_account" type="submit">
                                حفظ
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div id="editpass" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <form name="" id="change_password_form" method="POST" action="<?= base_url() ?>main/change_password" enctype="multipart/form-data" class="form-horizontal">
            <!-- Modal content-->
            <div class="col-lg-12">
                <div class="well">
                    <div class="con">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title" style="color:white;">تغيير كلمة المرور</h4>
                        </div>
                        <div class="modal-body" style="padding: 0px; ">
                            <div class="col-lg-12" style="margin-top:10px">
                                <div class="form-group ">
                                    <label class="col-lg-4">كلمة المرور القديمة</label>

                                    <div class="col-lg-7">
                                        <input type="password" id="old_password" name="old_password" required="" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label class="col-lg-4">كلمة المرور الجديدة</label>

                                    <div class="col-lg-7">
                                        <input type="password" id="new_password" pattern="^\S{6,}$" required="" name="new_password"
                                               onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Must have at least 6 characters' : ''); if(this.checkValidity()) form.confirm_password.pattern = this.value;"
                                               class="form-control">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label class="col-lg-4">تأكيد كلمة المرور</label>

                                    <div class="col-lg-7">
                                        <input type="password" id="confirm_password" pattern="^\S{6,}$" required="" name="confirm_password"
                                               onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Please enter the same Password as above' : '');" class="form-control">
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <input class="btn btn-default lognow btn-block" type="submit" name="change_pass_button" value="تغيير كلمة المرور">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div id="editemail" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <form name="" id="change_email_form" method="POST" action="<?= base_url() ?>main/change_email" enctype="multipart/form-data" class="form-horizontal">
            <!-- Modal content-->
            <div class="col-lg-12">
                <div class="well">
                    <div class="con">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title" style="color:white;">تعيير البريد الالكتروني</h4>
                        </div>
                        <div class="modal-body" style="padding: 0px; ">
                            <div class="col-lg-12" style="margin-top:10px">
                                <div class="form-group ">
                                    <label class="col-lg-4">بريد الكتروني قديم</label>

                                    <div class="col-lg-7">
                                        <input type="text" name="old_email" class="form-control" required="">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label class="col-lg-4">بريد الكتروني جديد</label>

                                    <div class="col-lg-7">
                                        <input type="text" name="new_email" class="form-control" required="">
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <input class="btn btn-default lognow btn-block" name="change_email" value="تعيير البريد الالكتروني" type="submit">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
    var base_url = "<?php echo base_url()?>";
    $(document).ready(function () {
        $('#change_email_form').formValidation({
            framework: 'bootstrap',
            excluded: ':disabled',
            icon: {
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {

                old_email: {
                    validators: {
                        notEmpty: {
                            message: 'Email could not be empty'
                        },
                        regexp: {
                            regexp: '^[^@\\s]+@([^@\\s]+\\.)+[^@\\s]+$',
                            message: 'Email address is not valid'
                        },
                        remote: {
                            message: 'Please Enter Your Correct Email',
                            url: base_url + 'main/check_email_exist',
                            data: {
                                type: 'email'
                            },
                            type: 'POST'
                        }
                    }
                },
                new_email: {
                    validators: {
                        notEmpty: {
                            message: 'Email could not be empty'
                        },
                        regexp: {
                            regexp: '^[^@\\s]+@([^@\\s]+\\.)+[^@\\s]+$',
                            message: 'Email address is not valid'
                        },
                    }
                }
            }
        });
    });
</script>




