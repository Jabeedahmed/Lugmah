<style>
    .red_col {
        background-color: red;
    }

    .green_col {
        background-color: green;
    }
</style>
<link rel="stylesheet" href="<?= base_url() ?>css/app.css">
<div class="">
    <div class="container">
        <div class="row">

            <div class="col-lg-8 col-lg-offset-2">
                <form name="" id="" method="POST" action="<?= base_url() ?>main/my_account"
                      enctype="multipart/form-data" class="form-horizontal">
                    <!-- Modal content-->
                    <div class="col-lg-10 col-lg-offset-1">
                        <div class="con">
                            <div class="modal-header" style="background-color: white;">
                                <h4 class="modal-title center" style="color:#FFC000;">تقسيم الدفع الخاص بك</h4>
                            </div>
                            <div class="modal-header">
                                <h1 class="modal-title center" style="color:white;">Payment Status</h1>

                            </div>
                            <div class="modal-body" style="padding: 0px; ">
                                <div class="col-lg-12 margin">
                                    <div class="col-lg-12">
                                        <div class="form-group ajax_div_data">
                                            <?php
                                            $i = 1;
                                            foreach ($split_data as $row) { ?>
                                                <label class="col-lg-8 color_model" style="margin-top: 8px;"><span
                                                        class="circle"><?= $i ?></span>
                                                    &nbsp;&nbsp;<?= $row->username_no; ?></label>
                                                <div class="col-lg-2">
                                                    <span style=""
                                                          class="<?php if ($row->status == '1' || $row->status == '3') { ?>circle2 glyphicon glyphicon-remove red_col<?php } else { ?>circle2 glyphicon glyphicon-ok green_col<?php } ?>"></span>
                                                </div>
                                                <div class="clearfix" style="margin-top: 50px;"></div>
                                                <hr>
                                                <?php $i++;
                                            } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer ">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top: 50px;">
                <hr>
                <div id="owl-demo1" class="owl-carousel text-center">
                    <?php
                    if (isset($banners)) {
                        foreach ($banners as $ban) {
                            ?>
                            <div class="item">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                        <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;"
                                             alt="" class="responsive">
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                    }
                    ?>
                </div>

            </div>
        </div>
    </div>
</div>

<script>
    var split_id = '<?=$split_id; ?>';
    function get_latest_status(split_id) {
        $('.ajax_div_data').empty();
        $url = '<?= base_url() ?>main/guest_split_payment_status_ajax?split_id=' + split_id;
        $.ajax({
            type: 'POST',
            url: $url,
            dataType: 'json',
            success: function (data) {
                if(data.status == '2'){
                    window.location.href = '<?=base_url() ?>main/place_guest_split_order?split_id='+split_id+'';
                }else {
                    var x = 1;
                    $.each(data.split_data, function (key, item) {
                        if (item.status == '1') {
                            var status_class = 'circle2 glyphicon glyphicon-remove red_col';
                        } else if (item.status == '3') {
                            var status_class = 'circle2 glyphicon glyphicon-remove red_col';
                        } else {
                            var status_class = 'circle2 glyphicon glyphicon-ok green_col';
                        }
                        var payment_status = '<label class="col-lg-10 color_model" style="margin-top: 8px;">' +
                            '<span class="circle">' + x + '</span>&nbsp;&nbsp;' + item.username_no + '</label>' +
                            '<div class="col-lg-2">' +
                            '<span class="' + status_class + '"></span>' +
                            '</div>' +
                            '<div class="clearfix" style="margin-top: 50px;"></div>' +
                            '<hr>';
                        $(".ajax_div_data").append(payment_status);
                        x = x + 1;
                    });
                }
            },complete: function (data){
                setTimeout(function () {
                    get_latest_status(split_id);
                }, 30000);
            }
    })
    }
    $(function () {
        get_latest_status(split_id);
    });
    function get_latest_split_status(split_id) {
        $url = '<?= base_url() ?>main/guest_split_status?split_id=' + split_id;
        $.ajax({
            type: 'POST',
            url: $url,
            dataType: 'json',
            success: function (data) {
                if(data.sp_status == '2'){
                    window.location.href = '<?=base_url() ?>main/place_guest_split_order_expire?split_id='+split_id+'';
                }
            },complete: function (data){
                setTimeout(function () {
                    get_latest_split_status(split_id);
                }, 30000);
            }
        })
    }
    $(function () {
        get_latest_split_status(split_id);
    });

</script>









