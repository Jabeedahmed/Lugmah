<link rel="stylesheet" href="<?= base_url() ?>css/app.css">
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div id="pg-content" class="row">
                    <div class="col-lg-12">
                        <div class="image" >
                            <img class="responsive" src="<?= base_url() ?>img/registerBack.png">
                            <div class="media" style="position: relative;margin-top: -70px;margin-left: 15px;">
                                <a class=" pull-left" href="#"> <img src="<?= base_url() ?>img/about-us-img.png" style="width: 50px; height: 50px;"> </a>
                                <div class="media-body">
                                    <h4><b>حول الموقع</b></h4>
                                    <p style="font-style: italic;">معرفة المزيد عنا</p>
                                </div>
                            </div>
                        </div>

                        <div id="description" class="small-12 columns">
                            <p>
                                <span>منذ عام 2004</span><?php  echo $abous_us->description;?>
                            </p>
                        </div><!-- Description End -->
                        <div id="about-us-list" class="small-12 columns">
                            <ul class="small-12 columns">
                                <li >
                                    <div class="section-heading">
                                        <a href="javascript:void(0)">حقائق سريعة عن Lugmah</a>
                                    </div>
                                    <div id="feature-list">
                                        <ul>
                                            <?php if(!empty($quick_facts)){
                                                foreach($quick_facts as $quick_fact){
                                            ?>
                                            <li>
                                                <?php  echo $quick_fact->description;?>
                                            </li>
                                            <?php }}?>

                                        </ul>
                                    </div>
                                </li>
                                <li >
                                    <div class="section-heading">
                                        <a href="javascript:void(0)">لماذا Lugmah.com</a>
                                    </div>
                                    <div id="feature-list">
                                        <ul>

                                                <?php if(!empty($why_lugmah)){
                                                foreach($why_lugmah as $why_lugh){
                                                ?>
                                            <li>
                                                <?php  echo $why_lugh->description;?>
                                            </li>
                                            <?php }}?>


                                        </ul>
                                    </div>
                                </li>
                            </ul>
                        </div>


                    </div>
                    <hr />

                </div>
            </div>
              <div class="clearfix"></div>

            <div class="col-lg-12" style="margin-top: 50px;">
                <hr>
                <div id="owl-demo1" class="owl-carousel text-center">
                    <?php
                    if (isset($banners)) {
                        foreach ($banners as $ban) {
                            ?>
                            <div class="item">
                                <div class="col-md-4 fet-part">
                                    <div class="feature-img-grid">
                                    <a href="<?= base_url() . 'restaurant/' . $ban->link_url ?>">
                                        <img src="<?= $ban->banner_url ?>" style="width: 350px;height: 200px;"
                                             alt="" class="responsive"></a>
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                    }
                    ?>
                </div>

            </div>
        </div>
    </div>
</div>











