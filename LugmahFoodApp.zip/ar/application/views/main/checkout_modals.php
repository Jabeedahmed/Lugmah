<style>
    .edit_split_color {
        background-color: green;
        color: white;
    }
</style>
<div class="modal fade" id="add_addressCheckout" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form name="" id="add_address" method="POST" action="<?= base_url() ?>main/add_user_new_address" enctype="multipart/form-data" class="form-horizontal">
            <!-- Modal content-->
            <div class="col-lg-12">
                <div class="well">
                    <div class="con">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title" style="color:white;">تغيير عنوان</h4>
                        </div>
                        <div class="modal-body" style="padding: 0px; ">
                            <div class="col-lg-12">
                                <div class="col-lg-12" style="margin-bottom:10px;">
                                    <div class="form-group">
                                        <div class="col-lg-12">
                                            <div class="radio">
                                                <input id="Offices" type="radio" name="address_type_id" value="3" >
                                                <label class="label-radio oswald-font bold font22" for="Offices">مكتب</label>

                                                <input id="Buildings" type="radio" name="address_type_id" value="2" >
                                                <label class="label-radio oswald-font bold font22" for="Buildings">بناء</label>

                                                <input id="Homes" type="radio" name="address_type_id" value="1" checked>
                                                <label class="label-radio oswald-font bold font22" for="Homes">الصفحة الرئيسية</label>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <select name="city_id" class="form-control">
                                                <option value="">اختار  مكانك</option>

                                                <?php foreach ($cities as $row) { ?>
                                                    <option value="<?php echo $row->city_id; ?>"><?php echo $row->city_name; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="address_name" placeholder="عنوان" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="block" placeholder="منع" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="judda" placeholder="الكامنة" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="street" placeholder="شارع" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group ">
                                            <input type="text" name="office_name" id="number" placeholder="رقم الدار" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div id="house_div" style="display:none;">
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="floor" id="floor" placeholder="أرضية" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group ">
                                                <input type="text" name="appartment" id="apartment_office" placeholder="مكتب شقة" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-12">
                                        <div class="form-group ">
                                            <textarea type="text" name="extra_direction" class="form-control"
                                                      placeholder="اتجاه إضافي ( إضافة مزيد من التفاصيل للسائق المطاعم ل تجد لك أسرع)"></textarea>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="modal-footer">
                            <div class="col-lg-12">
                                <button class="btn btn-default lognow btn-block" type="submit">
                                    إرسال
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="modal fade" id="split" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form name="" id="split_pay" method="POST" action="<?= base_url() ?>main/split_payment" enctype="multipart/form-data"
              class="form-horizontal">
            <!-- Modal content-->
            <input type="hidden" id="address_val_id" name="select_address_id">
            <input type="hidden" id="payment_method_id_val" name="payment_method_id">
            <input type="hidden" id="split_points_used" name="points_used">
            <input type="hidden" id="delievery_pickup_val" name="delivery_pickup">
            <input type="hidden" id="pickup_address_id_val" name="pickup_address_id">
            <input type="hidden" id="order_time_val" name="order_time">

            <div class="col-lg-10 col-lg-offset-1">
                <div class="con">
                    <div class="modal-header" style="background-color: white;">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title center" style="color:#FFC000;">تقسيم الدفع الخاص بك</h4>
                    </div>
                    <div class="modal-header">
                        <h4 class="modal-title center" style="color:white;">المبلغ الإجمالي</h4>

                        <div class="center col-lg-offset-3 kd">
                            <input id="total_split_amount" name="total_amount" readonly type="text" class=" modal-title center" style="border: none;outline: none;"
                                   value="<?php if (!empty($total_cost)) {
                                       echo $total_cost . '&nbsp;د.ك';
                                   } ?>">

                        </div>
                    </div>
                    <div class="modal-body" style="padding: 0px; ">
                        <div class="col-lg-12 margin">
                            <div class="col-lg-12">
                                <div class="form-group">

                                </div>
                                <div id="split_details">
                                    <div class="payee_content">
                                        <label class="col-lg-6 color_model"><span class="circle col-lg-3">1</span>

                                            <div class="col-lg-5">
                                                <input style="border:none;margin-top: 8px;width: 100px;" value="<?= $user->phone ?>" id="phone_Split" name="phone_no[]" type="text" readonly
                                                       placeholder="أدخل الهاتف"></div>
                                        </label>

                                        <div class="col-lg-5">
                                            <div class="form-group">
                                                <input type="text" readonly  name="price[]" value="<?php if (!empty($total_cost)) {
                                                    echo $total_cost;
                                                } ?>" class="form-control round20 center round_color split_payee split_auto_payee">
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                        <hr class="no-marrgin">
                                    </div>
                                </div>

                                <div id="add_more_splits"></div>
                                <label class="col-lg-6"></label>

                                <div class="col-lg-6 " style="float:right;">
                                    <div class="form-group" style="float:right;">
                                        <button type="button" style="float:right;"
                                                class="btn btn-default add_more_splitter">أضف المزيد
                                        </button>
                                    </div>
                                </div>
                                <div class="clearfix"></div>

                            </div>
                        </div>
                    </div>
                    <div class="modal-footer ">
                        <input type="submit" id="submit_split" class="btn btn-simple btn-block no_border_radius pay" value="دفع">
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
    $(document).ready(function () {

        $(document).on('click', '.add_more_splitter', function (e) {

            var counter = $('#split_details').find('input[type=text].split_payee').size() + 1;
            if (counter < 6) {
                $('.payee_content').eq(0)
                    .clone().appendTo('#split_details')
                    .find('.clearfix')
                    .before('<span class="glyphicon glyphicon-minus del_splitter"></span>');
                $('.payee_content').last().find('input[type=text]').each(function () {
                    $(this).val('');
                    $(this).attr("readonly", false);
                });

                update_counter();
                update_split();
                if (counter == 5) {
                    $(".add_more_splitter").hide();
                }
            }
            $('#split_pay').formValidation('addField','phone_no[]', {
                validators: {
                    notEmpty: {
                        message: 'مطلوب الهاتف'
                    }
                }
            });
            $('#split_pay').formValidation('addField','price[]', {
                validators: {
                    notEmpty: {
                        message: 'مطلوب السعر'
                    }
                }
            });

        });
        $(document).on('click', '.del_splitter', function (e) {
            $(this).parents().eq(0).remove();
            if (check_valid()) {
                $('.add_more_splitter').show();
            }
            update_counter();
            update_split();


        });
        $(document).on('change', '.split_payee', function (e) {

            $(this).removeClass('split_auto_payee');
            $(this).addClass('split_edit_payee');
            if (isNumeric($(this).val())) {
                if (parseFloat($(this).val()) >= parseFloat(total_cost_split)) {
                    toastr.error('كمية أكبر من المطلوب');
                    $('#submit_split').hide();
                    $('.add_more_splitter').hide();
                }
                else if (!check_valid()) {
                    toastr.error('كمية أكبر من المطلوب');
                    $('#submit_split').hide();
                    $('.add_more_splitter').hide();
                }
                else {
                    update_split();
                }
            } else {
                toastr.error('الرجاء إدخال صالح كمية');
                $('#submit_split').hide();
                $('.add_more_splitter').hide();
            }
        });

        function update_split() {
            var edit_cost = 0;
            if (check_valid) {
                $('#split_details').find('input[type=text].split_edit_payee').each(function () {
                    if (isNumeric($(this).val())) {
                        edit_cost = parseFloat($(this).val()) + edit_cost;
                    }
                });

                var cost = (total_cost_split - edit_cost) / $('#split_details').find('input[type=text].split_auto_payee').size();


                $('#split_details').find('input[type=text].split_auto_payee').each(
                    function () {
                        $(this).val(cost.toFixed(3));
                    }
                );
                $('#submit_split').show();
                if ($('#split_details').find('input[type=text].split_payee').size() < 5) {
                    $('.add_more_splitter').show();
                }
            }
        }

        function check_valid() {
            var sp_cur_cost = 0;
            $('#split_details').find('input[type=text].split_edit_payee').each(function () {
                sp_cur_cost = parseFloat($(this).val()) + sp_cur_cost;
            });

            if (sp_cur_cost > total_cost_split) {
                return false;
            } else {
                return true;
            }
        }

        function update_counter() {
            var num = 1;
            $('#split_details').find('.circle').each(function () {
                $(this).empty().text(num);
                num++;
            });
        }

        function isNumeric(n) {
            return !isNaN(parseFloat(n)) && isFinite(n);
        }
    });
</script>