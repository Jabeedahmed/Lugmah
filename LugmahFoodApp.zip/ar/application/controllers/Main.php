<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class main extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->lang->load('auth');
        $this->load->library('cart');
    }

    function index()
    {
        $this->load->model('main_banners_model');
        $this->load->model('restaurant_model');
        $this->load->model('banners_model');
        $this->load->model('cuisine_type_model');
        $this->load->model('cities_model');
        $this->load->model('general_setting_model');
        $this->load->model('split_transaction_model');
        $this->load->model('payment_method_model');

        if ($this->ion_auth->logged_in()) {
            $user_info = $this->ion_auth->user()->row();
            $data['split_payments'] = $this->split_transaction_model->get_active_splits($user_info->id);
        } else {
            $this->session->set_userdata('last_page', current_url());
        }

        $data['folder_name'] = 'main';
        $data['file_name'] = 'index';
        $data['header_name'] = 'header';
        $data['nav_name'] = 'nav_main';
        $data['login_url'] = $this->googleplus->loginURL();
        $data['cities'] = $this->cities_model->get_all();
        $data['capitals'] = $this->cities_model->get_all_capitals();
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['banners'] = $this->banners_model->get_promotion_banner();
        $data['discount_restaurants'] = $this->restaurant_model->get_discount_restaurants();
        $data['voucher_restaurants'] = $this->restaurant_model->get_voucher_restaurants();
        $data['banners_promotion'] = $this->main_banners_model->get_all();
        $data['header_banner'] = $this->banners_model->get_header_banner();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['cuisine_types'] = $this->cuisine_type_model->get_all();
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    public function register()
    {
        $this->load->model('cuisine_type_model');
        $this->load->model('user_setting_model');
        $this->load->model('user_addresses_model');
        $this->load->model('cities_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['cities'] = $this->cities_model->get_all();
        $data['capitals'] = $this->cities_model->get_all_capitals();
        $data['login_url'] = $this->googleplus->loginURL();

        if ($this->input->post('register')) {
            $post_data = $_POST;
            $data['user_type_id'] = '2';
            $email = strtolower($post_data['email']);
            $username = $post_data['email'];
            $password = $post_data['password'];
            if ($this->ion_auth->email_check(strtolower($email))) {
                $this->session->set_flashdata('error', "عنوان البريد الإلكتروني موجود بالفعل");
                redirect('main/register');
            } else {
                $data['first_name'] = $post_data['first_name'];
                $data['last_name'] = $post_data['last_name'];
                $data['dob'] = $post_data['year'] . '-' . $post_data['month'] . '-' . $post_data['day'];
                $data['phone'] = $post_data['mobile_number'];
                $data['country'] = '116';
                $data['gender'] = $post_data['gender'];
                $data['is_block'] = '0';
                $data['date_created'] = date('y-m-d h:i:s');
                $register_id = $this->ion_auth->register($username, $password, $email, $data, array('2'));

                $settings['user_id'] = $register_id;
                $settings['promo_setting'] = 1;
                $settings['update_by_sms_setting'] = 1;
                $this->user_setting_model->create($settings);
                $address['user_id'] = $register_id;
                $address['type_id'] = $post_data['address_type_id'];
                $address['area'] = $post_data['city_id'];
                $address['address_title'] = $post_data['address_name'];
                $address['block'] = $post_data['block'];
                $address['judda'] = $post_data['judda'];
                $address['street'] = $post_data['street'];
                $address['houseno_name'] = $post_data['office_name'];
                $address['floor'] = $post_data['floor'];
                $address['office_apt'] = $post_data['appartment'];
                $address['extra_direction'] = $post_data['extra_direction'];
                $this->user_addresses_model->create($address);
                $errors_array = $this->ion_auth->errors_array();
                $messages_array = $this->ion_auth->messages_array();
                if (!empty($errors_array[0])) {
                    $this->session->set_flashdata('error', $errors_array[0]);
                    redirect('main/register');
                } elseif (!empty($messages_array[0])) {
                    $this->session->set_flashdata('success', "وقعت بنجاح يرجى التحقق من حسابك من خلال وصلة إرسالها إلى عنوان البريد الإلكتروني الخاص بك");
                    redirect('main');
                }
            }
        }
        $data['folder_name'] = 'main';
        $data['file_name'] = 'register';
        $data['header_name'] = 'header_register';
        $data['nav_name'] = 'nav_main';
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    public function update_user_profile()
    {
        if ($this->ion_auth->logged_in()) {
            $post_data = $_POST;
            $logged_user = $this->ion_auth->user()->row();
            $this->load->model('ion_auth_model');
            $this->load->model('user_setting_model');
            $this->load->model('payment_method_model');
            $this->load->model('general_setting_model');
            $data['settings'] = $this->general_setting_model->get_setting();
            $data['payment_method_db'] = $this->payment_method_model->get_payment_images();

            $data['first_name'] = $post_data['first_name'];
            $data['last_name'] = $post_data['last_name'];
            $data['phone'] = $post_data['phone'];
            $data['gender'] = $post_data['gender'];
            $data['login_url'] = $this->googleplus->loginURL();
            $data['dob'] = $post_data['year'] . '-' . $post_data['month'] . '-' . $post_data['day'];
            $data['house_phone'] = $post_data['house_phone'];
            $data['work_phone'] = $post_data['work_phone'];
            $data['company'] = $post_data['company'];
            date_default_timezone_set("Asia/Karachi");
            $data['date_created'] = date("Y-m-d H:i:s");
            $this->ion_auth->update($logged_user->id, $data);
            $this->session->set_flashdata('success', "العضو التحديث بنجاح");
            redirect('main/my_account');
        } else {
            $this->session->set_flashdata('alert', "الرجاء تسجيل الدخول أولا إلى المضي قدما");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function logout()
    {
        $this->ion_auth->logout();
        redirect('main');
    }

    public function check_points()
    {
        $user = $this->ion_auth->user()->row();
        $user_id = $user->id;
        $points_used = $this->input->post('points_used');
        $this->load->model('user_points_model');

        $total_points = $this->user_points_model->get_user_points($user_id);
        $total = $total_points->points;
        if ($points_used < $total) {
            $isAvailable = true;
        } else {
            $isAvailable = false;
        }
        echo json_encode(array(
            'valid' => $isAvailable,
        ));
    }

    public function search_result()
    {
        $this->load->model('restaurant_model');
        $this->load->model('user_fav_restaurant_model');
        $this->load->model('cities_model');
        $this->load->model('cuisine_type_model');
        $this->load->model('payment_method_model');
        $this->load->model('banners_model');
        $this->load->model('general_setting_model');
        if ($this->ion_auth->logged_in()) {
            $user = $this->ion_auth->user()->row();
            $user_id = $user->id;
        } else {
            $user_id = 0;
            $this->session->set_userdata('last_page', current_url());
        }
        $catering = $this->input->get_post('catering');
        $cuisine = $this->input->get_post('cuisine');
        $area = $this->input->get_post('area');

        $filter['catering'] = isset($catering) ? $catering : null;
        $filter['cuisine'] = isset($cuisine) && !empty($cuisine) ? $cuisine : null;
        $filter['area'] = isset($area) && !empty($area) ? $area : null;
        $page = isset($page) && !empty($page) ? $page : 0;
        $result_per_page = 10;
        $restaurants = $this->restaurant_model->restaurant_search($filter, $result_per_page, $result_per_page * $page, $user_id);

        if (isset($restaurants['results'])) {
            foreach ($restaurants['results'] as $restau) {
                if (isset($restau->payment_methods) && !empty($restau->payment_methods)) {
                    $restau->payment_methods = $this->payment_method_model->get_by_ids(explode(',', $restau->payment_methods));
                } else {
                    $restau->payment_methods = null;
                }
                $search_rest[] = $restau;
            }
            $view_data['restaurants'] = $search_rest;
            $data['search_view'] = $this->load->view('util/search_view', $view_data, TRUE);
            $data['total_record'] = $restaurants['totalres'];
            $data['has_more'] = $restaurants['has_more'];
        } else {
            $data['total_record'] = 0;
            $data['has_more'] = false;

        }
        $data['selected_area'] = $this->cities_model->get_by_id($area);
        $data['selected_cuisine'] = $cuisine;
        $data['menu_promotions'] = $this->banners_model->get_search_promotion_banner();
        $data['banners'] = $this->banners_model->get_promotion_banner();
        $data['cuisine_types'] = $this->cuisine_type_model->get_all_cuisines();
        $data['cities'] = $this->cities_model->get_all();
        $data['capitals'] = $this->cities_model->get_all_capitals();
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['folder_name'] = 'main';
        $data['file_name'] = 'search_result';
        $data['header_name'] = 'header_search';
        $data['nav_name'] = 'nav_main';
        $data['login_url'] = $this->googleplus->loginURL();

        $this->load->view('index', $data);
    }

    function get_address_detail()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $address_id = $this->input->post('address_id');
            $address = $this->user_addresses_model->get_by_id($address_id);
            $data['address'] = wordwrap($address->address, 30, '<br>');
            print_r(json_encode($data));
        }
    }

    public function get_search_results()
    {
        $this->load->model('restaurant_model');
        $this->load->model('user_fav_restaurant_model');
        $this->load->model('restaurant_cuisine_type_model');
        $this->load->model('payment_method_model');
        $this->load->model('cities_model');
        if ($this->ion_auth->logged_in()) {
            $user = $this->ion_auth->user()->row();
            $user_id = $user->id;
        } else {
            $user_id = 0;
        }
        $catering = $this->input->post('catering');
        $cuisine = $this->input->post('cuisine');
        $area = $this->input->post('area');
        $page = $this->input->post('page_number');
        $sort_by = $this->input->post('sort_by');
        $free_delivery = $this->input->post('free_delivery');
        $discount_avail = $this->input->post('discount_avail');
        $has_promotions = $this->input->post('has_promotions');
        $cod_avail = $this->input->post('cod_avail');
        $split_avail = $this->input->post('split_avail');
        $open_rest = $this->input->post('openrest');
        $rating = $this->input->post('rating');
        $min_price = $this->input->post('min_price');
        $max_price = $this->input->post('max_price');
        $search_term = $this->input->post('search_term');
        $filter['catering'] = isset($catering) && !empty($catering) ? $catering : null;
        $filter['cuisine'] = isset($cuisine) && !empty($cuisine) ? $cuisine : null;
        $filter['area'] = isset($area) && !empty($area) ? $area : null;
        $filter['sort_by'] = isset($sort_by) && !empty($sort_by) ? $sort_by : null;
        $filter['free_delivery'] = isset($free_delivery) && !empty($free_delivery) ? $free_delivery : null;
        $filter['discount_avail'] = isset($discount_avail) && !empty($discount_avail) ? $discount_avail : null;
        $filter['has_promotions'] = isset($has_promotions) && !empty($has_promotions) ? $has_promotions : null;
        $filter['cod_avail'] = isset($cod_avail) && !empty($cod_avail) ? $cod_avail : null;
        $filter['split_avail'] = isset($split_avail) && !empty($split_avail) ? $split_avail : null;
        $filter['openrest'] = isset($open_rest) && !empty($open_rest) ? $open_rest : null;
        $filter['rating'] = isset($rating) && !empty($rating) ? $rating : null;
        $filter['min_price'] = isset($min_price) && !empty($min_price) ? $min_price : null;
        $filter['max_price'] = isset($max_price) && !empty($max_price) ? $max_price : null;
        $filter['search_term'] = isset($search_term) && !empty($search_term) ? $search_term : null;
        $page = isset($page) && !empty($page) ? $page : 0;
        $result_per_page = 10;
        $restaurants = $this->restaurant_model->restaurant_search($filter, $result_per_page, $result_per_page * $page, $user_id);
        if (isset($area)) {
            $selected_area = $this->cities_model->get_by_id($area);
        }

        if (isset($restaurants['results'])) {
            foreach ($restaurants['results'] as $restau) {
                if (isset($restau->payment_methods) && !empty($restau->payment_methods)) {
                    $restau->payment_methods = $this->payment_method_model->get_by_ids(explode(',', $restau->payment_methods));
                } else {
                    $restau->payment_methods = null;
                }
                $search_rest[] = $restau;
            }

            $view_data['restaurants'] = $search_rest;
            $data['search_view'] = $this->load->view('util/search_view', $view_data, TRUE);
            $data['total_record'] = $restaurants['totalres'];
            if (isset($selected_area)) {
                $data['result_status'] = "أمر من".$restaurants['totalres']."المطاعم في".$selected_area->city_name;

            } else {
                $data['result_status'] = "أمر من".$restaurants['totalres']."المطاعم";
            }
            $data['has_more'] = $restaurants['has_more'];
        } else {
            $data['total_record'] = 0;
            $data['has_more'] = false;
            $data['result_status'] = "لا توجد في مطاعم".$selected_area->city_name;

        }

        print_r(json_encode($data));
    }

    function my_account()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $this->load->model('address_type_model');
            $this->load->model('transaction_model');
            $this->load->model('transaction_detail_model');
            $this->load->model('restaurant_comments_model');
            $this->load->model('user_fav_items_model');
            $this->load->model('user_fav_restaurant_model');
            $this->load->model('user_points_model');
            $this->load->model('cities_model');
            $this->load->model('payment_method_model');
            $this->load->model('transaction_item_details_model');
            $data['payment_method_db'] = $this->payment_method_model->get_payment_images();

            $data['user_info'] = $this->ion_auth->user()->row();
            $data['change_pas_check'] = $data['user_info']->social_link;
            $data['address_type'] = $this->address_type_model->get_all();
            $data['address_info'] = $this->user_addresses_model->get_all_by_user_id($data['user_info']->id);
            $data['cities'] = $this->cities_model->get_all();
            $today = date('l');
            $order_history = $this->transaction_model->get_user_order_history_new($data['user_info']->id);
            if (isset($order_history)) {
                $orders = $this->transaction_model->get_by_order_id_new($order_history[0]['order_id'], $today);
                foreach ($orders as $order) {
                    $restaurant_rating = $this->restaurant_comments_model->get_restaurant_rating_by_id($order->rest_id);
                    $order->rating = $restaurant_rating->rating;
                    $order->rating_count = $restaurant_rating->total_rating;
                    $order->items = $this->transaction_detail_model->get_items_by_trans_id($order->trans_id);
                    foreach ($order->items as $rowdata) {
                        $items['name'] = $rowdata['name'];
                        $items['price'] = $rowdata['price'];
                        $items['item_quantity'] = $rowdata['item_quantity'];
                        $item_attr_sum = $this->transaction_item_details_model->get_by_detail_id($rowdata['detail_id']);
                        $items['options_name'] = $item_attr_sum->options_name;
                        $items['option_price'] = $item_attr_sum->option_price;
                        $item_with_attr[] = $items;
                    }
                    $order->items_attr = $item_with_attr;
                    unset($item_with_attr);
                    $order_ar[] = $order;
                }
                $data['latest_order'] = $order_ar;
                $data['order_history'] = $order_history;
            } else {
                $data['latest_order'] = null;
                $data['order_history'] = null;
            }
            $data['fav_items'] = $this->user_fav_items_model->get_all_by_user_id($data['user_info']->id);
            $data['fav_restaurant'] = $this->user_fav_restaurant_model->get_all_fav_restaurants_user_id($data['user_info']->id);


            $points = $this->user_points_model->get_user_points($data['user_info']->id);
            $this->load->model('cuisine_type_model');
            $this->load->model('general_setting_model');
            $data['settings'] = $this->general_setting_model->get_setting();
            $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
            $data['user_points'] = $points->points;
            $data['login_url'] = $this->googleplus->loginURL();
            $data['folder_name'] = 'main';
            $data['file_name'] = 'my_account';
            $data['header_name'] = 'header_after';
            $data['nav_name'] = 'nav_main';
            $this->load->view('index', $data);
        } else {
            $this->session->set_flashdata('alert', "الرجاء تسجيل الدخول أولا إلى المضي قدما");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function delete_user_address()
    {

        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $this->load->model('ion_auth_model');
            $address_id = $this->uri->segment(3);
            $logged_user = $this->ion_auth->user()->row();
            $user_id = $logged_user->id;
            $this->user_addresses_model->delete($address_id, $user_id);
            $this->session->set_flashdata('success', "عنوان المحذوفة بنجاح");
            redirect('main/my_account');
        } else {
            $this->session->set_flashdata('alert', "الرجاء تسجيل الدخول أولا إلى المضي قدما");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function change_password()
    {
        if ($this->ion_auth->logged_in()) {
            if (isset($_POST['old_password']) && isset($_POST['new_password'])) {
                $logged_user = $this->ion_auth->user()->row();
                $old = $_POST['old_password'];
                $new = $_POST['new_password'];
                $email = $logged_user->email;
                $identity = $email;
                $change = $this->ion_auth->change_password($identity, $old, $new);
                if ($change) {
                    $this->session->set_flashdata('success', "الرقم السري تغير بنجاح");
                    redirect('main/my_account');
                } else {
                    $this->session->set_flashdata('error', "الرجاء إدخال المعلومات الصحيحة");
                    redirect('main/my_account');
                }
            } else {
                $this->session->set_flashdata('error', "الرجاء إدخال المعلومات الصحيحة");
                redirect('main/my_account');
            }
        } else {
            $this->session->set_flashdata('alert', "الرجاء تسجيل الدخول أولا إلى المضي قدما");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function change_email()
    {
        if ($this->ion_auth->logged_in()) {
            if (isset($_POST['new_email']) && isset($_POST['old_email'])) {
                $logged_user = $this->ion_auth->user()->row();
                $email = $logged_user->email;
                if ($email == $_POST['old_email']) {
                    if ($this->ion_auth->email_check(strtolower($_POST['new_email']))) {
                        $this->session->set_flashdata('error', "البريد الالكتروني موجود بالفعل");
                        redirect('main/my_account');
                    } else {
                        $data['email'] = $_POST['new_email'];
                        if ($this->ion_auth->update($logged_user->id, $data)) {
                            $this->session->set_flashdata('success', "البريد الإلكتروني تغيير بنجاح");
                            redirect('main/my_account');
                        } else {
                            $this->session->set_flashdata('error', "الرجاء إدخال المعلومات الصحيحة");
                            redirect('main/my_account');
                        }
                    }
                } else {
                    $this->session->set_flashdata('error', "الرجاء إدخال المعلومات الصحيحة");
                    redirect('main/my_account');
                }
            } else {
                $this->session->set_flashdata('error', "الرجاء إدخال المعلومات الصحيحة");
                redirect('main/my_account');
            }
        } else {
            $this->session->set_flashdata('alert', "الرجاء تسجيل الدخول أولا إلى المضي قدما");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function add_user_address()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $this->load->model('ion_auth_model');
            $post_data = $this->input->post();
            $logged_user = $this->ion_auth->user()->row();
            $address['user_id'] = $logged_user->user_id;
            $address['type_id'] = (isset($post_data['address_type_id']) && !empty($post_data['address_type_id'])) ? $post_data['address_type_id'] : '';
            $address['area'] = (isset($post_data['city_id']) && !empty($post_data['city_id'])) ? $post_data['city_id'] : '';
            $address['address_title'] = (isset($post_data['address_name']) && !empty($post_data['address_name'])) ? $post_data['address_name'] : '';
            $address['block'] = (isset($post_data['block']) && !empty($post_data['block'])) ? $post_data['block'] : '';
            $address['judda'] = (isset($post_data['judda']) && !empty($post_data['judda'])) ? $post_data['judda'] : '';
            $address['street'] = (isset($post_data['street']) && !empty($post_data['street'])) ? $post_data['street'] : '';
            $address['houseno_name'] = (isset($post_data['office_name']) && !empty($post_data['office_name'])) ? $post_data['office_name'] : '';
            $address['floor'] = (isset($post_data['floor']) && !empty($post_data['floor'])) ? $post_data['floor'] : '';
            $post_data['floor'];
            $address['office_apt'] = (isset($post_data['appartment']) && !empty($post_data['appartment'])) ? $post_data['appartment'] : '';
            $address['extra_direction'] = (isset($post_data['extra_direction']) && !empty($post_data['extra_direction'])) ? $post_data['extra_direction'] : '';
            $this->user_addresses_model->create($address);
            $this->session->set_flashdata('success', "عنوان العضو أضيف بنجاح");
            redirect('main/my_account');
        } else {
            $this->session->set_flashdata('alert', "الرجاء تسجيل الدخول أولا إلى المضي قدما");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function edit_user_address()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $this->load->model('ion_auth_model');
            $post_data = $this->input->post();
            $logged_user = $this->ion_auth->user()->row();
            $address['user_id'] = $logged_user->user_id;
            $id = $post_data['id'];
            $address['type_id'] = (isset($post_data['address_type_id']) && !empty($post_data['address_type_id'])) ? $post_data['address_type_id'] : '';
            $address['area'] = (isset($post_data['city_id']) && !empty($post_data['city_id'])) ? $post_data['city_id'] : '';
            $address['address_title'] = (isset($post_data['address_name']) && !empty($post_data['address_name'])) ? $post_data['address_name'] : '';
            $address['block'] = (isset($post_data['block']) && !empty($post_data['block'])) ? $post_data['block'] : '';
            $address['judda'] = (isset($post_data['judda']) && !empty($post_data['judda'])) ? $post_data['judda'] : '';
            $address['street'] = (isset($post_data['street']) && !empty($post_data['street'])) ? $post_data['street'] : '';
            $address['houseno_name'] = (isset($post_data['office_name']) && !empty($post_data['office_name'])) ? $post_data['office_name'] : '';
            $address['floor'] = (isset($post_data['floor']) && !empty($post_data['floor'])) ? $post_data['floor'] : '';
            $post_data['floor'];
            $address['office_apt'] = (isset($post_data['appartment']) && !empty($post_data['appartment'])) ? $post_data['appartment'] : '';
            $address['extra_direction'] = (isset($post_data['extra_direction']) && !empty($post_data['extra_direction'])) ? $post_data['extra_direction'] : '';
            $this->user_addresses_model->update($id, $address);
            $this->session->set_flashdata('success', "عنوان المستخدم التحديث بنجاح");
            redirect('main/my_account');
        } else {
            $this->session->set_flashdata('alert', "الرجاء تسجيل الدخول لل متابعة");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    function menu($slug)
    {
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('restaurant_menu_model');
        $this->load->model('restaurant_timing_model');
        $this->load->model('banners_model');
        $this->load->model('restaurant_menu_categories_model');
        $this->load->model('payment_method_model');
        $this->load->model('general_setting_model');
        $this->load->model('restaurant_banner_model');

        $restaurant_ids = $this->restaurant_model->get_id_by_slug($slug);
        $restaurant_id = $restaurant_ids->id;

        if ($this->ion_auth->logged_in()) {
            $logged_user = $this->ion_auth->user()->row();
            $user_id = $logged_user->id;
        } else {
            $user_id = 0;
            $this->session->set_userdata('last_page', current_url());
        }
        $restaurant = $this->restaurant_model->get_restaurant_detail_by_id($restaurant_id, $user_id);
        if (isset($restaurant->payment_methods) && !empty($restaurant->payment_methods)) {
            $restaurant->payment_methods = $this->payment_method_model->get_by_ids(explode(',', $restaurant->payment_methods));
        } else {
            $restaurant->payment_methods = null;
        }
        $data['banner_list'] = $this->restaurant_banner_model->get_banners_by_restaurant($restaurant_id);
        $data['restaurant_detail'] = $restaurant;
        $data['restaurant_timing'] = $this->restaurant_timing_model->get_by_id($restaurant_id);
        $data['restaurant_all_comments'] = $this->restaurant_comments_model->get_all_by_id($restaurant_id);
        $data['categories'] = $this->restaurant_menu_categories_model->get_by_restaurant_id($restaurant_id);

        if (isset($data['categories'])) {
            for ($i = 0; $i < sizeof($data['categories']); $i++) {
                $sub[] = $this->restaurant_menu_model->get_categories_items($data['categories'][$i]->category_id, $user_id);
            }
            $data['sub_categories'] = $sub;
        }
        $data['menu_promotions'] = $this->banners_model->get_menu_promotion_banner();
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $cart = $this->prepareCart($this->cart->contents());
        if (isset($cart)) {
            $data['items_count'] = $cart['item_count'];
            $view_data['content'] = $cart['contents'];
            $data['cart_view'] = $this->load->view('util/menu_cart', $view_data, TRUE);
            $data['total_cost'] = $cart['total_cost'];
        }
        $data['slug'] = $slug;
        $data['login_url'] = $this->googleplus->loginURL();
        $data['restaurant_id'] = $restaurant_id;
        $data['folder_name'] = 'main';
        $data['file_name'] = 'menu';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->view('index', $data);
    }

    public function prepareCart($content)
    {
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('user_item_group_attributes_model');
        if (!empty($content)) {
            foreach ($content as $con_data) {
                $ids[] = $con_data['options']['restaurant_id'];
            }
            $restaurant_ids = array_unique($ids);
            $total_bill = 0;
            $cart_item_count = 0;
            foreach ($restaurant_ids as $row) {
                $restaurant = $this->restaurant_model->get_restaurant_detail_by_id($row);
                $resturant_rating = $this->restaurant_comments_model->get_restaurant_rating_by_id($row);
                $restaurant->rating = $resturant_rating->rating;
                $restaurant->total_rating = $resturant_rating->total_rating;

                $total_price = 0;
                foreach ($content as $content_data) {
                    if ($row == $content_data['options']['restaurant_id']) {
                        if ($content_data['id'] != 'voucher') {
                            $options_names = $this->user_item_group_attributes_model->get_by_id($content_data['options']['attribute_ids']);
                            $items['rowid'] = $content_data['rowid'];
                            $items['id'] = $content_data['id'];
                            $items['qty'] = $content_data['qty'];
                            $items['price'] = $content_data['price'];
                            $items['name'] = $content_data['name'];
                            $items['restaurant_id'] = $content_data['options']['restaurant_id'];
                            $items['attributes_name'] = $options_names->options_name;
                            $items['attributes_id'] = $content_data['options']['attribute_ids'];
                            $items['attributes_price'] = $options_names->option_price;
                            $items['subtotal'] = round($content_data['qty'] * ($content_data['price'] + $options_names->option_price), 3);
                            $cart_item[] = $items;
                            $total_price = round($total_price + $items['subtotal'], 3);
                            $cart_item_count++;
                        } else {
                            $has_voucher = TRUE;
                            $voucher_code = $content_data['name'];
                            $voucher_row_id = $content_data['rowid'];
                        }
                    }
                }
                if (isset($cart_item)) {
                    $restaurant->c_items = $cart_item;
                }
                $discount_type = $this->restaurant_model->check_restaurant_discount($row);

                if (isset($has_voucher)) {
                    $vou_discount = $this->restaurant_model->get_voucher_discount($voucher_code);
                    if ($vou_discount->voucher_min_amount <= $total_price) {

                        $restaurant->discount = $vou_discount->discount;
                        $restaurant->discount_type = 'voucher_used';
                        unset($has_voucher);

                    } else {
                        $data = array(
                            'rowid' => $voucher_row_id,
                            'qty' => 0
                        );
                        $this->cart->update($data);
                        $restaurant->discount = 0;
                        $restaurant->discount_type = 'voucher';
                        $data['voucher_status'] = 'discarded';
                        unset($has_voucher);
                    }

                } elseif ($restaurant->discount_type == 'flat') {
                    $restaurant->discount = $discount_type->discount;
                    $restaurant->discount_type = $discount_type->discount_type;
                } else {
                    $restaurant->discount = 0;
                    $restaurant->discount_type = $discount_type->discount_type;
                }

                $discount = $restaurant->discount;

                $restaurant->restaurant_total = $total_price;
                $total_price_discount = $total_price / 100 * $discount;
                $new_total_price = $total_price - $total_price_discount;
                $restaurant->rest_total = round($new_total_price + $restaurant->delivery_charges, 3);
                unset($cart_item);
                $total_bill = round($total_bill + $restaurant->rest_total, 3);
                $rest[] = $restaurant;
                $rest_totals['restaurant_id'] = $row;
                $rest_totals['total'] = $total_price;
                $rest_totals_ar[] = $rest_totals;
            }
            $data['contents'] = $rest;
            $data['subtotal_cost'] = $total_bill;
            $used_points = $this->session->userdata('used_points');
            $used_points = (isset($used_points) && !empty($used_points)) ? $used_points : 0;
            $data['total_cost'] = $total_bill - $used_points;
            $data['restaurant_subtotals'] = $rest_totals_ar;
            $data['item_count'] = $cart_item_count;

            return $data;

        } else {
            return null;
        }

    }

    public function add_restaurant_review($slug)
    {

        if ($this->ion_auth->logged_in()) {
            $this->load->model('restaurant_comments_model');
            $logged_user = $this->ion_auth->user()->row();
            $user_id = $logged_user->id;
            $data['user_id'] = $user_id;
            $data['restaurant_id'] = $this->input->post('restaurant_id');
            $data['comment'] = $this->input->post('review');
            $data['title'] = $this->input->post('title');
            $data['rating'] = $this->input->post('rating');
            $checked = $this->restaurant_comments_model->check_comment_exist($data['user_id'], $data['restaurant_id']);
            if (!empty($checked)) {
                $this->restaurant_comments_model->update($checked->id, $data);
                $this->session->set_flashdata('success', "تم التحديث بنجاح");
            } else {
                $this->restaurant_comments_model->create($data);
                $this->session->set_flashdata('success', "وأضاف بنجاح");
            }
            redirect('restaurant/' . $slug . '');
        } else {
            $this->session->set_flashdata('alert', "الرجاء تسجيل الدخول أولا.");

            redirect('main/login');
        }
    }

    function bookmark_restaurant()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_fav_restaurant_model');
            $restaurant_id = $this->input->post('rest_id');
            $logged_user = $this->ion_auth->user()->row();
            $user_id = $logged_user->id;
            $checked = $this->user_fav_restaurant_model->check_res_bookmark($user_id, $restaurant_id);
            if (isset($checked)) {
                $this->user_fav_restaurant_model->delete($checked->id);
                $data = "Updated";
                echo json_encode($data);
            } else {
                $this->user_fav_restaurant_model->create($user_id, $restaurant_id);
                $data = "Added";
                echo json_encode($data);
            }
        } else {
            $data = "login";
            echo json_encode($data);
        }
    }

    function bookmark_menu_item()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_fav_items_model');
            $item_id = $this->input->post('item_id');
            $logged_user = $this->ion_auth->user()->row();
            $user_id = $logged_user->id;
            $checked = $this->user_fav_items_model->check_item_bookmark($user_id, $item_id);
            if (isset($checked)) {
                $this->user_fav_items_model->delete($checked->id);
                $data = "Updated";
                echo json_encode($data);
            } else {
                $this->user_fav_items_model->create($user_id, $item_id);
                $data = "Added";
                echo json_encode($data);
            }
        } else {
            $data = "login";
            echo json_encode($data);
        }
    }

    function unbookmark_menu_item()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_fav_items_model');
            $item_id = $this->uri->segment(3);
            $logged_user = $this->ion_auth->user()->row();
            $user_id = $logged_user->id;
            $checked = $this->user_fav_items_model->check_item_bookmark($user_id, $item_id);
            if (isset($checked)) {
                $this->user_fav_items_model->delete($checked->id);
                $this->session->set_flashdata('success', "تم التحديث بنجاح");
                redirect('main/my_account');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    function thankyou()
    {
        $this->load->model('general_setting_model');
        $this->load->model('transaction_model');
        $this->load->model('transaction_detail_model');
        $this->load->model('transaction_item_details_model');
        $this->load->model('user_item_group_attributes_model');
        $order_id = $this->input->get('order_id');
        if (!isset($order_id) || empty($order_id)) {
            redirect(404);
        }
        $order_detail = $this->transaction_model->get_confirm_order_details($order_id, date('l'));
        if (isset($order_detail[0]->user_id) && !empty($order_detail[0]->user_id)) {
            $user_details = $this->ion_auth_model->get_user_contact_details($order_detail[0]->user_id, $order_detail[0]->select_address_id);
        } else {

        }
        $item_names = 'Currently Eating';
        $restaurant_names = '';

        if (isset($order_detail) && !empty($order_detail)) {
            $total_bill = 0;
            foreach ($order_detail as $row) {
                $total_bill = $total_bill + $row->subtotal;
                $row->c_items = $this->transaction_detail_model->get_order_items($row->trans_id);
                $rest[] = $row;
            }
            $view_data['restaurant'] = $rest;
            $view_data['user_detail'] = $user_details;
            $data['order_confirm_view'] = $this->load->view('util/order_confirm_view', $view_data, TRUE);
            $data['og_description'] = $item_names . ' From ' . $restaurant_names;
            $data['total_cost'] = $total_bill;
            $data['order_id'] = $order_id;
            $data['points_earned'] = isset($order_detail[0]->point) && !empty($order_detail[0]->point) && $order_detail[0]->point > 0 ? $order_detail[0]->point : 0;

        }

        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();

        $data['folder_name'] = 'main';
        $data['file_name'] = 'thankyou';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $data['login_url'] = $this->googleplus->loginURL();
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function about_us()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'about_us';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $this->load->model('about_us_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['banners'] = $this->banners_model->get_promotion_banner();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();

        $data['abous_us'] = $this->about_us_model->get_all_about_us();
        $data['quick_facts'] = $this->about_us_model->get_all_quick_fact();
        $data['why_lugmah'] = $this->about_us_model->get_all_why_lughma();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function privacy_policy()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'privacy_policy';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $this->load->model('privacy_policy_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['banners'] = $this->banners_model->get_promotion_banner();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['login_url'] = $this->googleplus->loginURL();
        $data['privacy_poloice'] = $this->privacy_policy_model->get_privacy_polocy();
        $data['security_polices_types'] = $this->privacy_policy_model->get_all_policy_type();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();


        $this->load->view('index', $data);
    }

    function feedback()
    {
        if ($this->input->post('add_feedback')) {
            $this->load->model('feedback_model');
            $data = $_POST;

            if (($this->ion_auth->logged_in())) {
                $user_info = $this->ion_auth->user()->row();
                $data['user_id'] = $user_info->id;
                $data['subject'] = (empty($data['subject']) ? NULL : $data['subject']);
                $data['detail'] = (empty($data['detail']) ? NULL : $data['detail']);
                $data['email'] = (empty($data['email']) ? NULL : $data['email']);
                $data['name'] = (empty($data['name']) ? NULL : $data['name']);
                $this->feedback_model->create($data);
                $this->session->set_flashdata('success', "الأقتراحات واضاف بنجاح");
                redirect('main');
            } else {
                $data['user_id'] = NULL;
                $data['subject'] = (empty($data['subject']) ? NULL : $data['subject']);
                $data['detail'] = (empty($data['detail']) ? NULL : $data['detail']);
                $data['email'] = (empty($data['email']) ? NULL : $data['email']);
                $data['name'] = (empty($data['name']) ? NULL : $data['name']);
                $this->feedback_model->create($data);
                $this->session->set_flashdata('success', "الأقتراحات واضاف بنجاح");
                $this->session->set_userdata('last_page', current_url());
                redirect('main');
            }

        }
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['folder_name'] = 'main';
        $data['file_name'] = 'feedback';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $data['login_url'] = $this->googleplus->loginURL();
        $data['banners'] = $this->banners_model->get_promotion_banner();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function faq()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'faq';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $this->load->model('faqs_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['faqs'] = $this->faqs_model->get_all();
        $data['login_url'] = $this->googleplus->loginURL();
        $data['banners'] = $this->banners_model->get_promotion_banner();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function my_favorite()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'my_favorite';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->view('index', $data);
    }

    function track_order()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('transaction_model');
            if ($this->ion_auth->logged_in()) {
                $this->load->model('split_transaction_model');
                $user_info = $this->ion_auth->user()->row();
                $data['order_history'] = $this->transaction_model->get_user_order_history($user_info->id);
                $data['split_payments'] = $this->split_transaction_model->get_active_splits($user_info->id);
            }
            $data['folder_name'] = 'main';
            $this->load->model('cuisine_type_model');
            $this->load->model('banners_model');
            $this->load->model('general_setting_model');
            $data['settings'] = $this->general_setting_model->get_setting();
            $data['banners'] = $this->banners_model->get_promotion_banner();
            $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
            $data['file_name'] = 'track_order';
            $this->load->model('payment_method_model');
            $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
            $data['login_url'] = $this->googleplus->loginURL();
            $this->session->set_userdata('last_page', current_url());
            $data['header_name'] = 'header_after';
            $data['nav_name'] = 'nav_main';
            $this->load->view('index', $data);
        } else {
            $this->load->model('general_setting_model');
            $this->load->model('payment_method_model');
            $data['settings'] = $this->general_setting_model->get_setting();
            $data['folder_name'] = 'main';
            $data['file_name'] = 'track_order';
            $data['message'] = "متاحة فقط لل مستخدم مسجل هذه الميزة .";
            $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
            $data['login_url'] = $this->googleplus->loginURL();
            $this->session->set_userdata('last_page', current_url());
            $data['header_name'] = 'header_after';
            $data['nav_name'] = 'nav_main';
            $this->load->view('index', $data);
        }
    }

    function contact_us()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'contact_us';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['banners'] = $this->banners_model->get_promotion_banner();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function info()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'info';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function reviews()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'reviews';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function add_user_new_address()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $this->load->model('ion_auth_model');
            $post_data = $this->input->post();
            $logged_user = $this->ion_auth->user()->row();
            $address['user_id'] = $logged_user->user_id;
            $address['type_id'] = (isset($post_data['address_type_id']) && !empty($post_data['address_type_id'])) ? $post_data['address_type_id'] : '';
            $address['area'] = (isset($post_data['city_id']) && !empty($post_data['city_id'])) ? $post_data['city_id'] : '';
            $address['address_title'] = (isset($post_data['address_name']) && !empty($post_data['address_name'])) ? $post_data['address_name'] : '';
            $address['block'] = (isset($post_data['block']) && !empty($post_data['block'])) ? $post_data['block'] : '';
            $address['judda'] = (isset($post_data['judda']) && !empty($post_data['judda'])) ? $post_data['judda'] : '';
            $address['street'] = (isset($post_data['street']) && !empty($post_data['street'])) ? $post_data['street'] : '';
            $address['houseno_name'] = (isset($post_data['office_name']) && !empty($post_data['office_name'])) ? $post_data['office_name'] : '';
            $address['floor'] = (isset($post_data['floor']) && !empty($post_data['floor'])) ? $post_data['floor'] : '';
            $post_data['floor'];
            $address['office_apt'] = (isset($post_data['appartment']) && !empty($post_data['appartment'])) ? $post_data['appartment'] : '';
            $address['extra_direction'] = (isset($post_data['extra_direction']) && !empty($post_data['extra_direction'])) ? $post_data['extra_direction'] : '';
            $this->user_addresses_model->create($address);
            $this->session->set_flashdata('success', "عنوان العضو أضيف بنجاح");
            redirect('main/checkout');
        } else {
            $this->session->set_flashdata('message', "الرجاء تسجيل الدخول لل متابعة");
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function checkout()
    {

        if ($this->ion_auth->logged_in()) {
            if ($this->cart->total_items() > 0) {
                $this->load->model('general_setting_model');
                $this->load->model('address_type_model');
                $this->load->model('user_addresses_model');
                $this->load->model('user_points_model');
                $this->load->model('payment_method_model');
                $this->load->model('cities_model');
                $this->load->model('cuisine_type_model');
                $this->load->model('restaurant_coverage_area_model');
                $this->load->model('restaurant_branches_model');

                $data['settings'] = $this->general_setting_model->get_setting();
                $data['folder_name'] = 'main';
                $data['file_name'] = 'checkout';
                $data['header_name'] = 'header_after';
                $data['nav_name'] = 'nav_main';
                $data['login_url'] = $this->googleplus->loginURL();
                $data['address_type'] = $this->address_type_model->get_all();

                $cart = $this->prepareCart($this->cart->contents());
                $view_data['restaurant'] = $cart['contents'];
                $data['cart_view'] = $this->load->view('util/checkout_cart', $view_data, TRUE);

                $data['total_cost'] = $cart['total_cost'];

                if ($this->ion_auth->logged_in()) {
                    $data['user'] = $this->ion_auth->user()->row();
                    $data['address_info'] = $this->user_addresses_model->get_all_by_user_id($data['user']->id);
                    $points = $this->user_points_model->get_user_points($data['user']->id);
                    $data['user_points'] = $points->points;
                }
                $points_view_data['user_points'] = $data['user_points'];
                $data['points_view'] = $this->load->view('util/points_view', $points_view_data, TRUE);

//                $data['coverage'] = $this->restaurant_coverage_area_model->get_by_restaurant_id($cart['restaurant_ids'][0]);
                $data['branches'] = $this->restaurant_branches_model->get_all_by_id($cart['restaurant_subtotals'][0]['restaurant_id']);
                $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
                $data['cities'] = $this->cities_model->get_all();
                $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
                $this->load->view('index', $data);
            } else {
                $this->session->set_flashdata('error', "أي بند في سلة التسوق");
                redirect('main');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function guest_checkout()
    {
        if (!$this->is_logged_in()) {
            if ($this->cart->total_items() > 0) {
                $this->load->model('general_setting_model');
                $this->load->model('address_type_model');
                $this->load->model('user_addresses_model');
                $this->load->model('user_points_model');
                $this->load->model('payment_method_model');
                $this->load->model('cities_model');
                $this->load->model('cuisine_type_model');
                $this->load->model('restaurant_coverage_area_model');
                $this->load->model('restaurant_branches_model');

                $data['settings'] = $this->general_setting_model->get_setting();
                $data['folder_name'] = 'main';
                $data['file_name'] = 'guest_checkout';
                $data['header_name'] = 'header_after';
                $data['nav_name'] = 'nav_main';
                $cart = $this->prepareCart($this->cart->contents());
                $view_data['restaurant'] = $cart['contents'];

                $data['cart_view'] = $this->load->view('util/checkout_cart', $view_data, TRUE);
                $data['total_cost'] = $cart['total_cost'];
                $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
                //            $data['coverage'] = $this->restaurant_coverage_area_model->get_by_restaurant_id($cart['restaurant_ids'][0]);
                $data['branches'] = $this->restaurant_branches_model->get_all_by_id($cart['restaurant_subtotals'][0]['restaurant_id']);
                $data['cities'] = $this->cities_model->get_all();
                $data['login_url'] = $this->googleplus->loginURL();
                $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
                $this->load->view('index', $data);
            } else {
                $this->session->set_flashdata('error', "أي بند في سلة التسوق");
                redirect('main');
            }
        } else {
            redirect();
        }
    }

    function is_logged_in()
    {
        $user_id = $this->session->userdata('user_id');
        if ($user_id != '' && $user_id != null) {
            return true;
        } else {
            return false;
        }
    }

    public function guest_checkout_new()
    {
        $this->load->model('transaction_model');
        $this->load->model('transaction_detail_model');
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('restaurant_coverage_area_model');
        $this->load->model('user_item_group_attributes_model');
        $this->load->model('transaction_item_details_model');
        if ($this->cart->total_items() > 0) {

            $payment_method_id = $this->input->post('payment_method_id');
            $pickup_address_id = $this->input->post('pickup_address_id');
            $delivery_pickup = $this->input->post('delivery_pickup');
            $order_time = $this->input->post('order_time');
            $order_id = base64_encode(mcrypt_create_iv("12", MCRYPT_DEV_URANDOM));
            $cart = $this->prepareCart($this->cart->contents());
            foreach ($cart['contents'] as $key) {

                if ($order_time == 1) {
                    $delivery_pickup_time = $this->input->post('delivery_pickup_time');
                } else {
                    $delivery_pickup_time = $key->delivery_time;
                }
                if ($delivery_pickup == 0) {
                    $restaurant_total = $key->totalbill + $key->delivery_charges;
                } else {
                    $restaurant_total = $key->totalbill - $key->delivery_charges;
                }
                $subtotal = $restaurant_total - $key->discount;
                $trans_data['user_id'] = NULL;
                $trans_data['status'] = '1';
                $trans_data['discount'] = round($key->discount, 2);
                $trans_data['total_amount'] = round($key->totalbill, 3);
                $trans_data['delivery_charges'] = $key->delivery_charges;
                $trans_data['select_address_id'] = NULL;
                $trans_data['paymant_method_id'] = $payment_method_id;
                $trans_data['delivery_pickup'] = $delivery_pickup;
                $trans_data['delivery_pickup_time'] = (empty($delivery_pickup_time) ? NULL : $delivery_pickup_time);
                $trans_data['pickup_address_id'] = (empty($pickup_address_id) ? NULL : $pickup_address_id);
                $trans_data['subtotal'] = round($subtotal, 3);
                $trans_data['points_used'] = 0;
                $trans_data['order_id'] = $order_id;
                $trans_data['restaurant_id'] = $key->id;
                $t_id = $this->transaction_model->create_new($trans_data);
                foreach ($key->c_items as $item) {
                    $trans_details['transaction_id'] = $t_id;
                    $trans_details['item_id'] = $item['id'];
                    $trans_details['item_quantity'] = $item['qty'];
                    $td_id = $this->transaction_detail_model->create($trans_details);
                    $attribute_ids = $item['attributes_id'];
                    if (!empty($attribute_ids)) {
                        $attr_id = explode(',', $attribute_ids);
                        foreach ($attr_id as $trans_attr) {
                            $trans_attr_details['trans_detail_id'] = $td_id;
                            $trans_attr_details['item_attribute_id'] = $trans_attr;
                            $this->transaction_item_details_model->create($trans_attr_details);
                        }
                    }
                }
            }
            $name = $this->input->post('name');
            $address = $this->input->post('address');
            $contact_no = $this->input->post('contact_no');
            $email = $this->input->post('email');
            $other_info = $this->input->post('other_info');
            $guest_id = $this->transaction_model->create_guest(array(
                'name' => $name,
                'address' => $address,
                'contact_no' => $contact_no,
                'email' => $email,
                'other_info' => $other_info
            ));
            $this->transaction_model->create_guest_details(array(
                'guest_id' => $guest_id,
                'order_id' => $order_id
            ));
            $this->cart->destroy();
            redirect('main/thankyou?order_id=' . urlencode($order_id) . '');
        } else {
            $this->session->set_flashdata('error', "أي بند في سلة التسوق");
            redirect('main/login');
        }

    }

    public function checkout_new()
    {

        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $this->load->model('restaurant_model');
            $this->load->model('restaurant_comments_model');
            $this->load->model('cities_model');
            $this->load->model('user_points_model');
            $this->load->model('restaurant_coverage_area_model');
            $this->load->model('transaction_model');
            $this->load->model('transaction_detail_model');
            $this->load->model('user_item_group_attributes_model');
            $this->load->model('transaction_item_details_model');

            $cart = $this->prepareCart($this->cart->contents());


            if (sizeof($cart) > 0) {

                if ($this->ion_auth->logged_in()) {
                    $data['user'] = $this->ion_auth->user()->row();
                    $data['address_info'] = $this->user_addresses_model->get_all_by_user_id($data['user']->id);
                    $points = $this->user_points_model->get_user_points($data['user']->id);
                    $data['user_points'] = $points->points;
                }
                $select_address_ids = $this->input->post('select_address_id');
                if (!empty($select_address_ids)) {
                    $select_address_id = $select_address_ids;
                    $payment_method_id = $this->input->post('payment_method_id');
                    $points_used = $this->input->post('points_used');
                    $pickup_address_id = $this->input->post('pickup_address_id');
                    $delivery_pickup = $this->input->post('delivery_pickup');
                    $order_time = $this->input->post('order_time');
                    $order_id = base64_encode(mcrypt_create_iv("12", MCRYPT_DEV_URANDOM));
                    foreach ($cart['contents'] as $key) {
                        if ($order_time == 1) {
                            $delivery_pickup_time = $this->input->post('delivery_pickup_time');
                        } else {
                            $delivery_pickup_time = $key->delivery_time;
                        }
                        if ($delivery_pickup == 0) {
                            $restaurant_total = $key->rest_total;
                        } else {
                            $restaurant_total = $key->rest_total - $key->delivery_charges;
                        }
                        $subtotal = $restaurant_total;
                        $trans_data['user_id'] = $data['user']->id;
                        $trans_data['status'] = '1';
                        if ($key->discount_type = 'flat' || $key->discount_type = 'voucher_used') {
                            $trans_data['discount'] = round($key->discount, 2);
                        } else {
                            $trans_data['discount'] = 0;
                        }
                        $trans_data['total_amount'] = $key->restaurant_total;
                        $trans_data['delivery_charges'] = $key->delivery_charges;
                        $trans_data['select_address_id'] = $select_address_id;
                        $trans_data['paymant_method_id'] = $payment_method_id;
                        $trans_data['delivery_pickup'] = $delivery_pickup;
                        $trans_data['delivery_pickup_time'] = (empty($delivery_pickup_time) ? NULL : $delivery_pickup_time);
                        $trans_data['pickup_address_id'] = (empty($pickup_address_id) ? NULL : $pickup_address_id);
                        $trans_data['subtotal'] = $key->rest_total;
                        $used_points = $this->session->userdata('used_points');
                        $trans_data['points_used'] = (isset($used_points) && !empty($used_points)) ? $used_points : 0;
                        $trans_data['order_id'] = $order_id;
                        $trans_data['restaurant_id'] = $key->id;
                        $t_id = $this->transaction_model->create_new($trans_data);
                        foreach ($key->c_items as $item) {
                            $trans_details['transaction_id'] = $t_id;
                            $trans_details['item_id'] = $item['id'];
                            $trans_details['item_quantity'] = $item['qty'];
                            $td_id = $this->transaction_detail_model->create($trans_details);
                            $attribute_ids = $item['attributes_id'];
                            if (!empty($attribute_ids)) {
                                $attr_id = explode(',', $attribute_ids);
                                foreach ($attr_id as $trans_attr) {
                                    $trans_attr_details['trans_detail_id'] = $td_id;
                                    $trans_attr_details['item_attribute_id'] = $trans_attr;
                                    $this->transaction_item_details_model->create($trans_attr_details);
                                }
                            }
                        }
                    }
                    $use_point = (isset($used_points) && !empty($used_points)) ? $used_points : 0;
                    if ($use_point == '0') {
                        $user_point['user_id'] = $data['user']->id;
                        $user_point['point'] = round($cart['total_cost'] * .1, 2);
                        $user_point['transaction_order_id'] = $order_id;
                        $this->user_points_model->create($user_point);
                    } else {
                        $user_point['user_id'] = $data['user']->id;
                        $user_point['point'] = -($use_point);
                        $user_point['transaction_order_id'] = $order_id;
                        $this->user_points_model->create($user_point);
                    }
                }
                if (!empty($select_address_id)) {
                    $this->cart->destroy();
                    redirect('main/thankyou?order_id=' . urlencode($order_id) . '');
                } else {
                    $this->session->set_flashdata('error', "الرجاء اختيار عنوان");
                    redirect('main/checkout');
                }
            } else {
                $this->session->set_flashdata('error', "أي بند في سلة التسوق");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    function order_history()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'order_history';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('general_setting_model');
        $this->load->model('payment_method_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->view('index', $data);
    }

    function see_all_cuisines()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'see_all_cuisines';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $this->load->model('cities_model');
        $this->load->model('general_setting_model');
        $this->load->model('payment_method_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['login_url'] = $this->googleplus->loginURL();
        $data['cities'] = $this->cities_model->get_all();
        $data['banners'] = $this->banners_model->get_promotion_banner();
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['cuisine_types'] = $this->cuisine_type_model->get_all();
        $this->load->view('index', $data);
    }

    function login()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'login';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function forget_password()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'forgot_password';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->view('index', $data);
    }

    function user_order_history()
    {
        $this->load->model('transaction_model');
        $this->load->model('transaction_detail_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('transaction_item_details_model');
        $logged_user = $this->ion_auth->user()->row();
        $order_id = $this->input->post('order_id');
        $user_id = $logged_user->id;
        $today = date('l');

        $order_detail = $this->transaction_model->get_by_order_id_new($order_id, $today);
        if (isset($order_detail)) {
            foreach ($order_detail as $order) {
                $restaurant_rating = $this->restaurant_comments_model->get_restaurant_rating_by_id($order->rest_id);
                $order->rating = $restaurant_rating->rating;
                $order->rating_count = $restaurant_rating->total_rating;
                $order->items = $this->transaction_detail_model->get_items_by_trans_id($order->trans_id);
                foreach ($order->items as $rowdata) {
                    $items['name'] = $rowdata['name'];
                    $items['price'] = $rowdata['price'];
                    $items['item_quantity'] = $rowdata['item_quantity'];
                    $item_attr_sum = $this->transaction_item_details_model->get_by_detail_id($rowdata['detail_id']);
                    $items['options_name'] = $item_attr_sum->options_name;
                    $items['option_price'] = $item_attr_sum->option_price;
                    $items['total_price_item'] = round($rowdata['item_quantity'] * ($rowdata['price'] + $item_attr_sum->option_price), 3);
                    $item_with_attr[] = $items;
                }
                $order->items_attr = $item_with_attr;
                unset($item_with_attr);
                $order_ar[] = $order;
            }
            $json = $order_ar;
        } else {
            $json = null;
        }
        print_r(json_encode($json));
    }

//    function blog_detail()
//    {
//        $data['folder_name'] = 'main';
//        $data['file_name'] = 'blog_detail';
//        $this->load->model('cuisine_type_model');
//        $this->load->model('general_setting_model');
//        $data['settings'] = $this->general_setting_model->get_setting();
//        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
//        $this->load->model('payment_method_model');
//        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
//        $data['login_url'] = $this->googleplus->loginURL();
//        $this->load->view('index', $data);
//    }
//
//    function blog_listing()
//    {
//        $data['folder_name'] = 'main';
//        $data['file_name'] = 'blog_listing';
//        $this->load->model('cuisine_type_model');
//        $this->load->model('general_setting_model');
//        $data['settings'] = $this->general_setting_model->get_setting();
//        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
//        $this->load->model('payment_method_model');
//        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
//        $data['login_url'] = $this->googleplus->loginURL();
//        $this->load->view('index', $data);
//    }

//    function index_directory()
//    {
//        $this->load->model('payment_method_model');
//        $this->load->model('general_setting_model');
//        $data['settings'] = $this->general_setting_model->get_setting();
//        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
//        $data['folder_name'] = 'main';
//        $data['file_name'] = 'index_directory';
//        $data['login_url'] = $this->googleplus->loginURL();
//        $this->load->view('index', $data);
//    }

    function reorder()
    {
        $this->load->model('transaction_model');
        $this->load->model('transaction_detail_model');
        $this->load->model('transaction_item_details_model');
        $order_id = $this->input->post('order_id');
        $transaction = $this->transaction_model->get_transaction_by_order_id($order_id);
        $i = 0;
        foreach ($transaction as $row) {
            $transaction_id = $row->id;
            $restaurant_id = $row->restaurant_id;
            if (!empty($restaurant_id)) {
                $transitems = $this->transaction_detail_model->get_items_by_trans_id_two($transaction_id);
                foreach ($transitems as $items) {
                    $detail_data = $this->transaction_item_details_model->get_by_detail_id($items['detail_id']);
                    $data = array(
                        'id' => $items['item_id'],
                        'qty' => $items['item_quantity'],
                        'price' => $items['price'],
                        'name' => $items['name'],
                        'options' => array('restaurant_id' => $restaurant_id, 'attribute_ids' => $detail_data->options_ids)
                    );

                    $this->cart->insert($data);
                    $i++;
                }
            }

        }
        $json['status'] = "ok";
        $json['content'] = $this->cart->contents();
        $json['total'] = $this->cart->total();
        $json['count'] = $i;
        print_r(json_encode($json));

    }

    function add_item_to_cart()
    {
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('user_item_group_attributes_model');
        if (isset($_POST['item_id']) && isset($_POST['item_name']) && isset($_POST['item_price'])) {

            $data = array(
                'id' => $_POST['item_id'],
                'qty' => $_POST['item_qty'],
                'price' => $_POST['item_price'],
                'name' => $_POST['item_name'],
                'options' => array('restaurant_id' => $_POST['rest_id'], 'attribute_ids' => $_POST['attribute_ids'])
            );

            $this->cart->insert($data);

            $cart = $this->prepareCart($this->cart->contents());
            if (isset($cart)) {
                $view_data['content'] = $cart['contents'];
                $json['cart_view'] = $this->load->view('util/menu_cart', $view_data, TRUE);
                $json['items_count'] = $cart['item_count'];
                $json['total_cost'] = $cart['total_cost'];
                $json['status'] = 'OK';
            } else {
                $json['status'] = 'NO_ITEMS';
            }
        } else {
            $json['status'] = 'not allowed';
        }
        print_r(json_encode($json));
    }

    function update_cart()
    {
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('user_item_group_attributes_model');
        if (isset($_POST['row_id']) && isset($_POST['qty'])) {
            $data = array(
                'rowid' => $_POST['row_id'],
                'qty' => $_POST['qty']
            );
            $this->cart->update($data);

            $cart = $this->prepareCart($this->cart->contents());


            if (isset($cart)) {
                $view_data['restaurant'] = $cart['contents'];
                $json['cart_view'] = $this->load->view('util/checkout_cart', $view_data, TRUE);
                $json['items_count'] = $cart['item_count'];
                $json['total_cost'] = $cart['total_cost'];
                $json['status'] = 'OK';
                if (isset($cart['voucher_status'])) {
                    $json['msg'] = 'Voucher Discarded. Minimum amount less than required';
                }
            } else {
                $json['status'] = 'NO_ITEMS';
            }

        } else {

            $json['status'] = 'NOT_ALLOWED';
        }
        print_r(json_encode($json));
    }

    function update_menu_cart()
    {
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('user_item_group_attributes_model');
        if (isset($_POST['row_id']) && isset($_POST['qty'])) {
            $data = array(
                'rowid' => $_POST['row_id'],
                'qty' => $_POST['qty']
            );
            $this->cart->update($data);

            $cart = $this->prepareCart($this->cart->contents());


            if (isset($cart)) {
                $view_data['content'] = $cart['contents'];
                $json['cart_view'] = $this->load->view('util/menu_cart', $view_data, TRUE);
                $json['items_count'] = $cart['item_count'];
                $json['total_cost'] = $cart['total_cost'];
                $json['status'] = 'OK';
            } else {
                $json['status'] = 'NO_ITEMS';
            }

        } else {

            $json['status'] = 'NOT_ALLOWED';
        }
        print_r(json_encode($json));
    }

    public function get_item_attributes()
    {
        $this->load->model('restaurant_menu_items_model');
        $item_id = $this->input->post('item_id');
        $group_attrib = '0';
        if (!empty($item_id)) {
            $item_detail = $this->restaurant_menu_items_model->get_by_id($item_id);
            $item_groups = $this->restaurant_menu_items_model->get_item_groups($item_id);
            if (isset($item_groups)) {
                foreach ($item_groups as $group) {
                    $group->attributes = $this->restaurant_menu_items_model->get_item_group_attributes($group->id);
                    if (!empty($group->attributes)) {
                        $group_attrib = '1';
                    }
                    $groups_ar[] = $group;
                }
                $json['item_id'] = $item_id;
                $json['item_name'] = $item_detail->name;
                $json['item_price'] = $item_detail->price;
                $json['item_description'] = $item_detail->description;
                $json['item_options'] = $groups_ar;
                $json['group_attrib'] = $group_attrib;
            } else {
                $json['item_options'] = null;
            }
            print_r(json_encode($json));
        } else {
            die('NOT ALLOWED');
        }
    }

    function get_order_detail_by_id()
    {
        $this->load->model('transaction_model');
        $user_id = $this->session->userdata('user_id');
        $order_id = $this->input->post('order_id');
        $data = $this->transaction_model->get_order_detail_by_id($user_id, $order_id);
        echo json_encode($data);
    }

    public function check_email_exist()
    {
        $user = $this->ion_auth->user()->row();
        $user_email = $user->email;
        $email = $this->input->post('old_email');
        if ($email == $user_email) {


            $this->load->model('ion_auth_model');
            if ($this->ion_auth->email_check(strtolower($email))) {
                $isAvailable = true;
            } else {
                $isAvailable = false;
            }
            echo json_encode(array(
                'valid' => $isAvailable,
            ));
        } else {
            echo json_encode(array(
                'valid' => false,
            ));
        }
    }

    function fblogin($type = null)
    {

        if (isset($_GET['code'])) {
            $this->facebook_ion_auth->login();
            if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
                redirect('', 'refresh');
                exit();
            }
            redirect('main/login');
            // header('main');
        }
    }

    function delete_fav_user_restaurant()
    {
        $this->load->model('user_fav_restaurant_model');
        $fav_id = $this->uri->segment(3);
        $this->user_fav_restaurant_model->delete($fav_id);
        redirect('main/my_account');

    }

    public function check_minimum_order()
    {
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('user_item_group_attributes_model');
        $content = $this->cart->contents();

        if (!empty($content)) {
            foreach ($content as $con_data) {
                $ids[] = $con_data['options']['restaurant_id'];
            }
            $restaurant_ids = array_unique($ids);
            $total_bill = 0;
            foreach ($restaurant_ids as $row) {
                $restaurant = $this->restaurant_model->get_restaurant_detail_by_id($row);
                $resturant_rating = $this->restaurant_comments_model->get_restaurant_rating_by_id($row);
                $restaurant->rating = $resturant_rating->rating;
                $restaurant->total_rating = $resturant_rating->total_rating;
                $total_price = 0;
                foreach ($content as $content_data) {

                    if ($row == $content_data['options']['restaurant_id']) {
                        $options_names = $this->user_item_group_attributes_model->get_by_id($content_data['options']['attribute_ids']);
                        $items['rowid'] = $content_data['rowid'];
                        $items['id'] = $content_data['id'];
                        $items['qty'] = $content_data['qty'];
                        $items['price'] = $content_data['price'];
                        $items['name'] = $content_data['name'];
                        $items['restaurant_id'] = $content_data['options']['restaurant_id'];
                        $items['attributes_id'] = $content_data['options']['attribute_ids'];
                        $items['attributes_name'] = $options_names->options_name;
                        $items['attributes_price'] = $options_names->option_price;
                        $items['subtotal'] = round($content_data['qty'] * ($content_data['price'] + $options_names->option_price), 3);
                        $cart_item[] = $items;
                        $total_price = round($total_price + $items['subtotal'], 3);
                    }
                }
                $restaurant->c_items = $cart_item;
                $discount = $restaurant->discount;
                $restaurant->totalbill = round($total_price, 3);
                $total_price_discount = $total_price / 100 * $discount;
                $restaurant->discount = round($total_price_discount, 3);
                $new_total_price = $total_price - $total_price_discount;
                $restaurant->rest_total = round($new_total_price + $restaurant->delivery_charges, 3);
                unset($cart_item);
                $total_bill = round($total_bill + $restaurant->rest_total, 3);
                $rest[] = $restaurant;
            }

            $data['cart_num'] = sizeof($this->cart->contents());
            $data['content'] = $rest;
            $data['total_cost'] = $total_bill;
            $proceed_result = 0;
            foreach ($rest as $result) {
                $min_order[] = $result->min_order;
                $total[] = $result->rest_total;
                $rest_name[] = $result->name;
            }

            for ($i = 0; $i < sizeof($min_order); $i++) {
                if ($min_order[$i] > $total[$i]) {
                    $proceed_result = 1;
                    $r_name = $rest_name[$i];
                }
            }
            if ($proceed_result == 1) {
                $json['proceed_result'] = 1;
                $json['name'] = $r_name;
            } else {
                $json['proceed_result'] = 0;
            }

        } else {
            $json['proceed_result'] = 2;
        }
        print_r(json_encode($json));

    }

    public function payment_checkout()
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->model('user_addresses_model');
            $this->load->model('restaurant_model');
            $this->load->model('restaurant_comments_model');
            $this->load->model('cities_model');
            $this->load->model('user_points_model');
            $this->load->model('restaurant_coverage_area_model');
            $this->load->model('temp_transaction_model');
            $this->load->model('temp_transaction_detail_model');
            $this->load->model('user_item_group_attributes_model');
            $this->load->model('temp_transaction_item_details_model');
            if (sizeof($this->cart->contents()) != '0') {
                $content = $this->cart->contents();
                if (!empty($content)) {
                    foreach ($content as $con_data) {
                        $ids[] = $con_data['options']['restaurant_id'];
                    }
                    $restaurant_ids = array_unique($ids);
                    $total_bill = 0;
                    foreach ($restaurant_ids as $row) {
                        $restaurant = $this->restaurant_model->get_restaurant_detail_by_id($row);
                        $resturant_rating = $this->restaurant_comments_model->get_restaurant_rating_by_id($row);
                        $restaurant->rating = $resturant_rating->rating;
                        $restaurant->total_rating = $resturant_rating->total_rating;
                        $total_price = 0;
                        foreach ($content as $content_data) {
                            if ($row == $content_data['options']['restaurant_id']) {
                                $options_names = $this->user_item_group_attributes_model->get_by_id($content_data['options']['attribute_ids']);
                                $items['rowid'] = $content_data['rowid'];
                                $items['id'] = $content_data['id'];
                                $items['qty'] = $content_data['qty'];
                                $items['price'] = $content_data['price'];
                                $items['name'] = $content_data['name'];
                                $items['restaurant_id'] = $content_data['options']['restaurant_id'];
                                $items['attributes_id'] = $content_data['options']['attribute_ids'];
                                $items['attributes_name'] = $options_names->options_name;
                                $items['attributes_price'] = $options_names->option_price;
                                $items['subtotal'] = round($content_data['qty'] * ($content_data['price'] + $options_names->option_price), 3);
                                $cart_item[] = $items;
                                $total_price = round($total_price + $items['subtotal'], 3);
                            }
                        }
                        $restaurant->c_items = $cart_item;
                        $discount = $restaurant->discount;
                        $restaurant->totalbill = round($total_price, 3);
                        $total_price_discount = $total_price / 100 * $discount;
                        $restaurant->discount = round($total_price_discount, 3);
                        $new_total_price = $total_price - $total_price_discount;
                        $restaurant->rest_total = round($new_total_price + $restaurant->delivery_charges, 3);
                        unset($cart_item);
                        $total_bill = round($total_bill + $restaurant->rest_total, 3);
                        $rest[] = $restaurant;
                    }

                    $data['restaurant'] = $rest;
                    $data['total_cost'] = $total_bill;
                }
                if ($this->ion_auth->logged_in()) {
                    $data['user'] = $this->ion_auth->user()->row();
                    $data['address_info'] = $this->user_addresses_model->get_all_by_user_id($data['user']->id);
                    $points = $this->user_points_model->get_user_points($data['user']->id);
                    $data['user_points'] = $points->points;
                }
                $select_address_ids = $this->input->post('select_address_id');
                if (!empty($select_address_ids)) {
                    $select_address_id = $select_address_ids;
                    $payment_method_id = $this->input->post('payment_method_id');
                    $points_used = $this->input->post('points_used');
                    $pickup_address_id = $this->input->post('pickup_address_id');
                    $delivery_pickup = $this->input->post('delivery_pickup');
                    $order_time = $this->input->post('order_time');
                    $order_id = base64_encode(mcrypt_create_iv("12", MCRYPT_DEV_URANDOM));
                    foreach ($data['restaurant'] as $key) {
                        if ($order_time == 1) {
                            $delivery_pickup_time = $this->input->post('delivery_pickup_time');
                        } else {
                            $delivery_pickup_time = $key->delivery_time;
                        }
                        if ($delivery_pickup == 0) {
                            $restaurant_total = $key->totalbill + $key->delivery_charges;
                        } else {
                            $restaurant_total = $key->totalbill - $key->delivery_charges;
                        }
                        $subtotal = $restaurant_total - $key->discount;
                        $trans_data['user_id'] = $data['user']->id;
                        $trans_data['status'] = '1';
                        $trans_data['discount'] = round($key->discount, 2);
                        $trans_data['total_amount'] = round($key->totalbill, 3);
                        $trans_data['delivery_charges'] = $key->delivery_charges;
                        $trans_data['select_address_id'] = $select_address_id;
                        $trans_data['paymant_method_id'] = $payment_method_id;
                        $trans_data['delivery_pickup'] = $delivery_pickup;
                        $trans_data['delivery_pickup_time'] = (empty($delivery_pickup_time) ? NULL : $delivery_pickup_time);
                        $trans_data['pickup_address_id'] = (empty($pickup_address_id) ? NULL : $pickup_address_id);
                        $trans_data['subtotal'] = round($subtotal, 3);
                        $trans_data['points_used'] = (empty($points_used) ? 0 : $points_used);
                        $trans_data['order_id'] = $order_id;
                        $trans_data['restaurant_id'] = $key->id;
                        $t_id = $this->temp_transaction_model->create_new($trans_data);
                        foreach ($key->c_items as $item) {
                            $trans_details['transaction_id'] = $t_id;
                            $trans_details['item_id'] = $item['id'];
                            $trans_details['item_quantity'] = $item['qty'];
                            $td_id = $this->temp_transaction_detail_model->create($trans_details);
                            $attribute_ids = $item['attributes_id'];
                            if (!empty($attribute_ids)) {
                                $attr_id = explode(',', $attribute_ids);
                                foreach ($attr_id as $trans_attr) {
                                    $trans_attr_details['trans_detail_id'] = $td_id;
                                    $trans_attr_details['item_attribute_id'] = $trans_attr;
                                    $this->temp_transaction_item_details_model->create($trans_attr_details);
                                }
                            }
                        }
                    }
                    $encode_order_id = urlencode($order_id);
                    $success_url = base_url('main/success_checkout');
                    $error_url = base_url('main/error_checkout');
                    $url = 'http://demo.hesabe.com/authpost';
                    $data = array('MerchantCode' => '642616', 'Amount' => number_format($total_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_order_id);
                    $options = array(
                        'http' => array(
                            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                            'method' => 'POST',
                            'content' => http_build_query($data)
                        )
                    );
                    $context = stream_context_create($options);
                    $result = file_get_contents($url, false, $context);
                    $json = json_decode($result);
                    if ($json->status === 'success') {
                        $token = $json->data->token;
                        $paymenturl = $json->data->paymenturl;
                        $url = $paymenturl . $token;
                        redirect($url);
                    } else {
                        redirect($error_url);
                    }
                } else {
                    $this->session->set_flashdata('error', "الرجاء اختيار عنوان الأولى");
                    redirect('main/checkout');
                }
            } else {
                $this->session->set_flashdata('error', "أي بند في سلة التسوق");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function success_checkout()
    {
        $status = $this->input->get('Status');
        $order_id = urldecode($this->input->get('Variable1'));
        if ($this->ion_auth->logged_in()) {
            if ($status == '1') {
                $this->cart->destroy();
                if (!empty($order_id)) {
                    $this->load->model('user_addresses_model');
                    $this->load->model('restaurant_model');
                    $this->load->model('restaurant_comments_model');
                    $this->load->model('cities_model');
                    $this->load->model('user_points_model');
                    $this->load->model('restaurant_coverage_area_model');
                    $this->load->model('general_setting_model');
                    $this->load->model('transaction_model');
                    $this->load->model('transaction_detail_model');
                    $this->load->model('transaction_item_details_model');
                    $this->load->model('temp_transaction_model');
                    $this->load->model('temp_transaction_detail_model');
                    $this->load->model('temp_transaction_item_details_model');
                    $this->load->model('user_item_group_attributes_model');
                    $total_bill = 0;
                    $order_detail = $this->temp_transaction_model->get_by_order($order_id);
                    $points_used = $order_detail[0]->points_used;
                    $user_id = $order_detail[0]->user_id;

                    if (!empty($order_detail)) {
                        foreach ($order_detail as $order) {
                            $trans_data['user_id'] = $order->user_id;
                            $trans_data['status'] = '1';
                            $trans_data['discount'] = round($order->discount, 3);
                            $trans_data['total_amount'] = round($order->total_amount, 3);
                            $trans_data['delivery_charges'] = $order->delivery_charges;
                            $trans_data['select_address_id'] = $order->select_address_id;
                            $trans_data['paymant_method_id'] = $order->paymant_method_id;
                            $trans_data['delivery_pickup'] = $order->delivery_pickup;
                            $trans_data['delivery_pickup_time'] = (empty($order->delivery_pickup_time) ? NULL : $order->delivery_pickup_time);
                            $trans_data['pickup_address_id'] = (empty($order->pickup_address_id) ? NULL : $order->pickup_address_id);
                            $trans_data['subtotal'] = round($order->subtotal, 3);
                            $trans_data['points_used'] = (empty($order->points_used) ? 0 : $order->points_used);
                            $trans_data['order_id'] = $order_id;
                            $trans_data['restaurant_id'] = $order->restaurant_id;
                            $t_id = $this->transaction_model->create_new($trans_data);
                            $total_bill = $total_bill + $order->subtotal;
                            $order_items = $this->temp_transaction_detail_model->get_by_trans_id($order->id);
                            foreach ($order_items as $item) {
                                $trans_details['transaction_id'] = $t_id;
                                $trans_details['item_id'] = $item->item_id;
                                $trans_details['item_quantity'] = $item->item_quantity;
                                $td_id = $this->transaction_detail_model->create($trans_details);
                                $order_item_attrib = $this->temp_transaction_item_details_model->get_by_trans_detail_id($item->id);
                                foreach ($order_item_attrib as $trans_attr) {
                                    $trans_attr_details['trans_detail_id'] = $td_id;
                                    $trans_attr_details['item_attribute_id'] = $trans_attr->item_attribute_id;
                                    $this->transaction_item_details_model->create($trans_attr_details);
                                }
                                $this->temp_transaction_item_details_model->delete($item->id);
                            }
                            $this->temp_transaction_detail_model->delete($order->id);
                        }
                        $this->temp_transaction_model->delete($order_id);
                        $use_point = (empty($points_used) ? 0 : $points_used);
                        if ($use_point == '0') {
                            $user_point['user_id'] = $user_id;
                            $user_point['point'] = round($total_bill * .1, 2);
                            $user_point['transaction_order_id'] = $order_id;
                            $this->user_points_model->create($user_point);
                        } else {
                            $user_point['user_id'] = $user_id;
                            $user_point['point'] = -($use_point);
                            $user_point['transaction_order_id'] = $order_id;
                            $this->user_points_model->create($user_point);
                        }
                    }
                    if (!empty($order_id)) {
                        redirect('main/thankyou?order_id=' . urlencode($order_id) . '');
                    } else {
                        $this->session->set_flashdata('error', "حدث خطأ ما");
                        redirect('main/checkout');
                    }
                } else {
                    $this->session->set_flashdata('error', "حدث خطأ ما");
                    redirect('main/checkout');
                }
            } else {
                $this->session->set_flashdata('error', "حدث خطأ ما");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function error_checkout()
    {

        $status = $this->input->get('Status');
        $order_refrence = $this->input->get('Variable1');
        $order_id = urldecode($order_refrence);
        if ($this->ion_auth->logged_in()) {
            if ($status == '0') {
                if (!empty($order_id)) {
                    $this->load->model('temp_transaction_model');
                    $this->load->model('temp_transaction_detail_model');
                    $this->load->model('temp_transaction_item_details_model');
                    $order_detail = $this->temp_transaction_model->get_by_order($order_id);
                    if (!empty($order_detail)) {
                        foreach ($order_detail as $order) {
                            $order_items = $this->temp_transaction_detail_model->get_by_trans_id($order->id);
                            foreach ($order_items as $item) {
                                $this->temp_transaction_item_details_model->delete($item->id);
                            }
                            $this->temp_transaction_detail_model->delete($order->id);
                        }
                        $this->temp_transaction_model->delete($order_id);
                    }
                    if (!empty($order_id)) {
                        $this->session->set_flashdata('error', "حدث خطأ ما");
                        redirect('main/checkout');
                    } else {
                        $this->session->set_flashdata('error', "حدث خطأ ما");
                        redirect('main/checkout');
                    }
                } else {
                    $this->session->set_flashdata('error', "حدث خطأ ما");
                    redirect('main/checkout');
                }
            } else {
                $this->session->set_flashdata('error', "حدث خطأ ما");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function guest_payment_checkout()
    {
        $this->load->model('user_addresses_model');
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('cities_model');
        $this->load->model('user_points_model');
        $this->load->model('temp_guests_model');
        $this->load->model('temp_guest_order_details_model');
        $this->load->model('restaurant_coverage_area_model');
        $this->load->model('temp_transaction_model');
        $this->load->model('temp_transaction_detail_model');
        $this->load->model('user_item_group_attributes_model');
        $this->load->model('temp_transaction_item_details_model');
        if (sizeof($this->cart->contents()) != '0') {
            $content = $this->cart->contents();
            if (!empty($content)) {
                foreach ($content as $con_data) {
                    $ids[] = $con_data['options']['restaurant_id'];
                }
                $restaurant_ids = array_unique($ids);
                $total_bill = 0;
                foreach ($restaurant_ids as $row) {
                    $restaurant = $this->restaurant_model->get_restaurant_detail_by_id($row);
                    $resturant_rating = $this->restaurant_comments_model->get_restaurant_rating_by_id($row);
                    $restaurant->rating = $resturant_rating->rating;
                    $restaurant->total_rating = $resturant_rating->total_rating;
                    $total_price = 0;
                    foreach ($content as $content_data) {
                        if ($row == $content_data['options']['restaurant_id']) {
                            $options_names = $this->user_item_group_attributes_model->get_by_id($content_data['options']['attribute_ids']);
                            $items['rowid'] = $content_data['rowid'];
                            $items['id'] = $content_data['id'];
                            $items['qty'] = $content_data['qty'];
                            $items['price'] = $content_data['price'];
                            $items['name'] = $content_data['name'];
                            $items['restaurant_id'] = $content_data['options']['restaurant_id'];
                            $items['attributes_id'] = $content_data['options']['attribute_ids'];
                            $items['attributes_name'] = $options_names->options_name;
                            $items['attributes_price'] = $options_names->option_price;
                            $items['subtotal'] = round($content_data['qty'] * ($content_data['price'] + $options_names->option_price), 3);
                            $cart_item[] = $items;
                            $total_price = round($total_price + $items['subtotal'], 3);
                        }
                    }
                    $restaurant->c_items = $cart_item;
                    $discount = $restaurant->discount;
                    $restaurant->totalbill = round($total_price, 3);
                    $total_price_discount = $total_price / 100 * $discount;
                    $restaurant->discount = round($total_price_discount, 3);
                    $new_total_price = $total_price - $total_price_discount;
                    $restaurant->rest_total = round($new_total_price + $restaurant->delivery_charges, 3);
                    unset($cart_item);
                    $total_bill = round($total_bill + $restaurant->rest_total, 3);
                    $rest[] = $restaurant;
                }

                $data['restaurant'] = $rest;
                $data['total_cost'] = $total_bill;
            }
            $payment_method_id = $this->input->post('payment_method_id');
            $pickup_address_id = $this->input->post('pickup_address_id');
            $delivery_pickup = $this->input->post('delivery_pickup');
            $order_time = $this->input->post('order_time');
            $order_id = base64_encode(mcrypt_create_iv("12", MCRYPT_DEV_URANDOM));
            foreach ($data['restaurant'] as $key) {

                if ($order_time == 1) {
                    $delivery_pickup_time = $this->input->post('delivery_pickup_time');
                } else {
                    $delivery_pickup_time = $key->delivery_time;
                }
                if ($delivery_pickup == 0) {
                    $restaurant_total = $key->totalbill + $key->delivery_charges;
                } else {
                    $restaurant_total = $key->totalbill - $key->delivery_charges;
                }
                $subtotal = $restaurant_total - $key->discount;
                $trans_data['user_id'] = NULL;
                $trans_data['status'] = '1';
                $trans_data['discount'] = round($key->discount, 2);
                $trans_data['total_amount'] = round($key->totalbill, 3);
                $trans_data['delivery_charges'] = $key->delivery_charges;
                $trans_data['select_address_id'] = NULL;
                $trans_data['paymant_method_id'] = $payment_method_id;
                $trans_data['delivery_pickup'] = $delivery_pickup;
                $trans_data['delivery_pickup_time'] = (empty($delivery_pickup_time) ? NULL : $delivery_pickup_time);
                $trans_data['pickup_address_id'] = (empty($pickup_address_id) ? NULL : $pickup_address_id);
                $trans_data['subtotal'] = round($subtotal, 3);
                $trans_data['points_used'] = 0;
                $trans_data['order_id'] = $order_id;
                $trans_data['restaurant_id'] = $key->id;
                $t_id = $this->temp_transaction_model->create_new($trans_data);
                foreach ($key->c_items as $item) {
                    $trans_details['transaction_id'] = $t_id;
                    $trans_details['item_id'] = $item['id'];
                    $trans_details['item_quantity'] = $item['qty'];
                    $td_id = $this->temp_transaction_detail_model->create($trans_details);
                    $attribute_ids = $item['attributes_id'];
                    if (!empty($attribute_ids)) {
                        $attr_id = explode(',', $attribute_ids);
                        foreach ($attr_id as $trans_attr) {
                            $trans_attr_details['trans_detail_id'] = $td_id;
                            $trans_attr_details['item_attribute_id'] = $trans_attr;
                            $this->temp_transaction_item_details_model->create($trans_attr_details);
                        }
                    }
                }
            }
            $name = $this->input->post('name');
            $address = $this->input->post('address');
            $contact_no = $this->input->post('contact_no');
            $email = $this->input->post('email');
            $other_info = $this->input->post('other_info');
            $guest_id = $this->temp_guests_model->create(array(
                'name' => $name,
                'address' => $address,
                'contact_no' => $contact_no,
                'email' => $email,
                'other_info' => $other_info
            ));
            $this->temp_guest_order_details_model->create(array(
                'guest_id' => $guest_id,
                'order_id' => $order_id
            ));
            $new_tot_bill = round($total_bill, 3);
            $encode_order_id = urlencode($order_id);
            $success_url = base_url('main/guest_success_checkout');
            $error_url = base_url('main/guest_error_checkout');
            $url = 'http://demo.hesabe.com/authpost';
            $data = array('MerchantCode' => '642616', 'Amount' => number_format($new_tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_order_id);
            $options = array(
                'http' => array(
                    'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                    'method' => 'POST',
                    'content' => http_build_query($data)
                )
            );
            $context = stream_context_create($options);
            $result = file_get_contents($url, false, $context);
            $json = json_decode($result);
            if ($json->status === 'success') {
                $token = $json->data->token;
                $paymenturl = $json->data->paymenturl;
                $url = $paymenturl . $token;
                redirect($url);
            } else {
                redirect($error_url . '?Variable1=' . $order_id . '');
            }
        } else {
            $this->session->set_flashdata('error', "أي بند في سلة التسوق");
            redirect('main/checkout');
        }
    }

    public function guest_success_checkout()
    {
        $status = $this->input->get('Status');
        $order_refrence = $this->input->get('Variable1');
        $order_id = urldecode($order_refrence);
        if ($status == '1') {
            if (!empty($order_id)) {
                $this->cart->destroy();
                $this->load->model('user_addresses_model');
                $this->load->model('restaurant_model');
                $this->load->model('restaurant_comments_model');
                $this->load->model('cities_model');
                $this->load->model('user_points_model');
                $this->load->model('restaurant_coverage_area_model');
                $this->load->model('general_setting_model');
                $this->load->model('transaction_model');
                $this->load->model('transaction_detail_model');
                $this->load->model('transaction_item_details_model');
                $this->load->model('temp_transaction_model');
                $this->load->model('temp_transaction_detail_model');
                $this->load->model('temp_transaction_item_details_model');
                $this->load->model('user_item_group_attributes_model');
                $this->load->model('temp_guests_model');
                $this->load->model('temp_guest_order_details_model');
                $this->load->model('guests_model');
                $this->load->model('guest_order_details_model');
                $total_bill = 0;
                $order_detail = $this->temp_transaction_model->get_by_order($order_id);
                if (!empty($order_detail)) {
                    foreach ($order_detail as $order) {
                        $trans_data['user_id'] = NULL;
                        $trans_data['status'] = '1';
                        $trans_data['discount'] = round($order->discount, 3);
                        $trans_data['total_amount'] = round($order->total_amount, 3);
                        $trans_data['delivery_charges'] = $order->delivery_charges;
                        $trans_data['select_address_id'] = NULL;
                        $trans_data['paymant_method_id'] = $order->paymant_method_id;
                        $trans_data['delivery_pickup'] = $order->delivery_pickup;
                        $trans_data['delivery_pickup_time'] = (empty($order->delivery_pickup_time) ? NULL : $order->delivery_pickup_time);
                        $trans_data['pickup_address_id'] = (empty($order->pickup_address_id) ? NULL : $order->pickup_address_id);
                        $trans_data['subtotal'] = round($order->subtotal, 3);
                        $trans_data['points_used'] = (empty($order->points_used) ? 0 : $order->points_used);
                        $trans_data['order_id'] = $order_id;
                        $trans_data['restaurant_id'] = $order->restaurant_id;
                        $t_id = $this->transaction_model->create_new($trans_data);
                        $total_bill = $total_bill + $order->subtotal;
                        $order_items = $this->temp_transaction_detail_model->get_by_trans_id($order->id);
                        if (!empty($order_items)) {
                            foreach ($order_items as $item) {
                                $trans_details['transaction_id'] = $t_id;
                                $trans_details['item_id'] = $item->item_id;
                                $trans_details['item_quantity'] = $item->item_quantity;
                                $td_id = $this->transaction_detail_model->create($trans_details);
                                $order_item_attrib = $this->temp_transaction_item_details_model->get_by_trans_detail_id($item->id);
                                if (!empty($order_item_attrib)) {
                                    foreach ($order_item_attrib as $trans_attr) {
                                        $trans_attr_details['trans_detail_id'] = $td_id;
                                        $trans_attr_details['item_attribute_id'] = $trans_attr->item_attribute_id;
                                        $this->transaction_item_details_model->create($trans_attr_details);
                                    }
                                }
                                $this->temp_transaction_item_details_model->delete($item->id);
                            }
                        }
                        $this->temp_transaction_detail_model->delete($order->id);
                    }
                    $temp_guest_detail = $this->temp_guest_order_details_model->get_by_order_id($order_id);
                    $temp_guest = $this->temp_guests_model->get_by_id($temp_guest_detail->guest_id);
                    $guest['name'] = $temp_guest->name;
                    $guest['address'] = $temp_guest->address;
                    $guest['contact_no'] = $temp_guest->contact_no;
                    $guest['email'] = $temp_guest->email;
                    $guest['other_info'] = $temp_guest->other_info;
                    $g_id = $this->transaction_model->create_guest($guest);
                    $guest_detail['guest_id'] = $g_id;
                    $guest_detail['order_id'] = $order_id;
                    $this->transaction_model->create_guest_details($guest_detail);
                    $this->temp_guest_order_details_model->delete($temp_guest_detail->guest_id);
                    $this->temp_guests_model->delete($temp_guest_detail->guest_id);
                    $this->temp_transaction_model->delete($order_id);
                }
                if (!empty($order_id)) {
                    redirect('main/thankyou?order_id=' . urlencode($order_id) . '');
                } else {
                    $this->session->set_flashdata('error', "حدث خطأ ما");
                    redirect('main/guest_checkout');
                }
            } else {
                $this->session->set_flashdata('error', "حدث خطأ ما");
                redirect('main/guest_checkout');
            }
        } else {
            redirect('main/guest_checkout');
        }
    }

    public function guest_error_checkout()
    {

        $status = $this->input->get('Status');
        $order_refrence = $this->input->get('Variable1');
        $order_id = urldecode($order_refrence);
        if (!empty($order_id)) {
            $this->load->model('temp_transaction_model');
            $this->load->model('temp_transaction_detail_model');
            $this->load->model('temp_transaction_item_details_model');
            $this->load->model('temp_guests_model');
            $this->load->model('temp_guest_order_details_model');
            $order_detail = $this->temp_transaction_model->get_by_order($order_id);
            if (!empty($order_detail)) {
                foreach ($order_detail as $order) {
                    $order_items = $this->temp_transaction_detail_model->get_by_trans_id($order->id);
                    foreach ($order_items as $item) {
                        $this->temp_transaction_item_details_model->delete($item->id);
                    }
                    $this->temp_transaction_detail_model->delete($order->id);
                }
                $this->temp_transaction_model->delete($order_id);
                $temp_guest_detail = $this->temp_guest_order_details_model->get_by_order_id($order_id);
                $temp_guest = $this->temp_guests_model->get_by_id($temp_guest_detail->guest_id);
                $this->temp_guests_model->delete($temp_guest_detail->guest_id);
                $this->temp_guest_order_details_model->delete($temp_guest_detail->guest_id);
            }
            if (!empty($order_id)) {
                $this->session->set_flashdata('error', "حدث خطأ ما");
                redirect('main/guest_checkout');
            } else {
                $this->session->set_flashdata('error', "حدث خطأ ما");
                redirect('main/guest_checkout');
            }
        } else {
            $this->session->set_flashdata('error', "حدث خطأ ما");
            redirect('main/guest_checkout');
        }
    }

    function split_payment($split_id = null)
    {
        if ($this->ion_auth->logged_in()) {
            $this->load->library('twilio');
            $this->load->model('split_transaction_model');
            $this->load->model('split_transaction_detail_model');
            $user_info = $this->ion_auth->user()->row();
            if (isset($_POST)) {
                $f_data = $_POST;
                $cart_data['select_address_id'] = $this->input->post('select_address_id');
                $cart_data['payment_method_id'] = $this->input->post('payment_method_id');
                $cart_data['points_used'] = $this->input->post('points_used');
                $cart_data['pickup_address_id'] = $this->input->post('pickup_address_id');
                $cart_data['delivery_pickup'] = $this->input->post('delivery_pickup');
                $cart_data['order_time'] = $this->input->post('order_time');
                $cart_return = $this->create_temp_cart($cart_data);
                if ($cart_return != false) {
                    $cart_id = $cart_return;
                    $split_transaction['cart_id'] = $cart_id;
                    $split_transaction['total_amount'] = $this->input->post('total_amount');
                    $split_id = $this->split_transaction_model->create($split_transaction);
                    $phone_no = $f_data['phone_no'];
                    $price = $f_data['price'];
                    for ($i = 0; $i < sizeof($phone_no); $i++) {
                        $entry[$i]['phone_no'] = $phone_no[$i];
                        $entry[$i]['price'] = $price[$i];
                    }
                    foreach ($entry as $row) {
                        $split_trans_id = base64_encode(mcrypt_create_iv("14", MCRYPT_DEV_URANDOM));
                        $from = '+1 224-334-3232';
                        $to = $row['phone_no'];
                        $s_trans_url = base_url() . 'main/split_transaction_payment?split_transaction_id=' . urlencode($split_trans_id);
                        $message = $s_trans_url;
                        $response = $this->twilio->sms($from, $to, $message);
                        if ($response->IsError) {
                            $split_detail['sms_status'] = '2';
                        } else {
                            $split_detail['sms_status'] = '1';
                        }
                        $split_detail['split_id'] = $split_id;
                        $split_detail['split_trans_id'] = $split_trans_id;
                        $split_detail['amount'] = $row['price'];
                        $split_detail['username_no'] = $row['phone_no'];
                        $this->split_transaction_detail_model->create($split_detail);
                    }
                }
            }
            $admin_detail_data = $this->split_transaction_detail_model->get_by_split_email_id($split_id);
            $tot_bill = round($admin_detail_data[0]->amount, 3);
            $encode_split_trans_id = urlencode($admin_detail_data[0]->split_trans_id);
            $success_url = base_url('main/split_payment_status');
            $error_url = base_url('main/split_payment_status');
            $url = 'http://demo.hesabe.com/authpost';
            $data = array('MerchantCode' => '642616', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
            $options = array(
                'http' => array(
                    'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                    'method' => 'POST',
                    'content' => http_build_query($data)
                )
            );
            $context = stream_context_create($options);
            $result = file_get_contents($url, false, $context);
            $json = json_decode($result);
            if ($json->status === 'success') {
                //$this->cart->destroy();
                $token = $json->data->token;
                $paymenturl = $json->data->paymenturl;
                $url = $paymenturl . $token;
                redirect($url);
            } else {
                $this->session->set_flashdata('error', "حدث خطأ ما");
                redirect('main/split_payment_status?split_transaction_id=' . $admin_detail_data[0]->split_trans_id . '');
            }
            $data['split_data'] = $this->split_transaction_detail_model->get_by_split_id($split_id);
            $this->load->model('general_setting_model');
            $data['settings'] = $this->general_setting_model->get_setting();
            $data['folder_name'] = 'main';
            $data['file_name'] = 'split_after';
            $data['header_name'] = 'header_after';
            $data['nav_name'] = 'nav_main';
            $this->load->model('cuisine_type_model');
            $this->load->model('banners_model');
            $data['login_url'] = $this->googleplus->loginURL();
            $data['banners'] = $this->banners_model->get_promotion_banner();
            $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
            $this->load->model('payment_method_model');
            $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
            $this->load->view('index', $data);
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    public function create_temp_cart($cart_data)
    {
        $this->load->model('user_addresses_model');
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('cities_model');
        $this->load->model('user_points_model');
        $this->load->model('restaurant_coverage_area_model');
        $this->load->model('temp_transaction_model');
        $this->load->model('temp_transaction_detail_model');
        $this->load->model('user_item_group_attributes_model');
        $this->load->model('temp_transaction_item_details_model');
        if (sizeof($this->cart->contents()) != '0') {
            $cart = $this->get_cart_data();
            if ($this->ion_auth->logged_in()) {
                $data['user'] = $this->ion_auth->user()->row();
                $data['address_info'] = $this->user_addresses_model->get_all_by_user_id($data['user']->id);
                $points = $this->user_points_model->get_user_points($data['user']->id);
                $data['user_points'] = $points->points;
            }
            $select_address_ids = $cart_data['select_address_id'];
            if (!empty($select_address_ids)) {
                $select_address_id = $select_address_ids;
                $payment_method_id = $cart_data['payment_method_id'];
                $points_used = $cart_data['points_used'];
                $pickup_address_id = $cart_data['pickup_address_id'];
                $delivery_pickup = $cart_data['delivery_pickup'];
                $order_time = $cart_data['order_time'];
                $order_id = base64_encode(mcrypt_create_iv("12", MCRYPT_DEV_URANDOM));
                foreach ($cart['restaurant'] as $key) {
                    if ($order_time == 1) {
                        $delivery_pickup_time = $this->input->post('delivery_pickup_time');
                    } else {
                        $delivery_pickup_time = $key->delivery_time;
                    }
                    if ($delivery_pickup == 0) {
                        $restaurant_total = $key->totalbill + $key->delivery_charges;
                    } else {
                        $restaurant_total = $key->totalbill - $key->delivery_charges;
                    }
                    $subtotal = $restaurant_total - $key->discount;
                    $trans_data['user_id'] = $data['user']->id;
                    $trans_data['status'] = '1';
                    $trans_data['discount'] = round($key->discount, 2);
                    $trans_data['total_amount'] = round($key->totalbill, 3);
                    $trans_data['delivery_charges'] = $key->delivery_charges;
                    $trans_data['select_address_id'] = $select_address_id;
                    $trans_data['paymant_method_id'] = $payment_method_id;
                    $trans_data['delivery_pickup'] = $delivery_pickup;
                    $trans_data['delivery_pickup_time'] = (empty($delivery_pickup_time) ? NULL : $delivery_pickup_time);
                    $trans_data['pickup_address_id'] = (empty($pickup_address_id) ? NULL : $pickup_address_id);
                    $trans_data['subtotal'] = round($subtotal, 3);
                    $trans_data['points_used'] = (empty($points_used) ? 0 : $points_used);
                    $trans_data['order_id'] = $order_id;
                    $trans_data['restaurant_id'] = $key->id;
                    $t_id = $this->temp_transaction_model->create_new($trans_data);
                    foreach ($key->c_items as $item) {
                        $trans_details['transaction_id'] = $t_id;
                        $trans_details['item_id'] = $item['id'];
                        $trans_details['item_quantity'] = $item['qty'];
                        $td_id = $this->temp_transaction_detail_model->create($trans_details);
                        $attribute_ids = $item['attributes_id'];
                        if (!empty($attribute_ids)) {
                            $attr_id = explode(',', $attribute_ids);
                            foreach ($attr_id as $trans_attr) {
                                $trans_attr_details['trans_detail_id'] = $td_id;
                                $trans_attr_details['item_attribute_id'] = $trans_attr;
                                $this->temp_transaction_item_details_model->create($trans_attr_details);
                            }
                        }
                    }
                }
                $this->cart->destroy();
                return $order_id;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function get_cart_data()
    {
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('user_item_group_attributes_model');
        if (sizeof($this->cart->contents()) != '0') {
            $content = $this->cart->contents();
            if (!empty($content)) {
                foreach ($content as $con_data) {
                    $ids[] = $con_data['options']['restaurant_id'];
                }
                $restaurant_ids = array_unique($ids);
                $total_bill = 0;
                foreach ($restaurant_ids as $row) {
                    $restaurant = $this->restaurant_model->get_restaurant_detail_by_id($row);
                    $resturant_rating = $this->restaurant_comments_model->get_restaurant_rating_by_id($row);
                    $restaurant->rating = $resturant_rating->rating;
                    $restaurant->total_rating = $resturant_rating->total_rating;
                    $total_price = 0;
                    foreach ($content as $content_data) {
                        if ($row == $content_data['options']['restaurant_id']) {
                            $options_names = $this->user_item_group_attributes_model->get_by_id($content_data['options']['attribute_ids']);
                            $items['rowid'] = $content_data['rowid'];
                            $items['id'] = $content_data['id'];
                            $items['qty'] = $content_data['qty'];
                            $items['price'] = $content_data['price'];
                            $items['name'] = $content_data['name'];
                            $items['restaurant_id'] = $content_data['options']['restaurant_id'];
                            $items['attributes_id'] = $content_data['options']['attribute_ids'];
                            $items['attributes_name'] = $options_names->options_name;
                            $items['attributes_price'] = $options_names->option_price;
                            $items['subtotal'] = round($content_data['qty'] * ($content_data['price'] + $options_names->option_price), 3);
                            $cart_item[] = $items;
                            $total_price = round($total_price + $items['subtotal'], 3);
                        }
                    }
                    $restaurant->c_items = $cart_item;
                    $discount = $restaurant->discount;
                    $restaurant->totalbill = round($total_price, 3);
                    $total_price_discount = $total_price / 100 * $discount;
                    $restaurant->discount = round($total_price_discount, 3);
                    $new_total_price = $total_price - $total_price_discount;
                    $restaurant->rest_total = round($new_total_price + $restaurant->delivery_charges, 3);
                    unset($cart_item);
                    $total_bill = round($total_bill + $restaurant->rest_total, 3);
                    $rest[] = $restaurant;
                }
                $data['restaurant'] = $rest;
                $data['total_cost'] = $total_bill;
            }
            return $data;
        }
    }

    public function split_transaction_payment()
    {
        $split_trans_id = $this->input->get('split_transaction_id');
        if (isset($split_trans_id)) {
            $split_status = $this->checkUserSplitStatus($split_trans_id);
            if ($split_status['status'] == 'active') {
                $this->load->model('split_transaction_model');
                $this->load->model('split_transaction_detail_model');
                $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
                $tot_bill = round($split_trans_data->amount, 3);
                $encode_split_trans_id = urlencode($split_trans_id);
                $success_url = base_url('main/split_payment_status');
                $error_url = base_url('main/split_payment_status');
                $url = 'http://demo.hesabe.com/authpost';
                $data = array('MerchantCode' => '642616', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
                $options = array(
                    'http' => array(
                        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                        'method' => 'POST',
                        'content' => http_build_query($data)
                    )
                );
                $context = stream_context_create($options);
                $result = file_get_contents($url, false, $context);
                $json = json_decode($result);
                if ($json->status === 'success') {
                    //$this->cart->destroy();
                    $token = $json->data->token;
                    $paymenturl = $json->data->paymenturl;
                    $url = $paymenturl . $token;
                    redirect($url);
                } else {
                    $this->session->set_flashdata('error', "حدث خطأ ما");
                    redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
                }
            } else if ($split_status['status'] == 'expired') {
                $this->session->set_flashdata('error', "رابط منتهي الصلاحية");
                redirect('main/expired');
            } else if ($split_status['status'] == 'completed') {
                $this->session->set_flashdata('success', "معاملتك أنجزت بالفعل");
                redirect('main');
            } else if ($split_status['status'] == 'pay_admin') {
                $this->load->model('split_transaction_model');
                $this->load->model('split_transaction_detail_model');
                $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
                $tot_bill = round($split_trans_data->amount, 3);
                $encode_split_trans_id = urlencode($split_trans_id);
                $success_url = base_url('main/split_payment_status');
                $error_url = base_url('main/split_payment_status');
                $url = 'http://demo.hesabe.com/authpost';
                $data = array('MerchantCode' => '642616', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
                $options = array(
                    'http' => array(
                        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                        'method' => 'POST',
                        'content' => http_build_query($data)
                    )
                );
                $context = stream_context_create($options);
                $result = file_get_contents($url, false, $context);
                $json = json_decode($result);
                if ($json->status === 'success') {
                    //$this->cart->destroy();
                    $token = $json->data->token;
                    $paymenturl = $json->data->paymenturl;
                    $url = $paymenturl . $token;
                    redirect($url);
                } else {
                    $this->session->set_flashdata('error', "حدث خطأ ما");
                    redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
                }
            } elseif ($split_status['status'] == 'admin_link') {
                $this->load->model('split_transaction_model');
                $this->load->model('split_transaction_detail_model');
                $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
                $tot_bill = round($split_trans_data->amount, 3);
                $encode_split_trans_id = urlencode($split_trans_id);
                $success_url = base_url('main/split_payment_status');
                $error_url = base_url('main/split_payment_status');
                $url = 'http://demo.hesabe.com/authpost';
                $data = array('MerchantCode' => '642616', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
                $options = array(
                    'http' => array(
                        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                        'method' => 'POST',
                        'content' => http_build_query($data)
                    )
                );
                $context = stream_context_create($options);
                $result = file_get_contents($url, false, $context);
                $json = json_decode($result);
                if ($json->status === 'success') {
                    //$this->cart->destroy();
                    $token = $json->data->token;
                    $paymenturl = $json->data->paymenturl;
                    $url = $paymenturl . $token;
                    redirect($url);
                } else {
                    $this->session->set_flashdata('error', "حدث خطأ ما");
                    redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
                }
            } elseif ($split_status['status'] == 'Error: ORDER NOT PLACED') {
                $this->session->set_flashdata('error', "حدث خطأ ما");
                redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
            } elseif ($split_status == 'DB ERROR') {
                $this->session->set_flashdata('error', "حدث خطأ ما");
                redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
            } else {
                $this->session->set_flashdata('error', "حدث خطأ ما");
                redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
            }
        } else {
            redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
        }
    }

    public function checkUserSplitStatus($split_id = null)
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_status = $this->split_transaction_detail_model->get_split_transaction_status($split_id);

        $com_status = $this->split_transaction_detail_model->check_if_complete($split_status->id);

        if ($com_status->val == 0 && $split_status->user_status != 'completed') {
            $cart = $this->split_transaction_model->get_cart_id($split_status->id);
            if ($this->placeOrder($cart->cart_id, 'split,' . $split_status->id, $cart->complete_time)) {
                $this->split_transaction_model->update_split_status($split_status->id, '2');
                $return['status'] = 'completed';
            } else {
                $return['status'] = 'Error: ORDER NOT PLACED';
            }
        } else {

            if ($split_status->user_status == 'exp_split') {

                if ($this->split_transaction_detail_model->expire_split_transaction($split_status->id)) {

                    $return['status'] = 'expired';

                } else {
                    echo 'DB ERROR';
                }

            } else if ($split_status->user_status == 'admin_pay') {
                $admin_link_status = $this->split_transaction_detail_model->check_admin_link($split_status->id);
                if ($admin_link_status->val == 0) {
                    $split_trans_id = base64_encode(mcrypt_create_iv("14", MCRYPT_DEV_URANDOM));

                    $this->split_transaction_detail_model->expire_users_split($split_status->id);
                    $split_admin = $this->split_transaction_detail_model->get_split_admin($split_status->id);

                    $split_detail['split_id'] = $split_status->id;
                    $split_detail['username_no'] = $split_admin->number;
                    $split_detail['amount'] = $com_status->amount;
                    $from = '+1 224-334-3232';
                    $to = $split_admin->number;
                    $s_trans_url = base_url() . 'main/split_transaction_payment?split_transaction_id=' . urlencode($split_trans_id);
                    $message = $s_trans_url;
                    $response = $this->twilio->sms($from, $to, $message);
                    if ($response->IsError) {
                        $split_detail['sms_status'] = '2';
                    } else {
                        $split_detail['sms_status'] = '1';
                    }
                    $split_detail['split_trans_id'] = $split_trans_id;

                    $id = $this->split_transaction_detail_model->create_admin_link($split_detail);
                    $admin_link = $this->split_transaction_detail_model->get_by_id($id);
                    $return['status'] = 'pay_admin';
                    $return['split_id'] = $admin_link->split_trans_id;
                    $return['amount'] = $admin_link->amount;
                    $return['time_remaining'] = $admin_link->time_remaining;

                } else {
                    $user_link = $this->split_transaction_detail_model->get_admin_time_by_split_transaction_id($split_id);
                    $return['status'] = 'admin_link';
                    $return['time_remaining'] = $user_link->time_remaining;
                    $return['users_status'] = $this->split_transaction_detail_model->get_split_user_status($split_status->id);
                }

            } else if ($split_status->user_status == 'active') {
                $user_link = $this->split_transaction_detail_model->get_time_by_split_transaction_id($split_id);
                $return['status'] = 'active';
                $return['users_status'] = $this->split_transaction_detail_model->get_split_user_status($split_status->id);
                $return['time_remaining'] = $user_link->time_remaining;

            } else if ($split_status->user_status == 'completed') {
                $return['status'] = 'completed';

            } else {
                $return['status'] = 'expired';
            }
        }

        return $return;

    }

    public function placeOrder($cart_id, $payment_id, $timestamp)
    {
        if ($cart_id) {

            $this->load->model('transaction_model');
            $this->load->model('transaction_detail_model');
            $this->load->model('transaction_item_details_model');
            $this->load->model('temp_transaction_model');
            $this->load->model('temp_transaction_detail_model');
            $this->load->model('temp_transaction_item_details_model');

            $order_id = base64_encode(mcrypt_create_iv("12", MCRYPT_DEV_URANDOM));
            $total_bill = 0;
            $order_detail = $this->temp_transaction_model->get_by_order($cart_id);
            $points_used = $order_detail[0]->points_used;
            $user_id = $order_detail[0]->user_id;

            if (!empty($order_detail)) {
                foreach ($order_detail as $order) {
                    $trans_data['user_id'] = $user_id;
                    $trans_data['status'] = '1';
                    $trans_data['discount'] = round($order->discount, 3);
                    $trans_data['total_amount'] = round($order->total_amount, 3);
                    $trans_data['delivery_charges'] = $order->delivery_charges;
                    $trans_data['select_address_id'] = $order->select_address_id;
                    $trans_data['paymant_method_id'] = $order->paymant_method_id;
                    $trans_data['delivery_pickup'] = $order->delivery_pickup;
                    $trans_data['delivery_pickup_time'] = (empty($order->delivery_pickup_time) ? "NULL" : $order->delivery_pickup_time);
                    $trans_data['pickup_address_id'] = (empty($order->pickup_address_id) ? NULL : $order->pickup_address_id);
                    $trans_data['subtotal'] = round($order->subtotal, 3);
                    $trans_data['points_used'] = (empty($order->points_used) ? 0 : $order->points_used);
                    $trans_data['order_id'] = $order_id;
                    $trans_data['restaurant_id'] = $order->restaurant_id;
                    $t_id = $this->transaction_model->create($trans_data);
                    $total_bill = $total_bill + $order->subtotal;
                    $order_items = $this->temp_transaction_detail_model->get_by_trans_id($order->id);
                    if (isset($order_items)) {
                        foreach ($order_items as $item) {
                            $trans_details['transaction_id'] = $t_id;
                            $trans_details['item_id'] = $item->item_id;
                            $trans_details['item_quantity'] = $item->item_quantity;
                            $td_id = $this->transaction_detail_model->create($trans_details);
                            $order_item_attrib = $this->temp_transaction_item_details_model->get_by_trans_detail_id($item->id);

                            if (isset($order_item_attrib)) {
                                foreach ($order_item_attrib as $trans_attr) {
                                    $trans_attr_details['trans_detail_id'] = $td_id;
                                    $trans_attr_details['item_attribute_id'] = $trans_attr->item_attribute_id;
                                    $this->transaction_item_details_model->create($trans_attr_details);
                                }
                            }
                        }
                    }
                }

            }

            if (isset($user_id)) {
                $use_point = (empty($points_used) ? 0 : $points_used);
                if ($use_point == '0') {
                    $user_point['user_id'] = $user_id;
                    $user_point['point'] = round($total_bill * .1, 2);
                    $user_point['transaction_order_id'] = $order_id;
                    $this->user_points_model->create($user_point);
                } else {
                    $user_point['user_id'] = $user_id;
                    $user_point['point'] = -($use_point);
                    $user_point['transaction_order_id'] = $order_id;
                    $this->user_points_model->create($user_point);
                }
            }
            if (!isset($user_id)) {
                $guest_detail = $this->temp_transaction_model->get_guest_details($cart_id);
                $guest_id = $this->transaction_model->create_guest($guest_detail);
                $this->transaction_model->create_guest_details(array(
                    'guest_id' => $guest_id,
                    'order_id' => $order_id
                ));
                $this->temp_transaction_model->delete($cart_id);
                $this->temp_transaction_model->delete_guest($guest_detail['id']);
            }


            $json['status'] = 'OK';
            $json['order_id'] = $order_id;

            return true;
        } else {

            return false;
        }
    }

    public function check_splitt_status($split_id)
    {
        $this->load->model('split_transaction_model');
        $split_data = $this->split_transaction_model->get_by_id($split_id);
        if ($split_data->status == '1') {
            return true;
        } else {
            return false;
        }

    }

    public function check_active($start_time)
    {
        $current_time = date("Y-m-d H:i:s");
        $to_time = strtotime($current_time);
        $from_time = strtotime($start_time);
        $minutes_of_trans = round(abs($to_time - $from_time) / 60, 2);
        if ($minutes_of_trans < '45') {
            return 'Active';
        } else {
            return 'Expired';
        }

    }

    public function check_payment_status($trans_detail_id)
    {
        $this->load->model('split_transaction_detail_model');
        $split_trans_data = $this->split_transaction_detail_model->get_by_id($trans_detail_id);
        if ($split_trans_data->completed_time == "" && $split_trans_data->completed_payment_id == "") {
            return true;
        } else {
            return false;
        }

    }

    public function split_transaction_payment_expired()
    {

        $split_trans_id = $this->input->get('split_transaction_id');
        if (isset($split_trans_id)) {
            $this->load->model('split_transaction_model');
            $this->load->model('split_transaction_detail_model');
            $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
            $start_time = $split_trans_data->start_time;
            $check_status = $this->check_active_expired($start_time);
            if ($check_status == '1') {
                $check_payment_status = $this->check_payment_status($split_trans_data->id);
                if ($check_payment_status == true) {
                    $tot_bill = round($split_trans_data->amount, 3);
                    $encode_split_trans_id = urlencode($split_trans_id);
                    $success_url = base_url('main/split_payment_status');
                    $error_url = base_url('main/split_payment_status');
                    $url = 'http://demo.hesabe.com/authpost';
                    $data = array('MerchantCode' => '642616', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
                    $options = array(
                        'http' => array(
                            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                            'method' => 'POST',
                            'content' => http_build_query($data)
                        )
                    );
                    $context = stream_context_create($options);
                    $result = file_get_contents($url, false, $context);
                    $json = json_decode($result);
                    if ($json->status === 'success') {
                        //$this->cart->destroy();
                        $token = $json->data->token;
                        $paymenturl = $json->data->paymenturl;
                        $url = $paymenturl . $token;
                        redirect($url);
                    } else {
                        $this->session->set_flashdata('error', "حدث خطأ ما");
                        redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
                    }
                } else {
                    $this->session->set_flashdata('success', "معاملتك أنجزت بالفعل");
                    redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
                }
            } else {
                redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
            }
        } else {
            redirect('main/split_payment_status?split_transaction_id=' . $split_trans_id . '');
        }
    }

    public function check_active_expired($start_time)
    {
        $current_time = date("Y-m-d H:i:s");
        $to_time = strtotime($current_time);
        $from_time = strtotime($start_time);
        $minutes_of_trans = round(abs($to_time - $from_time) / 60, 2);
        if ($minutes_of_trans < '60') {
            return '1';
        } else {
            return '2';
        }

    }

    function split_payment_status()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_status = $this->input->get('Status');
        $split_trn_id = urldecode($this->input->get('split_transaction_id'));
        if (!empty($split_trn_id)) {
            $split_trans_id = $this->input->get('split_transaction_id');
        } elseif (!empty($split_status)) {
            $split_status = $this->input->get('Status');
            $split_trans = $this->input->get('Variable1');
            $split_trans_id = urldecode($split_trans);
            $payment_id = $this->input->get('PaymentId');
            if ($split_status == '1') {
                $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
                $check_payment_status = $this->check_payment_status($split_trans_data->id);
                if ($check_payment_status == true) {
                    $this->split_transaction_detail_model->update($split_trans_id, $payment_id);
                }
            }
        } else {
            $this->session->set_flashdata('error', "الرجاء استخدام الرابط مرة أخرى ل دفع");
            redirect('main');
        }
        $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
        $data['split_data'] = $this->checkUserSplitStatus($split_trans_id);
        $this->load->model('general_setting_model');
        $data['split_id'] = $split_trans_id;
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['folder_name'] = 'main';
        $data['file_name'] = 'split_after';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $data['login_url'] = $this->googleplus->loginURL();
        $data['banners'] = $this->banners_model->get_promotion_banner();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function split_payment_status_ajax()
    {
        $split_trans_id = $this->input->get('split_id');
        if (isset($split_trans_id)) {
            $json = $this->checkUserSplitStatus($split_trans_id);
        }else{
            $json = null;
        }
        print_r(json_encode($json));
    }

    function split_status()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_id = $this->input->get('split_id');
        $split_data = $this->split_transaction_model->get_by_id($split_id);
        $start_time = $split_data->start_time;
        $check_status2 = $this->check_active_expired($start_time);
        if ($check_status2 == '1') {
            $json['sp_status'] = '1';
        } else {
            $json['sp_status'] = '2';
        }

        print_r(json_encode($json));
    }

    public function place_split_order_expire()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_id = $this->input->get('split_id');
        if ($this->ion_auth->logged_in()) {
            if (isset($split_id)) {
                $split_data = $this->split_transaction_model->get_by_id($split_id);
                $order_id = $split_data->cart_id;
                if (!empty($order_id)) {
                    $this->cart->destroy();
                    $this->load->model('temp_transaction_model');
                    $this->load->model('temp_transaction_detail_model');
                    $this->load->model('temp_transaction_item_details_model');
                    $this->load->model('user_item_group_attributes_model');
                    $order_detail = $this->temp_transaction_model->get_by_order($order_id);
                    if (!empty($order_detail)) {
                        foreach ($order_detail as $order) {
                            $order_items = $this->temp_transaction_detail_model->get_by_trans_id($order->id);
                            foreach ($order_items as $item) {
                                $this->temp_transaction_item_details_model->delete($item->id);
                            }
                            $this->temp_transaction_detail_model->delete($order->id);
                        }
                        $this->temp_transaction_model->delete($order_id);
                        $this->split_transaction_model->update_expire_split($split_id);
                        $this->cart->destroy();
                        $this->session->set_flashdata('error', "دفع الانقسام انتهى");
                        redirect('main');
                    }
                } else {
                    $this->session->set_flashdata('error', "حدث خطأ ما");
                    redirect('main/checkout');
                }
            } else {
                $this->session->set_flashdata('error', "حدث خطأ ما");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_userdata('last_page', current_url());
            redirect('main/login');
        }
    }

    function guest_split_payment($split_id = null)
    {
        $this->load->library('twilio');
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        if (isset($_POST)) {
            $f_data = $_POST;
            $cart_data['name'] = $this->input->post('name');
            $cart_data['contact_no'] = $this->input->post('contact_no');
            $cart_data['address'] = $this->input->post('address');
            $cart_data['email'] = $this->input->post('email');
            $cart_data['other_info'] = $this->input->post('other_info');
            $cart_data['payment_method_id'] = $this->input->post('payment_method_id');
            $cart_data['pickup_address_id'] = $this->input->post('pickup_address_id');
            $cart_data['delivery_pickup'] = $this->input->post('delivery_pickup');
            $cart_data['order_time'] = $this->input->post('order_time');
            $cart_return = $this->create_guest_temp_cart($cart_data);
            if ($cart_return != false) {
                $cart_id = $cart_return;
                $split_transaction['cart_id'] = $cart_id;
                $split_transaction['total_amount'] = $this->input->post('total_amount');
                $split_id = $this->split_transaction_model->create($split_transaction);
                $phone_no = $f_data['phone_no'];
                $price = $f_data['price'];
                for ($i = 0; $i < sizeof($phone_no); $i++) {
                    $entry[$i]['phone_no'] = $phone_no[$i];
                    $entry[$i]['price'] = $price[$i];
                }
                foreach ($entry as $row) {
                    $split_trans_id = base64_encode(mcrypt_create_iv("14", MCRYPT_DEV_URANDOM));
                    $from = '+1 224-334-3232';
                    $to = $row['phone_no'];
                    $s_trans_url = base_url() . 'main/guest_split_transaction_payment?split_transaction_id=' . urlencode($split_trans_id);
                    $message = $s_trans_url;
                    $response = $this->twilio->sms($from, $to, $message);
                    if ($response->IsError) {
                        $split_detail['sms_status'] = '2';
                    } else {
                        $split_detail['sms_status'] = '1';
                    }
                    $split_detail['split_id'] = $split_id;
                    $split_detail['split_trans_id'] = $split_trans_id;
                    $split_detail['amount'] = $row['price'];
                    $split_detail['username_no'] = $row['phone_no'];
                    $this->split_transaction_detail_model->create($split_detail);
                }
            }
        }
        $admin_detail_data = $this->split_transaction_detail_model->get_by_split_email_id($split_id);
        $tot_bill = round($admin_detail_data[0]->amount, 3);
        $encode_split_trans_id = urlencode($admin_detail_data[0]->split_trans_id);
        $success_url = base_url('main/guest_split_payment_status');
        $error_url = base_url('main/guest_split_payment_status');
        $url = 'http://demo.hesabe.com/authpost';
        $data = array('MerchantCode' => '642616', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
        $options = array(
            'http' => array(
                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => http_build_query($data)
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        $json = json_decode($result);
        if ($json->status === 'success') {
            //$this->cart->destroy();
            $token = $json->data->token;
            $paymenturl = $json->data->paymenturl;
            $url = $paymenturl . $token;
            redirect($url);
        } else {
            $this->session->set_flashdata('error', "حدث خطأ ما");
            redirect('main/guest_split_payment_status?split_transaction_id=' . $admin_detail_data[0]->split_trans_id . '');
        }
        $data['split_data'] = $this->split_transaction_detail_model->get_by_split_id($split_id);
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['folder_name'] = 'main';
        $data['file_name'] = 'guest_split_after';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $data['login_url'] = $this->googleplus->loginURL();
        $data['banners'] = $this->banners_model->get_promotion_banner();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    public function create_guest_temp_cart($cart_data)
    {
        $this->load->model('user_addresses_model');
        $this->load->model('restaurant_model');
        $this->load->model('restaurant_comments_model');
        $this->load->model('cities_model');
        $this->load->model('user_points_model');
        $this->load->model('temp_guests_model');
        $this->load->model('temp_guest_order_details_model');
        $this->load->model('restaurant_coverage_area_model');
        $this->load->model('temp_transaction_model');
        $this->load->model('temp_transaction_detail_model');
        $this->load->model('user_item_group_attributes_model');
        $this->load->model('temp_transaction_item_details_model');
        if (sizeof($this->cart->contents()) != '0') {
            $content = $this->cart->contents();
            if (!empty($content)) {
                foreach ($content as $con_data) {
                    $ids[] = $con_data['options']['restaurant_id'];
                }
                $restaurant_ids = array_unique($ids);
                $total_bill = 0;
                foreach ($restaurant_ids as $row) {
                    $restaurant = $this->restaurant_model->get_restaurant_detail_by_id($row);
                    $resturant_rating = $this->restaurant_comments_model->get_restaurant_rating_by_id($row);
                    $restaurant->rating = $resturant_rating->rating;
                    $restaurant->total_rating = $resturant_rating->total_rating;
                    $total_price = 0;
                    foreach ($content as $content_data) {
                        if ($row == $content_data['options']['restaurant_id']) {
                            $options_names = $this->user_item_group_attributes_model->get_by_id($content_data['options']['attribute_ids']);
                            $items['rowid'] = $content_data['rowid'];
                            $items['id'] = $content_data['id'];
                            $items['qty'] = $content_data['qty'];
                            $items['price'] = $content_data['price'];
                            $items['name'] = $content_data['name'];
                            $items['restaurant_id'] = $content_data['options']['restaurant_id'];
                            $items['attributes_id'] = $content_data['options']['attribute_ids'];
                            $items['attributes_name'] = $options_names->options_name;
                            $items['attributes_price'] = $options_names->option_price;
                            $items['subtotal'] = round($content_data['qty'] * ($content_data['price'] + $options_names->option_price), 3);
                            $cart_item[] = $items;
                            $total_price = round($total_price + $items['subtotal'], 3);
                        }
                    }
                    $restaurant->c_items = $cart_item;
                    $discount = $restaurant->discount;
                    $restaurant->totalbill = round($total_price, 3);
                    $total_price_discount = $total_price / 100 * $discount;
                    $restaurant->discount = round($total_price_discount, 3);
                    $new_total_price = $total_price - $total_price_discount;
                    $restaurant->rest_total = round($new_total_price + $restaurant->delivery_charges, 3);
                    unset($cart_item);
                    $total_bill = round($total_bill + $restaurant->rest_total, 3);
                    $rest[] = $restaurant;
                }
                $data['restaurant'] = $rest;
                $data['total_cost'] = $total_bill;
            }
            $payment_method_id = $cart_data['payment_method_id'];
            $pickup_address_id = $cart_data['pickup_address_id'];
            $delivery_pickup = $cart_data['delivery_pickup'];
            $order_time = $cart_data['order_time'];
            $order_id = base64_encode(mcrypt_create_iv("12", MCRYPT_DEV_URANDOM));
            foreach ($data['restaurant'] as $key) {
                if ($order_time == 1) {
                    $delivery_pickup_time = $this->input->post('delivery_pickup_time');
                } else {
                    $delivery_pickup_time = $key->delivery_time;
                }
                if ($delivery_pickup == 0) {
                    $restaurant_total = $key->totalbill + $key->delivery_charges;
                } else {
                    $restaurant_total = $key->totalbill - $key->delivery_charges;
                }
                $subtotal = $restaurant_total - $key->discount;
                $trans_data['user_id'] = NULL;
                $trans_data['status'] = '1';
                $trans_data['discount'] = round($key->discount, 2);
                $trans_data['total_amount'] = round($key->totalbill, 3);
                $trans_data['delivery_charges'] = $key->delivery_charges;
                $trans_data['select_address_id'] = NULL;
                $trans_data['paymant_method_id'] = $payment_method_id;
                $trans_data['delivery_pickup'] = $delivery_pickup;
                $trans_data['delivery_pickup_time'] = (empty($delivery_pickup_time) ? NULL : $delivery_pickup_time);
                $trans_data['pickup_address_id'] = (empty($pickup_address_id) ? NULL : $pickup_address_id);
                $trans_data['subtotal'] = round($subtotal, 3);
                $trans_data['points_used'] = (empty($points_used) ? 0 : $points_used);
                $trans_data['order_id'] = $order_id;
                $trans_data['restaurant_id'] = $key->id;
                $t_id = $this->temp_transaction_model->create_new($trans_data);
                foreach ($key->c_items as $item) {
                    $trans_details['transaction_id'] = $t_id;
                    $trans_details['item_id'] = $item['id'];
                    $trans_details['item_quantity'] = $item['qty'];
                    $td_id = $this->temp_transaction_detail_model->create($trans_details);
                    $attribute_ids = $item['attributes_id'];
                    if (!empty($attribute_ids)) {
                        $attr_id = explode(',', $attribute_ids);
                        foreach ($attr_id as $trans_attr) {
                            $trans_attr_details['trans_detail_id'] = $td_id;
                            $trans_attr_details['item_attribute_id'] = $trans_attr;
                            $this->temp_transaction_item_details_model->create($trans_attr_details);
                        }
                    }
                }
            }
            $name = $cart_data['name'];
            $address = $cart_data['address'];
            $contact_no = $cart_data['contact_no'];
            $email = $cart_data['email'];
            $other_info = $cart_data['other_info'];
            $guest_id = $this->temp_guests_model->create(array(
                'name' => $name,
                'address' => $address,
                'contact_no' => $contact_no,
                'email' => $email,
                'other_info' => $other_info
            ));
            $this->temp_guest_order_details_model->create(array(
                'guest_id' => $guest_id,
                'order_id' => $order_id
            ));
            return $order_id;
        } else {
            return false;
        }
    }

    public function guest_split_transaction_payment()
    {
        $split_trans_id = $this->input->get('split_transaction_id');
        if (isset($split_trans_id)) {
            $this->load->model('split_transaction_model');
            $this->load->model('split_transaction_detail_model');
            $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
            $split_tran_status = $this->check_splitt_status($split_trans_data->split_id);
            if ($split_tran_status == true) {
                $start_time = $split_trans_data->start_time;
                $check_status = $this->check_active($start_time);
                if ($check_status == 'Active') {
                    $check_payment_status = $this->check_payment_status($split_trans_data->id);
                    if ($check_payment_status == true) {
                        $tot_bill = round($split_trans_data->amount, 3);
                        $encode_split_trans_id = urlencode($split_trans_id);
                        $success_url = base_url('main/guest_split_payment_status');
                        $error_url = base_url('main/guest_split_payment_status');
                        $url = 'http://demo.hesabe.com/authpost';
                        $data = array('MerchantCode' => '642616', 'Amount' => number_format($tot_bill, 3), 'SuccessUrl' => $success_url, 'FailureUrl' => $error_url, 'Variable1' => $encode_split_trans_id);
                        $options = array(
                            'http' => array(
                                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                                'method' => 'POST',
                                'content' => http_build_query($data)
                            )
                        );
                        $context = stream_context_create($options);
                        $result = file_get_contents($url, false, $context);
                        $json = json_decode($result);
                        if ($json->status === 'success') {
                            //$this->cart->destroy();
                            $token = $json->data->token;
                            $paymenturl = $json->data->paymenturl;
                            $url = $paymenturl . $token;
                            redirect($url);
                        } else {
                            $this->session->set_flashdata('error', "حدث خطأ ما");
                            redirect('main/guest_split_payment_status?split_transaction_id=' . $split_trans_id . '');
                        }
                    } else {
                        $this->session->set_flashdata('success', "معاملتك أنجزت بالفعل");
                        redirect('main/guest_split_payment_status?split_transaction_id=' . $split_trans_id . '');
                    }
                } else {
                    redirect('main/guest_split_payment_status?split_transaction_id=' . $split_trans_id . '');
                }
            } else {
                $this->session->set_flashdata('error', "رابط منتهي الصلاحية");
                redirect('main/expired');
            }
        } else {
            redirect('main/guest_split_payment_status?split_transaction_id=' . $split_trans_id . '');
        }
    }

    function guest_split_payment_status()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_status = $this->input->get('Status');
        $split_trn_id = urldecode($this->input->get('split_transaction_id'));
        if (!empty($split_trn_id)) {
            $split_trans_id = $this->input->get('split_transaction_id');
        } elseif (!empty($split_status)) {
            $split_status = $this->input->get('Status');
            $split_trans = $this->input->get('Variable1');
            $split_trans_id = urldecode($split_trans);
            $payment_id = $this->input->get('PaymentId');
            if ($split_status == '1') {
                $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
                $check_payment_status = $this->check_payment_status($split_trans_data->id);
                if ($check_payment_status == true) {
                    $this->split_transaction_detail_model->update($split_trans_id, $payment_id);
                }
            }
        } else {
            $this->session->set_flashdata('error', "الرجاء استخدام الرابط مرة أخرى ل دفع");
            redirect('main');
        }
        $split_trans_data = $this->split_transaction_detail_model->get_by_split_trans_id($split_trans_id);
        $data['split_data'] = $this->split_transaction_detail_model->get_by_split_id($split_trans_data->split_id);
        $this->load->model('general_setting_model');
        $data['split_id'] = $split_trans_data->split_id;
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['folder_name'] = 'main';
        $data['file_name'] = 'guest_split_after';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('cuisine_type_model');
        $this->load->model('banners_model');
        $data['login_url'] = $this->googleplus->loginURL();
        $data['banners'] = $this->banners_model->get_promotion_banner();
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $this->load->model('payment_method_model');
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->view('index', $data);
    }

    function guest_split_payment_status_ajax()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_id = $this->input->get('split_id');
        $split_data = $this->split_transaction_detail_model->get_by_split_id($split_id);
        $split_admin = $this->split_transaction_model->get_user_by_split_id($split_id);
        foreach ($split_data as $row) {
            $status_sp['status'] = $row->status;
            $status_sp['username_no'] = $row->username_no;
            $status_sp['split_trans_id'] = $row->split_trans_id;
            $start_time = $row->start_time;
            $split_data_all[] = $status_sp;

        }
        $json['split_data'] = $split_data_all;
        $status_split = $this->split_transaction_detail_model->get_split_status($split_id);
        if (empty($status_split)) {
            $json['status'] = '2';
        } else {
            $json['status'] = '1';
        }

        print_r(json_encode($json));
    }

    public function place_guest_split_order()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_id = $this->input->get('split_id');
        if (isset($split_id)) {
            $split_data = $this->split_transaction_model->get_by_id($split_id);
            $order_id = $split_data->cart_id;
            if (!empty($order_id)) {
                $this->cart->destroy();
                $this->load->model('temp_guests_model');
                $this->load->model('temp_guest_order_details_model');
                $this->load->model('user_addresses_model');
                $this->load->model('restaurant_model');
                $this->load->model('restaurant_comments_model');
                $this->load->model('cities_model');
                $this->load->model('user_points_model');
                $this->load->model('restaurant_coverage_area_model');
                $this->load->model('general_setting_model');
                $this->load->model('transaction_model');
                $this->load->model('transaction_detail_model');
                $this->load->model('transaction_item_details_model');
                $this->load->model('temp_transaction_model');
                $this->load->model('temp_transaction_detail_model');
                $this->load->model('temp_transaction_item_details_model');
                $this->load->model('user_item_group_attributes_model');
                $total_bill = 0;
                $order_detail = $this->temp_transaction_model->get_by_order($order_id);
                $points_used = $order_detail[0]->points_used;

                if (!empty($order_detail)) {
                    foreach ($order_detail as $order) {
                        $trans_data['user_id'] = NULL;
                        $trans_data['status'] = '1';
                        $trans_data['discount'] = round($order->discount, 3);
                        $trans_data['total_amount'] = round($order->total_amount, 3);
                        $trans_data['delivery_charges'] = $order->delivery_charges;
                        $trans_data['select_address_id'] = NULL;
                        $trans_data['paymant_method_id'] = $order->paymant_method_id;
                        $trans_data['delivery_pickup'] = $order->delivery_pickup;
                        $trans_data['delivery_pickup_time'] = (empty($order->delivery_pickup_time) ? NULL : $order->delivery_pickup_time);
                        $trans_data['pickup_address_id'] = (empty($order->pickup_address_id) ? NULL : $order->pickup_address_id);
                        $trans_data['subtotal'] = round($order->subtotal, 3);
                        $trans_data['points_used'] = (empty($order->points_used) ? 0 : $order->points_used);
                        $trans_data['order_id'] = $order_id;
                        $trans_data['restaurant_id'] = $order->restaurant_id;
                        $t_id = $this->transaction_model->create_new($trans_data);
                        $total_bill = $total_bill + $order->subtotal;
                        $order_items = $this->temp_transaction_detail_model->get_by_trans_id($order->id);
                        foreach ($order_items as $item) {
                            $trans_details['transaction_id'] = $t_id;
                            $trans_details['item_id'] = $item->item_id;
                            $trans_details['item_quantity'] = $item->item_quantity;
                            $td_id = $this->transaction_detail_model->create($trans_details);
                            $order_item_attrib = $this->temp_transaction_item_details_model->get_by_trans_detail_id($item->id);
                            foreach ($order_item_attrib as $trans_attr) {
                                $trans_attr_details['trans_detail_id'] = $td_id;
                                $trans_attr_details['item_attribute_id'] = $trans_attr->item_attribute_id;
                                $this->transaction_item_details_model->create($trans_attr_details);
                            }
                            $this->temp_transaction_item_details_model->delete($item->id);
                        }
                        $this->temp_transaction_detail_model->delete($order->id);
                    }
                    $temp_guest_detail = $this->temp_guest_order_details_model->get_by_order_id($order_id);
                    $temp_guest = $this->temp_guests_model->get_by_id($temp_guest_detail->guest_id);
                    $guest['name'] = $temp_guest->name;
                    $guest['address'] = $temp_guest->address;
                    $guest['contact_no'] = $temp_guest->contact_no;
                    $guest['email'] = $temp_guest->email;
                    $guest['other_info'] = $temp_guest->other_info;
                    $g_id = $this->transaction_model->create_guest($guest);
                    $guest_detail['guest_id'] = $g_id;
                    $guest_detail['order_id'] = $order_id;
                    $this->transaction_model->create_guest_details($guest_detail);
                    $this->temp_guest_order_details_model->delete($temp_guest_detail->guest_id);
                    $this->temp_guests_model->delete($temp_guest_detail->guest_id);
                    $this->temp_transaction_model->delete($order_id);
                    $this->split_transaction_model->update_split($split_id);
                    $this->cart->destroy();
                }
                if (!empty($order_id)) {
                    redirect('main/thankyou?order_id=' . urlencode($order_id) . '');
                } else {
                    $this->session->set_flashdata('error', "حدث خطأ ما");
                    redirect('main/guest_checkout');
                }
            } else {
                $this->session->set_flashdata('error', "حدث خطأ ما");
                redirect('main/guest_checkout');
            }
        } else {
            $this->session->set_flashdata('error', "حدث خطأ ما");
            redirect('main/guest_checkout');
        }
    }

    public function place_guest_split_order_expire()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_id = $this->input->get('split_id');
        if (isset($split_id)) {
            $split_data = $this->split_transaction_model->get_by_id($split_id);
            $order_id = $split_data->cart_id;
            if (!empty($order_id)) {
                $this->cart->destroy();
                $this->load->model('temp_transaction_model');
                $this->load->model('temp_transaction_detail_model');
                $this->load->model('temp_transaction_item_details_model');
                $this->load->model('user_item_group_attributes_model');
                $order_detail = $this->temp_transaction_model->get_by_order($order_id);
                if (!empty($order_detail)) {
                    foreach ($order_detail as $order) {
                        $order_items = $this->temp_transaction_detail_model->get_by_trans_id($order->id);
                        foreach ($order_items as $item) {
                            $this->temp_transaction_item_details_model->delete($item->id);
                        }
                        $this->temp_transaction_detail_model->delete($order->id);
                    }
                    $this->temp_transaction_model->delete($order_id);
                    $this->split_transaction_model->update_expire_split($split_id);
                    $this->cart->destroy();
                    $this->session->set_flashdata('error', "دفع الانقسام انتهى");
                    redirect('main');
                }
            } else {
                $this->session->set_flashdata('error', "حدث خطأ ما");
                redirect('main/checkout');
            }
        } else {
            $this->session->set_flashdata('error', "حدث خطأ ما");
            redirect('main/checkout');
        }
    }

    function guest_split_status()
    {
        $this->load->model('split_transaction_model');
        $this->load->model('split_transaction_detail_model');
        $split_id = $this->input->get('split_id');
        $split_data = $this->split_transaction_model->get_by_id($split_id);
        $start_time = $split_data->start_time;
        $check_status = $this->check_active($start_time);
        if ($check_status == 'Active') {
            $json['sp_status'] = '1';
        } else {
            $json['sp_status'] = '2';
        }

        print_r(json_encode($json));
    }

    function expired()
    {
        $data['folder_name'] = 'main';
        $data['file_name'] = 'expired';
        $data['header_name'] = 'header_after';
        $data['nav_name'] = 'nav_main';
        $this->load->model('payment_method_model');
        $this->load->model('general_setting_model');
        $data['settings'] = $this->general_setting_model->get_setting();
        $data['payment_method_db'] = $this->payment_method_model->get_payment_images();
        $this->load->model('cuisine_type_model');
        $data['cuisine_banner'] = $this->cuisine_type_model->get_all_by_limit();
        $data['login_url'] = $this->googleplus->loginURL();
        $this->load->view('index', $data);
    }

    public function get_restaurants_name()
    {
        $this->load->model('restaurant_model');
        if (isset($_GET['term'])) {
            $q = strtolower($_GET['term']);
            $this->restaurant_model->get_restaurant($q);
        }
    }

    public function apply_voucher()
    {

        $this->load->model('restaurant_model');
        $post_code = $this->input->post('voucher_code');
        $voucher_data = explode('|', $post_code);
        $voucher = $this->restaurant_model->check_restaurant_promotion($voucher_data[0], $voucher_data[1]);

        if (isset($voucher)) {
            $min_check = $this->minimumOrderCheck($voucher_data[0], $voucher->minimum_amount);
            if ($min_check) {
                $data = array(
                    'id' => 'voucher',
                    'qty' => '1',
                    'price' => '0',
                    'name' => $voucher_data[1],
                    'options' => array('restaurant_id' => $voucher_data[0], 'attribute_ids' => '')
                );

                $this->cart->insert($data);

                $cart = $this->prepareCart($this->cart->contents());
                if (isset($cart)) {
                    $view_data['restaurant'] = $cart['contents'];
                    $json['cart_view'] = $this->load->view('util/checkout_cart', $view_data, TRUE);
                    $json['items_count'] = $cart['item_count'];
                    $json['total_cost'] = $cart['total_cost'];
                    $json['status'] = 'OK';
                } else {
                    $json['status'] = 'NO_ITEMS';
                }
            } else {
                $json['status'] = 'MIN_ORDER';
            }
        } else {
            $json['status'] = 'NO_VOUCHER';
        }

        print_r(json_encode($json));
    }

    public function minimumOrderCheck($id, $amount)
    {
        $check = FALSE;
        $cart = $this->prepareCart($this->cart->contents());
        foreach ($cart['restaurant_subtotals'] as $total) {
            if ($total['restaurant_id'] == $id && $total['total'] >= $amount) {
                $check = TRUE;
            }
        }
        return $check;
    }

    public function apply_points()
    {

        $this->load->model('user_points_model');
        $points = $this->input->post('points');
        if (isset($points) && !empty($points)) {
            if ($this->ion_auth->logged_in()) {
                $data['user'] = $this->ion_auth->user()->row();
                $points_data = $this->user_points_model->get_user_points($data['user']->id);
                $user_points = $points_data->points;
            }
            if (isset($user_points) && !empty($user_points)) {

                if ($user_points >= $points) {
                    $cart = $this->prepareCart($this->cart->contents());
                    if ($points <= $cart['subtotal_cost']) {
                        $this->session->set_userdata('used_points', $points);
                        $points_view_data['user_points'] = $user_points;
                        $json['points_view'] = $this->load->view('util/points_view', $points_view_data, TRUE);
                        $json['total_cost'] = $cart['subtotal_cost'] - $points;
                        $json['points_used'] = $points;
                        $json['status'] = 'OK';
                    } else {
                        $points = $cart['subtotal_cost'];
                        $this->session->set_userdata('used_points', $points);
                        $points_view_data['user_points'] = $user_points;
                        $json['points_view'] = $this->load->view('util/points_view', $points_view_data, TRUE);
                        $json['total_cost'] = $cart['subtotal_cost'] - $points;
                        $json['points_used'] = $points;
                        $json['status'] = 'OK';
                    }

                } else {
                    $json['status'] = 'NO_POINTS';
                }

            } else {
                $json['status'] = 'ERROR';

            }
            print_r(json_encode($json));
        } else {
            die('NOT_ALLOWED');
        }
    }

    public function clear_points()
    {
        $this->load->model('user_points_model');
        if ($this->ion_auth->logged_in()) {
            $cart = $this->prepareCart($this->cart->contents());
            $data['user'] = $this->ion_auth->user()->row();
            $points_data = $this->user_points_model->get_user_points($data['user']->id);
            $user_points = $points_data->points;
            $this->session->unset_userdata('used_points');
            $points_view_data['user_points'] = $user_points;
            $json['points_view'] = $this->load->view('util/points_view', $points_view_data, TRUE);
            $json['total_cost'] = $cart['subtotal_cost'];
            $json['status'] = 'OK';
        } else {
            $json['status'] = 'ERROR';
        }
        print_r(json_encode($json));

    }

}
