$(document).ready(function () {
    $('#register_user').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            first_name: {
                validators: {
                    notEmpty: {
                        message: 'First name is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z]+$',
                        message: 'Must be Alphabet'
                    },
                    stringLength: {
                        max: 50,
                        message: 'The name must be less than 50 characters long'
                    }
                }
            },
            last_name: {
                validators: {
                    notEmpty: {
                        message: 'Last name is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z]+$',
                        message: 'Must be Alphabet'
                    },
                    stringLength: {
                        max: 50,
                        message: 'The name must be less than 50 characters long'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'Email is required'
                    },
                    emailAddress: {
                        message: 'The value is not a valid email address'
                    }
                }
            },
            mobile_number: {
                validators: {
                    notEmpty: {
                        message: 'Contact number is required'
                    },
                    stringLength: {
                        max: 8,
                        min: 8,
                        message: 'Must be 8 digits'
                    },
                    digits: {
                        message: 'Must be Number'
                    }
                }
            },
            password: {
                validators: {
                    notEmpty: {
                        message: 'Password is required'
                    },
                    stringLength: {
                        min: 6,
                        message: 'Password need to be at least 6 characters'
                    }
                }
            },
            confirm_pass: {
                validators: {
                    notEmpty: {
                        message: 'Confirm Password is required'
                    },
                    identical: {
                        field: 'password',
                        message: 'The password and its confirm are not the same'
                    }
                }
            },
            gender: {
                validators: {
                    notEmpty: {
                        message: 'Gender is required'
                    }
                }
            },
            month: {
                validators: {
                    notEmpty: {
                        message: 'Month is required'
                    }
                }
            },
            day: {
                validators: {
                    notEmpty: {
                        message: 'Day is required'
                    }
                }
            },
            year: {
                validators: {
                    notEmpty: {
                        message: 'Year is required'
                    }
                }
            },
            city_id: {
                validators: {
                    notEmpty: {
                        message: 'Area is required'
                    }
                }
            },
            address_name: {
                validators: {
                    notEmpty: {
                        message: 'Address Name is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'Must be Alpha Numeric'
                    }
                }
            },
            block: {
                validators: {
                    notEmpty: {
                        message: 'Block is required'
                    },
                    integer: {
                        message: 'Block Must be Numeric'
                    }
                }
            },
            judda: {
                validators: {
                    integer: {
                        message: 'Block Must be Numeric'
                    }
                }
            },
            office_name: {
                validators: {
                    notEmpty: {
                        message: 'Number is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'Must be Alpha Numeric'
                    }
                }
            },
            street: {
                validators: {
                    notEmpty: {
                        message: 'Street is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'Must be Alpha Numeric'
                    }
                }
            },
            floor: {
                validators: {
                    notEmpty: {
                        message: 'Floor is required'
                    },
                    integer: {
                        message: 'Floor Must be Numeric'
                    }
                }
            },
            appartment: {
                validators: {
                    notEmpty: {
                        message: 'Apartment is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'Must be Alpha Numeric'
                    }
                }
            },
            terms: {
                validators: {
                    notEmpty: {
                        message: 'Must accept this field'
                    }
                }
            }
        }
    });
    $('#edit_userProfile').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            first_name: {
                validators: {
                    notEmpty: {
                        message: 'First name is required'
                    },
                    stringLength: {
                        max: 20,
                        message: 'The name must be less than 20 characters long'
                    }
                }
            },
            last_name: {
                validators: {
                    notEmpty: {
                        message: 'Last name is required'
                    },
                    stringLength: {
                        max: 20,
                        message: 'The name must be less than 20 characters long'
                    }
                }
            },
            phone: {
                validators: {
                    notEmpty: {
                        message: 'Contact number is required'
                    },
                    stringLength: {
                        max: 8,
                        min: 8,
                        message: 'Must be 8 digits'
                    }
                }
            },
            house_phone: {
                validators: {
                    stringLength: {
                        max: 8,
                        min: 8,
                        message: 'Must be 8 digits'
                    }
                }
            },
            work_phone: {
                validators: {
                    stringLength: {
                        max: 8,
                        min: 8,
                        message: 'Must be 8 digits'
                    }
                }
            },
            gender: {
                validators: {
                    notEmpty: {
                        message: 'Gender is required'
                    }
                }
            },
            month: {
                validators: {
                    notEmpty: {
                        message: 'Month is required'
                    }
                }
            },
            day: {
                validators: {
                    notEmpty: {
                        message: 'Day is required'
                    }
                }
            },
            year: {
                validators: {
                    notEmpty: {
                        message: 'Year is required'
                    }
                }
            }
        }
    });
    $('#edit_address').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            city_id: {
                validators: {
                    notEmpty: {
                        message: 'City is required'
                    }
                }
            },
            address_name: {
                validators: {
                    notEmpty: {
                        message: 'Address Name is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'Must be Alpha Numeric'
                    }
                }
            },
            block: {
                validators: {
                    notEmpty: {
                        message: 'Block is required'
                    },
                    integer: {
                        message: 'Block Must be Numeric'
                    }
                }
            },
            judda: {
                validators: {
                    integer: {
                        message: 'Block Must be Numeric'
                    }
                }
            },
            office_name: {
                validators: {
                    notEmpty: {
                        message: 'Number is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'Must be Alpha Numeric'
                    }
                }
            },
            street: {
                validators: {
                    notEmpty: {
                        message: 'Street is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'Must be Alpha Numeric'
                    }
                }
            },
            floor: {
                validators: {
                    notEmpty: {
                        message: 'Floor is required'
                    },
                    integer: {
                        message: 'Floor Must be Numeric'
                    }
                }
            },
            appartment: {
                validators: {
                    notEmpty: {
                        message: 'Apartment is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'Must be Alpha Numeric'
                    }
                }
            }
        }
    });
    $('#add_address').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            city_id: {
                validators: {
                    notEmpty: {
                        message: 'City is required'
                    }
                }
            },
            address_name: {
                validators: {
                    notEmpty: {
                        message: 'Address Name is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'Must be Alpha Numeric'
                    }
                }
            },
            block: {
                validators: {
                    notEmpty: {
                        message: 'Block is required'
                    },
                    integer: {
                        message: 'Block Must be Numeric'
                    }
                }
            },
            judda: {
                validators: {
                    integer: {
                        message: 'Block Must be Numeric'
                    }
                }
            },
            office_name: {
                validators: {
                    notEmpty: {
                        message: 'Number is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'Must be Alpha Numeric'
                    }
                }
            },
            street: {
                validators: {
                    notEmpty: {
                        message: 'Street is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'Must be Alpha Numeric'
                    }
                }
            },
            floor: {
                validators: {
                    notEmpty: {
                        message: 'Floor is required'
                    },
                    integer: {
                        message: 'Floor Must be Numeric'
                    }
                }
            },
            appartment: {
                validators: {
                    notEmpty: {
                        message: 'Apartment is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z0-9 ]+$',
                        message: 'Must be Alpha Numeric'
                    }
                }
            }
        }
    });

    $('#guest_checkout').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            name: {
                validators: {
                    notEmpty: {
                        message: 'Name is required'
                    },
                    stringLength: {
                        max: 20,
                        message: 'The name must be less than 20 characters long'
                    }
                }
            },
            email: {
                validators: {

                    emailAddress: {
                        message: 'The value is not a valid email address'
                    }
                }
            },
            contact_no: {
                validators: {
                    regexp: {
                        regexp: '^[0-9]*$',
                        message: 'Must be digits'
                    },
                    notEmpty: {
                        message: 'Contact number is required'
                    },
                    stringLength: {
                        max: 8,
                        min: 8,
                        message: 'Must be 8 digits'
                    }
                }
            },
            address: {
                validators: {
                    notEmpty: {
                        message: 'Address is required'
                    }
                }
            }
        }
    });
    $('#checkout').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            select_address_id: {
                validators: {
                    notEmpty: {
                        message: 'Address is required'
                    }
                }
            }
        }
    });
    $('#contact_us').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            name: {
                validators: {
                    notEmpty: {
                        message: 'Name is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z]+$',
                        message: 'Must be Alphabet'
                    },
                    stringLength: {
                        max: 50,
                        message: 'The name must be less than 50 characters long'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'Email is required'
                    },
                    emailAddress: {
                        message: 'The value is not a valid email address'
                    }
                }
            },

            subject: {
                validators: {
                    notEmpty: {
                        message: 'company is required'
                    }
                }
            }

        }
    });
    $('#r_add_feedback').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            name: {
                validators: {
                    notEmpty: {
                        message: 'Name is required'
                    },
                    regexp: {
                        regexp: '^[a-zA-Z]+$',
                        message: 'Must be Alphabet'
                    },
                    stringLength: {
                        max: 50,
                        message: 'The name must be less than 20 characters long'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'Email is required'
                    },
                    emailAddress: {
                        message: 'The value is not a valid email address'
                    }
                }
            },
            subject: {
                validators: {
                    notEmpty: {
                        message: 'Title is required'
                    },
                    stringLength: {

                        max: 60,
                        message: 'The title must be 60 characters '
                    }
                }
            },
            detail: {
                // The messages for this field are shown as usual
                validators: {
                    notEmpty: {
                        message: 'The review is required'
                    },
                    stringLength: {

                        min: 50,
                        message: 'Please make sure your review contains at least 50 characters'
                    }
                }
            }


        }
    });
    $('#reviews_validate').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            title: {
                validators: {
                    notEmpty: {
                        message: 'Title is required'
                    },
                }
            },
            review: {
                validators: {
                    notEmpty: {
                        message: 'Review is required'
                    },
                }
            },
            rating: {
                validators: {
                    notEmpty: {
                        message: ' Ratings required'
                    }
                }
            }


        }
    });
    $('#login').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            email: {
                validators: {
                    notEmpty: {
                        message: 'This Field is required'
                    }
                }
            },
            password: {
                validators: {
                    notEmpty: {
                        message: ' Password is required'
                    }
                }
            }


        }
    });
});